{
  description = "Vitals — native Linux system monitor built on Anomaly Rune";

  inputs.nixpkgs.url = "github:NixOS/nixpkgs/b25309931cfda5f0b8805f462a29897eeae50168";

  outputs =
    { nixpkgs, ... }:
    let
      systems = [
        "x86_64-linux"
        "aarch64-linux"
      ];
      forAllSystems = nixpkgs.lib.genAttrs systems;
      packagesFor =
        system:
        import nixpkgs {
          inherit system;
          config = { };
          overlays = [ ];
        };
      libraries = pkgs: with pkgs; [
        wayland
        libxkbcommon
        vulkan-loader
        mesa
        libGL
        libglvnd
        libx11
        libxcursor
        libxi
        libxrandr
      ];
    in
    {
      packages = forAllSystems (
        system:
        let
          pkgs = packagesFor system;
        in
        {
          runeSource = pkgs.callPackage ./nix/rune-source.nix { };
        }
      );
      devShells = forAllSystems (
        system:
        let
          pkgs = packagesFor system;
          runeSource = pkgs.callPackage ./nix/rune-source.nix { };
        in
        {
          default = pkgs.mkShell {
            packages = with pkgs; [
              cargo
              rustc
              rustfmt
              clippy
              pkg-config
            ];
            buildInputs = libraries pkgs;
            shellHook = ''
              ln -sfnT ${runeSource} "$PWD/.rune-source"
            '';
            LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath (libraries pkgs);
          };
        }
      );
    };
}
