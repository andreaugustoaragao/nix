#!/usr/bin/env bash
# Offline tests, clippy, and headless fixture snapshots for vitals.
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

# Same link `run` and the dev shell create. Headless checks compile the patched
# Rune sources, so the checkout has to exist before Cargo starts.
if [[ ! -f "$root/.rune-source/crates/rune/Cargo.toml" ]]; then
  err="$(mktemp)"
  if ! rune_out="$(nix build --no-link --print-out-paths --no-write-lock-file --offline "$root#runeSource" 2>"$err")"; then
    if ! rune_out="$(nix-build --no-out-link -E "with import <nixpkgs> {}; callPackage $root/nix/rune-source.nix {}" 2>"$err")"; then
      cat "$err" >&2
      rm -f "$err"
      echo "verification failed: could not build nix/rune-source.nix" >&2
      exit 1
    fi
  fi
  rm -f "$err"
  ln -sfnT "$rune_out" "$root/.rune-source"
fi

export WGPU_BACKEND="${WGPU_BACKEND:-gl}"

# True when an existing LD_LIBRARY_PATH entry can load the Vulkan loader.
vulkan_on_ld_library_path() {
  local rest="${LD_LIBRARY_PATH:-}"
  local dir
  while [[ -n "$rest" ]]; do
    dir="${rest%%:*}"
    if [[ "$rest" == *:* ]]; then
      rest="${rest#*:}"
    else
      rest=""
    fi
    if [[ -n "$dir" && -e "${dir}/libvulkan.so.1" ]]; then
      return 0
    fi
  done
  return 1
}

# Headless Rune needs libvulkan.so.1 and the Wayland, xkbcommon, GL, and X11
# libraries that nix develop would put on LD_LIBRARY_PATH. A plain shell often
# has none of them. Resolve one closure from this flake's pinned nixpkgs and
# prepend it. Leave an existing loader path alone.
ensure_vulkan_loader() {
  if vulkan_on_ld_library_path; then
    return 0
  fi
  local nix_libs prefix nix_err
  nix_err="$(mktemp)"
  if ! nix_libs="$(
    nix eval \
      --extra-experimental-features 'nix-command flakes' \
      --no-write-lock-file \
      --offline \
      --impure \
      --raw \
      --expr '
let
  flake = builtins.getFlake (toString ./.);
  system = builtins.currentSystem;
  pkgs = flake.inputs.nixpkgs.legacyPackages.${system};
  names = [
    "vulkan-loader"
    "wayland"
    "libxkbcommon"
    "mesa"
    "libGL"
    "libglvnd"
    "libx11"
    "libxcursor"
    "libxi"
    "libxrandr"
  ];
in pkgs.lib.makeLibraryPath (map (name: pkgs.${name}) names)
' 2>"$nix_err"
  )"; then
    cat "$nix_err" >&2
    rm -f "$nix_err"
    echo "verification failed: could not resolve Nix graphics libraries" >&2
    exit 1
  fi
  rm -f "$nix_err"
  if [[ ! -e "${nix_libs%%:*}/libvulkan.so.1" ]]; then
    echo "verification failed: resolved Nix path has no libvulkan.so.1" >&2
    exit 1
  fi
  prefix="$nix_libs"
  if [[ -n "${LD_LIBRARY_PATH:-}" ]]; then
    export LD_LIBRARY_PATH="${prefix}:${LD_LIBRARY_PATH}"
  else
    export LD_LIBRARY_PATH="${prefix}"
  fi
  echo "prepended Nix graphics libraries onto LD_LIBRARY_PATH"
}

# virgl's EGL/GLES driver is the host Mesa at /run/opengl-driver, even when
# libvulkan.so.1 was already on the path.
ensure_opengl_driver() {
  local driver="/run/opengl-driver/lib"
  if [[ ! -d "$driver" ]]; then
    return 0
  fi
  case ":${LD_LIBRARY_PATH:-}:" in
    *:"$driver":*) return 0 ;;
  esac
  if [[ -n "${LD_LIBRARY_PATH:-}" ]]; then
    export LD_LIBRARY_PATH="${driver}:${LD_LIBRARY_PATH}"
  else
    export LD_LIBRARY_PATH="${driver}"
  fi
  echo "prepended ${driver} onto LD_LIBRARY_PATH"
}

ensure_vulkan_loader
ensure_opengl_driver

cargo build --offline --bin vitals
cargo test --offline
cargo clippy --offline --all-targets -- -D warnings

mkdir -p artifacts

run_app() {
  echo "+ cargo run --offline --bin vitals -- $*"
  cargo run --offline --bin vitals -- "$@"
}

require_nonempty() {
  local path="$1"
  if [[ ! -s "$path" ]]; then
    echo "verification failed: ${path} is missing or empty" >&2
    exit 1
  fi
  echo "ok ${path} ($(wc -c < "$path") bytes)"
}

run_app --fixture --theme dark --scene dark --snap artifacts/vitals-dark.png
run_app --fixture --theme light --scene light --snap artifacts/vitals-light.png
run_app --fixture --theme dark --scene cpu --snap artifacts/vitals-cpu.png
run_app --fixture --theme dark --scene processes --snap artifacts/vitals-processes.png
run_app --fixture --scene dark --tree artifacts/vitals-tree.json

require_nonempty artifacts/vitals-dark.png
require_nonempty artifacts/vitals-light.png
require_nonempty artifacts/vitals-cpu.png
require_nonempty artifacts/vitals-processes.png
require_nonempty artifacts/vitals-tree.json

echo "verification ok"
