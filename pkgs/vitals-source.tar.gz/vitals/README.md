# Vitals

`Vitals` (`vitals`) is a native GPU-accelerated Linux system monitor and process manager built from scratch on [Anomaly Rune](https://github.com/anomalyco/rune). Windowing, input, layout, and headless scene tooling come from `rune`, UI components are assembled with `rune` and `rune-kit`, and telemetry charts and process tree connectors are vector `rune::Shape`s drawn on the GPU.

An ordinary interactive launch samples live `/proc` and `/sys` through `State::new_live()` on a background collector thread (`vitals-collector`). `--fixture` forces the deterministic fixture and wins over `--live`. Headless `--snap`, `--scene`, and `--tree` also use the fixture unless `--live` is passed, so snapshots do not touch the host unless asked to.

## Features

- **Real-time Linux telemetry & PSI pressure badges.** Per-core and aggregate CPU usage, frequencies, temperatures, load averages, Linux PSI (`cpu`, `memory` some/full, and `io` pressure stall readouts), extended RAM breakdown (`Available`, `Cached`, `Buffers`, `Shared`, `Dirty`, `Slab`) and swap, network RX/TX mirror charts with active listening/established sockets (`TCP`/`TCP6`/`UDP`/`UDP6` mapped to owning PID/process; the Network pane filters them by `All` / `Listen` / `Estab` / `TCP` / `UDP` and by port, address, state, or process), disk mounts with I/O throughput plus `Busy %` utilization and `Await ms` latency, `hwmon` / thermal sensors, battery wattage, and interactive chart hover readouts (`Hover -Ns: ...`) with a live crosshair cursor.
- **Process table, collapsible continuous vector tree, watchlist, and deep inspector.** Virtualized, searchable, sortable process table (`Table`, `Tree [t]`, `Grouped [g]`) with an inline signal confirmation modal (`SIGTERM`, `SIGKILL`, `SIGSTOP`, `SIGCONT`), pinned processes watchlist (`P` / `Pin [P]`) that floats ★-pinned processes to the top with a live watchlist strip, and collapsible subtrees in Tree mode (`▾` / `▸ +N` chips and `Left`/`Right`/`z`/`Enter` keys) drawn over full-row (`24px`) GPU vector `rune::Shape` connectors. The Process Inspector card renders per-process CPU and memory mini sparklines, `Nice` priority controls (`Nice -` / `Nice +`), `Copy Cmd`, systemd `Unit`, `CWD`, `Exe`, bound `Ports`, and the process's open files. Narrow process cards drop columns: under 520px the table keeps PID, Name, CPU, and a compact memory size; from 520px it adds User and State; from 700px it shows Read and Write as well.
- **Open files (`Files [7]`).** The seventh pane lists open files, sockets, devices, and pipes for the machine (`All`, `Files`, `Sockets`, `Devices`, `Pipes`) with PID, process, user, FD, kind, and target path. The shared search field filters that list. Clicking a row selects its process in the inspector.
- **Polkit privilege elevation (`All Users [S]`).** Press `S` (`Shift+S`) or click `Elevate` / `All Users [S]` to authenticate via `pkexec` (`--collector-helper`) and view telemetry, send signals, and renice processes across all users' processes. Press `S` or click `Root` / `All Users · Root [S]` to drop privileges immediately and return to unprivileged sampling.
- **Customizable dashboard layouts & card reorganization.** Cycle four Overview presets (`3×2 Grid`, `Processes Top`, `Split Columns`, `2×3 Wide`) with `L`, the toolbar layout chip, or Settings. Drag row and column borders (`split-row-*`, `split-col-*`) to resize adjacent cards (double-click to reset), and drag or click any two card `⇄` handles to swap slots across the six Overview positions.
- **Configurable color schemes & desktop theme detection.** Choose `System`, `Dark`, or `Light` appearance and switch between `System`, `Gruvbox`, `Catppuccin`, `Obsidian`, `Tokyo Night`, `Nord`, and `Rosé Pine` color schemes in Settings (`,`) or from the CLI. `System` detects dark/light mode and desktop colors from `gruvbox-mode`, Noctalia, Strata, Herdr, and GTK 3/4 CSS / `settings.ini` (falling back to the XDG desktop portal) and live-updates when the desktop theme changes.
- **Global UI zoom.** Scale the entire interface from `50%` to `200%` in `10%` steps with `Ctrl+Shift++` (`Ctrl+Shift+=`), `Ctrl+Shift+-`, and `Ctrl+Shift+0` (reset to `100%`), from Settings, or via the toolbar zoom badge.
- **Persistent preferences with seamless migration.** Appearance, color scheme, UI zoom, layout preset, card slot order, and splitter ratios save atomically to `$XDG_CONFIG_HOME/vitals/settings.json` (falling back to `$XDG_CONFIG_HOME/btm-rune/settings.json` on first read if `vitals/settings.json` does not exist yet).

## Architecture

| Module | Role |
| --- | --- |
| `src/model.rs` | Domain types (`PsiMetrics`, `NetSocketEntry`, `SelectedProcessHistory`, etc.) and `HistoryRing` (newest samples, oldest at the front, default capacity 240). `SystemSnapshot` holds one telemetry sample. `build_process_rows_ext` produces the table, collapsible process tree, or group-by-name rollup with pinned processes sorted first. |
| `src/collector.rs` | Linux `/proc` and `/sys` delta sampler with parallel scan workers (`vitals-scan-*`), PSI pressure stall reader, `/proc/net/{tcp,udp}*` socket & listening port mapper, disk utilization/await latency, `send_process_signal`, `renice_process`, and the line-delimited JSON `--collector-helper` Polkit root helper (`HelperClient`). |
| `src/fixture.rs` | `fixture_snapshot(step)` builds one deterministic synthetic sample: 8 cores, hostname `rune-node`, PSI metrics, sockets, disk latency, and 47 processes with systemd units, CWDs, listening ports, parent links, and repeated comm names. |
| `src/charts.rs` | GPU vector charts and guides on `rune::Shape`: `area_line_chart`, `multi_series_chart`, `dual_mirror_chart`, `meter_bar_shape`, `sparkline_shape`, `sparkline_chart`, `with_hover_cursor`, and `tree_connector_shape`. Coordinates are the element box, origin at the top-left, larger values toward the top. |
| `src/theme.rs` | `Palette`, `AppearanceMode`, `ColorSchemeId` (`System`, `Gruvbox`, `Catppuccin`, `Obsidian`, `Tokyo Night`, `Nord`, `Rosé Pine`), and `detect_system_theme` for desktop dark/light and palette detection. |
| `src/state.rs` | Interactive state: live background worker (`vitals-collector`) or fixture sampling, Polkit elevation (`vitals-elevate`), renice & command copy actions, pinned watchlist, collapsible tree state, interactive chart hover tracking, pane zoom, dashboard layout presets, card slots & splitters, UI zoom, sort, filter, tree/grouped modes, freeze, poll rate, history window, settings, help, signal dialog, and `settings.json` persistence. |
| `src/widgets.rs` | Bordered instrument cards: CPU (with PSI), memory (with PSI and `Shared`/`Dirty`/`Slab`), network (with a filterable sockets table), disks and sensors (with `IO PSI`, `Busy %`, and `Await ms`), chart hover readouts, and the deep process inspector (sparklines, actions, `Nice`/`Unit`/`CWD`/`Exe`/`Ports`). |
| `src/ui.rs` | Rune view (`Vitals — System Monitor`), started from `src/main.rs`: toolbar, customizable Overview dashboard, virtualized process table with pinned watchlist strip, collapsible vector tree connectors, `Files [7]` open-file pane, settings modal, help overlay, and signal confirmation modal. |

### Process rows

`build_process_rows` dedupes by pid, then applies the search query to the comm name, command line, user, and pid (case-insensitive substring).

- **Table.** One row per process, sorted by the active column.
- **Tree** (`t`). Children hang off their parent. A matching descendant keeps its ancestors visible. Hierarchy prefixes (`├─ `, `└─ `, `│  `) are rendered in the UI as continuous full-height GPU vector `rune::Shape` connectors (`tree_connector_shape`) colored per depth level. A parent cycle has no root, so those nodes are emitted once, in sort order, after the rooted walk; a visited set stops the walk from looping.
- **Grouped** (`g`). Rows collapse by comm name. CPU, memory, disk rates, and thread counts sum. The representative pid is the lowest pid in the group, and `count` is the group size.

Sort keys are CPU, memory, pid, name, read I/O, write I/O, user, state, and (for groups) count. Choosing the active column again flips direction. A new numeric column starts descending; pid, name, user, and state start ascending.

### Sampler, privilege elevation, and signals

The collector reads `/proc` (`stat`, `meminfo`, `uptime`, `loadavg`, `net/dev`, `diskstats`, mounts, and per-pid `stat` / `cmdline` / `io`) and `/sys` (hwmon or thermal zones, cpufreq, and power supply). Disk bytes come from `statvfs` on each mount. The sampler keeps the previous counters in the process and has no extra collection crate.

Pressing `S` (or clicking `Elevate` / `All Users [S]`) launches `pkexec --disable-internal-agent <vitals> --collector-helper`, which answers `Sample` and `Kill` JSON requests over stdio so `Vitals` can inspect all users' processes without running the GUI itself as root. Toggling elevation off closes the helper's stdin and immediately switches back to unprivileged sampling.

`send_process_signal` refuses pid 0 and pid 1. On a live session it calls `libc::kill` (or routes through the root helper while elevated) with signal 15, 9, 19, or 18. On the fixture it records the pid as killed, drops it from the current snapshot, and leaves it out of later fixture steps.

### Fixture

`fixture_history(steps)` records steps `0..steps` and returns the last snapshot. `State::new_fixture()` calls `fixture_history(60)`, so the constructed snapshot is step 59 and the rings hold 60 samples. The first painted frame runs `State::poll` at `t=0`. That poll is due, and it advances the displayed snapshot to step 60. Later polls advance one fixture step at a time.

## Build

The crate targets Linux. The Nix flake provides Rust, Clippy, and the Wayland, xkbcommon, Vulkan, Mesa/GL, and X11 libraries Rune loads at runtime:

```sh
nix develop
cargo build
cargo run                 # live /proc and /sys
cargo run -- --fixture    # deterministic fixture
```

The package version is `0.1.0`. `rune` and `rune-kit` are built from the pinned Nix derivation in `nix/rune-source.nix`. Versions are locked in `Cargo.lock`, so the checks below pass `--offline`.

## Command line

`src/main.rs` parses `--fixture`, `--live`, `--rate <ms>`, `--window <secs>`, `--theme <dark|light|system>`, and `--color-scheme <slug>` first (and handles `--collector-helper` before starting the GUI). Every remaining argument is forwarded to `rune::App::args`, including `--snap`, `--scene`, `--tree`, `--at`, `--size`, `--scale`, `--help`, and `--list-scenes`.

```sh
vitals [--fixture] [--live] [--rate <ms>] [--window <secs>]
       [--theme dark|light|system]
       [--color-scheme system|gruvbox|catppuccin|obsidian|tokyo-night|nord|rose-pine]
       [--scene <dark|light|cpu|processes>] [--snap <path.png>] [--tree <path.json>]
```

| Flag | Meaning |
| --- | --- |
| *(none)* | Ordinary launch. Calls `State::new_live()`, loads `~/.config/vitals/settings.json` (with fallback to `~/.config/btm-rune/settings.json`), and samples this machine. |
| `--fixture` | Force the deterministic fixture. Wins when both `--fixture` and `--live` are set. |
| `--live` | Sample this machine through `LinuxCollector`. This is already the ordinary default. On a headless run it also wins over the fixture default. A `/proc` read error falls back to the fixture and shows an error banner. |
| `--rate <ms>` | Poll interval in milliseconds. Default `1000`. The keyboard cycles 250, 500, 1000, and 2000 (Settings also offers 5000). |
| `--window <secs>` | History visible in the charts, in seconds. Default `60`. The keyboard cycles 15, 30, 60, and 120 (Settings also offers 300). The chart uses `window * 1000 / rate` samples, clamped to 8..=240. |
| `--theme <dark\|light\|system>` | Session appearance mode (`Dark`, `Light`, or `System` / `auto`). Not written back to `settings.json`. |
| `--color-scheme <slug>` | Session color scheme: `system`, `gruvbox`, `catppuccin`, `obsidian`, `tokyo-night`, `nord`, or `rose-pine`. Not written back to `settings.json`. |
| `--scene <name>` | Forwarded to Rune and applied on top of the initial state. Names: `dark`, `light`, `cpu`, `processes`. `--list-scenes` prints them. Without `--live`, selecting a scene also selects the fixture. |
| `--snap <path.png>` | Forwarded to Rune. Render one offscreen frame to a PNG and exit. No window is opened. Without `--live`, this selects the fixture. |
| `--tree <path.json>` | Forwarded to Rune. Write the element tree (layout and animated values) as JSON and exit. Without `--live`, this selects the fixture. |

Examples:

```sh
# Live sampler, two samples per second, 30 seconds of history, Gruvbox dark.
cargo run -- --rate 500 --window 30 --theme dark --color-scheme gruvbox

# Headless fixture frames used by scripts/verify.sh.
cargo run --offline --bin vitals -- --fixture --theme dark --scene dark --snap artifacts/vitals-dark.png
cargo run --offline --bin vitals -- --fixture --theme light --scene light --snap artifacts/vitals-light.png
cargo run --offline --bin vitals -- --fixture --theme dark --scene cpu --snap artifacts/vitals-cpu.png
cargo run --offline --bin vitals -- --fixture --theme dark --scene processes --snap artifacts/vitals-processes.png
cargo run --offline --bin vitals -- --fixture --scene dark --tree artifacts/vitals-tree.json
```

`--help` is forwarded to `rune::App::args` and prints Rune's tooling help. `--size WxH`, `--scale`, `--at`, and `--list-scenes` are forwarded the same way.

## Keyboard

Shortcuts are handled by `State::on_key` when the search field is not capturing text (`Ctrl+F` focuses search, and `Ctrl+Shift++/-/0` UI zoom works globally at all times, including inside search and dialogs).

| Keys | Action |
| --- | --- |
| `1` | Overview. All six cards in the active dashboard layout preset. |
| `2` | Zoom the CPU pane. |
| `3` | Zoom the memory pane. |
| `4` | Zoom the network pane. Filter sockets by Listen, Established, TCP, or UDP, search ports, addresses, states, or processes, and click a row to select its process. |
| `5` | Zoom the disks and sensors pane. |
| `6` | Zoom the process pane. |
| `7` | Open Files (`Files [7]`). Filter files, sockets, devices, and pipes, and select a process from a row. |
| `e` | Zoom the focused pane, or return to the overview if a pane is already zoomed. |
| `L` | Cycle Overview dashboard layout preset (`3×2 Grid`, `Processes Top`, `Split Columns`, `2×3 Wide`). Capital `L`. |
| `Ctrl+Shift++`, `Ctrl+Shift+=` | Zoom UI in by `10%` (up to `200%`). |
| `Ctrl+Shift+-` | Zoom UI out by `10%` (down to `50%`). |
| `Ctrl+Shift+0` | Reset UI zoom to `100%`. |
| `Tab` | Move focus forward: CPU, memory, network, disks, processes. On a zoomed pane, the zoom follows focus. |
| `Shift+Tab` | Move focus backward through the same panes. |
| `/`, `Ctrl+F` | Focus the search field. On Processes it matches name, command line, user, or pid. On Network it matches port, address, protocol, state, process, or pid. On Files it matches path, process, user, pid, or kind. |
| `t` | Toggle the process tree (continuous GPU vector connectors). Pressing it again returns to the flat table. |
| `Left` | In Tree mode, collapse the selected process if expanded, or jump selection to its parent if already collapsed/leaf. |
| `Right` | In Tree mode, expand the selected process if collapsed. |
| `z`, `Enter` | In Tree mode (when no signal dialog is open), toggle collapse/expand on the selected process. |
| `g` | Toggle group-by-name. Pressing it again returns to the flat table. |
| `P` | Pin or unpin the selected process (`Shift+P`), floating it to the top and adding it to the watchlist strip. |
| `c` | Sort by CPU. Pressing the active column again flips direction. |
| `m` | Sort by memory. |
| `p` | Sort by pid. |
| `n` | Sort by name. |
| `I` | Invert the current sort direction. Capital `I`. |
| `j`, `Down` | Select the next process row. |
| `k`, `Up` | Select the previous process row. |
| `PageDown` | Move the selection down 12 rows. |
| `PageUp` | Move the selection up 12 rows. |
| `Home` | Select the first visible row. |
| `End` | Select the last visible row. |
| `d`, `Delete`, `K` | Open the signal dialog for the selected process, starting at `SIGTERM`. Capital `K`. Pid 0 and pid 1 are refused. |
| `S` | Toggle Polkit privilege elevation (`All Users [S]` / drop elevated helper). Capital `S`. |
| `f`, `Space` | Freeze or resume sampling. |
| `+`, `=` | Previous history window in `15, 30, 60, 120` seconds. |
| `-` | Next history window in `15, 30, 60, 120` seconds. |
| `[` | Previous poll interval in `250, 500, 1000, 2000` ms. |
| `]` | Next poll interval in `250, 500, 1000, 2000` ms. |
| `a` | Toggle the CPU chart between the per-core overlay and the single total series. |
| `l` | Show or hide the loopback interface. |
| `,` | Toggle the Settings modal (appearance mode, dashboard layout, color scheme, monitor preferences). |
| `?` | Toggle the keyboard shortcuts help overlay. |
| `Escape` | Dismiss the topmost state in order: signal dialog, settings modal, help overlay, armed card swap, search focus, non-empty query, then zoomed pane (back to Overview). |

### Signal dialog

`d`, `Delete`, or `K` asks for confirmation before anything is signaled. While the dialog is open, these keys replace the global map:

| Keys | Action |
| --- | --- |
| `1`, `t` | Choose `SIGTERM` (15). |
| `2`, `k` | Choose `SIGKILL` (9). |
| `3`, `s` | Choose `SIGSTOP` (19). |
| `4`, `c` | Choose `SIGCONT` (18). |
| `y`, `Enter` | Send the chosen signal. |
| `Escape` | Cancel. The process is left running. |

A successful send sets a status banner: `Sent SIGTERM to vim (pid 330)`. Live failures show the OS error. The fixture removes the process from the table instead of calling `kill`.

## Verification

`scripts/verify.sh` is the automated check. From the repository root:

```sh
./scripts/verify.sh
```

It runs, in order:

1. `cargo build --offline --bin vitals`
2. `cargo test --offline`
3. `cargo clippy --offline --all-targets -- -D warnings`
4. Headless fixture renders via `vitals`, then refuses to succeed if any output is missing or empty:
   - `artifacts/vitals-dark.png` — `--fixture --theme dark --scene dark --snap`
   - `artifacts/vitals-light.png` — `--fixture --theme light --scene light --snap`
   - `artifacts/vitals-cpu.png` — `--fixture --theme dark --scene cpu --snap`
   - `artifacts/vitals-processes.png` — `--fixture --theme dark --scene processes --snap`
   - `artifacts/vitals-tree.json` — `--fixture --scene dark --tree`

`artifacts/` is gitignored. Re-running the script overwrites those five files. Those commands pass `--fixture`, so they do not read `/proc` and do not send a real signal.

If `LD_LIBRARY_PATH` does not already provide `libvulkan.so.1`, the script prepends the Nix store `lib` directories for `vulkan-loader`, `wayland`, `libxkbcommon`, `mesa`, `libGL`, `libglvnd`, `libx11`, `libxcursor`, `libxi`, and `libxrandr`, and `/run/opengl-driver/lib` when that directory exists. A plain shell can render the snapshots without entering `nix develop` first.
