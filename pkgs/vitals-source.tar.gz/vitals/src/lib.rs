//! Vitals — a native GPU-accelerated Linux system monitor built from scratch on Anomaly Rune.

pub mod charts;
pub mod collector;
pub mod fixture;
pub mod model;
pub mod state;
pub mod theme;
pub mod ui;
pub mod widgets;

#[cfg(test)]
mod tests;
