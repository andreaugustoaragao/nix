//! Deterministic snapshots for UI tests and headless playback.
//!
//! `step` is the only input. The same step always yields the same snapshot,
//! including process parent links and repeated comm names used by tree and
//! grouped modes.

use crate::model::{
    BatteryMetrics, CoreMetrics, CpuMetrics, DiskMetrics, MemMetrics, NetInterfaceMetrics,
    NetSocketEntry, OpenFileEntry, OpenFileKind, ProcessInfo, PsiMetrics, SensorMetrics,
    SystemSnapshot, TelemetryHistory,
};

const CORE_COUNT: usize = 8;
const MEM_TOTAL: u64 = 32_u64 << 30;
const SWAP_TOTAL: u64 = 8_u64 << 30;
const ROOT_DISK: u64 = 512_u64 << 30;
const HOME_DISK: u64 = 2_u64 << 40;

struct ProcSpec {
    pid: u32,
    ppid: u32,
    name: &'static str,
    user: &'static str,
    state: char,
    cpu: f32,
    mem_mib: u64,
    threads: u32,
    kernel: bool,
}

pub fn fixture_snapshot(step: usize) -> SystemSnapshot {
    let cores = fixture_cores(step);
    let total_usage = cores.iter().map(|core| core.usage_pct).sum::<f32>() / CORE_COUNT as f32;
    let processes = fixture_processes(step);
    let tasks_running = processes.iter().filter(|proc| proc.state == 'R').count();
    let networks = fixture_networks(step);
    let (net_rx_total_bps, net_tx_total_bps) = networks.iter().fold((0.0, 0.0), |acc, iface| {
        if iface.is_loopback {
            acc
        } else {
            (
                acc.0 + iface.rx_bytes_per_sec,
                acc.1 + iface.tx_bytes_per_sec,
            )
        }
    });
    let mem = fixture_mem(step);
    let load = total_usage / 100.0 * CORE_COUNT as f32 * 0.18;

    SystemSnapshot {
        timestamp_sec: 1_700_000_000.0 + step as f64,
        hostname: "rune-node".to_string(),
        kernel: "6.12.7-rune".to_string(),
        cpu: CpuMetrics {
            model_name: "AMD Ryzen 7 7840U".to_string(),
            total_usage_pct: total_usage,
            user_pct: total_usage * 0.70,
            system_pct: total_usage * 0.22,
            iowait_pct: total_usage * 0.08,
            load_avg: [load, load * 0.82, load * 0.64],
            cores,
            uptime_secs: 100_000 + step as u64 * 2,
            tasks_total: processes.len(),
            tasks_running,
        },
        mem,
        networks,
        net_rx_total_bps,
        net_tx_total_bps,
        disks: fixture_disks(step),
        sensors: fixture_sensors(step),
        batteries: vec![fixture_battery(step)],
        processes,
        psi: fixture_psi(step),
        sockets: fixture_sockets(),
        open_files: fixture_open_files(),
    }
}

pub fn fixture_history(steps: usize) -> (SystemSnapshot, TelemetryHistory) {
    let mut history = TelemetryHistory::default();
    if steps == 0 {
        return (fixture_snapshot(0), history);
    }
    let mut last = fixture_snapshot(0);
    for step in 0..steps {
        last = fixture_snapshot(step);
        history.record(&last);
    }
    (last, history)
}

fn fixture_cores(step: usize) -> Vec<CoreMetrics> {
    (0..CORE_COUNT)
        .map(|index| {
            let wave = triangle(step + index * 3, 20);
            let usage = (6.0 + index as f32 * 2.5 + wave * 28.0).clamp(0.0, 100.0);
            CoreMetrics {
                index,
                usage_pct: usage,
                user_pct: usage * 0.70,
                system_pct: usage * 0.22,
                iowait_pct: usage * 0.08,
                freq_mhz: Some(1800 + (index as u32 * 150) + (step as u32 % 5) * 50),
                temp_c: Some(46.0 + index as f32 * 1.4 + wave * 8.0),
            }
        })
        .collect()
}

fn fixture_psi(step: usize) -> PsiMetrics {
    PsiMetrics {
        cpu_some_pct: (1.2 + triangle(step, 16) * 8.4).clamp(0.0, 100.0),
        mem_some_pct: (0.3 + triangle(step + 3, 24) * 3.2).clamp(0.0, 100.0),
        mem_full_pct: (0.05 + triangle(step + 3, 24) * 0.85).clamp(0.0, 100.0),
        io_some_pct: (0.8 + triangle(step + 6, 18) * 6.5).clamp(0.0, 100.0),
        io_full_pct: (0.2 + triangle(step + 6, 18) * 2.1).clamp(0.0, 100.0),
    }
}

fn fixture_mem(step: usize) -> MemMetrics {
    let used_pct = 41.0 + triangle(step, 30) * 27.0;
    let swap_pct = triangle(step + 5, 40) * 12.0;
    let used_bytes = scale_bytes(MEM_TOTAL, used_pct);
    let swap_used_bytes = scale_bytes(SWAP_TOTAL, swap_pct);
    let cached_bytes = MEM_TOTAL / 8;
    let buffers_bytes = MEM_TOTAL / 64;
    let shared_bytes = (MEM_TOTAL / 32) + scale_bytes(128_u64 << 20, triangle(step, 20) * 100.0);
    let dirty_bytes = (16_u64 << 20) + scale_bytes(96_u64 << 20, triangle(step + 2, 12) * 100.0);
    let writeback_bytes = scale_bytes(24_u64 << 20, triangle(step + 5, 10) * 100.0);
    let slab_bytes = (MEM_TOTAL / 24) + scale_bytes(64_u64 << 20, triangle(step + 1, 28) * 100.0);
    MemMetrics {
        total_bytes: MEM_TOTAL,
        used_bytes,
        available_bytes: MEM_TOTAL.saturating_sub(used_bytes),
        cached_bytes,
        buffers_bytes,
        used_pct,
        swap_total_bytes: SWAP_TOTAL,
        swap_used_bytes,
        swap_pct,
        shared_bytes,
        dirty_bytes,
        writeback_bytes,
        slab_bytes,
    }
}

fn fixture_networks(step: usize) -> Vec<NetInterfaceMetrics> {
    let burst = step.is_multiple_of(10);
    let shape = f64::from(triangle(step, 8));
    let eth_rx = if burst {
        80_000_000.0
    } else {
        250_000.0 + shape * 1_500_000.0
    };
    let eth_tx = eth_rx * 0.16;
    let wlan_rx = 40_000.0 + f64::from(triangle(step.wrapping_add(3), 12)) * 900_000.0;
    let wlan_tx = wlan_rx * 0.35;
    let base = 2_000_000_000_u64.saturating_add((step as u64).saturating_mul(8_000_000));
    vec![
        NetInterfaceMetrics {
            name: "lo".to_string(),
            is_loopback: true,
            rx_bytes_per_sec: 1_200.0,
            tx_bytes_per_sec: 1_200.0,
            total_rx_bytes: 50_000_000 + step as u64 * 1_200,
            total_tx_bytes: 50_000_000 + step as u64 * 1_200,
            rx_packets_per_sec: 8.0,
            tx_packets_per_sec: 8.0,
        },
        NetInterfaceMetrics {
            name: "eth0".to_string(),
            is_loopback: false,
            rx_bytes_per_sec: eth_rx,
            tx_bytes_per_sec: eth_tx,
            total_rx_bytes: base,
            total_tx_bytes: base / 6,
            rx_packets_per_sec: eth_rx / 900.0,
            tx_packets_per_sec: eth_tx / 700.0,
        },
        NetInterfaceMetrics {
            name: "wlan0".to_string(),
            is_loopback: false,
            rx_bytes_per_sec: wlan_rx,
            tx_bytes_per_sec: wlan_tx,
            total_rx_bytes: base / 4,
            total_tx_bytes: base / 12,
            rx_packets_per_sec: wlan_rx / 1100.0,
            tx_packets_per_sec: wlan_tx / 900.0,
        },
    ]
}

fn fixture_disks(step: usize) -> Vec<DiskMetrics> {
    let read_wave = f64::from(triangle(step, 16));
    let write_wave = f64::from(triangle(step + 4, 16));
    let nvme_busy =
        (6.0 + (read_wave as f32 * 0.55 + write_wave as f32 * 0.45) * 42.0).clamp(0.0, 100.0);
    let nvme_await = (0.35 + write_wave as f32 * 1.85).max(0.0);
    let sda_busy =
        (3.5 + (read_wave as f32 * 0.40 + write_wave as f32 * 0.60) * 34.0).clamp(0.0, 100.0);
    let sda_await = (2.10 + write_wave as f32 * 6.40).max(0.0);
    vec![
        DiskMetrics {
            device: "nvme0n1p2".to_string(),
            mount_point: "/".to_string(),
            fs_type: "ext4".to_string(),
            total_bytes: ROOT_DISK,
            used_bytes: scale_bytes(ROOT_DISK, 46.0),
            free_bytes: scale_bytes(ROOT_DISK, 54.0),
            used_pct: 46.0,
            read_bytes_per_sec: 8_000_000.0 + read_wave * 40_000_000.0,
            write_bytes_per_sec: 1_500_000.0 + write_wave * 12_000_000.0,
            busy_pct: nvme_busy,
            await_ms: nvme_await,
        },
        DiskMetrics {
            device: "sda1".to_string(),
            mount_point: "/home".to_string(),
            fs_type: "xfs".to_string(),
            total_bytes: HOME_DISK,
            used_bytes: scale_bytes(HOME_DISK, 61.5),
            free_bytes: scale_bytes(HOME_DISK, 38.5),
            used_pct: 61.5,
            read_bytes_per_sec: 400_000.0 + read_wave * 6_000_000.0,
            write_bytes_per_sec: 900_000.0 + write_wave * 8_000_000.0,
            busy_pct: sda_busy,
            await_ms: sda_await,
        },
    ]
}

fn fixture_sockets() -> Vec<NetSocketEntry> {
    vec![
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "0.0.0.0:22".to_string(),
            remote_addr: "*".to_string(),
            state: "LISTEN".to_string(),
            inode: 11_022,
            pid: Some(300),
            process: "sshd".to_string(),
        },
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "0.0.0.0:80".to_string(),
            remote_addr: "*".to_string(),
            state: "LISTEN".to_string(),
            inode: 16_080,
            pid: Some(600),
            process: "nginx".to_string(),
        },
        NetSocketEntry {
            proto: "TCP6".to_string(),
            local_addr: "[::]:443".to_string(),
            remote_addr: "*".to_string(),
            state: "LISTEN".to_string(),
            inode: 16_443,
            pid: Some(600),
            process: "nginx".to_string(),
        },
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "127.0.0.1:3000".to_string(),
            remote_addr: "*".to_string(),
            state: "LISTEN".to_string(),
            inode: 22_300,
            pid: Some(1200),
            process: "node".to_string(),
        },
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "127.0.0.1:5432".to_string(),
            remote_addr: "*".to_string(),
            state: "LISTEN".to_string(),
            inode: 17_543,
            pid: Some(700),
            process: "postgres".to_string(),
        },
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "10.0.0.14:22".to_string(),
            remote_addr: "10.0.0.42:51824".to_string(),
            state: "ESTAB".to_string(),
            inode: 31_022,
            pid: Some(310),
            process: "sshd".to_string(),
        },
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "10.0.0.14:49320".to_string(),
            remote_addr: "142.250.190.78:443".to_string(),
            state: "ESTAB".to_string(),
            inode: 48_443,
            pid: Some(800),
            process: "firefox".to_string(),
        },
        NetSocketEntry {
            proto: "TCP".to_string(),
            local_addr: "10.0.0.14:52104".to_string(),
            remote_addr: "104.18.32.7:443".to_string(),
            state: "ESTAB".to_string(),
            inode: 59_443,
            pid: Some(900),
            process: "chrome".to_string(),
        },
    ]
}

fn fixture_sensors(step: usize) -> Vec<SensorMetrics> {
    let wave = triangle(step, 18);
    vec![
        SensorMetrics {
            label: "Package id 0".to_string(),
            temp_c: 58.0 + wave * 14.0,
            high_c: Some(95.0),
            crit_c: Some(105.0),
        },
        SensorMetrics {
            label: "NVMe Composite".to_string(),
            temp_c: 39.0 + wave * 7.0,
            high_c: Some(84.0),
            crit_c: Some(87.0),
        },
        SensorMetrics {
            label: "acpitz".to_string(),
            temp_c: 44.0 + triangle(step + 2, 18) * 6.0,
            high_c: Some(90.0),
            crit_c: Some(110.0),
        },
    ]
}

fn fixture_battery(step: usize) -> BatteryMetrics {
    let drained = (step % 50) as f32 * 0.35;
    BatteryMetrics {
        name: "BAT0".to_string(),
        status: "Discharging".to_string(),
        capacity_pct: (86.0 - drained).clamp(8.0, 100.0),
        power_watts: Some(7.4 + triangle(step, 14) * 6.0),
    }
}

fn fixture_processes(step: usize) -> Vec<ProcessInfo> {
    SPECS
        .iter()
        .map(|spec| {
            let swing = triangle(step.wrapping_add(spec.pid as usize), 12) * 5.0;
            let cpu_pct = (spec.cpu + swing).clamp(0.0, 800.0);
            let mem_bytes = spec.mem_mib.saturating_mul(1024 * 1024);
            let io = f64::from(triangle(step.wrapping_add(spec.pid as usize / 3), 9));
            ProcessInfo {
                pid: spec.pid,
                ppid: spec.ppid,
                name: spec.name.to_string(),
                cmdline: if spec.kernel {
                    String::new()
                } else {
                    format!("/usr/bin/{} --pid {}", spec.name, spec.pid)
                },
                user: spec.user.to_string(),
                state: spec.state,
                cpu_pct,
                mem_bytes,
                mem_pct: part_pct(mem_bytes, MEM_TOTAL),
                read_bytes_per_sec: if spec.kernel {
                    0.0
                } else {
                    2_048.0 + io * 250_000.0
                },
                write_bytes_per_sec: if spec.kernel {
                    0.0
                } else {
                    512.0 + io * 80_000.0
                },
                threads: spec.threads,
                fds: if spec.kernel {
                    None
                } else {
                    Some(8 + spec.threads)
                },
                nice: fixture_proc_nice(spec),
                unit: fixture_proc_unit(spec),
                cwd: fixture_proc_cwd(spec),
                exe: if spec.kernel {
                    None
                } else {
                    Some(format!("/usr/bin/{}", spec.name))
                },
                listening_ports: fixture_proc_ports(spec),
                open_files: fixture_proc_open_files(spec),
            }
        })
        .collect()
}

fn fixture_proc_nice(spec: &ProcSpec) -> i32 {
    match spec.pid {
        11 | 18 => -20,
        1400 => -11,
        1300 => -2,
        1001 | 1002 => 5,
        _ => 0,
    }
}

fn fixture_proc_unit(spec: &ProcSpec) -> Option<String> {
    if spec.kernel {
        return None;
    }
    let unit = match spec.pid {
        1 => "init.scope",
        80 => "systemd-journald.service",
        90 => "systemd-udevd.service",
        100 => "systemd-logind.service",
        150 => "dbus.service",
        200 => "NetworkManager.service",
        220 => "wpa_supplicant.service",
        300 => "sshd.service",
        310 | 320 | 330 | 331 | 1000 | 1001 | 1002 | 1100 | 1101 | 1500 => "session-2.scope",
        400 | 410 => "containerd.service",
        500 => "docker.service",
        600..=602 => "nginx.service",
        700..=703 => "postgresql.service",
        800..=803 => "app-firefox.scope",
        900..=903 => "app-chrome.scope",
        1200 | 1201 => "user@1000.service",
        1300 => "org.gnome.Shell@wayland.service",
        1400 => "pipewire.service",
        _ => "system.slice",
    };
    Some(unit.to_string())
}

fn fixture_proc_cwd(spec: &ProcSpec) -> Option<String> {
    if spec.kernel {
        return None;
    }
    let dir = match spec.pid {
        310 | 320 | 330 | 331 | 1000 | 1001 | 1002 | 1500 => "/home/alice/projects/vitals",
        600..=602 => "/var/www/html",
        700..=703 => "/var/lib/postgresql/data",
        1100 | 1101 => "/home/alice/scripts",
        1200 | 1201 => "/home/alice/projects/web",
        _ if spec.user == "alice" => "/home/alice",
        _ => "/",
    };
    Some(dir.to_string())
}

fn fixture_proc_ports(spec: &ProcSpec) -> Vec<String> {
    match spec.pid {
        300 => vec!["TCP *:22".to_string()],
        600..=602 => vec!["TCP *:80".to_string(), "TCP6 *:443".to_string()],
        700 => vec!["TCP 127.0.0.1:5432".to_string()],
        1200 => vec!["TCP 127.0.0.1:3000".to_string()],
        _ => Vec::new(),
    }
}

fn fixture_open_files() -> Vec<OpenFileEntry> {
    let entry = |pid: u32,
                 process: &str,
                 user: &str,
                 fd: u32,
                 count: u32,
                 kind: OpenFileKind,
                 path: &str| OpenFileEntry {
        pid,
        process: process.to_string(),
        user: user.to_string(),
        fd,
        count,
        kind,
        path: path.to_string(),
    };
    vec![
        // Files
        entry(
            1,
            "systemd",
            "root",
            3,
            1,
            OpenFileKind::File,
            "/etc/systemd/system.conf",
        ),
        entry(
            80,
            "systemd-journal",
            "root",
            8,
            1,
            OpenFileKind::File,
            "/var/log/journal/system.journal",
        ),
        entry(
            330,
            "vim",
            "alice",
            4,
            1,
            OpenFileKind::File,
            "/home/alice/projects/vitals/src/.ui.rs.swp",
        ),
        entry(
            600,
            "nginx",
            "root",
            5,
            1,
            OpenFileKind::File,
            "/var/log/nginx/access.log",
        ),
        entry(
            601,
            "nginx",
            "http",
            9,
            2,
            OpenFileKind::File,
            "/var/www/html/index.html",
        ),
        entry(
            700,
            "postgres",
            "postgres",
            4,
            1,
            OpenFileKind::File,
            "/var/lib/postgresql/data/PG_VERSION",
        ),
        entry(
            701,
            "postgres",
            "postgres",
            11,
            4,
            OpenFileKind::File,
            "/var/lib/postgresql/data/base/16384/2619",
        ),
        entry(
            800,
            "firefox",
            "alice",
            22,
            1,
            OpenFileKind::File,
            "/home/alice/.mozilla/firefox/places.sqlite",
        ),
        entry(
            900,
            "chrome",
            "alice",
            19,
            1,
            OpenFileKind::File,
            "/home/alice/.config/chromium/Default/History",
        ),
        entry(
            1001,
            "rustc",
            "alice",
            3,
            1,
            OpenFileKind::File,
            "/home/alice/projects/vitals/src/main.rs",
        ),
        entry(
            1001,
            "rustc",
            "alice",
            7,
            1,
            OpenFileKind::File,
            "/home/alice/projects/vitals/target/debug/deps/libvitals.rmeta",
        ),
        // Sockets
        entry(
            300,
            "sshd",
            "root",
            3,
            1,
            OpenFileKind::Socket,
            "TCP 0.0.0.0:22 -> * (LISTEN)",
        ),
        entry(
            310,
            "sshd",
            "alice",
            4,
            1,
            OpenFileKind::Socket,
            "TCP 10.0.0.14:22 -> 10.0.0.42:51824 (ESTAB)",
        ),
        entry(
            600,
            "nginx",
            "root",
            6,
            1,
            OpenFileKind::Socket,
            "TCP 0.0.0.0:80 -> * (LISTEN)",
        ),
        entry(
            600,
            "nginx",
            "root",
            7,
            1,
            OpenFileKind::Socket,
            "TCP6 [::]:443 -> * (LISTEN)",
        ),
        entry(
            700,
            "postgres",
            "postgres",
            6,
            1,
            OpenFileKind::Socket,
            "TCP 127.0.0.1:5432 -> * (LISTEN)",
        ),
        entry(
            800,
            "firefox",
            "alice",
            38,
            1,
            OpenFileKind::Socket,
            "TCP 10.0.0.14:49320 -> 142.250.190.78:443 (ESTAB)",
        ),
        entry(
            900,
            "chrome",
            "alice",
            41,
            1,
            OpenFileKind::Socket,
            "TCP 10.0.0.14:52104 -> 104.18.32.7:443 (ESTAB)",
        ),
        entry(
            1200,
            "node",
            "alice",
            14,
            1,
            OpenFileKind::Socket,
            "TCP 127.0.0.1:3000 -> * (LISTEN)",
        ),
        // Devices
        entry(
            1,
            "systemd",
            "root",
            1,
            2,
            OpenFileKind::Device,
            "/dev/null",
        ),
        entry(
            310,
            "sshd",
            "alice",
            8,
            3,
            OpenFileKind::Device,
            "/dev/pts/0",
        ),
        entry(
            800,
            "firefox",
            "alice",
            15,
            2,
            OpenFileKind::Device,
            "/dev/dri/renderD128",
        ),
        entry(
            1400,
            "pipewire",
            "alice",
            12,
            1,
            OpenFileKind::Device,
            "/dev/snd/pcmC0D0p",
        ),
        // Pipes / eventfds
        entry(
            1,
            "systemd",
            "root",
            4,
            6,
            OpenFileKind::Pipe,
            "anon_inode:[eventpoll]",
        ),
        entry(
            700,
            "postgres",
            "postgres",
            9,
            3,
            OpenFileKind::Pipe,
            "pipe:[71204]",
        ),
        entry(
            1001,
            "rustc",
            "alice",
            9,
            8,
            OpenFileKind::Pipe,
            "pipe:[94102]",
        ),
        entry(
            1200,
            "node",
            "alice",
            10,
            12,
            OpenFileKind::Pipe,
            "anon_inode:[eventfd]",
        ),
    ]
}

fn fixture_proc_open_files(spec: &ProcSpec) -> Vec<String> {
    if spec.kernel {
        return Vec::new();
    }
    let mut paths: Vec<String> = fixture_open_files()
        .into_iter()
        .filter(|entry| entry.pid == spec.pid)
        .map(|entry| entry.path)
        .collect();
    if paths.is_empty() {
        paths.push("/dev/null".to_string());
    }
    paths
}

fn triangle(step: usize, period: usize) -> f32 {
    let period = period.max(2);
    let half = period / 2;
    let x = step % period;
    if x <= half {
        x as f32 / half as f32
    } else {
        (period - x) as f32 / half as f32
    }
}

fn scale_bytes(total: u64, pct: f32) -> u64 {
    let value = (total as f64) * f64::from(pct) / 100.0;
    if value.is_sign_negative() || !value.is_finite() {
        0
    } else if value >= u64::MAX as f64 {
        u64::MAX
    } else {
        value.round() as u64
    }
}

fn part_pct(part: u64, total: u64) -> f32 {
    if total == 0 {
        0.0
    } else {
        ((part as f64) / (total as f64) * 100.0) as f32
    }
}

const SPECS: &[ProcSpec] = &[
    ProcSpec {
        pid: 1,
        ppid: 0,
        name: "systemd",
        user: "root",
        state: 'S',
        cpu: 0.4,
        mem_mib: 18,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 2,
        ppid: 0,
        name: "kthreadd",
        user: "root",
        state: 'S',
        cpu: 0.0,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 10,
        ppid: 2,
        name: "ksoftirqd/0",
        user: "root",
        state: 'R',
        cpu: 0.6,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 11,
        ppid: 2,
        name: "kworker/0:0H",
        user: "root",
        state: 'D',
        cpu: 0.2,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 12,
        ppid: 2,
        name: "rcu_sched",
        user: "root",
        state: 'S',
        cpu: 0.1,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 16,
        ppid: 2,
        name: "ksoftirqd/1",
        user: "root",
        state: 'R',
        cpu: 0.5,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 17,
        ppid: 2,
        name: "kworker/1:1",
        user: "root",
        state: 'S',
        cpu: 0.2,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 18,
        ppid: 2,
        name: "migration/0",
        user: "root",
        state: 'S',
        cpu: 0.0,
        mem_mib: 0,
        threads: 1,
        kernel: true,
    },
    ProcSpec {
        pid: 80,
        ppid: 1,
        name: "systemd-journal",
        user: "root",
        state: 'S',
        cpu: 0.3,
        mem_mib: 42,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 90,
        ppid: 1,
        name: "systemd-udevd",
        user: "root",
        state: 'S',
        cpu: 0.1,
        mem_mib: 12,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 100,
        ppid: 1,
        name: "systemd-logind",
        user: "root",
        state: 'S',
        cpu: 0.1,
        mem_mib: 8,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 150,
        ppid: 1,
        name: "dbus-daemon",
        user: "messagebus",
        state: 'S',
        cpu: 0.1,
        mem_mib: 6,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 200,
        ppid: 1,
        name: "NetworkManager",
        user: "root",
        state: 'S',
        cpu: 0.2,
        mem_mib: 22,
        threads: 3,
        kernel: false,
    },
    ProcSpec {
        pid: 220,
        ppid: 200,
        name: "wpa_supplicant",
        user: "root",
        state: 'S',
        cpu: 0.1,
        mem_mib: 8,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 300,
        ppid: 1,
        name: "sshd",
        user: "root",
        state: 'S',
        cpu: 0.1,
        mem_mib: 5,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 310,
        ppid: 300,
        name: "sshd",
        user: "alice",
        state: 'S',
        cpu: 0.1,
        mem_mib: 7,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 320,
        ppid: 310,
        name: "bash",
        user: "alice",
        state: 'S',
        cpu: 0.2,
        mem_mib: 6,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 330,
        ppid: 320,
        name: "vim",
        user: "alice",
        state: 'S',
        cpu: 0.4,
        mem_mib: 18,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 331,
        ppid: 320,
        name: "htop",
        user: "alice",
        state: 'S',
        cpu: 1.2,
        mem_mib: 8,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 400,
        ppid: 1,
        name: "containerd",
        user: "root",
        state: 'S',
        cpu: 0.4,
        mem_mib: 64,
        threads: 12,
        kernel: false,
    },
    ProcSpec {
        pid: 410,
        ppid: 400,
        name: "containerd-shim",
        user: "root",
        state: 'S',
        cpu: 0.2,
        mem_mib: 14,
        threads: 8,
        kernel: false,
    },
    ProcSpec {
        pid: 500,
        ppid: 1,
        name: "dockerd",
        user: "root",
        state: 'S',
        cpu: 0.5,
        mem_mib: 90,
        threads: 16,
        kernel: false,
    },
    ProcSpec {
        pid: 600,
        ppid: 1,
        name: "nginx",
        user: "root",
        state: 'S',
        cpu: 0.2,
        mem_mib: 8,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 601,
        ppid: 600,
        name: "nginx",
        user: "http",
        state: 'S',
        cpu: 1.4,
        mem_mib: 16,
        threads: 2,
        kernel: false,
    },
    ProcSpec {
        pid: 602,
        ppid: 600,
        name: "nginx",
        user: "http",
        state: 'S',
        cpu: 1.1,
        mem_mib: 15,
        threads: 2,
        kernel: false,
    },
    ProcSpec {
        pid: 700,
        ppid: 1,
        name: "postgres",
        user: "postgres",
        state: 'S',
        cpu: 0.3,
        mem_mib: 28,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 701,
        ppid: 700,
        name: "postgres",
        user: "postgres",
        state: 'S',
        cpu: 2.2,
        mem_mib: 120,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 702,
        ppid: 700,
        name: "postgres",
        user: "postgres",
        state: 'S',
        cpu: 0.8,
        mem_mib: 80,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 703,
        ppid: 700,
        name: "postgres",
        user: "postgres",
        state: 'S',
        cpu: 0.4,
        mem_mib: 40,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 800,
        ppid: 1,
        name: "firefox",
        user: "alice",
        state: 'S',
        cpu: 6.0,
        mem_mib: 420,
        threads: 40,
        kernel: false,
    },
    ProcSpec {
        pid: 801,
        ppid: 800,
        name: "firefox",
        user: "alice",
        state: 'S',
        cpu: 11.0,
        mem_mib: 310,
        threads: 18,
        kernel: false,
    },
    ProcSpec {
        pid: 802,
        ppid: 800,
        name: "firefox",
        user: "alice",
        state: 'S',
        cpu: 4.5,
        mem_mib: 260,
        threads: 14,
        kernel: false,
    },
    ProcSpec {
        pid: 803,
        ppid: 800,
        name: "firefox",
        user: "alice",
        state: 'S',
        cpu: 2.2,
        mem_mib: 180,
        threads: 10,
        kernel: false,
    },
    ProcSpec {
        pid: 900,
        ppid: 1,
        name: "chrome",
        user: "alice",
        state: 'S',
        cpu: 5.0,
        mem_mib: 280,
        threads: 22,
        kernel: false,
    },
    ProcSpec {
        pid: 901,
        ppid: 900,
        name: "chrome",
        user: "alice",
        state: 'S',
        cpu: 8.0,
        mem_mib: 240,
        threads: 16,
        kernel: false,
    },
    ProcSpec {
        pid: 902,
        ppid: 900,
        name: "chrome",
        user: "alice",
        state: 'S',
        cpu: 3.4,
        mem_mib: 190,
        threads: 12,
        kernel: false,
    },
    ProcSpec {
        pid: 903,
        ppid: 900,
        name: "chrome",
        user: "alice",
        state: 'R',
        cpu: 7.5,
        mem_mib: 210,
        threads: 15,
        kernel: false,
    },
    ProcSpec {
        pid: 1000,
        ppid: 320,
        name: "cargo",
        user: "alice",
        state: 'S',
        cpu: 1.0,
        mem_mib: 48,
        threads: 6,
        kernel: false,
    },
    ProcSpec {
        pid: 1001,
        ppid: 1000,
        name: "rustc",
        user: "alice",
        state: 'R',
        cpu: 140.0,
        mem_mib: 900,
        threads: 8,
        kernel: false,
    },
    ProcSpec {
        pid: 1002,
        ppid: 1000,
        name: "rustc",
        user: "alice",
        state: 'R',
        cpu: 95.0,
        mem_mib: 640,
        threads: 8,
        kernel: false,
    },
    ProcSpec {
        pid: 1100,
        ppid: 320,
        name: "python3",
        user: "alice",
        state: 'S',
        cpu: 3.0,
        mem_mib: 70,
        threads: 2,
        kernel: false,
    },
    ProcSpec {
        pid: 1101,
        ppid: 1100,
        name: "python3",
        user: "alice",
        state: 'S',
        cpu: 1.5,
        mem_mib: 40,
        threads: 1,
        kernel: false,
    },
    ProcSpec {
        pid: 1200,
        ppid: 1,
        name: "node",
        user: "alice",
        state: 'S',
        cpu: 2.4,
        mem_mib: 110,
        threads: 7,
        kernel: false,
    },
    ProcSpec {
        pid: 1201,
        ppid: 1200,
        name: "node",
        user: "alice",
        state: 'S',
        cpu: 1.1,
        mem_mib: 80,
        threads: 4,
        kernel: false,
    },
    ProcSpec {
        pid: 1300,
        ppid: 1,
        name: "gnome-shell",
        user: "alice",
        state: 'S',
        cpu: 4.0,
        mem_mib: 220,
        threads: 12,
        kernel: false,
    },
    ProcSpec {
        pid: 1400,
        ppid: 1,
        name: "pipewire",
        user: "alice",
        state: 'S',
        cpu: 0.6,
        mem_mib: 16,
        threads: 3,
        kernel: false,
    },
    ProcSpec {
        pid: 1500,
        ppid: 320,
        name: "btm",
        user: "alice",
        state: 'S',
        cpu: 2.0,
        mem_mib: 24,
        threads: 2,
        kernel: false,
    },
];

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{ProcessMode, SortColumn, build_process_rows};

    #[test]
    fn snapshots_are_deterministic_and_cover_a_process_tree() {
        assert_eq!(fixture_snapshot(0), fixture_snapshot(0));
        assert_eq!(fixture_snapshot(7), fixture_snapshot(7));
        assert_ne!(
            fixture_snapshot(0).cpu.total_usage_pct,
            fixture_snapshot(1).cpu.total_usage_pct
        );
        let snap = fixture_snapshot(3);
        assert!(snap.processes.len() >= 35);
        assert_eq!(snap.cpu.cores.len(), 8);
        assert_eq!(snap.hostname, "rune-node");
        assert!(snap.networks.iter().any(|iface| iface.is_loopback));
        assert!(snap.sensors.len() >= 3);
        assert_eq!(snap.batteries.len(), 1);
        assert_eq!(snap.disks.len(), 2);
        let non_loop: f64 = snap
            .networks
            .iter()
            .filter(|iface| !iface.is_loopback)
            .map(|iface| iface.rx_bytes_per_sec)
            .sum();
        assert!((non_loop - snap.net_rx_total_bps).abs() < 0.001);
        assert!(fixture_snapshot(10).net_rx_total_bps > fixture_snapshot(1).net_rx_total_bps * 2.0);

        let names = snap.processes.iter().fold(
            std::collections::HashMap::<&str, usize>::new(),
            |mut map, proc| {
                *map.entry(proc.name.as_str()).or_insert(0) += 1;
                map
            },
        );
        assert_eq!(names.get("firefox").copied(), Some(4));
        assert_eq!(names.get("chrome").copied(), Some(4));
        assert_eq!(names.get("nginx").copied(), Some(3));
        assert!(names.get("rustc").copied().unwrap_or(0) >= 2);

        let grouped = build_process_rows(
            &snap.processes,
            ProcessMode::Grouped,
            "",
            SortColumn::Count,
            true,
        );
        let firefox = grouped
            .iter()
            .find(|row| row.display_name == "firefox")
            .unwrap();
        assert_eq!(firefox.count, 4);
        assert!(firefox.cpu_pct > 20.0);
        let tree = build_process_rows(
            &snap.processes,
            ProcessMode::Tree,
            "vim",
            SortColumn::Pid,
            false,
        );
        assert!(
            tree.iter()
                .any(|row| row.display_name == "vim" && row.depth >= 3)
        );
        assert!(
            tree.iter()
                .any(|row| row.pid == 320 && row.display_name == "bash")
        );
        assert!(tree.iter().all(|row| row.display_name != "nginx"));
    }

    #[test]
    fn history_records_each_requested_step() {
        let (empty_snap, empty_hist) = fixture_history(0);
        assert_eq!(empty_snap, fixture_snapshot(0));
        assert!(empty_hist.cpu_total.is_empty());

        let (snap, history) = fixture_history(6);
        assert_eq!(snap, fixture_snapshot(5));
        assert_eq!(history.cpu_total.len(), 6);
        assert_eq!(history.mem_pct.len(), 6);
        assert_eq!(history.net_rx_bps.len(), 6);
        assert_eq!(history.disk_read_bps.len(), 6);
        assert_eq!(history.per_core.len(), 8);
        assert!(history.per_core.iter().all(|ring| ring.len() == 6));
        let again = fixture_history(6);
        assert_eq!(again.0, snap);
        assert_eq!(again.1.cpu_total.as_vec(), history.cpu_total.as_vec());
        assert_eq!(again.1.net_rx_bps.as_vec(), history.net_rx_bps.as_vec());
        assert_eq!(history.psi_cpu.len(), 6);
        assert_eq!(history.psi_mem.len(), 6);
        assert_eq!(history.psi_io.len(), 6);
    }

    #[test]
    fn fixture_populates_psi_memory_disk_sockets_and_process_metadata() {
        let snap = fixture_snapshot(4);
        assert!(snap.psi.cpu_some_pct > 0.0 && snap.psi.cpu_some_pct <= 100.0);
        assert!(snap.psi.mem_some_pct >= snap.psi.mem_full_pct);
        assert!(snap.psi.io_some_pct >= snap.psi.io_full_pct);

        assert!(snap.mem.shared_bytes > 0);
        assert!(snap.mem.dirty_bytes > 0);
        assert!(snap.mem.slab_bytes > 0);

        for disk in &snap.disks {
            assert!((0.0..=100.0).contains(&disk.busy_pct) && disk.busy_pct > 0.0);
            assert!(disk.await_ms > 0.0);
        }

        assert_eq!(snap.sockets.len(), 8);
        assert!(
            snap.sockets
                .iter()
                .any(|s| s.state == "LISTEN" && s.process == "postgres")
        );
        assert!(
            snap.sockets
                .iter()
                .any(|s| s.state == "LISTEN" && s.process == "nginx")
        );
        assert!(
            snap.sockets
                .iter()
                .any(|s| s.state == "ESTAB" && s.process == "firefox")
        );
        assert!(
            snap.sockets
                .iter()
                .any(|s| s.state == "ESTAB" && s.process == "chrome")
        );

        let postgres = snap
            .processes
            .iter()
            .find(|proc| proc.pid == 700)
            .expect("postgres master");
        assert_eq!(postgres.unit.as_deref(), Some("postgresql.service"));
        assert_eq!(postgres.cwd.as_deref(), Some("/var/lib/postgresql/data"));
        assert_eq!(postgres.exe.as_deref(), Some("/usr/bin/postgres"));
        assert_eq!(postgres.listening_ports, vec!["TCP 127.0.0.1:5432"]);

        let rustc = snap
            .processes
            .iter()
            .find(|proc| proc.pid == 1001)
            .expect("rustc");
        assert_eq!(rustc.nice, 5);
        assert_eq!(rustc.unit.as_deref(), Some("session-2.scope"));
        assert_eq!(rustc.cwd.as_deref(), Some("/home/alice/projects/vitals"));

        let kthread = snap
            .processes
            .iter()
            .find(|proc| proc.pid == 2)
            .expect("kthreadd");
        assert_eq!(kthread.unit, None);
        assert_eq!(kthread.cwd, None);
        assert_eq!(kthread.exe, None);
        assert!(kthread.listening_ports.is_empty());
        assert!(kthread.open_files.is_empty());

        assert!(snap.open_files.len() >= 18);
        for kind in [
            OpenFileKind::File,
            OpenFileKind::Socket,
            OpenFileKind::Device,
            OpenFileKind::Pipe,
        ] {
            assert!(snap.open_files.iter().any(|e| e.kind == kind));
        }
        assert!(postgres.open_files.iter().any(|p| p.contains("PG_VERSION")));
        assert!(rustc.open_files.iter().any(|p| p.ends_with("src/main.rs")));
    }
}
