//! Color schemes and desktop theme detection for Vitals.
//!
//! [`palette`] stays the Obsidian instrument face. The other built-in schemes are Gruvbox,
//! Catppuccin, Tokyo Night, Nord, and Rosé Pine, each with a dark and a light face. `System`
//! follows the desktop: `gruvbox-mode`, Noctalia, Strata, Herdr, and GTK `@define-color`s.
//! Surface colors are authored in sRGB; series hues sit in the same families in both modes.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use rune::Color;
use rune::color::{hex, srgb_decode};

/// Semantic colors for chrome, series, and threshold readouts.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Palette {
    pub base: Color,
    pub panel: Color,
    pub panel_alt: Color,
    pub chrome: Color,
    pub border: Color,
    pub border_focus: Color,
    pub text: Color,
    pub muted: Color,
    pub subtle: Color,
    pub accent: Color,
    pub cpu_total: Color,
    pub cpu_cores: [Color; 8],
    pub mem_used: Color,
    pub mem_cached: Color,
    pub swap_used: Color,
    pub net_rx: Color,
    pub net_tx: Color,
    pub disk_read: Color,
    pub disk_write: Color,
    pub ok: Color,
    pub warn: Color,
    pub crit: Color,
}

/// `dark` selects the obsidian instrument face. Light mode is the same hues in ink weights.
pub fn palette(dark: bool) -> Palette {
    if dark {
        Palette {
            base: paint("#0d1117"),
            panel: paint("#151b23"),
            panel_alt: paint("#1c2430"),
            chrome: paint("#090d12"),
            border: paint("#283242"),
            border_focus: paint("#58a6ff"),
            text: paint("#e8eef6"),
            muted: paint("#8b9bb0"),
            subtle: paint("#5d6d82"),
            accent: paint("#3ee0ff"),
            cpu_total: paint("#79b8ff"),
            cpu_cores: cores([
                "#2ec5d6", "#5b8def", "#8b7cf6", "#d56ad6", "#f07178", "#e3b341", "#8fce5a",
                "#3dbe8a",
            ]),
            mem_used: paint("#b48cff"),
            mem_cached: paint("#6d8eb5"),
            swap_used: paint("#e07ab0"),
            net_rx: paint("#1aae9f"),
            net_tx: paint("#f0a05a"),
            disk_read: paint("#6cb6c9"),
            disk_write: paint("#ff8a5b"),
            ok: paint("#3dd68c"),
            warn: paint("#f0b429"),
            crit: paint("#ff5d5d"),
        }
    } else {
        Palette {
            base: paint("#f6f8fa"),
            panel: paint("#ffffff"),
            panel_alt: paint("#eef2f7"),
            chrome: paint("#e5ebf1"),
            border: paint("#d0d8e2"),
            border_focus: paint("#0969da"),
            text: paint("#1b2430"),
            muted: paint("#526274"),
            subtle: paint("#7b8b9e"),
            accent: paint("#0077a8"),
            cpu_total: paint("#1858c7"),
            cpu_cores: cores([
                "#0f7f8c", "#1f4fd0", "#5b45c6", "#a33d9a", "#c43d45", "#9a6b00", "#4e7d22",
                "#0d7a52",
            ]),
            mem_used: paint("#6d4ec2"),
            mem_cached: paint("#5c7394"),
            swap_used: paint("#b14b86"),
            net_rx: paint("#0b7a56"),
            net_tx: paint("#b86a12"),
            disk_read: paint("#1a6fbf"),
            disk_write: paint("#c4512c"),
            ok: paint("#1b7f45"),
            warn: paint("#9a6700"),
            crit: paint("#cf222e"),
        }
    }
}

impl Palette {
    /// Core hue for `idx`, wrapping so a machine with more than eight threads stays in the scale.
    pub fn core_color(&self, idx: usize) -> Color {
        self.cpu_cores[idx % self.cpu_cores.len()]
    }

    /// Usage readout: ok below 65%, warn from 65% up to 85%, crit at 85% and above.
    /// NaN and -inf return ok; +inf returns crit.
    pub fn usage_color(&self, pct: f32) -> Color {
        self.threshold(pct, 65.0, 85.0)
    }

    /// Temperature readout in Celsius: ok below 65, warn from 65 up to 82, crit at 82 and above.
    /// NaN and -inf return ok; +inf returns crit.
    pub fn temp_color(&self, temp_c: f32) -> Color {
        self.threshold(temp_c, 65.0, 82.0)
    }

    /// NaN and -inf return ok; +inf returns crit. Finite values use `warn_at` and `crit_at`.
    fn threshold(&self, value: f32, warn_at: f32, crit_at: f32) -> Color {
        if value.is_nan() || value < warn_at {
            self.ok
        } else if value < crit_at {
            self.warn
        } else {
            self.crit
        }
    }
}

fn paint(s: &str) -> Color {
    hex(s).unwrap_or_else(|| panic!("invalid palette color {s}"))
}

fn cores(colors: [&str; 8]) -> [Color; 8] {
    colors.map(paint)
}

/// How the window chooses dark or light. `System` follows the desktop, then the portal.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum AppearanceMode {
    #[default]
    System,
    Dark,
    Light,
}

impl AppearanceMode {
    /// Short name for menus.
    pub fn label(self) -> &'static str {
        match self {
            Self::System => "System",
            Self::Dark => "Dark",
            Self::Light => "Light",
        }
    }

    /// Stable token for the CLI and `settings.json`.
    pub fn slug(self) -> &'static str {
        match self {
            Self::System => "system",
            Self::Dark => "dark",
            Self::Light => "light",
        }
    }

    /// Parses `system` / `auto`, `dark`, or `light`.
    pub fn from_slug(value: &str) -> Option<Self> {
        match normalize_slug(value).as_str() {
            "system" | "auto" => Some(Self::System),
            "dark" => Some(Self::Dark),
            "light" => Some(Self::Light),
            _ => None,
        }
    }

    /// `true` when the window should paint the dark face.
    pub fn resolve(self, system_dark: bool) -> bool {
        match self {
            Self::System => system_dark,
            Self::Dark => true,
            Self::Light => false,
        }
    }

    /// System → Dark → Light → System.
    pub fn cycle(self) -> Self {
        match self {
            Self::System => Self::Dark,
            Self::Dark => Self::Light,
            Self::Light => Self::System,
        }
    }

    /// `None` leaves the choice to the desktop. Dark and Light are explicit.
    pub fn as_dark_option(self) -> Option<bool> {
        match self {
            Self::System => None,
            Self::Dark => Some(true),
            Self::Light => Some(false),
        }
    }
}

/// Built-in faces plus `System`, which uses a [`SystemThemeSnapshot`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum ColorSchemeId {
    #[default]
    System,
    Gruvbox,
    Catppuccin,
    Obsidian,
    TokyoNight,
    Nord,
    RosePine,
}

impl ColorSchemeId {
    /// Menu order, also the cycle order.
    pub const ALL: [ColorSchemeId; 7] = [
        Self::System,
        Self::Gruvbox,
        Self::Catppuccin,
        Self::Obsidian,
        Self::TokyoNight,
        Self::Nord,
        Self::RosePine,
    ];

    /// Name shown on scheme cards.
    pub fn label(self) -> &'static str {
        match self {
            Self::System => "System",
            Self::Gruvbox => "Gruvbox",
            Self::Catppuccin => "Catppuccin",
            Self::Obsidian => "Obsidian",
            Self::TokyoNight => "Tokyo Night",
            Self::Nord => "Nord",
            Self::RosePine => "Rosé Pine",
        }
    }

    /// Stable token for `--color-scheme` and `settings.json`.
    pub fn slug(self) -> &'static str {
        match self {
            Self::System => "system",
            Self::Gruvbox => "gruvbox",
            Self::Catppuccin => "catppuccin",
            Self::Obsidian => "obsidian",
            Self::TokyoNight => "tokyo-night",
            Self::Nord => "nord",
            Self::RosePine => "rose-pine",
        }
    }

    /// Parses a slug, a theme file name, or a desktop builtin name.
    pub fn from_slug(value: &str) -> Option<Self> {
        let slug = normalize_slug(value);
        if slug == "system" || slug == "auto" {
            return Some(Self::System);
        }
        if slug == "gruvbox" || slug.starts_with("gruvbox-") {
            return Some(Self::Gruvbox);
        }
        if slug == "catppuccin"
            || slug.starts_with("catppuccin-")
            || matches!(slug.as_str(), "mocha" | "latte" | "frappe" | "macchiato")
        {
            return Some(Self::Catppuccin);
        }
        if slug == "obsidian" {
            return Some(Self::Obsidian);
        }
        if slug == "tokyo-night" || slug.starts_with("tokyo-night-") || slug == "tokyonight" {
            return Some(Self::TokyoNight);
        }
        if slug == "nord" || slug.starts_with("nord-") || slug == "nordic" {
            return Some(Self::Nord);
        }
        if slug == "rose-pine" || slug.starts_with("rose-pine-") || slug == "rosepine" {
            return Some(Self::RosePine);
        }
        None
    }

    /// Next entry in [`Self::ALL`], wrapping after Rosé Pine.
    pub fn cycle(self) -> Self {
        let index = Self::ALL
            .iter()
            .position(|scheme| *scheme == self)
            .unwrap_or(0);
        Self::ALL[(index + 1) % Self::ALL.len()]
    }

    /// Face for `dark`. `System` reads the snapshot; every other id ignores it.
    pub fn palette(self, dark: bool, system: &SystemThemeSnapshot) -> Palette {
        if self == Self::System {
            return if dark { system.dark } else { system.light };
        }
        builtin_palette(self, dark)
    }
}

/// Authored sRGB roles for one face. Series slots stay inside the scheme's hue family.
struct Ink {
    base: &'static str,
    chrome: &'static str,
    panel: &'static str,
    panel_alt: &'static str,
    border: &'static str,
    border_focus: &'static str,
    text: &'static str,
    muted: &'static str,
    subtle: &'static str,
    accent: &'static str,
    ok: &'static str,
    warn: &'static str,
    crit: &'static str,
    cores: [&'static str; 8],
    cpu_total: &'static str,
    mem_used: &'static str,
    mem_cached: &'static str,
    swap_used: &'static str,
    net_rx: &'static str,
    net_tx: &'static str,
    disk_read: &'static str,
    disk_write: &'static str,
}

fn ink(face: Ink) -> Palette {
    Palette {
        base: paint(face.base),
        panel: paint(face.panel),
        panel_alt: paint(face.panel_alt),
        chrome: paint(face.chrome),
        border: paint(face.border),
        border_focus: paint(face.border_focus),
        text: paint(face.text),
        muted: paint(face.muted),
        subtle: paint(face.subtle),
        accent: paint(face.accent),
        cpu_total: paint(face.cpu_total),
        cpu_cores: cores(face.cores),
        mem_used: paint(face.mem_used),
        mem_cached: paint(face.mem_cached),
        swap_used: paint(face.swap_used),
        net_rx: paint(face.net_rx),
        net_tx: paint(face.net_tx),
        disk_read: paint(face.disk_read),
        disk_write: paint(face.disk_write),
        ok: paint(face.ok),
        warn: paint(face.warn),
        crit: paint(face.crit),
    }
}

fn builtin_palette(scheme: ColorSchemeId, dark: bool) -> Palette {
    match scheme {
        ColorSchemeId::System | ColorSchemeId::Obsidian => palette(dark),
        ColorSchemeId::Gruvbox => {
            if dark {
                gruvbox_dark()
            } else {
                gruvbox_light()
            }
        }
        ColorSchemeId::Catppuccin => {
            if dark {
                catppuccin_dark()
            } else {
                catppuccin_light()
            }
        }
        ColorSchemeId::TokyoNight => {
            if dark {
                tokyo_night_dark()
            } else {
                tokyo_night_light()
            }
        }
        ColorSchemeId::Nord => {
            if dark {
                nord_dark()
            } else {
                nord_light()
            }
        }
        ColorSchemeId::RosePine => {
            if dark {
                rose_pine_dark()
            } else {
                rose_pine_light()
            }
        }
    }
}

/// Gruvbox Dark from the desktop palette: bg `#282828`, aqua/green/purple/orange series.
fn gruvbox_dark() -> Palette {
    ink(Ink {
        base: "#282828",
        chrome: "#1d2021",
        panel: "#32302f",
        panel_alt: "#3c3836",
        border: "#504945",
        border_focus: "#b8bb26",
        text: "#ebdbb2",
        muted: "#a89984",
        subtle: "#928374",
        accent: "#b8bb26",
        ok: "#b8bb26",
        warn: "#fabd2f",
        crit: "#fb4934",
        cores: [
            "#83a598", "#8ec07c", "#d3869b", "#fe8019", "#fabd2f", "#b8bb26", "#fb4934", "#458588",
        ],
        cpu_total: "#83a598",
        mem_used: "#d3869b",
        mem_cached: "#665c54",
        swap_used: "#d65d0e",
        net_rx: "#8ec07c",
        net_tx: "#fe8019",
        disk_read: "#458588",
        disk_write: "#cc241d",
    })
}

/// Gruvbox Light from the desktop palette: bg `#fbf1c7`, ink weights of the same hues.
fn gruvbox_light() -> Palette {
    ink(Ink {
        base: "#fbf1c7",
        chrome: "#f2e5bc",
        panel: "#f9f5d7",
        panel_alt: "#ebdbb2",
        border: "#d5c4a1",
        border_focus: "#79740e",
        text: "#3c3836",
        muted: "#665c54",
        subtle: "#928374",
        accent: "#79740e",
        ok: "#79740e",
        warn: "#b57614",
        crit: "#9d0006",
        cores: [
            "#076678", "#427b58", "#8f3f71", "#af3a03", "#b57614", "#79740e", "#9d0006", "#458588",
        ],
        cpu_total: "#076678",
        mem_used: "#8f3f71",
        mem_cached: "#7c6f64",
        swap_used: "#cc241d",
        net_rx: "#427b58",
        net_tx: "#af3a03",
        disk_read: "#458588",
        disk_write: "#9d0006",
    })
}

/// Catppuccin Mocha. Panel `#24273a` lifts cards off the `#1e1e2e` base.
fn catppuccin_dark() -> Palette {
    ink(Ink {
        base: "#1e1e2e",
        chrome: "#181825",
        panel: "#24273a",
        panel_alt: "#313244",
        border: "#45475a",
        border_focus: "#89b4fa",
        text: "#cdd6f4",
        muted: "#a6adc8",
        subtle: "#6c7086",
        accent: "#89b4fa",
        ok: "#a6e3a1",
        warn: "#f9e2af",
        crit: "#f38ba8",
        cores: [
            "#89b4fa", "#94e2d5", "#cba6f7", "#fab387", "#f9e2af", "#a6e3a1", "#f38ba8", "#74c7ec",
        ],
        cpu_total: "#89b4fa",
        mem_used: "#cba6f7",
        mem_cached: "#74c7ec",
        swap_used: "#f5c2e7",
        net_rx: "#94e2d5",
        net_tx: "#fab387",
        disk_read: "#89dceb",
        disk_write: "#eba0ac",
    })
}

/// Catppuccin Latte.
fn catppuccin_light() -> Palette {
    ink(Ink {
        base: "#eff1f5",
        chrome: "#e6e9ef",
        panel: "#ffffff",
        panel_alt: "#ccd0da",
        border: "#bcc0cc",
        border_focus: "#1e66f5",
        text: "#4c4f69",
        muted: "#6c6f85",
        subtle: "#9ca0b0",
        accent: "#1e66f5",
        ok: "#40a02b",
        warn: "#df8e1d",
        crit: "#d20f39",
        cores: [
            "#1e66f5", "#179299", "#8839ef", "#fe640b", "#df8e1d", "#40a02b", "#d20f39", "#209fb5",
        ],
        cpu_total: "#1e66f5",
        mem_used: "#8839ef",
        mem_cached: "#7287fd",
        swap_used: "#ea76cb",
        net_rx: "#179299",
        net_tx: "#fe640b",
        disk_read: "#209fb5",
        disk_write: "#e64553",
    })
}

/// Tokyo Night.
fn tokyo_night_dark() -> Palette {
    ink(Ink {
        base: "#1a1b26",
        chrome: "#16161e",
        panel: "#1f2335",
        panel_alt: "#292e42",
        border: "#3b4261",
        border_focus: "#7aa2f7",
        text: "#c0caf5",
        muted: "#a9b1d6",
        subtle: "#565f89",
        accent: "#7aa2f7",
        ok: "#9ece6a",
        warn: "#e0af68",
        crit: "#f7768e",
        cores: [
            "#7aa2f7", "#7dcfff", "#bb9af7", "#ff9e64", "#e0af68", "#9ece6a", "#f7768e", "#73daca",
        ],
        cpu_total: "#7aa2f7",
        mem_used: "#bb9af7",
        mem_cached: "#7dcfff",
        swap_used: "#9d7cd8",
        net_rx: "#73daca",
        net_tx: "#ff9e64",
        disk_read: "#2ac3de",
        disk_write: "#ff9e64",
    })
}

/// Tokyo Night Day.
fn tokyo_night_light() -> Palette {
    ink(Ink {
        base: "#e1e2e7",
        chrome: "#d5d6db",
        panel: "#eaebed",
        panel_alt: "#c4c8da",
        border: "#a8aecb",
        border_focus: "#2e7de9",
        text: "#3760bf",
        muted: "#6172b0",
        subtle: "#848cb5",
        accent: "#2e7de9",
        ok: "#587539",
        warn: "#8c6c3e",
        crit: "#f52a65",
        cores: [
            "#2e7de9", "#007197", "#7847bd", "#b15c00", "#8c6c3e", "#587539", "#f52a65", "#118c74",
        ],
        cpu_total: "#2e7de9",
        mem_used: "#7847bd",
        mem_cached: "#007197",
        swap_used: "#9854f1",
        net_rx: "#118c74",
        net_tx: "#b15c00",
        disk_read: "#007197",
        disk_write: "#f52a65",
    })
}

/// Nord Polar Night, with frost and aurora as the series.
fn nord_dark() -> Palette {
    ink(Ink {
        base: "#2e3440",
        chrome: "#242933",
        panel: "#3b4252",
        panel_alt: "#434c5e",
        border: "#4c566a",
        border_focus: "#88c0d0",
        text: "#eceff4",
        muted: "#d8dee9",
        subtle: "#9099ab",
        accent: "#88c0d0",
        ok: "#a3be8c",
        warn: "#ebcb8b",
        crit: "#bf616a",
        cores: [
            "#88c0d0", "#8fbcbb", "#b48ead", "#d08770", "#ebcb8b", "#a3be8c", "#bf616a", "#81a1c1",
        ],
        cpu_total: "#88c0d0",
        mem_used: "#b48ead",
        mem_cached: "#81a1c1",
        swap_used: "#d08770",
        net_rx: "#8fbcbb",
        net_tx: "#d08770",
        disk_read: "#5e81ac",
        disk_write: "#bf616a",
    })
}

/// Nord Snow Storm. Status hues are darkened so they stay readable on `#eceff4`.
fn nord_light() -> Palette {
    ink(Ink {
        base: "#eceff4",
        chrome: "#e5e9f0",
        panel: "#f8fafc",
        panel_alt: "#d8dee9",
        border: "#c0c8d8",
        border_focus: "#5e81ac",
        text: "#2e3440",
        muted: "#4c566a",
        subtle: "#7b88a1",
        accent: "#5e81ac",
        ok: "#4f7a38",
        warn: "#b47b22",
        crit: "#a53c46",
        cores: [
            "#5e81ac", "#2f6f6d", "#7a4e86", "#a15c45", "#b47b22", "#4f7a38", "#a53c46", "#3d5f8a",
        ],
        cpu_total: "#5e81ac",
        mem_used: "#7a4e86",
        mem_cached: "#3d5f8a",
        swap_used: "#a15c45",
        net_rx: "#2f6f6d",
        net_tx: "#a15c45",
        disk_read: "#3d5f8a",
        disk_write: "#a53c46",
    })
}

/// Rosé Pine main.
fn rose_pine_dark() -> Palette {
    ink(Ink {
        base: "#191724",
        chrome: "#1f1d2e",
        panel: "#21202e",
        panel_alt: "#26233a",
        border: "#403d52",
        border_focus: "#c4a7e7",
        text: "#e0def4",
        muted: "#908caa",
        subtle: "#6e6a86",
        accent: "#c4a7e7",
        ok: "#9ccfd8",
        warn: "#f6c177",
        crit: "#eb6f92",
        cores: [
            "#c4a7e7", "#9ccfd8", "#31748f", "#ebbcba", "#f6c177", "#3e8fb0", "#eb6f92", "#ea9a97",
        ],
        cpu_total: "#9ccfd8",
        mem_used: "#c4a7e7",
        mem_cached: "#31748f",
        swap_used: "#ebbcba",
        net_rx: "#31748f",
        net_tx: "#f6c177",
        disk_read: "#3e8fb0",
        disk_write: "#eb6f92",
    })
}

/// Rosé Pine Dawn.
fn rose_pine_light() -> Palette {
    ink(Ink {
        base: "#faf4ed",
        chrome: "#f2e9e1",
        panel: "#fffaf3",
        panel_alt: "#dfdad9",
        border: "#cecacd",
        border_focus: "#907aa9",
        text: "#575279",
        muted: "#797593",
        subtle: "#9893a5",
        accent: "#907aa9",
        ok: "#286983",
        warn: "#ea9d34",
        crit: "#b4637a",
        cores: [
            "#907aa9", "#56949f", "#286983", "#d7827e", "#ea9d34", "#b4637a", "#6b4c8a", "#3e6f86",
        ],
        cpu_total: "#286983",
        mem_used: "#907aa9",
        mem_cached: "#56949f",
        swap_used: "#d7827e",
        net_rx: "#286983",
        net_tx: "#ea9d34",
        disk_read: "#56949f",
        disk_write: "#b4637a",
    })
}

/// Desktop appearance captured for [`ColorSchemeId::System`].
#[derive(Clone, Debug, PartialEq)]
pub struct SystemThemeSnapshot {
    /// `Some(true)` is dark. `None` means no desktop file said, so the portal decides.
    pub system_dark: Option<bool>,
    /// Label for the System card, such as `Gruvbox` or `Matugen`.
    pub detected_name: String,
    /// Built-in family the desktop named, before GTK overrides. Custom themes keep Obsidian
    /// here and put the human name in [`Self::detected_name`].
    pub detected_scheme: ColorSchemeId,
    pub dark: Palette,
    pub light: Palette,
}

impl Default for SystemThemeSnapshot {
    fn default() -> Self {
        Self {
            system_dark: None,
            detected_name: "Obsidian".to_string(),
            detected_scheme: ColorSchemeId::Obsidian,
            dark: palette(true),
            light: palette(false),
        }
    }
}

/// XDG config directory, or `~/.config`.
pub(crate) fn config_dir() -> PathBuf {
    env_dir("XDG_CONFIG_HOME").unwrap_or_else(|| home_dir().join(".config"))
}

/// XDG state directory, or `~/.local/state`.
pub(crate) fn state_dir() -> PathBuf {
    env_dir("XDG_STATE_HOME").unwrap_or_else(|| home_dir().join(".local").join("state"))
}

/// Reads the desktop theme from `config_dir` and `state_dir`.
///
/// Dark/light, first hit wins: `gruvbox-mode`, Noctalia `[theme] mode`, GTK
/// `window_bg_color` / `theme_bg_color` luminance, `gtk-application-prefer-dark-theme`,
/// then the Strata theme file's `background` luminance (or its `-dark` / `-light` name).
/// The scheme name comes from Noctalia `builtin`, Strata `theme`, Herdr `settings.json`, or
/// the GTK `@import`, and falls back to Gruvbox when `gruvbox.css` or `gruvbox-mode` exists.
/// A Strata name that is not a built-in still selects that theme file. Strata theme TOML,
/// Herdr theme JSON, and GTK `@define-color`s then overlay the matching dark or light face.
pub fn detect_system_theme(config_dir: &Path, state_dir: &Path) -> SystemThemeSnapshot {
    let noctalia = read_noctalia(config_dir, state_dir);
    let (gtk_colors, gtk_import) = gtk_define_colors(config_dir);
    let mut system_dark =
        detect_system_dark(config_dir, state_dir, noctalia.as_deref(), &gtk_colors);
    let (detected_scheme, detected_name) = identify_scheme(
        config_dir,
        state_dir,
        noctalia.as_deref(),
        gtk_import.as_deref(),
    );
    let mut dark = builtin_palette(detected_scheme, true);
    let mut light = builtin_palette(detected_scheme, false);
    if let Some(is_dark) = overlay_strata_themes(config_dir, &mut dark, &mut light)
        && system_dark.is_none()
    {
        system_dark = Some(is_dark);
    }
    overlay_herdr_themes(config_dir, &mut dark, &mut light);
    let custom = gtk_import
        .as_deref()
        .is_none_or(|name| ColorSchemeId::from_slug(name).is_none())
        && !gtk_colors.is_empty();
    overlay_gtk(&mut dark, &mut light, &gtk_colors, custom);
    SystemThemeSnapshot {
        system_dark,
        detected_name,
        detected_scheme,
        dark,
        light,
    }
}

/// [`detect_system_theme`] for the current user's XDG directories.
pub fn detect_system_theme_default() -> SystemThemeSnapshot {
    detect_system_theme(&config_dir(), &state_dir())
}

fn env_dir(key: &str) -> Option<PathBuf> {
    let value = std::env::var_os(key)?;
    if value.is_empty() {
        return None;
    }
    Some(PathBuf::from(value))
}

fn home_dir() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/"))
}

fn read_to_string(path: &Path) -> Option<String> {
    std::fs::read_to_string(path).ok()
}

fn read_noctalia(config_dir: &Path, state_dir: &Path) -> Option<String> {
    read_to_string(&state_dir.join("noctalia").join("settings.toml"))
        .or_else(|| read_to_string(&config_dir.join("noctalia").join("settings.toml")))
}

fn detect_system_dark(
    config_dir: &Path,
    state_dir: &Path,
    noctalia: Option<&str>,
    gtk_colors: &HashMap<String, Color>,
) -> Option<bool> {
    if let Some(text) = read_to_string(&state_dir.join("gruvbox-mode"))
        && let Some(mode) = mode_flag(&text)
    {
        return Some(mode);
    }
    if let Some(text) = noctalia
        && let Some(mode) = toml_section_value(text, "theme", "mode")
        && let Some(flag) = mode_flag(&mode)
    {
        return Some(flag);
    }
    if let Some(flag) = gtk_background_dark(gtk_colors) {
        return Some(flag);
    }
    gtk_settings_dark(config_dir)
}

fn named_scheme(value: &str) -> Option<ColorSchemeId> {
    ColorSchemeId::from_slug(value).filter(|scheme| *scheme != ColorSchemeId::System)
}

fn mode_flag(text: &str) -> Option<bool> {
    match normalize_slug(text).as_str() {
        "dark" => Some(true),
        "light" => Some(false),
        _ => None,
    }
}

fn gtk_background_dark(colors: &HashMap<String, Color>) -> Option<bool> {
    let bg = colors
        .get("window_bg_color")
        .or_else(|| colors.get("theme_bg_color"))?;
    Some(bg.luminance() < 0.5)
}

fn gtk_settings_dark(config_dir: &Path) -> Option<bool> {
    for relative in ["gtk-4.0/settings.ini", "gtk-3.0/settings.ini"] {
        let Some(text) = read_to_string(&config_dir.join(relative)) else {
            continue;
        };
        for line in text.lines() {
            let Some(value) = assignment(line, "gtk-application-prefer-dark-theme") else {
                continue;
            };
            return match normalize_slug(&unquote(value)).as_str() {
                "1" | "true" | "yes" => Some(true),
                "0" | "false" | "no" => Some(false),
                _ => None,
            };
        }
    }
    None
}

fn identify_scheme(
    config_dir: &Path,
    state_dir: &Path,
    noctalia: Option<&str>,
    gtk_import: Option<&str>,
) -> (ColorSchemeId, String) {
    if let Some(text) = noctalia
        && let Some(builtin) = toml_section_value(text, "theme", "builtin")
    {
        if let Some(scheme) = named_scheme(&builtin) {
            return (scheme, scheme.label().to_string());
        }
        if !builtin.is_empty() && ColorSchemeId::from_slug(&builtin).is_none() {
            return (ColorSchemeId::Obsidian, display_name(&builtin));
        }
    }
    if let Some(text) = read_to_string(&config_dir.join("strata").join("settings.toml"))
        && let Some(theme) = root_assignment(&text, "theme")
        && safe_theme_name(&theme)
    {
        if let Some(scheme) = named_scheme(&theme) {
            return (scheme, scheme.label().to_string());
        }
        return (ColorSchemeId::Obsidian, display_name(&theme));
    }
    if let Some(text) = read_to_string(&config_dir.join("herdr-app").join("settings.json"))
        && let Ok(value) = serde_json::from_str::<serde_json::Value>(&text)
    {
        for key in ["dark", "light"] {
            let Some(name) = value
                .get("theme")
                .and_then(|theme| theme.get(key))
                .and_then(|entry| entry.as_str())
            else {
                continue;
            };
            if let Some(scheme) = named_scheme(name) {
                return (scheme, scheme.label().to_string());
            }
        }
    }
    if let Some(name) = gtk_import {
        if let Some(scheme) = named_scheme(name) {
            return (scheme, scheme.label().to_string());
        }
        return (ColorSchemeId::Obsidian, display_name(name));
    }
    let gruvbox_css = config_dir.join("gtk-4.0").join("gruvbox.css").is_file()
        || config_dir.join("gtk-3.0").join("gruvbox.css").is_file();
    if gruvbox_css || state_dir.join("gruvbox-mode").is_file() {
        return (ColorSchemeId::Gruvbox, "Gruvbox".to_string());
    }
    (ColorSchemeId::Obsidian, "Obsidian".to_string())
}

fn display_name(raw: &str) -> String {
    let stem = raw.rsplit(['/', '\\']).next().unwrap_or(raw);
    let stem = strip_known_extension(stem);
    let lower = stem.to_ascii_lowercase();
    if lower.contains("dank") || lower.contains("matugen") {
        return "Matugen".to_string();
    }
    if lower == "colors" || lower == "gtk" {
        return "Desktop".to_string();
    }
    if let Some(scheme) = named_scheme(stem) {
        return scheme.label().to_string();
    }
    let mut name = String::new();
    for word in stem.split(['-', '_', '.']) {
        if word.is_empty() {
            continue;
        }
        if !name.is_empty() {
            name.push(' ');
        }
        let mut chars = word.chars();
        if let Some(first) = chars.next() {
            name.extend(first.to_uppercase());
            name.extend(chars.flat_map(|ch| ch.to_lowercase()));
        }
    }
    if name.is_empty() {
        "Desktop".to_string()
    } else {
        name
    }
}

fn gtk_define_colors(config_dir: &Path) -> (HashMap<String, Color>, Option<String>) {
    let Some(css) = read_to_string(&config_dir.join("gtk-4.0").join("gtk.css")) else {
        return (HashMap::new(), None);
    };
    let import = import_file_name(&css);
    let mut colors = HashMap::new();
    if let Some(name) = import.as_deref()
        && let Some(path) = resolve_import(config_dir, name)
        && let Some(imported) = read_to_string(&path)
    {
        colors.extend(parse_define_colors(&imported));
    }
    colors.extend(parse_define_colors(&css));
    (colors, import)
}

fn import_file_name(css: &str) -> Option<String> {
    let index = css.find("@import")?;
    let rest = css[index + "@import".len()..].trim_start();
    let raw = if let Some(rest) = rest.strip_prefix("url(") {
        quoted_or_bare(rest.trim_start(), ')')?
    } else {
        quoted_or_bare(rest, ';')?
    };
    let name = raw.trim().trim_matches(['"', '\'']);
    if name.is_empty()
        || name.contains("..")
        || name.contains('/')
        || name.contains('\\')
        || name.contains(':')
    {
        return None;
    }
    Some(name.to_string())
}

fn quoted_or_bare(rest: &str, terminator: char) -> Option<&str> {
    let rest = rest.trim_start();
    if let Some(stripped) = rest.strip_prefix('"') {
        let end = stripped.find('"')?;
        return Some(&stripped[..end]);
    }
    if let Some(stripped) = rest.strip_prefix('\'') {
        let end = stripped.find('\'')?;
        return Some(&stripped[..end]);
    }
    let end = rest.find(terminator).unwrap_or(rest.len());
    let token = rest[..end].trim();
    (!token.is_empty()).then_some(token)
}

fn resolve_import(config_dir: &Path, name: &str) -> Option<PathBuf> {
    [
        config_dir.join("gtk-4.0").join(name),
        config_dir.join("gtk-3.0").join(name),
    ]
    .into_iter()
    .find(|path| path.is_file())
}

fn parse_define_colors(css: &str) -> HashMap<String, Color> {
    let mut colors = HashMap::new();
    let mut rest = css;
    while let Some(index) = rest.find("@define-color") {
        rest = rest[index + "@define-color".len()..].trim_start();
        let Some(name_end) = rest.find(char::is_whitespace) else {
            break;
        };
        let name = rest[..name_end].trim().trim_end_matches(';');
        if name.is_empty() {
            break;
        }
        rest = rest[name_end..].trim_start();
        let token = if rest.starts_with("rgb") || rest.starts_with("hsl") {
            let Some(end) = rest.find(')') else {
                break;
            };
            &rest[..=end]
        } else {
            rest.split_whitespace().next().unwrap_or("")
        };
        if let Some(color) = parse_css_color(token.trim_end_matches(';')) {
            colors.insert(name.to_string(), color);
        }
        if let Some(end) = rest.find(';') {
            rest = &rest[end + 1..];
        } else {
            break;
        }
    }
    colors
}

fn parse_css_color(raw: &str) -> Option<Color> {
    let raw = raw.trim().trim_end_matches([';', ',']);
    if raw.is_empty() {
        return None;
    }
    if let Some(color) = hex(raw) {
        return Some(color);
    }
    let inner = raw
        .strip_prefix("rgba(")
        .or_else(|| raw.strip_prefix("rgb("))?
        .strip_suffix(')')?;
    let mut channels = [0.0_f32; 3];
    let mut alpha = 1.0_f32;
    let mut count = 0_usize;
    for part in inner.split(',') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        let value: f32 = part.parse().ok()?;
        if count < 3 {
            channels[count] = srgb_decode((value / 255.0).clamp(0.0, 1.0));
        } else if count == 3 {
            alpha = value.clamp(0.0, 1.0);
        }
        count += 1;
    }
    (count >= 3).then_some(Color {
        r: channels[0],
        g: channels[1],
        b: channels[2],
        a: alpha,
    })
}

/// Reads `strata/themes/<theme>.toml` when `settings.toml` names a safe theme.
/// Returns whether that file's background (or `-dark` / `-light` suffix) is dark.
fn overlay_strata_themes(
    config_dir: &Path,
    dark: &mut Palette,
    light: &mut Palette,
) -> Option<bool> {
    let text = read_to_string(&config_dir.join("strata").join("settings.toml"))?;
    let name = root_assignment(&text, "theme")?;
    if !safe_theme_name(&name) {
        return None;
    }
    let path = config_dir
        .join("strata")
        .join("themes")
        .join(format!("{name}.toml"));
    let theme = read_to_string(&path)?;
    let colors = root_colors(&theme);
    let is_dark = strata_face_dark(&name, &colors)?;
    let target = if is_dark { dark } else { light };
    overlay_strata_colors(target, &colors);
    Some(is_dark)
}

fn strata_face_dark(name: &str, colors: &HashMap<String, Color>) -> Option<bool> {
    if let Some(background) = colors.get("background") {
        return Some(background.luminance() < 0.5);
    }
    let slug = normalize_slug(name);
    if slug.ends_with("-dark") {
        Some(true)
    } else if slug.ends_with("-light") {
        Some(false)
    } else {
        None
    }
}

fn overlay_strata_colors(palette: &mut Palette, colors: &HashMap<String, Color>) {
    if let Some(base) = colors.get("background") {
        palette.base = *base;
    }
    if let Some(surface) = colors.get("surface") {
        palette.panel_alt = *surface;
    }
    if let Some(highlight) = colors.get("highlight") {
        palette.panel = *highlight;
    }
    if let Some(text) = colors.get("text") {
        palette.text = *text;
    }
    if let Some(muted) = colors.get("muted") {
        palette.muted = *muted;
    }
    if let Some(subtle) = colors.get("dim_text") {
        palette.subtle = *subtle;
    }
    if let Some(accent) = colors.get("accent") {
        palette.accent = *accent;
        palette.border_focus = *accent;
    }
    if let Some(border) = colors.get("border") {
        palette.border = *border;
    }
    if let Some(crit) = colors.get("danger") {
        palette.crit = *crit;
    }
    for (index, key) in [
        "syntax_keyword",
        "syntax_string",
        "syntax_constant",
        "syntax_type",
        "syntax_preprocessor",
    ]
    .into_iter()
    .enumerate()
    {
        if let Some(color) = colors.get(key) {
            palette.cpu_cores[index] = *color;
        }
    }
}

fn root_colors(text: &str) -> HashMap<String, Color> {
    let mut colors = HashMap::new();
    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with('[') {
            break;
        }
        if trimmed.is_empty() || trimmed.starts_with('#') || trimmed.starts_with("//") {
            continue;
        }
        let Some((key, value)) = trimmed.split_once('=') else {
            continue;
        };
        let key = key.trim();
        if key.is_empty() {
            continue;
        }
        if let Some(color) = parse_css_color(&unquote(value)) {
            colors.insert(key.to_string(), color);
        }
    }
    colors
}

fn overlay_herdr_themes(config_dir: &Path, dark: &mut Palette, light: &mut Palette) {
    let Some(text) = read_to_string(&config_dir.join("herdr-app").join("settings.json")) else {
        return;
    };
    let Ok(value) = serde_json::from_str::<serde_json::Value>(&text) else {
        return;
    };
    if let Some(name) = value["theme"]["dark"].as_str() {
        apply_named_herdr(config_dir, name, dark, true);
    }
    if let Some(name) = value["theme"]["light"].as_str() {
        apply_named_herdr(config_dir, name, light, false);
    }
}

fn safe_theme_name(name: &str) -> bool {
    !name.is_empty()
        && !name.contains("..")
        && !name.contains('/')
        && !name.contains('\\')
        && name
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || ch == '-' || ch == '_' || ch == '.')
}

fn apply_named_herdr(config_dir: &Path, name: &str, palette: &mut Palette, want_dark: bool) {
    if !safe_theme_name(name) {
        return;
    }
    let path = config_dir
        .join("herdr-app")
        .join("themes")
        .join(format!("{name}.json"));
    let Some(text) = read_to_string(&path) else {
        return;
    };
    let Ok(value) = serde_json::from_str::<serde_json::Value>(&text) else {
        return;
    };
    let Some(background) =
        json_color(&value, "background").or_else(|| json_color(&value["colors"], "canvas"))
    else {
        return;
    };
    if (background.luminance() < 0.5) != want_dark {
        return;
    }
    overlay_herdr(palette, &value);
}

fn overlay_herdr(palette: &mut Palette, value: &serde_json::Value) {
    let colors = &value["colors"];
    if let Some(base) = json_color(value, "background").or_else(|| json_color(colors, "canvas")) {
        palette.base = base;
    }
    if let Some(chrome) = json_color(colors, "chrome") {
        palette.chrome = chrome;
    }
    if let Some(surface) = json_color(colors, "surface") {
        palette.panel_alt = surface;
    }
    if let Some(border) = json_color(colors, "border") {
        palette.border = border;
    }
    if let Some(text) = json_color(colors, "text").or_else(|| json_color(value, "foreground")) {
        palette.text = text;
    }
    if let Some(muted) = json_color(colors, "muted") {
        palette.muted = muted;
    }
    if let Some(accent) = json_color(colors, "accent") {
        palette.accent = accent;
        palette.border_focus = accent;
    }
}

fn json_color(value: &serde_json::Value, key: &str) -> Option<Color> {
    value
        .get(key)
        .and_then(|entry| entry.as_str())
        .and_then(parse_css_color)
}

fn overlay_gtk(
    dark: &mut Palette,
    light: &mut Palette,
    colors: &HashMap<String, Color>,
    custom: bool,
) {
    let Some(background) = colors
        .get("window_bg_color")
        .or_else(|| colors.get("theme_bg_color"))
        .copied()
    else {
        return;
    };
    let target = if background.luminance() < 0.5 {
        dark
    } else {
        light
    };
    if let Some(base) = colors
        .get("window_bg_color")
        .or_else(|| colors.get("theme_bg_color"))
        .copied()
    {
        target.base = base;
    }
    if let Some(chrome) = colors
        .get("headerbar_bg_color")
        .or_else(|| colors.get("sidebar_bg_color"))
        .copied()
    {
        target.chrome = chrome;
    }
    if let Some(card) = colors.get("card_bg_color").copied() {
        target.panel_alt = card;
        if custom {
            target.panel = target.base.mix(card, 0.45);
        }
    }
    if let Some(border) = colors
        .get("borders")
        .or_else(|| colors.get("sidebar_border_color"))
        .copied()
    {
        target.border = border;
    }
    if let Some(text) = colors
        .get("window_fg_color")
        .or_else(|| colors.get("theme_fg_color"))
        .copied()
    {
        target.text = text;
    }
    if let Some(muted) = colors.get("theme_unfocused_fg_color").copied() {
        target.muted = muted;
    }
    if let Some(subtle) = colors.get("insensitive_fg_color").copied() {
        target.subtle = subtle;
    }
    if let Some(accent) = colors.get("accent_color").copied() {
        target.accent = accent;
        target.border_focus = accent;
    }
    if let Some(ok) = colors.get("success_color").copied() {
        target.ok = ok;
    }
    if let Some(warn) = colors.get("warning_color").copied() {
        target.warn = warn;
    }
    if let Some(crit) = colors.get("error_color").copied() {
        target.crit = crit;
    }
    if custom {
        recolor_series(target);
    }
}

/// Builds chart hues from the desktop accent and status colors when GTK is a custom theme.
fn recolor_series(palette: &mut Palette) {
    let accent = palette.accent;
    let ok = palette.ok;
    let warn = palette.warn;
    let crit = palette.crit;
    let text = palette.text;
    let mut cores = [
        accent,
        ok,
        warn,
        crit,
        accent.mix(ok, 0.45),
        accent.mix(warn, 0.45),
        ok.mix(crit, 0.4),
        warn.mix(text, 0.28),
    ];
    for index in 0..cores.len() {
        let mut nudge = 0;
        while cores[..index].contains(&cores[index]) && nudge < 6 {
            cores[index] = cores[index].mix(text, 0.16);
            nudge += 1;
        }
    }
    palette.cpu_cores = cores;
    palette.cpu_total = cores[0];
    palette.mem_used = cores[2];
    palette.mem_cached = palette.muted;
    palette.swap_used = cores[3];
    palette.net_rx = cores[1];
    palette.net_tx = cores[5];
    palette.disk_read = cores[4];
    palette.disk_write = cores[6];
}

fn toml_section_value(text: &str, section: &str, key: &str) -> Option<String> {
    let header = format!("[{section}]");
    let mut in_section = false;
    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with('[') && trimmed.ends_with(']') {
            in_section = trimmed == header;
            continue;
        }
        if in_section && let Some(value) = assignment(trimmed, key) {
            return Some(unquote(value));
        }
    }
    None
}

fn root_assignment(text: &str, key: &str) -> Option<String> {
    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with('[') {
            break;
        }
        if let Some(value) = assignment(trimmed, key) {
            return Some(unquote(value));
        }
    }
    None
}

fn assignment<'a>(line: &'a str, key: &str) -> Option<&'a str> {
    let line = line.trim();
    if line.is_empty() || line.starts_with('#') || line.starts_with("//") {
        return None;
    }
    let (found, value) = line.split_once('=')?;
    (found.trim() == key).then_some(value.trim())
}

fn unquote(value: &str) -> String {
    let value = value.trim().trim_end_matches(',');
    if let Some(rest) = value.strip_prefix('"') {
        return rest.split('"').next().unwrap_or("").to_string();
    }
    if let Some(rest) = value.strip_prefix('\'') {
        return rest.split('\'').next().unwrap_or("").to_string();
    }
    value
        .split('#')
        .next()
        .unwrap_or(value)
        .split_whitespace()
        .next()
        .unwrap_or("")
        .trim_end_matches(',')
        .to_string()
}

fn normalize_slug(value: &str) -> String {
    let value = value.trim().trim_matches(['"', '\'']);
    let value = value.rsplit(['/', '\\']).next().unwrap_or(value);
    let value = strip_known_extension(value);
    let mut out = String::with_capacity(value.len());
    let mut pending_sep = false;
    for ch in value.chars() {
        if ch == 'é' || ch == 'É' {
            push_slug_char(&mut out, &mut pending_sep, 'e');
            continue;
        }
        if ch.is_ascii_alphanumeric() {
            push_slug_char(&mut out, &mut pending_sep, ch.to_ascii_lowercase());
        } else {
            pending_sep = true;
        }
    }
    while out.ends_with('-') {
        out.pop();
    }
    out
}

fn push_slug_char(out: &mut String, pending_sep: &mut bool, ch: char) {
    if *pending_sep && !out.is_empty() && !out.ends_with('-') {
        out.push('-');
    }
    *pending_sep = false;
    out.push(ch);
}

fn strip_known_extension(value: &str) -> &str {
    for suffix in [".css", ".json", ".toml"] {
        if let Some(stripped) = value.strip_suffix(suffix) {
            return stripped;
        }
    }
    value
}

#[cfg(test)]
mod tests {
    use super::*;

    fn swatches(p: &Palette) -> [Color; 29] {
        [
            p.base,
            p.panel,
            p.panel_alt,
            p.chrome,
            p.border,
            p.border_focus,
            p.text,
            p.muted,
            p.subtle,
            p.accent,
            p.cpu_total,
            p.mem_used,
            p.mem_cached,
            p.swap_used,
            p.net_rx,
            p.net_tx,
            p.disk_read,
            p.disk_write,
            p.ok,
            p.warn,
            p.crit,
            p.cpu_cores[0],
            p.cpu_cores[1],
            p.cpu_cores[2],
            p.cpu_cores[3],
            p.cpu_cores[4],
            p.cpu_cores[5],
            p.cpu_cores[6],
            p.cpu_cores[7],
        ]
    }

    fn assert_srgb(color: Color, rgb: &str) {
        assert_eq!(&color.hex()[..7], rgb, "{}", color.hex());
    }

    #[test]
    fn dark_and_light_palettes_build_with_distinct_colors() {
        let dark = palette(true);
        let light = palette(false);
        let dark_swatch = swatches(&dark);
        let light_swatch = swatches(&light);
        for (index, (left, right)) in dark_swatch.iter().zip(light_swatch).enumerate() {
            assert_ne!(left, &right, "swatch {index} matches across modes");
        }
        for (i, color) in dark.cpu_cores.iter().enumerate() {
            assert!(
                dark.cpu_cores[i + 1..].iter().all(|other| other != color),
                "dark core {i} is duplicated"
            );
            assert!(
                light.cpu_cores[i + 1..]
                    .iter()
                    .all(|other| other != &light.cpu_cores[i]),
                "light core {i} is duplicated"
            );
        }
        assert!(dark.text.luminance() > dark.base.luminance());
        assert!(light.base.luminance() > light.text.luminance());
    }

    #[test]
    fn surfaces_match_the_instrument_hex() {
        let dark = palette(true);
        let light = palette(false);
        assert_srgb(dark.base, "#0d1117");
        assert_srgb(dark.panel, "#151b23");
        assert_srgb(dark.panel_alt, "#1c2430");
        assert_srgb(dark.chrome, "#090d12");
        assert_srgb(dark.border, "#283242");
        assert_srgb(dark.border_focus, "#58a6ff");
        assert_srgb(light.base, "#f6f8fa");
        assert_srgb(light.panel, "#ffffff");
        assert_srgb(light.panel_alt, "#eef2f7");
        assert_srgb(light.chrome, "#e5ebf1");
        assert_srgb(light.border, "#d0d8e2");
        assert_srgb(light.border_focus, "#0969da");
    }

    #[test]
    fn core_color_wraps_and_thresholds_follow_the_bands() {
        let palette = palette(true);
        assert_eq!(palette.core_color(0), palette.cpu_cores[0]);
        assert_eq!(palette.core_color(7), palette.cpu_cores[7]);
        assert_eq!(palette.core_color(8), palette.cpu_cores[0]);
        assert_eq!(palette.core_color(15), palette.cpu_cores[7]);

        assert_eq!(palette.usage_color(0.0), palette.ok);
        assert_eq!(palette.usage_color(64.9), palette.ok);
        assert_eq!(palette.usage_color(65.0), palette.warn);
        assert_eq!(palette.usage_color(84.9), palette.warn);
        assert_eq!(palette.usage_color(85.0), palette.crit);
        assert_eq!(palette.usage_color(140.0), palette.crit);
        assert_eq!(palette.usage_color(f32::NAN), palette.ok);
        assert_eq!(palette.usage_color(f32::NEG_INFINITY), palette.ok);
        assert_eq!(palette.usage_color(f32::INFINITY), palette.crit);

        assert_eq!(palette.temp_color(20.0), palette.ok);
        assert_eq!(palette.temp_color(64.9), palette.ok);
        assert_eq!(palette.temp_color(65.0), palette.warn);
        assert_eq!(palette.temp_color(81.9), palette.warn);
        assert_eq!(palette.temp_color(82.0), palette.crit);
        assert_eq!(palette.temp_color(f32::NAN), palette.ok);
        assert_eq!(palette.temp_color(f32::INFINITY), palette.crit);
    }

    #[test]
    fn appearance_mode_cycles_resolves_and_round_trips() {
        assert_eq!(AppearanceMode::default(), AppearanceMode::System);
        assert_eq!(AppearanceMode::System.cycle(), AppearanceMode::Dark);
        assert_eq!(AppearanceMode::Dark.cycle(), AppearanceMode::Light);
        assert_eq!(AppearanceMode::Light.cycle(), AppearanceMode::System);
        assert!(AppearanceMode::System.resolve(true));
        assert!(!AppearanceMode::System.resolve(false));
        assert!(AppearanceMode::Dark.resolve(false));
        assert!(!AppearanceMode::Light.resolve(true));
        assert_eq!(AppearanceMode::System.as_dark_option(), None);
        assert_eq!(AppearanceMode::Dark.as_dark_option(), Some(true));
        assert_eq!(AppearanceMode::Light.as_dark_option(), Some(false));
        for mode in [
            AppearanceMode::System,
            AppearanceMode::Dark,
            AppearanceMode::Light,
        ] {
            assert_eq!(AppearanceMode::from_slug(mode.slug()), Some(mode));
            assert!(!mode.label().is_empty());
        }
        assert_eq!(
            AppearanceMode::from_slug("auto"),
            Some(AppearanceMode::System)
        );
        assert_eq!(AppearanceMode::from_slug("nope"), None);
    }

    #[test]
    fn color_scheme_cycle_and_slugs_cover_every_scheme() {
        assert_eq!(ColorSchemeId::default(), ColorSchemeId::System);
        assert_eq!(ColorSchemeId::ALL.len(), 7);
        let mut cursor = ColorSchemeId::System;
        for scheme in ColorSchemeId::ALL {
            assert_eq!(cursor, scheme);
            assert_eq!(ColorSchemeId::from_slug(scheme.slug()), Some(scheme));
            assert!(!scheme.label().is_empty());
            cursor = cursor.cycle();
        }
        assert_eq!(cursor, ColorSchemeId::System);
        assert_eq!(
            ColorSchemeId::from_slug("Tokyo Night"),
            Some(ColorSchemeId::TokyoNight)
        );
        assert_eq!(
            ColorSchemeId::from_slug("Rosé Pine"),
            Some(ColorSchemeId::RosePine)
        );
        assert_eq!(
            ColorSchemeId::from_slug("gruvbox-dark"),
            Some(ColorSchemeId::Gruvbox)
        );
        assert_eq!(
            ColorSchemeId::from_slug("gruvbox.css"),
            Some(ColorSchemeId::Gruvbox)
        );
        assert_eq!(
            ColorSchemeId::from_slug("catppuccin-mocha"),
            Some(ColorSchemeId::Catppuccin)
        );
        assert_eq!(ColorSchemeId::from_slug("solarized"), None);
    }

    #[test]
    fn builtin_schemes_keep_contrast_and_distinct_cores() {
        let system = SystemThemeSnapshot::default();
        for scheme in [
            ColorSchemeId::Gruvbox,
            ColorSchemeId::Catppuccin,
            ColorSchemeId::Obsidian,
            ColorSchemeId::TokyoNight,
            ColorSchemeId::Nord,
            ColorSchemeId::RosePine,
        ] {
            let dark = scheme.palette(true, &system);
            let light = scheme.palette(false, &system);
            assert_ne!(dark.base, light.base, "{}", scheme.label());
            assert_ne!(dark.text, light.text, "{}", scheme.label());
            assert_ne!(dark.chrome, light.chrome, "{}", scheme.label());
            assert!(
                dark.text.luminance() > dark.base.luminance(),
                "{}",
                scheme.label()
            );
            assert!(
                light.base.luminance() > light.text.luminance(),
                "{}",
                scheme.label()
            );
            assert_ne!(dark.ok, dark.warn, "{}", scheme.label());
            assert_ne!(dark.warn, dark.crit, "{}", scheme.label());
            assert_ne!(light.ok, light.warn, "{}", scheme.label());
            assert_ne!(light.warn, light.crit, "{}", scheme.label());
            for (index, color) in dark.cpu_cores.iter().enumerate() {
                assert!(
                    dark.cpu_cores[index + 1..]
                        .iter()
                        .all(|other| other != color),
                    "{} dark core {index} is duplicated",
                    scheme.label()
                );
                assert!(
                    light.cpu_cores[index + 1..]
                        .iter()
                        .all(|other| other != &light.cpu_cores[index]),
                    "{} light core {index} is duplicated",
                    scheme.label()
                );
            }
        }
    }

    #[test]
    fn authored_faces_match_the_desktop_hex() {
        let gruvbox_dark = ColorSchemeId::Gruvbox.palette(true, &SystemThemeSnapshot::default());
        let gruvbox_light = ColorSchemeId::Gruvbox.palette(false, &SystemThemeSnapshot::default());
        assert_srgb(gruvbox_dark.base, "#282828");
        assert_srgb(gruvbox_dark.chrome, "#1d2021");
        assert_srgb(gruvbox_dark.panel, "#32302f");
        assert_srgb(gruvbox_dark.panel_alt, "#3c3836");
        assert_srgb(gruvbox_dark.border, "#504945");
        assert_srgb(gruvbox_dark.accent, "#b8bb26");
        assert_srgb(gruvbox_dark.text, "#ebdbb2");
        assert_srgb(gruvbox_dark.muted, "#a89984");
        assert_srgb(gruvbox_dark.subtle, "#928374");
        assert_srgb(gruvbox_dark.warn, "#fabd2f");
        assert_srgb(gruvbox_dark.crit, "#fb4934");
        assert_srgb(gruvbox_dark.cpu_cores[0], "#83a598");
        assert_srgb(gruvbox_dark.cpu_cores[7], "#458588");
        assert_srgb(gruvbox_light.base, "#fbf1c7");
        assert_srgb(gruvbox_light.chrome, "#f2e5bc");
        assert_srgb(gruvbox_light.panel, "#f9f5d7");
        assert_srgb(gruvbox_light.panel_alt, "#ebdbb2");
        assert_srgb(gruvbox_light.border, "#d5c4a1");
        assert_srgb(gruvbox_light.accent, "#79740e");
        assert_srgb(gruvbox_light.text, "#3c3836");
        assert_srgb(gruvbox_light.muted, "#665c54");
        assert_srgb(gruvbox_light.warn, "#b57614");
        assert_srgb(gruvbox_light.crit, "#9d0006");
        assert_srgb(gruvbox_light.cpu_cores[0], "#076678");

        let mocha = ColorSchemeId::Catppuccin.palette(true, &SystemThemeSnapshot::default());
        let latte = ColorSchemeId::Catppuccin.palette(false, &SystemThemeSnapshot::default());
        assert_srgb(mocha.base, "#1e1e2e");
        assert_srgb(mocha.chrome, "#181825");
        assert_srgb(mocha.panel, "#24273a");
        assert_srgb(mocha.panel_alt, "#313244");
        assert_srgb(mocha.border, "#45475a");
        assert_srgb(mocha.accent, "#89b4fa");
        assert_srgb(mocha.text, "#cdd6f4");
        assert_srgb(mocha.ok, "#a6e3a1");
        assert_srgb(mocha.warn, "#f9e2af");
        assert_srgb(mocha.crit, "#f38ba8");
        assert_srgb(latte.base, "#eff1f5");
        assert_srgb(latte.panel, "#ffffff");
        assert_srgb(latte.accent, "#1e66f5");
        assert_srgb(latte.text, "#4c4f69");
        assert_srgb(latte.ok, "#40a02b");
        assert_srgb(latte.crit, "#d20f39");

        let night = ColorSchemeId::TokyoNight.palette(true, &SystemThemeSnapshot::default());
        let day = ColorSchemeId::TokyoNight.palette(false, &SystemThemeSnapshot::default());
        assert_srgb(night.base, "#1a1b26");
        assert_srgb(night.chrome, "#16161e");
        assert_srgb(night.accent, "#7aa2f7");
        assert_srgb(night.text, "#c0caf5");
        assert_srgb(night.ok, "#9ece6a");
        assert_srgb(night.crit, "#f7768e");
        assert_srgb(day.base, "#e1e2e7");
        assert_srgb(day.panel, "#eaebed");
        assert_srgb(day.accent, "#2e7de9");
        assert_srgb(day.text, "#3760bf");
        assert_srgb(day.ok, "#587539");
        assert_srgb(day.crit, "#f52a65");

        let polar = ColorSchemeId::Nord.palette(true, &SystemThemeSnapshot::default());
        let snow = ColorSchemeId::Nord.palette(false, &SystemThemeSnapshot::default());
        assert_srgb(polar.base, "#2e3440");
        assert_srgb(polar.chrome, "#242933");
        assert_srgb(polar.accent, "#88c0d0");
        assert_srgb(polar.text, "#eceff4");
        assert_srgb(polar.ok, "#a3be8c");
        assert_srgb(polar.crit, "#bf616a");
        assert_srgb(snow.base, "#eceff4");
        assert_srgb(snow.panel, "#f8fafc");
        assert_srgb(snow.accent, "#5e81ac");
        assert_srgb(snow.text, "#2e3440");
        assert_srgb(snow.ok, "#4f7a38");
        assert_srgb(snow.crit, "#a53c46");

        let rose = ColorSchemeId::RosePine.palette(true, &SystemThemeSnapshot::default());
        let dawn = ColorSchemeId::RosePine.palette(false, &SystemThemeSnapshot::default());
        assert_srgb(rose.base, "#191724");
        assert_srgb(rose.chrome, "#1f1d2e");
        assert_srgb(rose.panel, "#21202e");
        assert_srgb(rose.accent, "#c4a7e7");
        assert_srgb(rose.text, "#e0def4");
        assert_srgb(rose.ok, "#9ccfd8");
        assert_srgb(rose.crit, "#eb6f92");
        assert_srgb(dawn.base, "#faf4ed");
        assert_srgb(dawn.chrome, "#f2e9e1");
        assert_srgb(dawn.panel, "#fffaf3");
        assert_srgb(dawn.accent, "#907aa9");
        assert_srgb(dawn.text, "#575279");
        assert_srgb(dawn.ok, "#286983");
        assert_srgb(dawn.crit, "#b4637a");

        assert_eq!(
            ColorSchemeId::Obsidian
                .palette(true, &SystemThemeSnapshot::default())
                .base,
            palette(true).base
        );
    }

    #[test]
    fn system_scheme_uses_the_snapshot_instead_of_obsidian() {
        let mut system = SystemThemeSnapshot::default();
        system.dark = ColorSchemeId::Gruvbox.palette(true, &system);
        system.light = ColorSchemeId::Nord.palette(false, &SystemThemeSnapshot::default());
        let resolved = ColorSchemeId::System.palette(true, &system);
        assert_srgb(resolved.base, "#282828");
        assert_ne!(resolved.base, palette(true).base);
        assert_srgb(
            ColorSchemeId::System.palette(false, &system).base,
            "#eceff4",
        );
    }

    fn write_file(path: &std::path::Path, body: &str) {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).unwrap();
        }
        std::fs::write(path, body).unwrap();
    }

    #[test]
    fn empty_desktop_dirs_stay_on_obsidian() {
        let dir = tempfile::tempdir().unwrap();
        let snap = detect_system_theme(dir.path(), dir.path());
        assert_eq!(snap.system_dark, None);
        assert_eq!(snap.detected_name, "Obsidian");
        assert_eq!(snap.detected_scheme, ColorSchemeId::Obsidian);
        assert_eq!(snap.dark.base, palette(true).base);
        assert_eq!(snap.light.base, palette(false).base);
    }

    #[test]
    fn gruvbox_mode_noctalia_and_gtk_css_build_the_system_face() {
        let root = tempfile::tempdir().unwrap();
        let state = root.path().join("state");
        let config = root.path().join("config");
        write_file(&state.join("gruvbox-mode"), "dark\n");
        write_file(
            &state.join("noctalia/settings.toml"),
            "[other]\nmode = \"light\"\n\n[theme]\nbuiltin = \"Gruvbox\"\nmode = \"light\"\n",
        );
        write_file(
            &config.join("gtk-4.0/gtk.css"),
            "@import url(\"gruvbox.css\");\n",
        );
        write_file(
            &config.join("gtk-4.0/gruvbox.css"),
            "\
@define-color window_bg_color #282828;
@define-color headerbar_bg_color #1d2021;
@define-color card_bg_color #3c3836;
@define-color borders #665c54;
@define-color sidebar_border_color #504945;
@define-color window_fg_color #ebdbb2;
@define-color theme_unfocused_fg_color #bdae93;
@define-color insensitive_fg_color #928374;
@define-color accent_color #b8bb26;
@define-color success_color #b8bb26;
@define-color warning_color #fabd2f;
@define-color error_color #fb4934;
",
        );
        let snap = detect_system_theme(&config, &state);
        assert_eq!(snap.system_dark, Some(true));
        assert_eq!(snap.detected_scheme, ColorSchemeId::Gruvbox);
        assert_eq!(snap.detected_name, "Gruvbox");
        assert_srgb(snap.dark.base, "#282828");
        assert_srgb(snap.dark.chrome, "#1d2021");
        assert_srgb(snap.dark.panel_alt, "#3c3836");
        assert_srgb(snap.dark.border, "#665c54");
        assert_srgb(snap.dark.text, "#ebdbb2");
        assert_srgb(snap.dark.muted, "#bdae93");
        assert_srgb(snap.dark.subtle, "#928374");
        assert_srgb(snap.dark.accent, "#b8bb26");
        assert_srgb(snap.dark.cpu_cores[0], "#83a598");
        assert_srgb(snap.light.base, "#fbf1c7");
        assert_srgb(snap.light.accent, "#79740e");
    }

    #[test]
    fn light_mode_file_wins_and_custom_gtk_overlays_only_its_side() {
        let root = tempfile::tempdir().unwrap();
        let state = root.path().join("state");
        let config = root.path().join("config");
        write_file(&state.join("gruvbox-mode"), "light\n");
        write_file(
            &config.join("noctalia/settings.toml"),
            "[theme]\nbuiltin = \"Gruvbox\"\nmode = \"dark\"\n",
        );
        write_file(
            &config.join("gtk-4.0/gtk.css"),
            "@import url(\"dank-colors.css\");\n",
        );
        write_file(
            &config.join("gtk-4.0/dank-colors.css"),
            "\
@define-color window_bg_color #123456;
@define-color headerbar_bg_color #0b1c2c;
@define-color card_bg_color #1a3a52;
@define-color borders #2a4a62;
@define-color window_fg_color #e8eef6;
@define-color theme_unfocused_fg_color #9bb0c4;
@define-color insensitive_fg_color #6d8496;
@define-color accent_color #7ee0ff;
@define-color success_color #3dd68c;
@define-color warning_color #f0b429;
@define-color error_color #ff5d5d;
",
        );
        let snap = detect_system_theme(&config, &state);
        assert_eq!(snap.system_dark, Some(false));
        assert_eq!(snap.detected_name, "Gruvbox");
        assert_srgb(snap.light.base, "#fbf1c7");
        assert_srgb(snap.dark.base, "#123456");
        assert_srgb(snap.dark.chrome, "#0b1c2c");
        assert_srgb(snap.dark.accent, "#7ee0ff");
        assert_srgb(snap.dark.ok, "#3dd68c");
        assert_srgb(snap.dark.crit, "#ff5d5d");
        assert_eq!(snap.dark.cpu_total, snap.dark.accent);
        assert!(snap.dark.base.luminance() < 0.5);
    }

    #[test]
    fn gtk_import_from_gtk3_and_settings_ini_are_fallbacks() {
        let root = tempfile::tempdir().unwrap();
        let config = root.path().join("config");
        let state = root.path().join("state");
        write_file(
            &config.join("gtk-4.0/gtk.css"),
            "@import url(\"legacy.css\");\n",
        );
        write_file(
            &config.join("gtk-3.0/legacy.css"),
            "@define-color theme_bg_color #f4f1ea;\n@define-color theme_fg_color #2b2926;\n@define-color accent_color #8f3f71;\n",
        );
        let snap = detect_system_theme(&config, &state);
        assert_eq!(snap.system_dark, Some(false));
        assert_eq!(snap.detected_name, "Legacy");
        assert_srgb(snap.light.base, "#f4f1ea");
        assert_srgb(snap.light.text, "#2b2926");
        assert_srgb(snap.light.accent, "#8f3f71");
        assert_eq!(snap.dark.base, palette(true).base);

        let ini_root = tempfile::tempdir().unwrap();
        write_file(
            &ini_root.path().join("gtk-4.0/settings.ini"),
            "[Settings]\ngtk-application-prefer-dark-theme=true\n",
        );
        let ini = detect_system_theme(ini_root.path(), ini_root.path());
        assert_eq!(ini.system_dark, Some(true));
        assert_eq!(ini.detected_scheme, ColorSchemeId::Obsidian);
    }

    #[test]
    fn strata_herdr_and_gruvbox_mode_name_the_preset() {
        let root = tempfile::tempdir().unwrap();
        let config = root.path().join("config");
        let state = root.path().join("state");
        write_file(
            &config.join("strata/settings.toml"),
            "mode = \"theme\"\ntheme = \"nord-dark\"\n\n[ignored]\ntheme = \"gruvbox-dark\"\n",
        );
        let strata = detect_system_theme(&config, &state);
        assert_eq!(strata.detected_scheme, ColorSchemeId::Nord);
        assert_eq!(strata.system_dark, None);
        assert_srgb(strata.dark.base, "#2e3440");

        let herdr = tempfile::tempdir().unwrap();
        let herdr_config = herdr.path().join("config");
        write_file(
            &herdr_config.join("herdr-app/settings.json"),
            "{\"theme\":{\"dark\":\"catppuccin-mocha\",\"light\":\"catppuccin-latte\"}}\n",
        );
        write_file(
            &herdr_config.join("herdr-app/themes/catppuccin-mocha.json"),
            "{\"background\":\"#1e1e2e\",\"colors\":{\"accent\":\"#112233\",\"chrome\":\"#181825\",\"surface\":\"#313244\",\"text\":\"#cdd6f4\",\"canvas\":\"#1e1e2e\"}}\n",
        );
        let snap = detect_system_theme(&herdr_config, &herdr.path().join("state"));
        assert_eq!(snap.detected_scheme, ColorSchemeId::Catppuccin);
        assert_srgb(snap.dark.accent, "#112233");
        assert_srgb(snap.dark.base, "#1e1e2e");
        assert_srgb(snap.light.base, "#eff1f5");

        let mode_only = tempfile::tempdir().unwrap();
        write_file(&mode_only.path().join("gruvbox-mode"), "\"light\"\n");
        let named = detect_system_theme(mode_only.path(), mode_only.path());
        assert_eq!(named.system_dark, Some(false));
        assert_eq!(named.detected_scheme, ColorSchemeId::Gruvbox);
        assert_srgb(named.dark.border, "#504945");
        assert_srgb(named.light.base, "#fbf1c7");
    }

    #[test]
    fn strata_theme_file_overlays_colors_and_can_set_the_mode() {
        let root = tempfile::tempdir().unwrap();
        let config = root.path().join("config");
        let state = root.path().join("state");
        write_file(
            &config.join("noctalia/settings.toml"),
            "[theme]\nbuiltin = \"Nord\"\nmode = \"dark\"\n",
        );
        write_file(
            &config.join("strata/settings.toml"),
            "theme = \"nord-dark\"\n",
        );
        write_file(
            &config.join("strata/themes/nord-dark.toml"),
            "\
background = \"#2e3440\"
surface = \"#434c5e\"
text = \"#eceff4\"
muted = \"#d8dee9\"
dim_text = \"#9099ab\"
accent = \"#112233\"
border = \"#4c566a\"
danger = \"#bf616a\"
highlight = \"#3b4252\"
syntax_keyword = \"#81a1c1\"
syntax_string = \"#a3be8c\"
syntax_constant = \"#b48ead\"
syntax_type = \"#ebcb8b\"
syntax_preprocessor = \"#8fbcbb\"
",
        );
        let overlaid = detect_system_theme(&config, &state);
        assert_eq!(overlaid.detected_scheme, ColorSchemeId::Nord);
        assert_eq!(overlaid.system_dark, Some(true));
        assert_srgb(overlaid.dark.accent, "#112233");
        assert_srgb(overlaid.dark.border_focus, "#112233");
        assert_srgb(overlaid.dark.panel_alt, "#434c5e");
        assert_srgb(overlaid.dark.panel, "#3b4252");
        assert_srgb(overlaid.dark.subtle, "#9099ab");
        assert_srgb(overlaid.dark.crit, "#bf616a");
        assert_srgb(overlaid.dark.cpu_cores[0], "#81a1c1");
        assert_srgb(overlaid.dark.cpu_cores[4], "#8fbcbb");
        assert_eq!(
            overlaid.light.base,
            builtin_palette(ColorSchemeId::Nord, false).base
        );

        let only = tempfile::tempdir().unwrap();
        let only_config = only.path().join("config");
        write_file(
            &only_config.join("strata/settings.toml"),
            "theme = \"harbor\"\n",
        );
        write_file(
            &only_config.join("strata/themes/harbor.toml"),
            "\
background = \"#f4f1ea\"
surface = \"#fffaf3\"
text = \"#2b2926\"
muted = \"#6e6a62\"
dim_text = \"#9a948a\"
accent = \"#8f3f71\"
border = \"#d9d3c7\"
danger = \"#9d0006\"
highlight = \"#efe8dc\"
syntax_keyword = \"#8f3f71\"
syntax_string = \"#79740e\"
syntax_constant = \"#af3a03\"
syntax_type = \"#b57614\"
syntax_preprocessor = \"#427b58\"
",
        );
        let custom = detect_system_theme(&only_config, &only.path().join("state"));
        assert_eq!(custom.system_dark, Some(false));
        assert_eq!(custom.detected_scheme, ColorSchemeId::Obsidian);
        assert_eq!(custom.detected_name, "Harbor");
        assert_srgb(custom.light.base, "#f4f1ea");
        assert_srgb(custom.light.accent, "#8f3f71");
        assert_srgb(custom.light.text, "#2b2926");
        assert_srgb(custom.light.cpu_cores[1], "#79740e");
        assert_eq!(custom.dark.base, palette(true).base);

        let suffix = tempfile::tempdir().unwrap();
        let suffix_config = suffix.path().join("config");
        write_file(
            &suffix_config.join("strata/settings.toml"),
            "theme = \"harbor-dark\"\n",
        );
        write_file(
            &suffix_config.join("strata/themes/harbor-dark.toml"),
            "accent = \"#3ddc97\"\n",
        );
        let from_suffix = detect_system_theme(&suffix_config, &suffix.path().join("state"));
        assert_eq!(from_suffix.system_dark, Some(true));
        assert_eq!(from_suffix.detected_name, "Harbor Dark");
        assert_srgb(from_suffix.dark.accent, "#3ddc97");
        assert_eq!(from_suffix.light.accent, palette(false).accent);

        let escaped = tempfile::tempdir().unwrap();
        let escaped_config = escaped.path().join("config");
        write_file(
            &escaped_config.join("strata/settings.toml"),
            "theme = \"../escaped\"\n",
        );
        write_file(
            &escaped_config.join("strata/escaped.toml"),
            "background = \"#ff00ff\"\naccent = \"#00ff00\"\n",
        );
        let rejected = detect_system_theme(&escaped_config, &escaped.path().join("state"));
        assert_eq!(rejected.system_dark, None);
        assert_eq!(rejected.detected_scheme, ColorSchemeId::Obsidian);
        assert_eq!(rejected.detected_name, "Obsidian");
        assert_eq!(rejected.dark.base, palette(true).base);
    }

    #[test]
    fn this_host_follows_gruvbox_mode_when_configured() {
        let Some(home) = std::env::var_os("HOME") else {
            return;
        };
        let mode_path = std::path::PathBuf::from(home).join(".local/state/gruvbox-mode");
        if !mode_path.is_file() {
            return;
        }
        let snap = detect_system_theme_default();
        let mode = std::fs::read_to_string(&mode_path).unwrap();
        assert_eq!(
            snap.system_dark,
            mode_flag(&mode),
            "{mode:?} name {}",
            snap.detected_name
        );
        assert_eq!(
            snap.detected_scheme,
            ColorSchemeId::Gruvbox,
            "{}",
            snap.detected_name
        );
        if snap.system_dark == Some(true) {
            assert!(snap.dark.base.luminance() < 0.5);
            assert_srgb(snap.dark.base, "#282828");
        }
        if snap.system_dark == Some(false) {
            assert!(snap.light.base.luminance() > 0.5);
        }
    }
}
