//! Telemetry domain types, history rings, and process-row aggregation.

use std::cmp::Ordering;
use std::collections::{HashMap, HashSet, VecDeque};

/// Fixed-capacity ring of the newest samples, oldest at the front.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HistoryRing<T> {
    buf: VecDeque<T>,
    capacity: usize,
}

/// Alias for [`HistoryRing`] used by PSI and selected-process telemetry series.
pub type RingBuffer<T> = HistoryRing<T>;

impl<T> HistoryRing<T> {
    pub const DEFAULT_CAPACITY: usize = 240;

    pub fn new(capacity: usize) -> Self {
        let capacity = capacity.max(1);
        Self {
            buf: VecDeque::with_capacity(capacity),
            capacity,
        }
    }

    pub fn push(&mut self, value: T) {
        if self.buf.len() == self.capacity {
            self.buf.pop_front();
        }
        self.buf.push_back(value);
    }

    pub fn clear(&mut self) {
        self.buf.clear();
    }

    pub fn iter(&self) -> impl DoubleEndedIterator<Item = &T> + '_ {
        self.buf.iter()
    }

    pub fn latest(&self) -> Option<&T> {
        self.buf.back()
    }

    pub fn len(&self) -> usize {
        self.buf.len()
    }

    pub fn is_empty(&self) -> bool {
        self.buf.is_empty()
    }

    pub fn as_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.buf.iter().cloned().collect()
    }

    /// Newest `n` samples, still ordered oldest to newest.
    pub fn tail(&self, n: usize) -> Vec<T>
    where
        T: Clone,
    {
        let start = self.buf.len().saturating_sub(n);
        self.buf.iter().skip(start).cloned().collect()
    }
}

impl<T> Default for HistoryRing<T> {
    fn default() -> Self {
        Self::new(Self::DEFAULT_CAPACITY)
    }
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct CoreMetrics {
    pub index: usize,
    pub usage_pct: f32,
    pub user_pct: f32,
    pub system_pct: f32,
    pub iowait_pct: f32,
    pub freq_mhz: Option<u32>,
    pub temp_c: Option<f32>,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct CpuMetrics {
    pub model_name: String,
    pub total_usage_pct: f32,
    pub user_pct: f32,
    pub system_pct: f32,
    pub iowait_pct: f32,
    pub load_avg: [f32; 3],
    pub cores: Vec<CoreMetrics>,
    pub uptime_secs: u64,
    pub tasks_total: usize,
    pub tasks_running: usize,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct PsiMetrics {
    #[serde(default)]
    pub cpu_some_pct: f32,
    #[serde(default)]
    pub mem_some_pct: f32,
    #[serde(default)]
    pub mem_full_pct: f32,
    #[serde(default)]
    pub io_some_pct: f32,
    #[serde(default)]
    pub io_full_pct: f32,
}

#[derive(Debug, Clone, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
pub struct NetSocketEntry {
    #[serde(default)]
    pub proto: String,
    #[serde(default)]
    pub local_addr: String,
    #[serde(default)]
    pub remote_addr: String,
    #[serde(default)]
    pub state: String,
    #[serde(default)]
    pub inode: u64,
    #[serde(default)]
    pub pid: Option<u32>,
    #[serde(default)]
    pub process: String,
}

/// Kind chips for the Network socket table. `All` leaves the protocol and state alone.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum SocketKindFilter {
    #[default]
    All,
    Listen,
    Established,
    Tcp,
    Udp,
}

impl SocketKindFilter {
    pub const ALL: [SocketKindFilter; 5] = [
        Self::All,
        Self::Listen,
        Self::Established,
        Self::Tcp,
        Self::Udp,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Self::All => "All",
            Self::Listen => "Listen",
            Self::Established => "Estab",
            Self::Tcp => "TCP",
            Self::Udp => "UDP",
        }
    }

    pub fn slug(self) -> &'static str {
        match self {
            Self::All => "all",
            Self::Listen => "listen",
            Self::Established => "estab",
            Self::Tcp => "tcp",
            Self::Udp => "udp",
        }
    }

    pub fn matches(self, entry: &NetSocketEntry) -> bool {
        match self {
            Self::All => true,
            Self::Listen => {
                entry.state.eq_ignore_ascii_case("LISTEN")
                    || entry.state.eq_ignore_ascii_case("UNCONN")
            }
            Self::Established => {
                entry.state.eq_ignore_ascii_case("ESTAB")
                    || entry.state.eq_ignore_ascii_case("ESTABLISHED")
            }
            Self::Tcp => entry.proto.starts_with("TCP"),
            Self::Udp => entry.proto.starts_with("UDP"),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct MemMetrics {
    pub total_bytes: u64,
    pub used_bytes: u64,
    pub available_bytes: u64,
    pub cached_bytes: u64,
    pub buffers_bytes: u64,
    pub used_pct: f32,
    pub swap_total_bytes: u64,
    pub swap_used_bytes: u64,
    pub swap_pct: f32,
    #[serde(default)]
    pub shared_bytes: u64,
    #[serde(default)]
    pub dirty_bytes: u64,
    #[serde(default)]
    pub writeback_bytes: u64,
    #[serde(default)]
    pub slab_bytes: u64,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct NetInterfaceMetrics {
    pub name: String,
    pub is_loopback: bool,
    pub rx_bytes_per_sec: f64,
    pub tx_bytes_per_sec: f64,
    pub total_rx_bytes: u64,
    pub total_tx_bytes: u64,
    pub rx_packets_per_sec: f64,
    pub tx_packets_per_sec: f64,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct DiskMetrics {
    pub device: String,
    pub mount_point: String,
    pub fs_type: String,
    pub total_bytes: u64,
    pub used_bytes: u64,
    pub free_bytes: u64,
    pub used_pct: f32,
    pub read_bytes_per_sec: f64,
    pub write_bytes_per_sec: f64,
    #[serde(default)]
    pub busy_pct: f32,
    #[serde(default)]
    pub await_ms: f32,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct SensorMetrics {
    pub label: String,
    pub temp_c: f32,
    pub high_c: Option<f32>,
    pub crit_c: Option<f32>,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct BatteryMetrics {
    pub name: String,
    pub status: String,
    pub capacity_pct: f32,
    pub power_watts: Option<f32>,
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct ProcessInfo {
    pub pid: u32,
    pub ppid: u32,
    pub name: String,
    pub cmdline: String,
    pub user: String,
    pub state: char,
    pub cpu_pct: f32,
    pub mem_bytes: u64,
    pub mem_pct: f32,
    pub read_bytes_per_sec: f64,
    pub write_bytes_per_sec: f64,
    pub threads: u32,
    pub fds: Option<u32>,
    #[serde(default)]
    pub nice: i32,
    #[serde(default)]
    pub unit: Option<String>,
    #[serde(default)]
    pub cwd: Option<String>,
    #[serde(default)]
    pub exe: Option<String>,
    #[serde(default)]
    pub listening_ports: Vec<String>,
    #[serde(default)]
    pub open_files: Vec<String>,
}

#[derive(
    Debug, Clone, Copy, PartialEq, Eq, Hash, Default, serde::Serialize, serde::Deserialize,
)]
pub enum OpenFileKind {
    #[default]
    File,
    Socket,
    Device,
    Pipe,
}

impl OpenFileKind {
    pub fn label(&self) -> &'static str {
        match self {
            Self::File => "FILE",
            Self::Socket => "SOCK",
            Self::Device => "DEV",
            Self::Pipe => "PIPE",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
pub struct OpenFileEntry {
    #[serde(default)]
    pub pid: u32,
    #[serde(default)]
    pub process: String,
    #[serde(default)]
    pub user: String,
    #[serde(default)]
    pub fd: u32,
    #[serde(default)]
    pub count: u32,
    #[serde(default)]
    pub kind: OpenFileKind,
    #[serde(default)]
    pub path: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum FileKindFilter {
    #[default]
    All,
    Files,
    Sockets,
    Devices,
    Pipes,
}

impl FileKindFilter {
    pub const ALL: [FileKindFilter; 5] = [
        Self::All,
        Self::Files,
        Self::Sockets,
        Self::Devices,
        Self::Pipes,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Self::All => "All",
            Self::Files => "Files",
            Self::Sockets => "Sockets",
            Self::Devices => "Devices",
            Self::Pipes => "Pipes",
        }
    }

    pub fn slug(self) -> &'static str {
        match self {
            Self::All => "all",
            Self::Files => "file",
            Self::Sockets => "socket",
            Self::Devices => "device",
            Self::Pipes => "pipe",
        }
    }

    pub fn matches(self, kind: OpenFileKind) -> bool {
        match self {
            Self::All => true,
            Self::Files => kind == OpenFileKind::File,
            Self::Sockets => kind == OpenFileKind::Socket,
            Self::Devices => kind == OpenFileKind::Device,
            Self::Pipes => kind == OpenFileKind::Pipe,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct ProcessRow {
    pub id: String,
    pub pid: u32,
    pub ppid: u32,
    pub display_name: String,
    pub cmdline: String,
    pub user: String,
    pub state: char,
    pub cpu_pct: f32,
    pub mem_bytes: u64,
    pub mem_pct: f32,
    pub read_bytes_per_sec: f64,
    pub write_bytes_per_sec: f64,
    pub threads: u32,
    pub count: usize,
    pub depth: usize,
    pub tree_prefix: String,
    pub pinned: bool,
    pub has_children: bool,
    pub collapsed: bool,
    pub hidden_children: usize,
}

#[derive(
    Debug, Clone, Copy, PartialEq, Eq, Hash, Default, serde::Serialize, serde::Deserialize,
)]
pub enum PaneId {
    #[default]
    Overview,
    Cpu,
    Memory,
    Network,
    Disks,
    Processes,
    Files,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum ProcessMode {
    #[default]
    Table,
    Tree,
    Grouped,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum SortColumn {
    #[default]
    Cpu,
    Mem,
    Pid,
    Name,
    ReadIo,
    WriteIo,
    User,
    State,
    Count,
}

/// Signals the process dialog can send. Numbers are the Linux ABI values.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub enum SignalKind {
    Term,
    Kill,
    Stop,
    Cont,
}

impl SignalKind {
    pub fn number(self) -> i32 {
        match self {
            Self::Term => 15,
            Self::Kill => 9,
            Self::Stop => 19,
            Self::Cont => 18,
        }
    }

    /// Linux signal number passed to `libc::kill`.
    pub fn libc_signum(self) -> i32 {
        self.number()
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Term => "SIGTERM",
            Self::Kill => "SIGKILL",
            Self::Stop => "SIGSTOP",
            Self::Cont => "SIGCONT",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct SystemSnapshot {
    pub timestamp_sec: f64,
    pub hostname: String,
    pub kernel: String,
    pub cpu: CpuMetrics,
    pub mem: MemMetrics,
    pub networks: Vec<NetInterfaceMetrics>,
    pub net_rx_total_bps: f64,
    pub net_tx_total_bps: f64,
    pub disks: Vec<DiskMetrics>,
    pub sensors: Vec<SensorMetrics>,
    pub batteries: Vec<BatteryMetrics>,
    pub processes: Vec<ProcessInfo>,
    #[serde(default)]
    pub psi: PsiMetrics,
    #[serde(default)]
    pub sockets: Vec<NetSocketEntry>,
    #[serde(default)]
    pub open_files: Vec<OpenFileEntry>,
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct SelectedProcessHistory {
    pub pid: Option<u32>,
    pub cpu_pct: RingBuffer<f32>,
    pub mem_pct: RingBuffer<f32>,
    pub io_bps: RingBuffer<f64>,
}

impl SelectedProcessHistory {
    pub fn record_selected(&mut self, pid: Option<u32>, snap: &SystemSnapshot) {
        if self.pid != pid {
            self.pid = pid;
            self.cpu_pct.clear();
            self.mem_pct.clear();
            self.io_bps.clear();
        }
        if let Some(pid) = pid
            && let Some(proc) = snap.processes.iter().find(|proc| proc.pid == pid)
        {
            self.cpu_pct.push(proc.cpu_pct);
            self.mem_pct.push(proc.mem_pct);
            self.io_bps
                .push(proc.read_bytes_per_sec + proc.write_bytes_per_sec);
        }
    }
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct TelemetryHistory {
    pub cpu_total: HistoryRing<f32>,
    pub per_core: Vec<HistoryRing<f32>>,
    pub mem_pct: HistoryRing<f32>,
    pub swap_pct: HistoryRing<f32>,
    pub net_rx_bps: HistoryRing<f64>,
    pub net_tx_bps: HistoryRing<f64>,
    pub disk_read_bps: HistoryRing<f64>,
    pub disk_write_bps: HistoryRing<f64>,
    pub psi_cpu: RingBuffer<f32>,
    pub psi_mem: RingBuffer<f32>,
    pub psi_io: RingBuffer<f32>,
    pub selected_proc: SelectedProcessHistory,
}

impl TelemetryHistory {
    pub fn record(&mut self, snap: &SystemSnapshot) {
        self.cpu_total.push(snap.cpu.total_usage_pct);
        let max_index = snap.cpu.cores.iter().map(|core| core.index).max();
        if let Some(max_index) = max_index {
            let need = max_index.saturating_add(1);
            while self.per_core.len() < need {
                self.per_core.push(HistoryRing::default());
            }
            self.per_core.truncate(need);
            for core in &snap.cpu.cores {
                if let Some(ring) = self.per_core.get_mut(core.index) {
                    ring.push(core.usage_pct);
                }
            }
        } else {
            self.per_core.clear();
        }
        self.mem_pct.push(snap.mem.used_pct);
        self.swap_pct.push(snap.mem.swap_pct);
        self.net_rx_bps.push(snap.net_rx_total_bps);
        self.net_tx_bps.push(snap.net_tx_total_bps);

        let (disk_read, disk_write) = unique_disk_rates(&snap.disks);
        self.disk_read_bps.push(disk_read);
        self.disk_write_bps.push(disk_write);

        self.psi_cpu.push(snap.psi.cpu_some_pct);
        self.psi_mem.push(snap.psi.mem_some_pct);
        self.psi_io.push(snap.psi.io_some_pct);
    }

    pub fn record_selected(&mut self, pid: Option<u32>, snap: &SystemSnapshot) {
        self.selected_proc.record_selected(pid, snap);
    }
}

fn unique_disk_rates(disks: &[DiskMetrics]) -> (f64, f64) {
    let mut seen = HashSet::new();
    let mut read = 0.0;
    let mut write = 0.0;
    for disk in disks {
        if seen.insert(disk.device.clone()) {
            read += disk.read_bytes_per_sec;
            write += disk.write_bytes_per_sec;
        }
    }
    (read, write)
}

const BYTE_UNITS: [&str; 5] = ["B", "KiB", "MiB", "GiB", "TiB"];

pub fn format_bytes(bytes: u64) -> String {
    let mut value = bytes as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < BYTE_UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{bytes} B")
    } else {
        format!("{value:.1} {}", BYTE_UNITS[unit])
    }
}

pub fn format_rate(bytes_per_sec: f64) -> String {
    if !bytes_per_sec.is_finite() || bytes_per_sec <= 0.0 {
        return "0 B/s".to_string();
    }
    let whole = bytes_per_sec.round().clamp(0.0, u64::MAX as f64) as u64;
    format!("{}/s", format_bytes(whole))
}

pub fn format_uptime(secs: u64) -> String {
    let days = secs / 86_400;
    let hours = (secs % 86_400) / 3_600;
    let mins = (secs % 3_600) / 60;
    let rem = secs % 60;
    if days > 0 {
        format!("{days}d {hours:02}:{mins:02}:{rem:02}")
    } else {
        format!("{hours:02}:{mins:02}:{rem:02}")
    }
}

pub fn build_process_rows(
    processes: &[ProcessInfo],
    mode: ProcessMode,
    query: &str,
    sort_col: SortColumn,
    descending: bool,
) -> Vec<ProcessRow> {
    let empty = HashSet::new();
    build_process_rows_ext(processes, mode, query, sort_col, descending, &empty, &empty)
}

pub fn build_process_rows_ext(
    processes: &[ProcessInfo],
    mode: ProcessMode,
    query: &str,
    sort_col: SortColumn,
    descending: bool,
    collapsed_pids: &HashSet<u32>,
    pinned_pids: &HashSet<u32>,
) -> Vec<ProcessRow> {
    let unique = dedupe_pids(processes);
    let matched: Vec<&ProcessInfo> = unique
        .into_iter()
        .filter(|proc| query_matches(proc, query))
        .collect();
    match mode {
        ProcessMode::Table => rows_table(&matched, sort_col, descending, pinned_pids),
        ProcessMode::Grouped => rows_grouped(&matched, sort_col, descending, pinned_pids),
        ProcessMode::Tree => rows_tree(
            processes,
            query,
            sort_col,
            descending,
            collapsed_pids,
            pinned_pids,
        ),
    }
}

fn dedupe_pids(processes: &[ProcessInfo]) -> Vec<&ProcessInfo> {
    let mut seen = HashSet::new();
    let mut out = Vec::new();
    for proc in processes {
        if seen.insert(proc.pid) {
            out.push(proc);
        }
    }
    out
}

fn query_matches(proc: &ProcessInfo, query: &str) -> bool {
    let query = query.trim();
    if query.is_empty() {
        return true;
    }
    let query = query.to_lowercase();
    proc.name.to_lowercase().contains(&query)
        || proc.cmdline.to_lowercase().contains(&query)
        || proc.user.to_lowercase().contains(&query)
        || proc.pid.to_string().contains(&query)
}

fn rows_table(
    procs: &[&ProcessInfo],
    sort_col: SortColumn,
    descending: bool,
    pinned_pids: &HashSet<u32>,
) -> Vec<ProcessRow> {
    let mut rows: Vec<ProcessRow> = procs
        .iter()
        .copied()
        .map(|proc| {
            let mut row = row_from_process(proc);
            row.pinned = pinned_pids.contains(&row.pid);
            row
        })
        .collect();
    rows.sort_by(|a, b| {
        b.pinned
            .cmp(&a.pinned)
            .then_with(|| cmp_rows(a, b, sort_col, descending))
    });
    rows
}

fn row_from_process(proc: &ProcessInfo) -> ProcessRow {
    ProcessRow {
        id: proc.pid.to_string(),
        pid: proc.pid,
        ppid: proc.ppid,
        display_name: proc.name.clone(),
        cmdline: proc.cmdline.clone(),
        user: proc.user.clone(),
        state: proc.state,
        cpu_pct: proc.cpu_pct,
        mem_bytes: proc.mem_bytes,
        mem_pct: proc.mem_pct,
        read_bytes_per_sec: proc.read_bytes_per_sec,
        write_bytes_per_sec: proc.write_bytes_per_sec,
        threads: proc.threads,
        count: 1,
        depth: 0,
        tree_prefix: String::new(),
        pinned: false,
        has_children: false,
        collapsed: false,
        hidden_children: 0,
    }
}

struct GroupAcc {
    pid: u32,
    ppid: u32,
    cmdline: String,
    user: String,
    state: char,
    cpu_pct: f32,
    mem_bytes: u64,
    mem_pct: f32,
    read_bytes_per_sec: f64,
    write_bytes_per_sec: f64,
    threads: u32,
    count: usize,
    pinned: bool,
}

fn rows_grouped(
    procs: &[&ProcessInfo],
    sort_col: SortColumn,
    descending: bool,
    pinned_pids: &HashSet<u32>,
) -> Vec<ProcessRow> {
    let mut groups: HashMap<String, GroupAcc> = HashMap::new();
    for proc in procs {
        let member_pinned = pinned_pids.contains(&proc.pid);
        match groups.get_mut(&proc.name) {
            None => {
                groups.insert(proc.name.clone(), GroupAcc::from_proc(proc, member_pinned));
            }
            Some(group) => group.add(proc, member_pinned),
        }
    }
    let mut rows: Vec<ProcessRow> = groups
        .into_iter()
        .map(|(name, group)| ProcessRow {
            id: name.clone(),
            pid: group.pid,
            ppid: group.ppid,
            display_name: name,
            cmdline: group.cmdline,
            user: group.user,
            state: group.state,
            cpu_pct: group.cpu_pct,
            mem_bytes: group.mem_bytes,
            mem_pct: group.mem_pct,
            read_bytes_per_sec: group.read_bytes_per_sec,
            write_bytes_per_sec: group.write_bytes_per_sec,
            threads: group.threads,
            count: group.count,
            depth: 0,
            tree_prefix: String::new(),
            pinned: group.pinned,
            has_children: false,
            collapsed: false,
            hidden_children: 0,
        })
        .collect();
    rows.sort_by(|a, b| {
        b.pinned
            .cmp(&a.pinned)
            .then_with(|| cmp_rows(a, b, sort_col, descending))
    });
    rows
}

impl GroupAcc {
    fn from_proc(proc: &ProcessInfo, pinned: bool) -> Self {
        Self {
            pid: proc.pid,
            ppid: proc.ppid,
            cmdline: proc.cmdline.clone(),
            user: proc.user.clone(),
            state: proc.state,
            cpu_pct: proc.cpu_pct,
            mem_bytes: proc.mem_bytes,
            mem_pct: proc.mem_pct,
            read_bytes_per_sec: proc.read_bytes_per_sec,
            write_bytes_per_sec: proc.write_bytes_per_sec,
            threads: proc.threads,
            count: 1,
            pinned,
        }
    }

    fn add(&mut self, proc: &ProcessInfo, pinned: bool) {
        if proc.pid < self.pid {
            self.pid = proc.pid;
            self.ppid = proc.ppid;
            self.cmdline.clone_from(&proc.cmdline);
            self.user.clone_from(&proc.user);
            self.state = proc.state;
        }
        self.cpu_pct += proc.cpu_pct;
        self.mem_bytes = self.mem_bytes.saturating_add(proc.mem_bytes);
        self.mem_pct += proc.mem_pct;
        self.read_bytes_per_sec += proc.read_bytes_per_sec;
        self.write_bytes_per_sec += proc.write_bytes_per_sec;
        self.threads = self.threads.saturating_add(proc.threads);
        self.count += 1;
        self.pinned |= pinned;
    }
}

fn rows_tree(
    processes: &[ProcessInfo],
    query: &str,
    sort_col: SortColumn,
    descending: bool,
    collapsed_pids: &HashSet<u32>,
    pinned_pids: &HashSet<u32>,
) -> Vec<ProcessRow> {
    let unique = dedupe_pids(processes);
    let by_pid: HashMap<u32, &ProcessInfo> = unique.iter().map(|proc| (proc.pid, *proc)).collect();
    let mut children: HashMap<u32, Vec<u32>> = HashMap::new();
    let mut roots = Vec::new();
    for proc in &unique {
        if proc.ppid != proc.pid && by_pid.contains_key(&proc.ppid) {
            children.entry(proc.ppid).or_default().push(proc.pid);
        } else {
            roots.push(proc.pid);
        }
    }

    let mut visible_memo: HashMap<u32, bool> = HashMap::new();
    let mut visiting = HashSet::new();
    fn subtree_visible(
        pid: u32,
        by_pid: &HashMap<u32, &ProcessInfo>,
        children: &HashMap<u32, Vec<u32>>,
        query: &str,
        memo: &mut HashMap<u32, bool>,
        visiting: &mut HashSet<u32>,
    ) -> bool {
        if let Some(known) = memo.get(&pid) {
            return *known;
        }
        if !visiting.insert(pid) {
            return false;
        }
        let self_match = by_pid
            .get(&pid)
            .is_some_and(|proc| query_matches(proc, query));
        let child_match = children.get(&pid).is_some_and(|kids| {
            kids.iter()
                .any(|child| subtree_visible(*child, by_pid, children, query, memo, visiting))
        });
        visiting.remove(&pid);
        let visible = self_match || child_match;
        memo.insert(pid, visible);
        visible
    }

    for proc in &unique {
        subtree_visible(
            proc.pid,
            &by_pid,
            &children,
            query,
            &mut visible_memo,
            &mut visiting,
        );
    }

    let keep = |pid: u32| visible_memo.get(&pid).copied().unwrap_or(false);
    roots.retain(|pid| keep(*pid));
    for kids in children.values_mut() {
        kids.retain(|pid| keep(*pid));
    }

    let cmp_pids = |a: &u32, b: &u32| {
        let left = by_pid.get(a).map(|proc| row_from_process(proc));
        let right = by_pid.get(b).map(|proc| row_from_process(proc));
        match (left, right) {
            (Some(left), Some(right)) => cmp_rows(&left, &right, sort_col, descending),
            _ => a.cmp(b),
        }
    };
    let sort_roots = |ids: &mut [u32]| {
        ids.sort_by(|a, b| {
            pinned_pids
                .contains(b)
                .cmp(&pinned_pids.contains(a))
                .then_with(|| cmp_pids(a, b))
        });
    };
    sort_roots(&mut roots);
    for kids in children.values_mut() {
        kids.sort_by(cmp_pids);
    }

    let mut cursor = TreeCursor {
        by_pid: &by_pid,
        children: &children,
        collapsed_pids,
        pinned_pids,
        visited: HashSet::new(),
        rows: Vec::new(),
    };
    for (index, pid) in roots.iter().copied().enumerate() {
        cursor.walk(pid, 0, "", index + 1 == roots.len());
    }
    // A parent cycle has no pid whose parent is outside the map, so the walk
    // above never enters it. Promote the remaining visible pids, in sort
    // order, and rely on `visited` so each node is emitted once.
    let mut cyclic = unique
        .iter()
        .map(|proc| proc.pid)
        .filter(|pid| keep(*pid) && !cursor.visited.contains(pid))
        .collect::<Vec<_>>();
    sort_roots(&mut cyclic);
    let cyclic_len = cyclic.len();
    for (index, pid) in cyclic.into_iter().enumerate() {
        cursor.walk(pid, 0, "", index + 1 == cyclic_len);
    }
    cursor.rows
}

struct TreeCursor<'a> {
    by_pid: &'a HashMap<u32, &'a ProcessInfo>,
    children: &'a HashMap<u32, Vec<u32>>,
    collapsed_pids: &'a HashSet<u32>,
    pinned_pids: &'a HashSet<u32>,
    visited: HashSet<u32>,
    rows: Vec<ProcessRow>,
}

impl TreeCursor<'_> {
    fn walk(&mut self, pid: u32, depth: usize, child_prefix: &str, is_last: bool) {
        if !self.visited.insert(pid) {
            return;
        }
        let Some(proc) = self.by_pid.get(&pid) else {
            return;
        };
        let kids: Vec<u32> = self
            .children
            .get(&pid)
            .map(|list| {
                list.iter()
                    .copied()
                    .filter(|child| {
                        !self.visited.contains(child) && self.by_pid.contains_key(child)
                    })
                    .collect()
            })
            .unwrap_or_default();
        let has_children = !kids.is_empty();
        let branch = if depth == 0 {
            ""
        } else if is_last {
            "└─ "
        } else {
            "├─ "
        };
        let mut row = row_from_process(proc);
        row.depth = depth;
        row.tree_prefix = format!("{child_prefix}{branch}");
        row.pinned = self.pinned_pids.contains(&pid);
        row.has_children = has_children;

        if has_children && self.collapsed_pids.contains(&pid) {
            row.collapsed = true;
            row.hidden_children = self.mark_hidden_descendants(&kids);
            self.rows.push(row);
            return;
        }

        let next_prefix = if depth == 0 {
            String::new()
        } else if is_last {
            format!("{child_prefix}   ")
        } else {
            format!("{child_prefix}│  ")
        };
        self.rows.push(row);
        for (index, child) in kids.iter().copied().enumerate() {
            self.walk(child, depth + 1, &next_prefix, index + 1 == kids.len());
        }
    }

    fn mark_hidden_descendants(&mut self, kids: &[u32]) -> usize {
        let mut count = 0;
        let mut stack: Vec<u32> = kids.to_vec();
        while let Some(desc) = stack.pop() {
            if !self.by_pid.contains_key(&desc) || !self.visited.insert(desc) {
                continue;
            }
            count += 1;
            if let Some(grandkids) = self.children.get(&desc) {
                stack.extend(grandkids.iter().copied());
            }
        }
        count
    }
}

fn cmp_rows(a: &ProcessRow, b: &ProcessRow, sort_col: SortColumn, descending: bool) -> Ordering {
    let primary = match sort_col {
        SortColumn::Cpu => a.cpu_pct.total_cmp(&b.cpu_pct),
        SortColumn::Mem => a
            .mem_bytes
            .cmp(&b.mem_bytes)
            .then(a.mem_pct.total_cmp(&b.mem_pct)),
        SortColumn::Pid => a.pid.cmp(&b.pid),
        SortColumn::Name => a
            .display_name
            .to_lowercase()
            .cmp(&b.display_name.to_lowercase()),
        SortColumn::ReadIo => a.read_bytes_per_sec.total_cmp(&b.read_bytes_per_sec),
        SortColumn::WriteIo => a.write_bytes_per_sec.total_cmp(&b.write_bytes_per_sec),
        SortColumn::User => a.user.to_lowercase().cmp(&b.user.to_lowercase()),
        SortColumn::State => a.state.cmp(&b.state),
        SortColumn::Count => a.count.cmp(&b.count),
    };
    let primary = if descending {
        primary.reverse()
    } else {
        primary
    };
    primary.then(a.pid.cmp(&b.pid))
}

pub fn filter_open_files(
    files: &[OpenFileEntry],
    kind_filter: FileKindFilter,
    query: &str,
) -> Vec<OpenFileEntry> {
    let query = query.trim();
    if query.is_empty() {
        if kind_filter == FileKindFilter::All {
            return files.to_vec();
        }
        return files
            .iter()
            .filter(|entry| kind_filter.matches(entry.kind))
            .cloned()
            .collect();
    }
    let q = query.to_lowercase();
    files
        .iter()
        .filter(|entry| {
            kind_filter.matches(entry.kind)
                && (entry.path.to_lowercase().contains(&q)
                    || entry.process.to_lowercase().contains(&q)
                    || entry.user.to_lowercase().contains(&q)
                    || entry.pid.to_string().contains(&q)
                    || entry.kind.label().to_ascii_lowercase().contains(&q))
        })
        .cloned()
        .collect()
}

pub fn filter_sockets(
    sockets: &[NetSocketEntry],
    kind_filter: SocketKindFilter,
    query: &str,
) -> Vec<NetSocketEntry> {
    let query = query.trim();
    if query.is_empty() {
        if kind_filter == SocketKindFilter::All {
            return sockets.to_vec();
        }
        return sockets
            .iter()
            .filter(|entry| kind_filter.matches(entry))
            .cloned()
            .collect();
    }
    let q = query.to_lowercase();
    sockets
        .iter()
        .filter(|entry| {
            kind_filter.matches(entry)
                && (entry.local_addr.to_lowercase().contains(&q)
                    || entry.remote_addr.to_lowercase().contains(&q)
                    || entry.state.to_lowercase().contains(&q)
                    || entry.proto.to_lowercase().contains(&q)
                    || entry.process.to_lowercase().contains(&q)
                    || entry
                        .pid
                        .is_some_and(|pid| pid.to_string().contains(&q)))
        })
        .cloned()
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn proc(pid: u32, ppid: u32, name: &str, cpu: f32, mem: u64) -> ProcessInfo {
        ProcessInfo {
            pid,
            ppid,
            name: name.to_string(),
            cmdline: format!("/usr/bin/{name}"),
            user: "alice".to_string(),
            state: 'S',
            cpu_pct: cpu,
            mem_bytes: mem,
            mem_pct: mem as f32 / 100.0,
            read_bytes_per_sec: f64::from(pid) * 10.0,
            write_bytes_per_sec: f64::from(pid),
            threads: 1,
            fds: None,
            ..ProcessInfo::default()
        }
    }

    #[test]
    fn history_ring_wraps_and_reports_tail() {
        let mut ring = HistoryRing::new(3);
        assert!(ring.is_empty());
        assert_eq!(ring.len(), 0);
        assert_eq!(ring.latest(), None);
        for value in 0..5 {
            ring.push(value);
        }
        assert_eq!(ring.len(), 3);
        assert_eq!(ring.as_vec(), vec![2, 3, 4]);
        assert_eq!(ring.iter().copied().collect::<Vec<_>>(), vec![2, 3, 4]);
        assert_eq!(ring.latest(), Some(&4));
        assert_eq!(ring.tail(2), vec![3, 4]);
        assert_eq!(ring.tail(0), Vec::<i32>::new());
        assert_eq!(ring.tail(10), vec![2, 3, 4]);
        assert_eq!(HistoryRing::<f32>::default().len(), 0);
        let mut full = HistoryRing::<u8>::default();
        for value in 0..=HistoryRing::<u8>::DEFAULT_CAPACITY as u8 {
            full.push(value);
        }
        assert_eq!(full.len(), HistoryRing::<u8>::DEFAULT_CAPACITY);
        assert_eq!(full.as_vec().first().copied(), Some(1));
    }

    #[test]
    fn format_helpers_cover_units_rates_and_uptime() {
        assert_eq!(format_bytes(0), "0 B");
        assert_eq!(format_bytes(512), "512 B");
        assert_eq!(format_bytes(1024), "1.0 KiB");
        assert_eq!(format_bytes(1536), "1.5 KiB");
        assert_eq!(format_bytes(1024 * 1024), "1.0 MiB");
        assert_eq!(format_bytes(1024 * 1024 * 1024), "1.0 GiB");
        assert_eq!(format_rate(0.0), "0 B/s");
        assert_eq!(format_rate(-5.0), "0 B/s");
        assert_eq!(format_rate(f64::NAN), "0 B/s");
        assert_eq!(format_rate(1536.2), "1.5 KiB/s");
        assert_eq!(format_uptime(0), "00:00:00");
        assert_eq!(format_uptime(59), "00:00:59");
        assert_eq!(format_uptime(3661), "01:01:01");
        assert_eq!(format_uptime(90_061), "1d 01:01:01");
    }

    #[test]
    fn table_filters_and_sorts() {
        let procs = vec![
            proc(2, 1, "nginx", 1.0, 30),
            proc(3, 1, "vim", 9.0, 10),
            proc(4, 1, "nginx", 4.0, 50),
        ];
        let rows = build_process_rows(&procs, ProcessMode::Table, "NGINX", SortColumn::Cpu, true);
        assert_eq!(
            rows.iter().map(|row| row.pid).collect::<Vec<_>>(),
            vec![4, 2]
        );
        let by_name = build_process_rows(&procs, ProcessMode::Table, "", SortColumn::Name, false);
        assert_eq!(
            by_name
                .iter()
                .map(|row| row.display_name.as_str())
                .collect::<Vec<_>>(),
            vec!["nginx", "nginx", "vim"]
        );
        let by_mem = build_process_rows(&procs, ProcessMode::Table, "4", SortColumn::Mem, true);
        assert_eq!(by_mem.len(), 1);
        assert_eq!(by_mem[0].pid, 4);
        assert_eq!(by_mem[0].count, 1);
        assert_eq!(by_mem[0].depth, 0);
        assert!(by_mem[0].tree_prefix.is_empty());
    }

    #[test]
    fn grouped_rows_sum_members_and_sort_by_count() {
        let mut nginx_a = proc(5, 1, "nginx", 1.5, 10);
        nginx_a.threads = 2;
        nginx_a.read_bytes_per_sec = 100.0;
        let mut nginx_b = proc(2, 1, "nginx", 2.5, 20);
        nginx_b.threads = 3;
        nginx_b.read_bytes_per_sec = 40.0;
        nginx_b.user = "root".to_string();
        let vim = proc(9, 1, "vim", 3.0, 5);
        let rows = build_process_rows(
            &[nginx_a, nginx_b, vim],
            ProcessMode::Grouped,
            "",
            SortColumn::Count,
            true,
        );
        assert_eq!(rows[0].display_name, "nginx");
        assert_eq!(rows[0].id, "nginx");
        assert_eq!(rows[0].count, 2);
        assert_eq!(rows[0].pid, 2);
        assert_eq!(rows[0].user, "root");
        assert_eq!(rows[0].cpu_pct, 4.0);
        assert_eq!(rows[0].mem_bytes, 30);
        assert_eq!(rows[0].threads, 5);
        assert_eq!(rows[0].read_bytes_per_sec, 140.0);
        assert_eq!(rows[1].display_name, "vim");
        assert_eq!(rows[1].count, 1);
    }

    #[test]
    fn tree_prefixes_keep_matching_ancestors() {
        let procs = vec![
            proc(1, 0, "systemd", 0.1, 1),
            proc(10, 1, "sshd", 0.2, 1),
            proc(11, 10, "sshd", 0.2, 1),
            proc(12, 11, "bash", 0.3, 1),
            proc(13, 12, "vim", 1.0, 1),
            proc(14, 12, "htop", 9.0, 1),
            proc(20, 1, "nginx", 0.4, 1),
        ];
        let rows = build_process_rows(&procs, ProcessMode::Tree, "", SortColumn::Pid, false);
        let prefix = |pid: u32| {
            rows.iter()
                .find(|row| row.pid == pid)
                .map(|row| (row.depth, row.tree_prefix.clone()))
                .unwrap()
        };
        assert_eq!(prefix(1), (0, String::new()));
        assert_eq!(prefix(10), (1, "├─ ".to_string()));
        assert_eq!(prefix(11), (2, "│  └─ ".to_string()));
        assert_eq!(prefix(12), (3, "│     └─ ".to_string()));
        assert_eq!(prefix(13), (4, "│        ├─ ".to_string()));
        assert_eq!(prefix(14), (4, "│        └─ ".to_string()));
        assert_eq!(prefix(20), (1, "└─ ".to_string()));

        let filtered = build_process_rows(&procs, ProcessMode::Tree, "vim", SortColumn::Pid, false);
        assert_eq!(
            filtered.iter().map(|row| row.pid).collect::<Vec<_>>(),
            vec![1, 10, 11, 12, 13]
        );
        assert_eq!(filtered[1].tree_prefix, "└─ ");
        assert_eq!(filtered[4].tree_prefix, "         └─ ");

        let by_cpu = build_process_rows(&procs, ProcessMode::Tree, "", SortColumn::Cpu, true);
        let bash_children: Vec<u32> = by_cpu
            .iter()
            .filter(|row| row.ppid == 12)
            .map(|row| row.pid)
            .collect();
        assert_eq!(bash_children, vec![14, 13]);
    }

    #[test]
    fn tree_emits_a_two_node_parent_cycle_once() {
        let procs = vec![proc(2, 3, "two", 1.0, 1), proc(3, 2, "three", 2.0, 1)];
        let rows = build_process_rows(&procs, ProcessMode::Tree, "", SortColumn::Pid, false);
        assert_eq!(
            rows.iter()
                .map(|row| (row.pid, row.depth, row.tree_prefix.as_str()))
                .collect::<Vec<_>>(),
            vec![(2, 0, ""), (3, 1, "└─ ")]
        );
    }

    #[test]
    fn signal_kinds_expose_linux_numbers_and_labels() {
        assert_eq!(SignalKind::Term.number(), 15);
        assert_eq!(SignalKind::Kill.number(), 9);
        assert_eq!(SignalKind::Stop.number(), 19);
        assert_eq!(SignalKind::Cont.number(), 18);
        assert_eq!(SignalKind::Term.libc_signum(), SignalKind::Term.number());
        assert_eq!(SignalKind::Kill.libc_signum(), SignalKind::Kill.number());
        assert_eq!(SignalKind::Stop.libc_signum(), SignalKind::Stop.number());
        assert_eq!(SignalKind::Cont.libc_signum(), SignalKind::Cont.number());
        assert_eq!(SignalKind::Term.label(), "SIGTERM");
        assert_eq!(SignalKind::Kill.label(), "SIGKILL");
        assert_eq!(SignalKind::Stop.label(), "SIGSTOP");
        assert_eq!(SignalKind::Cont.label(), "SIGCONT");
    }

    #[test]
    fn history_records_snapshot_series_and_dedupes_disk_devices() {
        let mut history = TelemetryHistory::default();
        let mut snap = SystemSnapshot {
            cpu: CpuMetrics {
                total_usage_pct: 12.5,
                cores: vec![
                    CoreMetrics {
                        index: 0,
                        usage_pct: 10.0,
                        ..CoreMetrics::default()
                    },
                    CoreMetrics {
                        index: 1,
                        usage_pct: 15.0,
                        ..CoreMetrics::default()
                    },
                ],
                ..CpuMetrics::default()
            },
            mem: MemMetrics {
                used_pct: 40.0,
                swap_pct: 2.0,
                ..MemMetrics::default()
            },
            net_rx_total_bps: 1000.0,
            net_tx_total_bps: 250.0,
            disks: vec![
                DiskMetrics {
                    device: "nvme0n1p2".to_string(),
                    read_bytes_per_sec: 100.0,
                    write_bytes_per_sec: 10.0,
                    ..DiskMetrics::default()
                },
                DiskMetrics {
                    device: "nvme0n1p2".to_string(),
                    read_bytes_per_sec: 100.0,
                    write_bytes_per_sec: 10.0,
                    ..DiskMetrics::default()
                },
                DiskMetrics {
                    device: "sda1".to_string(),
                    read_bytes_per_sec: 50.0,
                    write_bytes_per_sec: 5.0,
                    ..DiskMetrics::default()
                },
            ],
            ..SystemSnapshot::default()
        };
        history.record(&snap);
        snap.cpu.total_usage_pct = 20.0;
        snap.cpu.cores.pop();
        history.record(&snap);
        assert_eq!(history.cpu_total.as_vec(), vec![12.5, 20.0]);
        assert_eq!(history.per_core.len(), 1);
        assert_eq!(history.per_core[0].latest(), Some(&10.0));
        assert_eq!(history.mem_pct.latest(), Some(&40.0));
        assert_eq!(history.swap_pct.latest(), Some(&2.0));
        assert_eq!(history.net_rx_bps.latest(), Some(&1000.0));
        assert_eq!(history.net_tx_bps.latest(), Some(&250.0));
        assert_eq!(history.disk_read_bps.as_vec(), vec![150.0, 150.0]);
        assert_eq!(history.disk_write_bps.latest(), Some(&15.0));
    }

    #[test]
    fn build_process_rows_ext_pins_in_table_grouped_and_tree_modes() {
        let procs = vec![
            proc(10, 1, "nginx", 1.0, 20),
            proc(20, 1, "nginx", 2.0, 30),
            proc(30, 1, "rustc", 90.0, 500),
            proc(40, 1, "vim", 0.5, 10),
        ];
        let empty = HashSet::new();
        let pinned: HashSet<u32> = [40, 20].into_iter().collect();

        // Table: pinned rows first (sorted by CPU desc within pinned), then unpinned by CPU desc.
        let table = build_process_rows_ext(
            &procs,
            ProcessMode::Table,
            "",
            SortColumn::Cpu,
            true,
            &empty,
            &pinned,
        );
        assert_eq!(
            table
                .iter()
                .map(|row| (row.pid, row.pinned))
                .collect::<Vec<_>>(),
            vec![(20, true), (40, true), (30, false), (10, false)]
        );

        // Grouped: pinning non-representative member pid 20 pins the whole "nginx" group (pid 10).
        let grouped = build_process_rows_ext(
            &procs,
            ProcessMode::Grouped,
            "",
            SortColumn::Cpu,
            true,
            &empty,
            &pinned,
        );
        assert_eq!(
            grouped
                .iter()
                .map(|row| (row.display_name.as_str(), row.pid, row.pinned))
                .collect::<Vec<_>>(),
            vec![("nginx", 10, true), ("vim", 40, true), ("rustc", 30, false)]
        );

        // Tree: pinned root nodes sort before unpinned roots while preserving hierarchy.
        let tree_procs = vec![
            proc(1, 0, "systemd", 10.0, 10),
            proc(2, 0, "kthreadd", 0.1, 0),
            proc(11, 1, "sshd", 2.0, 5),
            proc(21, 2, "kworker", 0.2, 0),
        ];
        let pinned_roots: HashSet<u32> = [2, 11].into_iter().collect();
        let tree = build_process_rows_ext(
            &tree_procs,
            ProcessMode::Tree,
            "",
            SortColumn::Cpu,
            true,
            &empty,
            &pinned_roots,
        );
        assert_eq!(
            tree.iter()
                .map(|row| (row.pid, row.depth, row.pinned, row.has_children))
                .collect::<Vec<_>>(),
            vec![
                (2, 0, true, true),
                (21, 1, false, false),
                (1, 0, false, true),
                (11, 1, true, false),
            ]
        );
    }

    #[test]
    fn build_process_rows_ext_collapses_subtrees_and_counts_visible_descendants() {
        let procs = vec![
            proc(1, 0, "systemd", 0.1, 1),
            proc(10, 1, "sshd", 0.2, 1),
            proc(11, 10, "sshd", 0.2, 1),
            proc(12, 11, "bash", 0.3, 1),
            proc(13, 12, "vim", 1.0, 1),
            proc(14, 12, "htop", 9.0, 1),
            proc(20, 1, "nginx", 0.4, 1),
        ];
        let empty = HashSet::new();
        // Include leaf pid 20 in collapsed_pids to verify leaves stay collapsed = false.
        let collapsed: HashSet<u32> = [10, 12, 20].into_iter().collect();

        let rows = build_process_rows_ext(
            &procs,
            ProcessMode::Tree,
            "",
            SortColumn::Pid,
            false,
            &collapsed,
            &empty,
        );
        assert_eq!(
            rows.iter()
                .map(|row| (
                    row.pid,
                    row.has_children,
                    row.collapsed,
                    row.hidden_children,
                    row.tree_prefix.as_str()
                ))
                .collect::<Vec<_>>(),
            vec![
                (1, true, false, 0, ""),
                (10, true, true, 4, "├─ "),
                (20, false, false, 0, "└─ "),
            ]
        );

        // With search query "vim", only 11, 12, 13 are visible under 10 -> hidden_children = 3.
        let filtered = build_process_rows_ext(
            &procs,
            ProcessMode::Tree,
            "vim",
            SortColumn::Pid,
            false,
            &collapsed,
            &empty,
        );
        assert_eq!(
            filtered
                .iter()
                .map(|row| (row.pid, row.collapsed, row.hidden_children))
                .collect::<Vec<_>>(),
            vec![(1, false, 0), (10, true, 3)]
        );

        // Collapsing a cyclic root must not re-emit its cycle partner.
        let cycle = vec![proc(2, 3, "two", 1.0, 1), proc(3, 2, "three", 2.0, 1)];
        let cycle_collapsed: HashSet<u32> = [2].into_iter().collect();
        let cycle_rows = build_process_rows_ext(
            &cycle,
            ProcessMode::Tree,
            "",
            SortColumn::Pid,
            false,
            &cycle_collapsed,
            &empty,
        );
        assert_eq!(cycle_rows.len(), 1);
        assert_eq!(cycle_rows[0].pid, 2);
        assert!(cycle_rows[0].collapsed);
        assert_eq!(cycle_rows[0].hidden_children, 1);
    }

    #[test]
    fn psi_and_selected_process_history_record_and_reset_on_pid_change() {
        let mut history = TelemetryHistory::default();
        let snap_a = SystemSnapshot {
            psi: PsiMetrics {
                cpu_some_pct: 3.5,
                mem_some_pct: 1.25,
                mem_full_pct: 0.4,
                io_some_pct: 6.0,
                io_full_pct: 2.0,
            },
            processes: vec![
                proc(100, 1, "postgres", 12.0, 500),
                proc(200, 1, "nginx", 4.0, 100),
            ],
            ..SystemSnapshot::default()
        };
        let mut snap_b = snap_a.clone();
        snap_b.psi.cpu_some_pct = 7.0;
        snap_b.psi.mem_some_pct = 2.5;
        snap_b.psi.io_some_pct = 9.0;
        snap_b.processes[0].cpu_pct = 18.0;
        snap_b.processes[0].mem_pct = 8.0;

        history.record(&snap_a);
        history.selected_proc.record_selected(Some(100), &snap_a);
        history.record(&snap_b);
        history.record_selected(Some(100), &snap_b);

        assert_eq!(history.psi_cpu.as_vec(), vec![3.5, 7.0]);
        assert_eq!(history.psi_mem.as_vec(), vec![1.25, 2.5]);
        assert_eq!(history.psi_io.as_vec(), vec![6.0, 9.0]);
        assert_eq!(history.selected_proc.pid, Some(100));
        assert_eq!(history.selected_proc.cpu_pct.as_vec(), vec![12.0, 18.0]);
        assert_eq!(history.selected_proc.mem_pct.as_vec(), vec![5.0, 8.0]);
        assert_eq!(history.selected_proc.io_bps.as_vec(), vec![1100.0, 1100.0]);

        // Switching PID clears previous samples and records the new PID.
        history.selected_proc.record_selected(Some(200), &snap_b);
        assert_eq!(history.selected_proc.pid, Some(200));
        assert_eq!(history.selected_proc.cpu_pct.as_vec(), vec![4.0]);
        assert_eq!(history.selected_proc.mem_pct.as_vec(), vec![1.0]);
        assert_eq!(history.selected_proc.io_bps.as_vec(), vec![2200.0]);

        // Clearing selection resets rings.
        history.selected_proc.record_selected(None, &snap_b);
        assert_eq!(history.selected_proc.pid, None);
        assert!(history.selected_proc.cpu_pct.is_empty());
        assert!(history.selected_proc.mem_pct.is_empty());
        assert!(history.selected_proc.io_bps.is_empty());
    }

    #[test]
    fn serde_defaults_allow_legacy_json_without_new_telemetry_fields() {
        let legacy_snap: SystemSnapshot = serde_json::from_str(
            r#"{
                "timestamp_sec": 1.0,
                "hostname": "legacy",
                "kernel": "6.1",
                "cpu": {
                    "model_name": "CPU",
                    "total_usage_pct": 0.0,
                    "user_pct": 0.0,
                    "system_pct": 0.0,
                    "iowait_pct": 0.0,
                    "load_avg": [0.0, 0.0, 0.0],
                    "cores": [],
                    "uptime_secs": 10,
                    "tasks_total": 0,
                    "tasks_running": 0
                },
                "mem": {
                    "total_bytes": 1024,
                    "used_bytes": 512,
                    "available_bytes": 512,
                    "cached_bytes": 0,
                    "buffers_bytes": 0,
                    "used_pct": 50.0,
                    "swap_total_bytes": 0,
                    "swap_used_bytes": 0,
                    "swap_pct": 0.0
                },
                "networks": [],
                "net_rx_total_bps": 0.0,
                "net_tx_total_bps": 0.0,
                "disks": [{
                    "device": "sda1",
                    "mount_point": "/",
                    "fs_type": "ext4",
                    "total_bytes": 1000,
                    "used_bytes": 500,
                    "free_bytes": 500,
                    "used_pct": 50.0,
                    "read_bytes_per_sec": 0.0,
                    "write_bytes_per_sec": 0.0
                }],
                "sensors": [],
                "batteries": [],
                "processes": [{
                    "pid": 1,
                    "ppid": 0,
                    "name": "init",
                    "cmdline": "/sbin/init",
                    "user": "root",
                    "state": "S",
                    "cpu_pct": 0.0,
                    "mem_bytes": 4096,
                    "mem_pct": 0.1,
                    "read_bytes_per_sec": 0.0,
                    "write_bytes_per_sec": 0.0,
                    "threads": 1,
                    "fds": null
                }]
            }"#,
        )
        .expect("legacy snapshot deserializes");
        assert_eq!(legacy_snap.psi, PsiMetrics::default());
        assert!(legacy_snap.sockets.is_empty());
        assert_eq!(legacy_snap.mem.shared_bytes, 0);
        assert_eq!(legacy_snap.mem.dirty_bytes, 0);
        assert_eq!(legacy_snap.mem.writeback_bytes, 0);
        assert_eq!(legacy_snap.mem.slab_bytes, 0);
        assert_eq!(legacy_snap.disks[0].busy_pct, 0.0);
        assert_eq!(legacy_snap.disks[0].await_ms, 0.0);
        assert_eq!(legacy_snap.processes[0].nice, 0);
        assert_eq!(legacy_snap.processes[0].unit, None);
        assert_eq!(legacy_snap.processes[0].cwd, None);
        assert_eq!(legacy_snap.processes[0].exe, None);
        assert!(legacy_snap.processes[0].listening_ports.is_empty());
        assert!(legacy_snap.processes[0].open_files.is_empty());
        assert!(legacy_snap.open_files.is_empty());
    }

    #[test]
    fn open_file_kinds_filters_and_search_match_expected_entries() {
        assert_eq!(OpenFileKind::File.label(), "FILE");
        assert_eq!(OpenFileKind::Socket.label(), "SOCK");
        assert_eq!(OpenFileKind::Device.label(), "DEV");
        assert_eq!(OpenFileKind::Pipe.label(), "PIPE");
        assert_eq!(OpenFileKind::default(), OpenFileKind::File);
        assert_eq!(FileKindFilter::default(), FileKindFilter::All);

        for filter in FileKindFilter::ALL {
            assert!(!filter.label().is_empty());
            assert!(!filter.slug().is_empty());
            assert!(FileKindFilter::All.matches(match filter {
                FileKindFilter::All | FileKindFilter::Files => OpenFileKind::File,
                FileKindFilter::Sockets => OpenFileKind::Socket,
                FileKindFilter::Devices => OpenFileKind::Device,
                FileKindFilter::Pipes => OpenFileKind::Pipe,
            }));
        }

        let entries = vec![
            OpenFileEntry {
                pid: 700,
                process: "postgres".to_string(),
                user: "postgres".to_string(),
                fd: 4,
                count: 1,
                kind: OpenFileKind::File,
                path: "/var/lib/postgresql/data/PG_VERSION".to_string(),
            },
            OpenFileEntry {
                pid: 700,
                process: "postgres".to_string(),
                user: "postgres".to_string(),
                fd: 6,
                count: 1,
                kind: OpenFileKind::Socket,
                path: "TCP 127.0.0.1:5432 -> * (LISTEN)".to_string(),
            },
            OpenFileEntry {
                pid: 800,
                process: "firefox".to_string(),
                user: "alice".to_string(),
                fd: 12,
                count: 2,
                kind: OpenFileKind::Device,
                path: "/dev/dri/renderD128".to_string(),
            },
            OpenFileEntry {
                pid: 1001,
                process: "rustc".to_string(),
                user: "alice".to_string(),
                fd: 9,
                count: 4,
                kind: OpenFileKind::Pipe,
                path: "pipe:[94102]".to_string(),
            },
        ];

        assert_eq!(
            filter_open_files(&entries, FileKindFilter::All, "").len(),
            4
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::Files, "")
                .iter()
                .map(|e| e.kind)
                .collect::<Vec<_>>(),
            vec![OpenFileKind::File]
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::Sockets, "")
                .iter()
                .map(|e| e.path.as_str())
                .collect::<Vec<_>>(),
            vec!["TCP 127.0.0.1:5432 -> * (LISTEN)"]
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::Devices, "")
                .iter()
                .map(|e| e.pid)
                .collect::<Vec<_>>(),
            vec![800]
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::Pipes, "")
                .iter()
                .map(|e| e.pid)
                .collect::<Vec<_>>(),
            vec![1001]
        );

        // Case-insensitive query matches path, process, user, pid, or kind label.
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::All, "PG_VERSION").len(),
            1
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::All, "ALICE").len(),
            2
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::All, "1001")[0].process,
            "rustc"
        );
        assert_eq!(
            filter_open_files(&entries, FileKindFilter::All, "sock")[0].kind,
            OpenFileKind::Socket
        );
        assert!(filter_open_files(&entries, FileKindFilter::Pipes, "postgres").is_empty());
    }

    fn sock(
        proto: &str,
        local: &str,
        remote: &str,
        state: &str,
        pid: Option<u32>,
        process: &str,
    ) -> NetSocketEntry {
        NetSocketEntry {
            proto: proto.to_string(),
            local_addr: local.to_string(),
            remote_addr: remote.to_string(),
            state: state.to_string(),
            inode: 1,
            pid,
            process: process.to_string(),
        }
    }

    #[test]
    fn socket_kind_filter_matches_state_and_protocol() {
        assert_eq!(SocketKindFilter::default(), SocketKindFilter::All);
        let listen = sock("TCP", "0.0.0.0:22", "*", "LISTEN", Some(300), "sshd");
        let unconn = sock("UDP", "0.0.0.0:5353", "*", "UNCONN", Some(200), "avahi");
        let estab = sock(
            "TCP",
            "10.0.0.14:49320",
            "142.250.190.78:443",
            "ESTAB",
            Some(800),
            "firefox",
        );
        let established = sock(
            "TCP6",
            "[::1]:5432",
            "[::1]:51234",
            "ESTABLISHED",
            None,
            "",
        );
        let udp6 = sock("UDP6", "[::]:53", "*", "UNCONN", Some(50), "named");
        for filter in SocketKindFilter::ALL {
            assert!(!filter.label().is_empty());
            assert!(!filter.slug().is_empty());
        }
        assert!(SocketKindFilter::All.matches(&listen));
        assert!(SocketKindFilter::Listen.matches(&listen));
        assert!(SocketKindFilter::Listen.matches(&unconn));
        assert!(!SocketKindFilter::Listen.matches(&estab));
        assert!(SocketKindFilter::Established.matches(&estab));
        assert!(SocketKindFilter::Established.matches(&established));
        assert!(!SocketKindFilter::Established.matches(&listen));
        assert!(SocketKindFilter::Tcp.matches(&listen));
        assert!(SocketKindFilter::Tcp.matches(&established));
        assert!(!SocketKindFilter::Tcp.matches(&unconn));
        assert!(SocketKindFilter::Udp.matches(&unconn));
        assert!(SocketKindFilter::Udp.matches(&udp6));
        assert!(!SocketKindFilter::Udp.matches(&listen));
    }

    #[test]
    fn filter_sockets_keeps_kind_and_matches_addr_state_process_and_pid() {
        let sockets = vec![
            sock("TCP", "127.0.0.1:5432", "*", "LISTEN", Some(700), "postgres"),
            sock(
                "TCP",
                "10.0.0.14:49320",
                "142.250.190.78:443",
                "ESTAB",
                Some(800),
                "firefox",
            ),
            sock("UDP", "0.0.0.0:5353", "*", "unconn", Some(200), "avahi"),
            sock("TCP6", "[::]:443", "*", "LISTEN", None, "nginx"),
        ];
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "").len(),
            4
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::Listen, "")
                .iter()
                .map(|entry| entry.process.as_str())
                .collect::<Vec<_>>(),
            vec!["postgres", "avahi", "nginx"]
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::Established, "")[0].process,
            "firefox"
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::Tcp, "").len(),
            3
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::Udp, "")[0].proto,
            "UDP"
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "5432")[0].process,
            "postgres"
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "142.250")[0].process,
            "firefox"
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "estab").len(),
            1
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "tcp6")[0].process,
            "nginx"
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "Firefox")[0].pid,
            Some(800)
        );
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::All, "700")[0].process,
            "postgres"
        );
        assert!(filter_sockets(&sockets, SocketKindFilter::Udp, "firefox").is_empty());
        assert_eq!(
            filter_sockets(&sockets, SocketKindFilter::Listen, "  [::]:443 ").len(),
            1
        );
    }
}
