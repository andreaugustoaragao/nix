//! Window assembly for Vitals: chrome, customizable dashboard layouts, process table, and dialogs.

#![allow(clippy::large_types_passed_by_value)]

use rune::{
    Align, AppSpec, Color, Cursor, Cx, Drag, El, GrowthSpec, Icon, Phase, ScrollSpec, Transition,
    Tx, canvas, col, el, icon, row, text, text_input,
};

use crate::charts::tree_connector_shape;
use crate::model::{
    FileKindFilter, OpenFileEntry, PaneId, ProcessMode, ProcessRow, SignalKind, SocketKindFilter,
    SortColumn, format_bytes, format_rate,
};
use crate::state::{
    CardId, ChartKind, ElevationState, LayoutPreset, MAX_COL_SPLIT, MAX_ROW_SPLIT, MIN_COL_SPLIT,
    MIN_ROW_SPLIT, SignalDialog, State,
};
use crate::theme::{AppearanceMode, ColorSchemeId, Palette};
use crate::widgets::{
    BADGE, ChartHoverSpec, LABEL, MONO, MONO_SMALL, PANEL_TITLE, cpu_panel_slot,
    disks_sensors_panel_slot, memory_panel_slot, network_panel_slot, panel_frame_slot,
    process_inspector_card_slot,
};

const COL_PID: f32 = 68.0;
const COL_NAME: f32 = 96.0;
const COL_CPU: f32 = 72.0;
const COL_MEM: f32 = 148.0;
const COL_READ: f32 = 88.0;
const COL_WRITE: f32 = 88.0;
const COL_USER: f32 = 72.0;
const COL_STATE: f32 = 44.0;

const FOOTER: &str = "1-7 panes    Files [7]    e zoom    L layout    Ctrl+Shift++/-/0 ui zoom    tab focus    f freeze    / find    t tree    ←/→/z fold    g group    P pin    d signal    S all users / elevate    j/k select    ? help    , settings    +/- window    [ ] rate";

const HELP: &[&str] = &[
    "1-7      Overview, CPU, Memory, Network, Disks, Processes, Files [7]",
    "e        Zoom the focused pane",
    "L        Cycle dashboard layout preset",
    "Ctrl+Shift++/-/0    UI zoom in, out, or back to 100%",
    "Tab      Cycle focus    Shift-Tab reverses",
    "f, Space Freeze or resume sampling",
    "/        Filter processes, files, or sockets    Ctrl+F focuses",
    "t        Process tree    ←/→/z collapse or expand",
    "g        Group processes by name",
    "P        Pin or unpin the selected process",
    "d        Signal the selected process",
    "S        All Users / Elevate",
    "Enter    Confirm the open signal (or fold tree node)",
    "Esc      Close settings, the dialog, help, search, or zoom",
    "j / k    Move the selection down or up",
    "c m p n  Sort by CPU, memory, pid, or name",
    "+ / -    Cycle the time window",
    "[ / ]    Cycle the poll rate",
    ",        Settings: appearance mode and color scheme",
    "theme    Toolbar cycles System, Dark, and Light",
    "?        Toggle this help",
];

/// 24×24 cog: an eight-tooth silhouette with the hub punched out, plus a stroked center ring.
pub static GEAR_ICON: Icon = Icon {
    name: "gear",
    view: 24.0,
    body: r##"<path fill-rule="evenodd" d="M9.44 5.81 L10.21 2.77 L13.79 2.77 L14.56 5.81 L17.26 4.21 L19.79 6.74 L18.19 9.44 L21.23 10.21 L21.23 13.79 L18.19 14.56 L19.79 17.26 L17.26 19.79 L14.56 18.19 L13.79 21.23 L10.21 21.23 L9.44 18.19 L6.74 19.79 L4.21 17.26 L5.81 14.56 L2.77 13.79 L2.77 10.21 L5.81 9.44 L4.21 6.74 L6.74 4.21 Z M15.15 12 a3.15 3.15 0 1 0 -6.3 0 a3.15 3.15 0 1 0 6.3 0 Z"/><circle cx="12" cy="12" r="3.15" fill="none" stroke="#fff" stroke-width="1.35"/>"##,
};

/// 2×2 grid for the dashboard layout control.
pub static LAYOUT_ICON: Icon = Icon {
    name: "layout",
    view: 24.0,
    body: r##"<rect x="3" y="3" width="7.5" height="7.5" rx="1.2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.2"/>"##,
};

/// Shield used for privilege elevation.
pub static SHIELD_ICON: Icon = Icon {
    name: "shield",
    view: 24.0,
    body: r##"<path d="M12 2.4L20.2 5.8V12.4C20.2 17.2 16.7 20.5 12 21.7C7.3 20.5 3.8 17.2 3.8 12.4V5.8Z"/>"##,
};

/// Two bars, shown while sampling is live.
pub static PAUSE_ICON: Icon = Icon {
    name: "pause",
    view: 24.0,
    body: r##"<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>"##,
};

/// Triangle, shown while sampling is frozen.
pub static PLAY_ICON: Icon = Icon {
    name: "play",
    view: 24.0,
    body: r##"<path d="M8 4.5L19.5 12L8 19.5Z"/>"##,
};

/// Sun, for the appearance-mode control.
pub static THEME_ICON: Icon = Icon {
    name: "theme",
    view: 24.0,
    body: r##"<circle cx="12" cy="12" r="4"/><path d="M12 2.2V5.2M12 18.8V21.8M2.2 12H5.2M18.8 12H21.8M4.9 4.9L7.1 7.1M16.9 16.9L19.1 19.1M19.1 4.9L16.9 7.1M7.1 16.9L4.9 19.1" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>"##,
};

/// Circled question mark for the shortcut overlay.
pub static HELP_ICON: Icon = Icon {
    name: "help",
    view: 24.0,
    body: r##"<circle cx="12" cy="12" r="9" fill="none" stroke="#fff" stroke-width="1.8"/><path d="M9.1 9.3a3 3 0 1 1 4.5 2.6c-.8.5-1.3 1-1.3 2.1" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="17.4" r="1.15"/>"##,
};

/// 24×24 dashboard: four panels, the top-left and bottom-right ones wider.
pub static OVERVIEW_ICON: Icon = Icon {
    name: "overview",
    view: 24.0,
    body: r##"<rect x="2.5" y="3" width="11" height="8" rx="1.4"/><rect x="15" y="3" width="6.5" height="8" rx="1.4"/><rect x="2.5" y="13" width="6.5" height="8" rx="1.4"/><rect x="10.5" y="13" width="11" height="8" rx="1.4"/>"##,
};

/// 24×24 microchip: die outline, inner core, and pins on all four sides.
pub static CPU_ICON: Icon = Icon {
    name: "cpu",
    view: 24.0,
    body: r##"<rect x="6" y="6" width="12" height="12" rx="2" fill="none" stroke="#fff" stroke-width="1.6"/><rect x="9.5" y="9.5" width="5" height="5" rx="0.6"/><rect x="8" y="2.2" width="1.5" height="3.8" rx="0.4"/><rect x="11.25" y="2.2" width="1.5" height="3.8" rx="0.4"/><rect x="14.5" y="2.2" width="1.5" height="3.8" rx="0.4"/><rect x="8" y="18" width="1.5" height="3.8" rx="0.4"/><rect x="11.25" y="18" width="1.5" height="3.8" rx="0.4"/><rect x="14.5" y="18" width="1.5" height="3.8" rx="0.4"/><rect x="2.2" y="8" width="3.8" height="1.5" rx="0.4"/><rect x="2.2" y="11.25" width="3.8" height="1.5" rx="0.4"/><rect x="2.2" y="14.5" width="3.8" height="1.5" rx="0.4"/><rect x="18" y="8" width="3.8" height="1.5" rx="0.4"/><rect x="18" y="11.25" width="3.8" height="1.5" rx="0.4"/><rect x="18" y="14.5" width="3.8" height="1.5" rx="0.4"/>"##,
};

/// 24×24 RAM stick: module outline, three chips, and bottom connector pins.
pub static MEMORY_ICON: Icon = Icon {
    name: "memory",
    view: 24.0,
    body: r##"<rect x="3" y="6" width="18" height="9" rx="1.5" fill="none" stroke="#fff" stroke-width="1.6"/><rect x="5.2" y="8" width="3.4" height="5" rx="0.4"/><rect x="10.3" y="8" width="3.4" height="5" rx="0.4"/><rect x="15.4" y="8" width="3.4" height="5" rx="0.4"/><rect x="5" y="15" width="1.5" height="3.4" rx="0.3"/><rect x="8.4" y="15" width="1.5" height="3.4" rx="0.3"/><rect x="11.8" y="15" width="1.5" height="3.4" rx="0.3"/><rect x="15.2" y="15" width="1.5" height="3.4" rx="0.3"/><rect x="18.6" y="15" width="1.5" height="3.4" rx="0.3"/>"##,
};

/// 24×24 network activity: an up arrow on the left and a down arrow on the right.
pub static NETWORK_ICON: Icon = Icon {
    name: "network",
    view: 24.0,
    body: r##"<path d="M5.6 19.5 L8.4 19.5 L8.4 12.4 L11.2 12.4 L7 5.6 L2.8 12.4 L5.6 12.4 Z"/><path d="M15.6 4.5 L18.4 4.5 L18.4 11.6 L21.2 11.6 L17 18.4 L12.8 11.6 L15.6 11.6 Z"/>"##,
};

/// 24×24 drive enclosure: rounded bay, platter line, and a status LED.
pub static DISKS_ICON: Icon = Icon {
    name: "disks",
    view: 24.0,
    body: r##"<rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="#fff" stroke-width="1.7"/><line x1="5" y1="13" x2="19" y2="13" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/><circle cx="17.2" cy="16.3" r="1.35"/>"##,
};

/// 24×24 activity pulse for the process list.
pub static PROCESSES_ICON: Icon = Icon {
    name: "processes",
    view: 24.0,
    body: r##"<path d="M2 12 L6 12 L9 5 L15 19 L18 12 L22 12" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>"##,
};

/// 24×24 folder.
pub static FILES_ICON: Icon = Icon {
    name: "files",
    view: 24.0,
    body: r##"<path d="M3 6 L9 6 L11 8 L21 8 L21 19 L3 19 Z"/>"##,
};

const RATE_CHOICES_MS: [u64; 5] = [250, 500, 1_000, 2_000, 5_000];
const WINDOW_CHOICES_SECS: [u32; 5] = [15, 30, 60, 120, 300];

/// Full monitor view. Appearance follows the saved mode, then the desktop, then the portal.
///
/// `zoom-viewport` is the window. At any scale other than 100% the stage is laid out at
/// `window / zoom` and scaled about its top-left, so `(vw / zoom) * zoom` fills the window.
pub fn view(s: &State, cx: &mut Cx<State>) -> El {
    let [vw, vh] = cx.layout_size("zoom-viewport").unwrap_or([1360.0, 880.0]);
    let portal_dark = cx.system_dark();
    let dark = s.resolved_dark(portal_dark);
    let system_dark = s.system_prefers_dark(portal_dark);
    let reduced = cx.system_reduced_motion();
    cx.reduced_motion(reduced);
    let p = s.color_scheme.palette(dark, &s.system_theme);

    let mut root = col()
        .key("zoom-stage")
        .w_full()
        .h_full()
        .min_h(0.0)
        .min_w(0.0)
        .fill(p.base)
        .child(toolbar(s, dark, p));
    if let Some((message, is_error)) = &s.status_banner {
        root = root.child(status_banner(message, *is_error, p));
    }
    root = root.child(workspace(s, cx, p)).child(footer(p));
    if s.signal_dialog.is_some() || s.show_help || s.show_settings {
        root = root.child(scrim(p));
    }
    if let Some(dialog) = &s.signal_dialog {
        root = root.child(signal_dialog(dialog, p));
    }
    if s.show_help {
        root = root.child(help_dialog(p));
    }
    if s.show_settings {
        root = root.child(settings_modal(s, dark, system_dark, p));
    }
    let stage = if s.ui_zoom_pct == 100 {
        root
    } else {
        let zoom = s.ui_zoom();
        root.w(vw / zoom).h(vh / zoom).origin(0.0, 0.0).scale(zoom)
    };
    el().key("zoom-viewport")
        .w_full()
        .h_full()
        .fill(p.base)
        .child(stage)
}

/// App entry the binary and headless tests share.
pub fn spec() -> AppSpec<State> {
    AppSpec {
        min_size: Some((900.0, 600.0)),
        poll: Some(State::poll),
        on_key: Some(State::on_key),
        scenes: SCENES,
        ..AppSpec::new(
            "Vitals — System Monitor",
            (1360.0, 880.0),
            State::default,
            view,
        )
    }
}

fn scene_dark(state: &mut State) {
    state.appearance_mode = AppearanceMode::Dark;
    state.dark = Some(true);
}

fn scene_light(state: &mut State) {
    state.appearance_mode = AppearanceMode::Light;
    state.dark = Some(false);
}

fn scene_cpu(state: &mut State) {
    state.set_pane(PaneId::Cpu);
}

fn scene_processes(state: &mut State) {
    state.set_pane(PaneId::Processes);
}

type Scene = (&'static str, fn(&mut State));

static SCENES: &[Scene] = &[
    ("dark", scene_dark),
    ("light", scene_light),
    ("cpu", scene_cpu),
    ("processes", scene_processes),
];

fn toolbar(s: &State, dark: bool, p: Palette) -> El {
    row()
        .key("toolbar")
        .h(42.0)
        .w_full()
        .px(10.0)
        .gap(8.0)
        .items_center()
        .fill(p.chrome)
        .child(identity(s, p))
        .child(tabs(s, p))
        .child(el().grow(1.0).min_w(0.0))
        .child(window_controls(s, dark, p))
}

fn identity(_s: &State, p: Palette) -> El {
    text("vitals").font(PANEL_TITLE).color(p.accent)
}

fn tabs(s: &State, p: Palette) -> El {
    row()
        .gap(4.0)
        .items_center()
        .child(tab(
            "tab-overview",
            &OVERVIEW_ICON,
            "Overview [1]",
            s.pane == PaneId::Overview,
            PaneId::Overview,
            p,
        ))
        .child(tab(
            "tab-cpu",
            &CPU_ICON,
            "CPU [2]",
            s.pane == PaneId::Cpu,
            PaneId::Cpu,
            p,
        ))
        .child(tab(
            "tab-memory",
            &MEMORY_ICON,
            "Memory [3]",
            s.pane == PaneId::Memory,
            PaneId::Memory,
            p,
        ))
        .child(tab(
            "tab-network",
            &NETWORK_ICON,
            "Network [4]",
            s.pane == PaneId::Network,
            PaneId::Network,
            p,
        ))
        .child(tab(
            "tab-disks",
            &DISKS_ICON,
            "Disks [5]",
            s.pane == PaneId::Disks,
            PaneId::Disks,
            p,
        ))
        .child(tab(
            "tab-processes",
            &PROCESSES_ICON,
            "Processes [6]",
            s.pane == PaneId::Processes,
            PaneId::Processes,
            p,
        ))
        .child(tab(
            "tab-files",
            &FILES_ICON,
            "Files [7]",
            s.pane == PaneId::Files,
            PaneId::Files,
            p,
        ))
}

/// Compact 26×26 pane control. The glyph is the face; `label` is the accessible name and tooltip.
fn tab(
    key: &'static str,
    glyph: &'static Icon,
    label: &'static str,
    active: bool,
    target: PaneId,
    p: Palette,
) -> El {
    let ink = if active { p.accent } else { p.text };
    let fill = if active {
        p.accent.alpha(0.16)
    } else {
        p.panel_alt
    };
    row()
        .key(key)
        .size(26.0, 26.0)
        .center()
        .radius(4.0)
        .fill(fill)
        .cursor(Cursor::Pointer)
        .transition(Transition::none())
        .role("button")
        .label(label)
        .help(label)
        .on_press(move |state: &mut State| state.set_pane(target))
        .child(icon(glyph, 15.0).color(ink))
}

fn window_controls(s: &State, dark: bool, p: Palette) -> El {
    let mut controls = row()
        .gap(6.0)
        .items_center()
        .child(icon_button(
            "btn-layout",
            &LAYOUT_ICON,
            format!("Layout: {}", s.layout_preset.label()),
            s.layout_preset != LayoutPreset::Grid,
            p,
            |state: &mut State| state.cycle_layout_preset(),
        ))
        .child(icon_button(
            "btn-elevate-top",
            &SHIELD_ICON,
            elevation_top_label(s.elevation).to_string(),
            s.elevation != ElevationState::Unprivileged,
            p,
            |state: &mut State| state.toggle_elevation(),
        ))
        .child(chip(
            "btn-window",
            format!("{}s", s.time_window_secs),
            false,
            p,
            |state: &mut State| state.cycle_time_window(false),
        ))
        .child(chip(
            "btn-rate",
            format_poll_rate(s.poll_interval_ms),
            false,
            p,
            |state: &mut State| state.cycle_poll_interval(false),
        ))
        .child(icon_button(
            "btn-freeze",
            if s.frozen { &PLAY_ICON } else { &PAUSE_ICON },
            if s.frozen {
                "Frozen".to_string()
            } else {
                "Live".to_string()
            },
            s.frozen,
            p,
            |state: &mut State| state.frozen = !state.frozen,
        ));
    if s.ui_zoom_pct != 100 {
        controls = controls.child(chip_now(
            "btn-zoom-reset",
            format!("{}%", s.ui_zoom_pct),
            true,
            p,
            |state: &mut State| state.reset_ui_zoom(),
        ));
    }
    controls
        .child(icon_button(
            "btn-theme",
            &THEME_ICON,
            theme_label(s.appearance_mode, dark),
            s.appearance_mode != AppearanceMode::System,
            p,
            |state: &mut State| state.cycle_appearance_mode(),
        ))
        .child(icon_button(
            "btn-help",
            &HELP_ICON,
            "Help [?]".to_string(),
            s.show_help,
            p,
            |state: &mut State| {
                state.show_help = !state.show_help;
                if state.show_help {
                    state.signal_dialog = None;
                    state.show_settings = false;
                }
            },
        ))
        .child(icon_button(
            "btn-settings",
            &GEAR_ICON,
            "Settings [,]".to_string(),
            s.show_settings,
            p,
            |state: &mut State| state.toggle_settings(),
        ))
}

fn format_poll_rate(ms: u64) -> String {
    match ms {
        1_000 => "1s".to_string(),
        2_000 => "2s".to_string(),
        5_000 => "5s".to_string(),
        other => format!("{other}ms"),
    }
}

/// Compact 26×26 toolbar control. The glyph is the face; `label` is the accessible name and tooltip.
fn icon_button(
    key: &str,
    glyph: &'static Icon,
    label: String,
    active: bool,
    p: Palette,
    on_press: impl Fn(&mut State) + 'static,
) -> El {
    let ink = if active { p.accent } else { p.text };
    let fill = if active {
        p.accent.alpha(0.16)
    } else {
        p.panel_alt
    };
    let help = label.clone();
    row()
        .key(key)
        .size(26.0, 26.0)
        .items_center()
        .justify_center()
        .radius(4.0)
        .fill(fill)
        .cursor(Cursor::Pointer)
        .transition(Transition::none())
        .label(label)
        .help(help)
        .on_press_tx(move |state: &mut State, tx: &mut Tx| {
            tx.instant();
            on_press(state);
        })
        .child(icon(glyph, 14.0).color(ink))
}

fn chip(
    key: impl Into<String>,
    label: impl Into<String>,
    active: bool,
    p: Palette,
    on_press: impl Fn(&mut State) + 'static,
) -> El {
    chip_tx(key, label, active, p, false, move |state, _| {
        on_press(state)
    })
}

/// Opens or closes a layer. The press lands at once, and the control itself does not fade.
fn chip_now(
    key: impl Into<String>,
    label: impl Into<String>,
    active: bool,
    p: Palette,
    on_press: impl Fn(&mut State) + 'static,
) -> El {
    chip_tx(key, label, active, p, true, move |state, tx| {
        tx.instant();
        on_press(state);
    })
}

fn chip_tx(
    key: impl Into<String>,
    label: impl Into<String>,
    active: bool,
    p: Palette,
    arrive: bool,
    on_press: impl Fn(&mut State, &mut Tx) + 'static,
) -> El {
    let ink = if active { p.accent } else { p.text };
    let fill = if active {
        p.accent.alpha(0.16)
    } else {
        p.panel_alt
    };
    let mut button = row()
        .key(key)
        .h(26.0)
        .px(8.0)
        .items_center()
        .radius(4.0)
        .fill(fill)
        .cursor(Cursor::Pointer)
        .on_press_tx(on_press)
        .child(text(label).font(LABEL).color(ink));
    if arrive {
        button = button.transition(Transition::none());
    }
    button
}

fn status_banner(message: &str, is_error: bool, p: Palette) -> El {
    let ink = if is_error { p.crit } else { p.ok };
    row()
        .key("status-banner")
        .h(30.0)
        .w_full()
        .px(10.0)
        .gap(8.0)
        .items_center()
        .fill(ink.alpha(0.14))
        .child(
            text(message)
                .font(LABEL)
                .color(ink)
                .truncate()
                .grow(1.0)
                .min_w(0.0),
        )
        .child(chip_now(
            "dismiss-banner",
            "Dismiss",
            false,
            p,
            |state: &mut State| {
                state.status_banner = None;
            },
        ))
}

#[derive(Clone, Copy)]
struct SlotCtx {
    slot_rects: [Option<[f32; 4]>; 6],
    handle_rects: [Option<[f32; 4]>; 6],
    cpu_hover: ChartHoverSpec,
    mem_hover: ChartHoverSpec,
    net_hover: ChartHoverSpec,
    disk_hover: ChartHoverSpec,
    p: Palette,
}

fn chart_hover_spec(
    s: &State,
    cx: &Cx<State>,
    kind: ChartKind,
    layout_key: &str,
) -> ChartHoverSpec {
    let width_hint = cx
        .layout_size(layout_key)
        .map(|sz| sz[0])
        .filter(|&w| w > 1.0)
        .unwrap_or(360.0);
    let active_frac = match s.chart_hover {
        Some((k, frac)) if k == kind => Some(frac),
        _ => None,
    };
    ChartHoverSpec {
        active_frac,
        width_hint,
        poll_interval_ms: s.poll_interval_ms,
        interactive: true,
    }
}

fn workspace(s: &State, cx: &mut Cx<State>, p: Palette) -> El {
    let mut shell = col()
        .key("workspace")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .min_w(0.0)
        .padding(8.0);
    shell = match s.pane {
        PaneId::Overview => shell.child(overview(s, cx, p)),
        PaneId::Cpu => {
            let hover = chart_hover_spec(s, cx, ChartKind::Cpu, "cpu-chart");
            let panel_w = measured_panel_w(cx, "cpu-panel");
            shell.child(fill_panel(cpu_panel_slot(
                &s.snapshot,
                &s.history,
                s.sample_count(),
                s.per_core_chart,
                true,
                s.focused_pane == PaneId::Cpu,
                panel_w,
                hover,
                None,
                false,
                p,
            )))
        }
        PaneId::Memory => {
            let hover = chart_hover_spec(s, cx, ChartKind::Memory, "memory-chart");
            shell.child(fill_panel(memory_panel_slot(
                &s.snapshot,
                &s.history,
                s.sample_count(),
                true,
                s.focused_pane == PaneId::Memory,
                hover,
                None,
                false,
                p,
            )))
        }
        PaneId::Network => {
            let hover = chart_hover_spec(s, cx, ChartKind::Network, "network-chart");
            let panel_w = measured_panel_w(cx, "network-panel");
            shell.child(fill_panel(network_panel_slot(
                &s.snapshot,
                &s.history,
                s.sample_count(),
                s.show_loopback,
                true,
                s.focused_pane == PaneId::Network,
                panel_w,
                hover,
                None,
                false,
                &s.socket_rows,
                Some(socket_toolbar(s, p)),
                p,
            )))
        }
        PaneId::Disks => {
            let hover = chart_hover_spec(s, cx, ChartKind::Disks, "disk-io-chart");
            let panel_w = measured_panel_w(cx, "disks-panel");
            shell.child(fill_panel(disks_sensors_panel_slot(
                &s.snapshot,
                &s.history,
                s.sample_count(),
                true,
                s.focused_pane == PaneId::Disks,
                panel_w,
                hover,
                None,
                false,
                p,
            )))
        }
        PaneId::Processes => shell.child(processes_zoom(s, cx, p)),
        PaneId::Files => shell.child(files_zoom(s, p)),
    };
    shell
}

fn fill_panel(panel: El) -> El {
    panel.w_full().h_full().grow(1.0).min_h(0.0).min_w(0.0)
}

fn measured_panel_w(cx: &Cx<State>, key: &str) -> f32 {
    cx.layout_size(key)
        .map(|size| size[0])
        .filter(|width| *width > 1.0)
        .unwrap_or(800.0)
}

fn overview(s: &State, cx: &mut Cx<State>, p: Palette) -> El {
    let slot_rects: [Option<[f32; 4]>; 6] =
        std::array::from_fn(|idx| cx.layout(&format!("card-slot-{idx}")));
    let handle_rects: [Option<[f32; 4]>; 6] =
        std::array::from_fn(|idx| cx.layout(&format!("drag-card-{idx}")));
    let ctx = SlotCtx {
        slot_rects,
        handle_rects,
        cpu_hover: chart_hover_spec(s, cx, ChartKind::Cpu, "cpu-chart"),
        mem_hover: chart_hover_spec(s, cx, ChartKind::Memory, "memory-chart"),
        net_hover: chart_hover_spec(s, cx, ChartKind::Network, "network-chart"),
        disk_hover: chart_hover_spec(s, cx, ChartKind::Disks, "disk-io-chart"),
        p,
    };
    match s.layout_preset {
        LayoutPreset::Grid => col()
            .w_full()
            .h_full()
            .grow(1.0)
            .min_h(0.0)
            .min_w(0.0)
            .child(two_card_row(s, ctx, s.row_splits[0], 0, 1, 0))
            .child(row_splitter(0, p))
            .child(two_card_row(s, ctx, s.row_splits[1], 2, 3, 1))
            .child(row_splitter(1, p))
            .child(two_card_row(s, ctx, s.row_splits[2], 4, 5, 2)),
        LayoutPreset::ProcessesTop => col()
            .w_full()
            .h_full()
            .grow(1.0)
            .min_h(0.0)
            .min_w(0.0)
            .child(two_card_row(s, ctx, s.row_splits[0], 4, 5, 2))
            .child(row_splitter(0, p))
            .child(two_card_row(s, ctx, s.row_splits[1], 0, 1, 0))
            .child(row_splitter(1, p))
            .child(two_card_row(s, ctx, s.row_splits[2], 2, 3, 1)),
        LayoutPreset::SplitColumns => {
            let left_ratio = s.col_splits[3].clamp(MIN_COL_SPLIT, MAX_COL_SPLIT);
            row()
                .w_full()
                .h_full()
                .grow(1.0)
                .min_h(0.0)
                .min_w(0.0)
                .child(
                    col()
                        .h_full()
                        .grow(left_ratio)
                        .min_h(0.0)
                        .min_w(0.0)
                        .child(card_slot(4, s.row_splits[0], s, ctx))
                        .child(row_splitter(0, p))
                        .child(card_slot(5, s.row_splits[1], s, ctx)),
                )
                .child(col_splitter(3, p))
                .child(
                    col()
                        .h_full()
                        .grow(1.0 - left_ratio)
                        .min_h(0.0)
                        .min_w(0.0)
                        .child(two_card_row(s, ctx, s.row_splits[1], 0, 1, 0))
                        .child(row_splitter(1, p))
                        .child(two_card_row(s, ctx, s.row_splits[2], 2, 3, 1)),
                )
        }
        LayoutPreset::Wide2x3 => col()
            .w_full()
            .h_full()
            .grow(1.0)
            .min_h(0.0)
            .min_w(0.0)
            .child(three_card_row(s, ctx, s.row_splits[0], [0, 1, 2], [0, 1]))
            .child(row_splitter(0, p))
            .child(three_card_row(s, ctx, s.row_splits[1], [3, 4, 5], [2, 3])),
    }
}

fn two_card_row(
    s: &State,
    ctx: SlotCtx,
    row_grow: f32,
    left_slot: usize,
    right_slot: usize,
    col_split_idx: usize,
) -> El {
    let ratio = s.col_splits[col_split_idx].clamp(MIN_COL_SPLIT, MAX_COL_SPLIT);
    row()
        .w_full()
        .grow(row_grow)
        .min_h(0.0)
        .min_w(0.0)
        .child(card_slot(left_slot, ratio, s, ctx))
        .child(col_splitter(col_split_idx, ctx.p))
        .child(card_slot(right_slot, 1.0 - ratio, s, ctx))
}

fn three_card_row(
    s: &State,
    ctx: SlotCtx,
    row_grow: f32,
    slots: [usize; 3],
    split_indices: [usize; 2],
) -> El {
    let left_w = s.col_splits[split_indices[0]].clamp(MIN_COL_SPLIT, MAX_COL_SPLIT);
    let right_w = (1.0 - s.col_splits[split_indices[1]].clamp(MIN_COL_SPLIT, MAX_COL_SPLIT))
        .clamp(MIN_COL_SPLIT, MAX_COL_SPLIT);
    let mid_w = (1.5 - left_w - right_w).max(MIN_COL_SPLIT);
    row()
        .w_full()
        .grow(row_grow)
        .min_h(0.0)
        .min_w(0.0)
        .child(card_slot(slots[0], left_w, s, ctx))
        .child(col_splitter(split_indices[0], ctx.p))
        .child(card_slot(slots[1], mid_w, s, ctx))
        .child(col_splitter(split_indices[1], ctx.p))
        .child(card_slot(slots[2], right_w, s, ctx))
}

fn row_splitter(index: usize, p: Palette) -> El {
    row()
        .key(format!("split-row-{index}"))
        .h(6.0)
        .w_full()
        .items_center()
        .justify_center()
        .cursor(Cursor::ResizeRow)
        .on_double_press(move |state: &mut State| {
            state.reset_row_split(index);
        })
        .on_drag(move |state: &mut State, drag: &mut Drag, tx: &mut Tx| {
            if index + 1 >= state.row_splits.len() {
                return;
            }
            match drag.phase {
                Phase::Down => {
                    state.drag_split_start = state.row_splits[index];
                    state.drag_split_pair_start = state.row_splits[index + 1];
                }
                Phase::Move => {
                    let zoom = state.ui_zoom();
                    let delta = (drag.dy / zoom) / 240.0;
                    let a0 = state.drag_split_start;
                    let b0 = state.drag_split_pair_start;
                    let total = a0 + b0;
                    let min_a = MIN_ROW_SPLIT.max(total - MAX_ROW_SPLIT);
                    let max_a = MAX_ROW_SPLIT.min(total - MIN_ROW_SPLIT);
                    let next_a = if min_a <= max_a {
                        (a0 + delta).clamp(min_a, max_a)
                    } else {
                        (a0 + delta).clamp(MIN_ROW_SPLIT, MAX_ROW_SPLIT)
                    };
                    let next_b = (total - next_a).clamp(MIN_ROW_SPLIT, MAX_ROW_SPLIT);
                    state.row_splits[index] = next_a;
                    state.row_splits[index + 1] = next_b;
                }
                Phase::Up => {
                    if drag.cancelled() {
                        state.row_splits[index] = state.drag_split_start;
                        state.row_splits[index + 1] = state.drag_split_pair_start;
                        tx.instant();
                    } else {
                        state.persist_prefs();
                    }
                }
            }
        })
        .child(splitter_hairline(true, p))
}

fn col_splitter(index: usize, p: Palette) -> El {
    col()
        .key(format!("split-col-{index}"))
        .w(6.0)
        .h_full()
        .items_center()
        .justify_center()
        .cursor(Cursor::ResizeColumn)
        .on_double_press(move |state: &mut State| {
            state.reset_col_split(index);
        })
        .on_drag(move |state: &mut State, drag: &mut Drag, tx: &mut Tx| {
            if index >= state.col_splits.len() {
                return;
            }
            match drag.phase {
                Phase::Down => {
                    state.drag_split_start = state.col_splits[index];
                }
                Phase::Move => {
                    let zoom = state.ui_zoom();
                    let delta = (drag.dx / zoom) / 1100.0;
                    state.col_splits[index] =
                        (state.drag_split_start + delta).clamp(MIN_COL_SPLIT, MAX_COL_SPLIT);
                }
                Phase::Up => {
                    if drag.cancelled() {
                        state.col_splits[index] = state.drag_split_start;
                        tx.instant();
                    } else {
                        state.persist_prefs();
                    }
                }
            }
        })
        .child(splitter_hairline(false, p))
}

/// Resting splitters draw nothing. Hover and press tint only the hairline.
fn splitter_hairline(horizontal: bool, p: Palette) -> El {
    let mut line = el()
        .fill(Color::TRANSPARENT)
        .hover(p.accent.alpha(0.55))
        .press(p.accent.alpha(0.55));
    line = if horizontal {
        line.w_full().h(1.0)
    } else {
        line.w(1.0).h_full()
    };
    line
}

fn card_slot(slot_idx: usize, grow: f32, s: &State, ctx: SlotCtx) -> El {
    let p = ctx.p;
    let card = s.card_slots[slot_idx];
    let highlighted = s.swap_source_slot == Some(slot_idx) || s.drag_hover_slot == Some(slot_idx);
    let handle = card_drag_handle(slot_idx, s, ctx);
    let panel_w = ctx.slot_rects[slot_idx]
        .map(|rect| rect[2])
        .unwrap_or(640.0);
    let panel = match card {
        CardId::Cpu => cpu_panel_slot(
            &s.snapshot,
            &s.history,
            s.sample_count(),
            s.per_core_chart,
            false,
            s.focused_pane == PaneId::Cpu,
            panel_w,
            ctx.cpu_hover,
            Some(handle),
            highlighted,
            p,
        ),
        CardId::Memory => memory_panel_slot(
            &s.snapshot,
            &s.history,
            s.sample_count(),
            false,
            s.focused_pane == PaneId::Memory,
            ctx.mem_hover,
            Some(handle),
            highlighted,
            p,
        ),
        CardId::Network => network_panel_slot(
            &s.snapshot,
            &s.history,
            s.sample_count(),
            s.show_loopback,
            false,
            s.focused_pane == PaneId::Network,
            panel_w,
            ctx.net_hover,
            Some(handle),
            highlighted,
            &s.socket_rows,
            None,
            p,
        ),
        CardId::Disks => disks_sensors_panel_slot(
            &s.snapshot,
            &s.history,
            s.sample_count(),
            false,
            s.focused_pane == PaneId::Disks,
            panel_w,
            ctx.disk_hover,
            Some(handle),
            highlighted,
            p,
        ),
        CardId::Processes => processes_panel_slot(s, Some(handle), highlighted, panel_w, p),
        CardId::Inspector => process_inspector_card_slot(
            s.selected_process(),
            &s.history.selected_proc,
            s.selected_pid
                .is_some_and(|pid| s.pinned_pids.contains(&pid)),
            s.sample_count(),
            Some(handle),
            highlighted,
            p,
        ),
    };
    let mut slot = el()
        .key(format!("card-slot-{slot_idx}"))
        .w_full()
        .h_full()
        .grow(grow)
        .min_h(0.0)
        .min_w(0.0)
        .radius(6.0);
    if highlighted {
        slot = slot.outline(1.5, 0.0, p.accent);
    }
    slot.child(panel)
}

fn card_drag_handle(slot_idx: usize, s: &State, ctx: SlotCtx) -> El {
    let p = ctx.p;
    let is_source = s.swap_source_slot == Some(slot_idx);
    let is_hover = s.drag_hover_slot == Some(slot_idx) && !is_source;
    let active = is_source || is_hover;
    let label = if is_source { "Swap…" } else { "⇄" };
    let cursor = if is_source && s.is_dragging_card {
        Cursor::Grabbing
    } else if s.swap_source_slot.is_some() {
        Cursor::Pointer
    } else {
        Cursor::Grab
    };
    let ink = if active { p.accent } else { p.muted };
    let fill = if active {
        p.accent.alpha(0.20)
    } else {
        p.base.alpha(0.55)
    };
    let slot_rects = ctx.slot_rects;
    let handle_rects = ctx.handle_rects;
    row()
        .key(format!("drag-card-{slot_idx}"))
        .h(18.0)
        .px(6.0)
        .items_center()
        .justify_center()
        .radius(4.0)
        .fill(fill)
        .hover(p.accent.alpha(0.16))
        .cursor(cursor)
        .transition(Transition::none())
        .on_drag(move |state: &mut State, drag: &mut Drag, tx: &mut Tx| {
            state.slot_rects = slot_rects;
            let pointer = handle_rects[slot_idx]
                .map(|hr| [hr[0] + drag.x, hr[1] + drag.y])
                .or_else(|| {
                    slot_rects[slot_idx]
                        .map(|sr| [sr[0] + sr[2] - 8.0 - drag.w + drag.x, sr[1] + 5.0 + drag.y])
                });
            let hovered = pointer.and_then(|pt| slot_containing(&slot_rects, pt));
            match drag.phase {
                Phase::Down => {
                    state.drag_prev_swap_source = state.swap_source_slot;
                    state.swap_source_slot = Some(slot_idx);
                    state.drag_hover_slot = None;
                    state.is_dragging_card = false;
                    tx.instant();
                }
                Phase::Move => {
                    if drag.dx.hypot(drag.dy) > 12.0 {
                        state.is_dragging_card = true;
                    }
                    state.drag_hover_slot = hovered;
                }
                Phase::Up => {
                    state.is_dragging_card = false;
                    tx.instant();
                    if drag.cancelled() {
                        state.swap_source_slot = state.drag_prev_swap_source.take();
                        state.drag_hover_slot = None;
                    } else if drag.dx.hypot(drag.dy) > 12.0 {
                        let target = hovered.or(state.drag_hover_slot);
                        state.drag_prev_swap_source = None;
                        if let Some(target) = target
                            && target != slot_idx
                        {
                            state.swap_card_slots(slot_idx, target);
                        } else {
                            state.swap_source_slot = None;
                            state.drag_hover_slot = None;
                        }
                    } else {
                        let prev = state.drag_prev_swap_source.take();
                        state.drag_hover_slot = None;
                        match prev {
                            None => {
                                state.swap_source_slot = Some(slot_idx);
                            }
                            Some(src) if src == slot_idx => {
                                state.swap_source_slot = None;
                            }
                            Some(src) => {
                                state.swap_card_slots(src, slot_idx);
                            }
                        }
                    }
                }
            }
        })
        .child(text(label).font(BADGE).color(ink))
}

fn slot_containing(rects: &[Option<[f32; 4]>; 6], point: [f32; 2]) -> Option<usize> {
    if let Some(exact) = rects.iter().enumerate().find_map(|(idx, rect)| {
        let [x, y, w, h] = (*rect)?;
        (point[0] >= x && point[0] <= x + w && point[1] >= y && point[1] <= y + h).then_some(idx)
    }) {
        return Some(exact);
    }
    rects.iter().enumerate().find_map(|(idx, rect)| {
        let [x, y, w, h] = (*rect)?;
        (point[0] >= x - 4.0
            && point[0] <= x + w + 4.0
            && point[1] >= y - 4.0
            && point[1] <= y + h + 4.0)
            .then_some(idx)
    })
}

fn processes_zoom(s: &State, cx: &Cx<State>, p: Palette) -> El {
    let panel_w = measured_panel_w(cx, "processes-panel");
    row()
        .w_full()
        .h_full()
        .grow(1.0)
        .min_h(0.0)
        .min_w(0.0)
        .gap(8.0)
        .child(
            processes_panel_slot(s, None, false, panel_w, p)
                .grow(1.0)
                .min_w(0.0)
                .min_h(0.0),
        )
        .child(inspector(s, p))
}

fn files_zoom(s: &State, p: Palette) -> El {
    row()
        .w_full()
        .h_full()
        .grow(1.0)
        .min_h(0.0)
        .min_w(0.0)
        .gap(8.0)
        .child(open_files_panel(s, p).grow(1.0).min_w(0.0).min_h(0.0))
        .child(inspector(s, p))
}

fn inspector(s: &State, p: Palette) -> El {
    el().w(310.0)
        .h_full()
        .min_h(0.0)
        .child(process_inspector_card_slot(
            s.selected_process(),
            &s.history.selected_proc,
            s.selected_pid
                .is_some_and(|pid| s.pinned_pids.contains(&pid)),
            s.sample_count(),
            None,
            false,
            p,
        ))
}

/// Process table: filter, mode, sortable columns, and a virtualized row list.
pub fn processes_panel(s: &State, p: Palette) -> El {
    processes_panel_slot(s, None, false, 800.0, p)
}

fn processes_panel_slot(
    s: &State,
    header_action: Option<El>,
    slot_highlight: bool,
    panel_w: f32,
    p: Palette,
) -> El {
    let mut body = col().w_full().h_full().min_h(0.0).min_w(0.0);
    if !s.pinned_pids.is_empty() {
        body = body.child(watchlist_strip(s, p)).child(hairline(p));
    }
    body = body
        .child(search_row(s, p))
        .child(process_controls(s, p))
        .child(column_header(s, panel_w, p))
        .child(process_stream(s, panel_w, p));
    panel_frame_slot(
        "processes-panel",
        "Processes",
        process_subtitle(s),
        Some((
            format!("{} running", s.snapshot.cpu.tasks_running),
            p.accent,
        )),
        header_action,
        s.focused_pane == PaneId::Processes || s.pane == PaneId::Processes,
        slot_highlight,
        p,
        body,
    )
}

fn watchlist_strip(s: &State, p: Palette) -> El {
    let mut entries: Vec<(u32, String, f32)> = s
        .pinned_pids
        .iter()
        .map(|&pid| {
            if let Some(proc) = s.snapshot.processes.iter().find(|pr| pr.pid == pid) {
                (pid, proc.name.clone(), proc.cpu_pct)
            } else {
                (pid, format!("pid {pid}"), 0.0)
            }
        })
        .collect();
    entries.sort_by(|a, b| b.2.total_cmp(&a.2).then(a.0.cmp(&b.0)));

    let mut strip = row()
        .key("pinned-watchlist")
        .w_full()
        .px(8.0)
        .py(4.0)
        .gap(6.0)
        .flex_wrap()
        .items_center()
        .fill(p.panel_alt)
        .child(text("★ Watch").font(LABEL).color(p.accent));
    for (pid, name, cpu) in entries {
        strip = strip.child(chip_now(
            format!("watch-chip-{pid}"),
            format!("{name} {cpu:.1}%"),
            s.selected_pid == Some(pid),
            p,
            move |state: &mut State| {
                state.select_pid(pid);
                state.focused_pane = PaneId::Processes;
            },
        ));
    }
    strip
}

fn process_controls(s: &State, p: Palette) -> El {
    let is_pinned = s
        .selected_pid
        .is_some_and(|pid| s.pinned_pids.contains(&pid));
    row()
        .w_full()
        .h(36.0)
        .px(8.0)
        .gap(6.0)
        .items_center()
        .child(chip(
            "mode-table",
            "Table",
            s.process_mode == ProcessMode::Table,
            p,
            |state: &mut State| state.set_process_mode(ProcessMode::Table),
        ))
        .child(chip(
            "mode-tree",
            "Tree [t]",
            s.process_mode == ProcessMode::Tree,
            p,
            |state: &mut State| state.set_process_mode(ProcessMode::Tree),
        ))
        .child(chip(
            "mode-grouped",
            "Grouped [g]",
            s.process_mode == ProcessMode::Grouped,
            p,
            |state: &mut State| state.set_process_mode(ProcessMode::Grouped),
        ))
        .child(chip_now(
            "btn-pin",
            "Pin [P]",
            is_pinned,
            p,
            |state: &mut State| state.toggle_pin_selected(),
        ))
        .child(chip_now(
            "btn-signal",
            "Signal [d]",
            false,
            p,
            |state: &mut State| state.open_signal_dialog(SignalKind::Term),
        ))
        .child(elevate_chip(s, p))
}

fn elevate_chip(s: &State, p: Palette) -> El {
    chip_now(
        "btn-elevate",
        elevation_process_label(s.elevation),
        s.elevation != ElevationState::Unprivileged,
        p,
        |state: &mut State| state.toggle_elevation(),
    )
}

fn search_row(s: &State, p: Palette) -> El {
    let mut bar = row()
        .key("search-row")
        .w_full()
        .h(36.0)
        .px(8.0)
        .gap(6.0)
        .items_center()
        .child(search_field(s, p).w_full());
    if !s.query.text.is_empty() {
        bar = bar.child(chip(
            "clear-search",
            "Clear",
            false,
            p,
            |state: &mut State| {
                state.query.clear();
                state.on_query_change();
            },
        ));
    }
    bar
}

fn open_files_panel(s: &State, p: Palette) -> El {
    let body = col()
        .w_full()
        .h_full()
        .min_h(0.0)
        .min_w(0.0)
        .child(files_toolbar(s, p))
        .child(file_header(p))
        .child(file_stream(s, p));
    panel_frame_slot(
        "files-panel",
        "Open Files",
        format!(
            "{} shown / {} total",
            s.file_rows.len(),
            s.snapshot.open_files.len()
        ),
        None,
        None,
        s.focused_pane == PaneId::Files || s.pane == PaneId::Files,
        false,
        p,
        body,
    )
}

fn socket_toolbar(s: &State, p: Palette) -> El {
    let mut filters = row().w_full().px(8.0).gap(6.0).flex_wrap().items_center();
    for filter in SocketKindFilter::ALL {
        let key = format!("sock-kind-{}", filter.slug());
        let label = filter.label();
        filters = filters.child(chip(
            key,
            label,
            s.socket_filter == filter,
            p,
            move |state: &mut State| state.set_socket_filter(filter),
        ));
    }
    col()
        .w_full()
        .gap(4.0)
        .child(search_row(s, p))
        .child(filters)
}

fn files_toolbar(s: &State, p: Palette) -> El {
    let mut filters = row().w_full().px(8.0).gap(6.0).flex_wrap().items_center();
    for filter in FileKindFilter::ALL {
        let key = format!("file-kind-{}", filter.slug());
        let label = filter.label();
        filters = filters.child(chip(
            key,
            label,
            s.file_filter == filter,
            p,
            move |state: &mut State| state.set_file_filter(filter),
        ));
    }
    filters = filters.child(elevate_chip(s, p));
    col()
        .w_full()
        .gap(4.0)
        .child(search_row(s, p))
        .child(filters)
}

fn file_header(p: Palette) -> El {
    row()
        .key("file-columns")
        .h(26.0)
        .w_full()
        .items_center()
        .fill(p.panel_alt)
        .child(file_head("PID", COL_PID, false, Align::End, p))
        .child(file_head("Process", 110.0, true, Align::Start, p))
        .child(file_head("User", COL_USER, false, Align::Start, p))
        .child(file_head("FD", 64.0, false, Align::End, p))
        .child(file_head("Kind", 52.0, false, Align::Start, p))
        .child(file_head(
            "Target Path / Socket",
            160.0,
            true,
            Align::Start,
            p,
        ))
}

fn file_head(label: &str, width: f32, flexible: bool, align: Align, p: Palette) -> El {
    let line = align_text(text(label).font(LABEL).color(p.muted).truncate(), align);
    cell(width, flexible, line)
}

fn file_stream(s: &State, p: Palette) -> El {
    let stream = col()
        .key("file-stream")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .min_w(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        });
    if s.file_rows.is_empty() {
        return stream
            .padding(12.0)
            .child(text("No matching files").font(LABEL).color(p.muted));
    }
    stream.child(
        col()
            .key("file-rows")
            .w_full()
            .growth(GrowthSpec::default())
            .instant_changes()
            .virtual_rows(
                s.file_rows.len(),
                24.0,
                |_state: &State, index| format!("file-{index}").into(),
                move |state: &State, index| {
                    file_line(&state.file_rows[index], index, state.selected_pid, p)
                },
            )
            .virtual_rows_version((s.revision, s.selected_pid)),
    )
}

fn file_line(entry: &OpenFileEntry, index: usize, selected_pid: Option<u32>, p: Palette) -> El {
    let pid = entry.pid;
    let selected = selected_pid == Some(pid);
    let fd = if entry.count > 1 {
        format!("{} ×{}", entry.fd, entry.count)
    } else {
        entry.fd.to_string()
    };
    el().w_full().h(24.0).child(
        row()
            .key(format!("file-row-{index}"))
            .w_full()
            .h(24.0)
            .items_center()
            .fill(if selected {
                p.accent.alpha(0.16)
            } else {
                p.panel
            })
            .cursor(Cursor::Pointer)
            .on_press(move |state: &mut State| {
                state.select_pid(pid);
            })
            .child(selection_mark(selected, p))
            .child(fixed_text(COL_PID, pid.to_string(), p.muted, Align::End))
            .child(flex_text(110.0, entry.process.clone(), p.text))
            .child(fixed_text(
                COL_USER,
                entry.user.clone(),
                p.muted,
                Align::Start,
            ))
            .child(fixed_text(64.0, fd, p.text, Align::End))
            .child(fixed_text(
                52.0,
                entry.kind.label().to_string(),
                p.text,
                Align::Start,
            ))
            .child(flex_text(160.0, entry.path.clone(), p.text)),
    )
}

fn elevation_process_label(elevation: ElevationState) -> &'static str {
    match elevation {
        ElevationState::Unprivileged => "All Users [S]",
        ElevationState::Authenticating => "Auth… [S]",
        ElevationState::Elevated => "All Users · Root [S]",
    }
}

fn elevation_top_label(elevation: ElevationState) -> &'static str {
    match elevation {
        ElevationState::Unprivileged => "Elevate",
        ElevationState::Authenticating => "Auth…",
        ElevationState::Elevated => "Root",
    }
}

fn process_subtitle(s: &State) -> String {
    let shown = format!(
        "{} shown / {} total",
        s.rows.len(),
        s.snapshot.processes.len()
    );
    if s.elevation == ElevationState::Elevated {
        format!("{shown} · all users")
    } else {
        shown
    }
}

fn search_field(s: &State, p: Palette) -> El {
    let placeholder = match s.pane {
        PaneId::Network => "Filter ports, IPs, states, or processes (/ or Ctrl+F)…",
        PaneId::Files => "Filter files, sockets, processes, or PIDs (/ or Ctrl+F)…",
        _ => "Filter processes (/ or Ctrl+F)…",
    };
    text_input(&s.query, MONO)
        .single_line()
        .key("search")
        .placeholder(placeholder, p.subtle)
        .caret(p.text, p.accent.alpha(0.35))
        .color(p.text)
        .fill(p.base)
        .radius(4.0)
        .px(8.0)
        .h(26.0)
        .grow(1.0)
        .min_w(80.0)
        .shrink()
        .on_edit(|state: &mut State| &mut state.query)
        .on_input_change(|state: &mut State, _| state.on_query_change())
}

#[derive(Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
enum ProcDensity {
    /// PID, Name, CPU, and a compact memory size.
    Compact,
    /// Compact columns plus User and State.
    Medium,
    /// All eight process columns.
    Full,
}

fn proc_density(panel_w: f32) -> ProcDensity {
    if panel_w < 520.0 {
        ProcDensity::Compact
    } else if panel_w < 700.0 {
        ProcDensity::Medium
    } else {
        ProcDensity::Full
    }
}

fn column_header(s: &State, panel_w: f32, p: Palette) -> El {
    let density = proc_density(panel_w);
    let mem_w = if density == ProcDensity::Compact {
        72.0
    } else {
        COL_MEM
    };
    let mut header = row()
        .h(26.0)
        .w_full()
        .items_center()
        .fill(p.panel_alt)
        .child(el().w(2.0).h_full())
        .child(sort_header(
            "sort-pid",
            "PID",
            SortColumn::Pid,
            COL_PID,
            false,
            s,
            p,
        ))
        .child(sort_header(
            "sort-name",
            "Name",
            SortColumn::Name,
            COL_NAME,
            true,
            s,
            p,
        ))
        .child(sort_header(
            "sort-cpu",
            "CPU",
            SortColumn::Cpu,
            COL_CPU,
            false,
            s,
            p,
        ))
        .child(sort_header(
            "sort-mem",
            "Mem",
            SortColumn::Mem,
            mem_w,
            false,
            s,
            p,
        ));
    if density == ProcDensity::Full {
        header = header
            .child(sort_header(
                "sort-read",
                "Read",
                SortColumn::ReadIo,
                COL_READ,
                false,
                s,
                p,
            ))
            .child(sort_header(
                "sort-write",
                "Write",
                SortColumn::WriteIo,
                COL_WRITE,
                false,
                s,
                p,
            ));
    }
    if density != ProcDensity::Compact {
        header = header
            .child(sort_header(
                "sort-user",
                "User",
                SortColumn::User,
                COL_USER,
                false,
                s,
                p,
            ))
            .child(sort_header(
                "sort-state",
                "State",
                SortColumn::State,
                COL_STATE,
                false,
                s,
                p,
            ));
    }
    header
}

fn sort_header(
    key: &str,
    label: &str,
    column: SortColumn,
    width: f32,
    flexible: bool,
    s: &State,
    p: Palette,
) -> El {
    let active = s.sort_col == column;
    let ink = if active { p.accent } else { p.muted };
    let label = align_text(
        text(sort_caption(label, column, s))
            .font(LABEL)
            .color(ink)
            .truncate(),
        column_align(column),
    );
    cell(width, flexible, label)
        .key(key)
        .cursor(Cursor::Pointer)
        .on_press(move |state: &mut State| state.click_sort(column))
}

fn sort_caption(label: &str, column: SortColumn, s: &State) -> String {
    if s.sort_col != column {
        return label.to_string();
    }
    let mark = if s.sort_desc { "▼" } else { "▲" };
    format!("{label} {mark}")
}

fn process_stream(s: &State, panel_w: f32, p: Palette) -> El {
    let stream = col()
        .key("process-stream")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .min_w(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        });
    if s.rows.is_empty() {
        return stream
            .padding(12.0)
            .child(text("No matching processes").font(LABEL).color(p.muted));
    }
    stream.child(
        col()
            .key("process-rows")
            .w_full()
            .growth(GrowthSpec::default())
            .instant_changes()
            .virtual_rows(
                s.rows.len(),
                24.0,
                |state: &State, index| state.rows[index].id.as_str().into(),
                move |state: &State, index| {
                    process_line(
                        &state.rows[index],
                        state.selected_pid,
                        state.process_mode,
                        panel_w,
                        p,
                    )
                },
            )
            .virtual_rows_version((s.revision, proc_density(panel_w) as u8)),
    )
}

fn process_line(
    entry: &ProcessRow,
    selected_pid: Option<u32>,
    process_mode: ProcessMode,
    panel_w: f32,
    p: Palette,
) -> El {
    let pid = entry.pid;
    let selected = selected_pid == Some(pid);
    let label = if entry.count > 1 {
        format!("{} ×{}", entry.display_name, entry.count)
    } else {
        entry.display_name.clone()
    };
    let guide = tree_connector_shape(&entry.tree_prefix, 24.0, &p.cpu_cores);
    let show_toggle = process_mode == ProcessMode::Tree && entry.has_children;
    let name_cell = if guide.is_none() && !show_toggle && !entry.pinned {
        flex_text(COL_NAME, label, p.text)
    } else {
        let mut inner = row().w_full().h_full().min_w(0.0).items_center().gap(3.0);
        if let Some((shape, width)) = guide {
            inner = inner.child(
                canvas(shape)
                    .key(format!("tree-guide-{pid}"))
                    .size(width, 24.0)
                    .min_w(width),
            );
        }
        if show_toggle {
            let toggle_label = if entry.collapsed {
                format!("▸ +{}", entry.hidden_children)
            } else {
                "▾".to_string()
            };
            let toggle_ink = if entry.collapsed { p.accent } else { p.muted };
            let toggle_fill = if entry.collapsed {
                p.accent.alpha(0.18)
            } else {
                p.panel_alt
            };
            inner = inner.child(
                row()
                    .key(format!("btn-tree-toggle-{pid}"))
                    .h(18.0)
                    .px(4.0)
                    .radius(3.0)
                    .items_center()
                    .justify_center()
                    .fill(toggle_fill)
                    .cursor(Cursor::Pointer)
                    .transition(Transition::none())
                    .on_press_tx(move |state: &mut State, tx: &mut Tx| {
                        tx.instant();
                        state.toggle_collapse_pid(pid);
                    })
                    .child(text(toggle_label).font(MONO_SMALL).color(toggle_ink)),
            );
        }
        if entry.pinned {
            inner = inner.child(text("★").font(MONO_SMALL).color(p.accent));
        }
        inner = inner.child(
            styled_text(label, p.text, Align::Start)
                .truncate()
                .grow(1.0)
                .min_w(0.0),
        );
        cell(COL_NAME, true, inner)
    };
    let density = proc_density(panel_w);
    let mem_w = if density == ProcDensity::Compact {
        72.0
    } else {
        COL_MEM
    };
    let mem_label = if density == ProcDensity::Compact {
        format_bytes(entry.mem_bytes)
    } else {
        format!("{:.1}%  {}", entry.mem_pct, format_bytes(entry.mem_bytes))
    };
    let mut line = row()
        .key(format!("proc-row-{pid}"))
        .w_full()
        .h(24.0)
        .items_center()
        .fill(if selected {
            p.accent.alpha(0.16)
        } else {
            p.panel
        })
        .cursor(Cursor::Pointer)
        .on_press(move |state: &mut State| {
            state.select_pid(pid);
            state.focused_pane = PaneId::Processes;
        })
        .child(selection_mark(selected, p))
        .child(fixed_text(
            COL_PID,
            entry.pid.to_string(),
            p.muted,
            column_align(SortColumn::Pid),
        ))
        .child(name_cell)
        .child(fixed_text(
            COL_CPU,
            format!("{:.1}%", entry.cpu_pct),
            p.usage_color(entry.cpu_pct),
            column_align(SortColumn::Cpu),
        ))
        .child(fixed_text(
            mem_w,
            mem_label,
            p.text,
            column_align(SortColumn::Mem),
        ));
    if density == ProcDensity::Full {
        line = line
            .child(fixed_text(
                COL_READ,
                format_rate(entry.read_bytes_per_sec),
                p.disk_read,
                column_align(SortColumn::ReadIo),
            ))
            .child(fixed_text(
                COL_WRITE,
                format_rate(entry.write_bytes_per_sec),
                p.disk_write,
                column_align(SortColumn::WriteIo),
            ));
    }
    if density != ProcDensity::Compact {
        line = line
            .child(fixed_text(
                COL_USER,
                entry.user.clone(),
                p.muted,
                column_align(SortColumn::User),
            ))
            .child(fixed_text(
                COL_STATE,
                entry.state.to_string(),
                p.text,
                column_align(SortColumn::State),
            ));
    }
    el().w_full().h(24.0).child(line)
}

fn selection_mark(selected: bool, p: Palette) -> El {
    el().w(2.0).h_full().fill(if selected {
        p.accent
    } else {
        Color::TRANSPARENT
    })
}

fn column_align(column: SortColumn) -> Align {
    match column {
        SortColumn::State => Align::Center,
        SortColumn::Pid
        | SortColumn::Cpu
        | SortColumn::Mem
        | SortColumn::ReadIo
        | SortColumn::WriteIo => Align::End,
        SortColumn::Name | SortColumn::User | SortColumn::Count => Align::Start,
    }
}

fn align_text(line: El, align: Align) -> El {
    if align == Align::Start {
        line
    } else {
        line.align(align).w_full()
    }
}

fn fixed_text(width: f32, content: String, color: Color, align: Align) -> El {
    cell(width, false, styled_text(content, color, align))
}

fn flex_text(width: f32, content: String, color: Color) -> El {
    cell(
        width,
        true,
        styled_text(content, color, Align::Start).truncate(),
    )
}

fn styled_text(content: String, color: Color, align: Align) -> El {
    align_text(text(content).font(MONO_SMALL).color(color), align)
}

fn cell(width: f32, flexible: bool, child: El) -> El {
    let mut slot = el().h_full().items_center().px(4.0);
    slot = if flexible {
        slot.grow(1.0).min_w(width)
    } else {
        slot.w(width)
    };
    slot.child(child)
}

fn scrim(p: Palette) -> El {
    el().key("overlay-scrim")
        .pin(Some(0.0), Some(0.0), Some(0.0), Some(0.0))
        .fill(p.base.alpha(0.58))
        .transition(Transition::none())
        .on_press(|state: &mut State| {
            state.show_settings = false;
        })
}

fn signal_dialog(dialog: &SignalDialog, p: Palette) -> El {
    dialog_card("signal-dialog", p)
        .child(arrive(
            text(format!(
                "Send signal to {} (pid {})",
                dialog.name, dialog.pid
            ))
            .font(PANEL_TITLE)
            .color(p.text),
        ))
        .child(arrive(
            text(format!("Selected {}", dialog.signal.label()))
                .font(MONO)
                .color(p.accent),
        ))
        .child(arrive(
            row()
                .w_full()
                .gap(6.0)
                .flex_wrap()
                .child(signal_choice("sig-term", SignalKind::Term, dialog, p))
                .child(signal_choice("sig-kill", SignalKind::Kill, dialog, p))
                .child(signal_choice("sig-stop", SignalKind::Stop, dialog, p))
                .child(signal_choice("sig-cont", SignalKind::Cont, dialog, p)),
        ))
        .child(arrive(
            row()
                .w_full()
                .gap(8.0)
                .justify_end()
                .child(chip_now(
                    "cancel-signal",
                    "Cancel [Esc]",
                    false,
                    p,
                    |state: &mut State| state.signal_dialog = None,
                ))
                .child(chip_now(
                    "confirm-signal",
                    "Confirm [Enter]",
                    true,
                    p,
                    |state: &mut State| state.confirm_signal(),
                )),
        ))
}

fn signal_choice(key: &str, kind: SignalKind, dialog: &SignalDialog, p: Palette) -> El {
    chip_now(
        key,
        kind.label(),
        dialog.signal == kind,
        p,
        move |state: &mut State| {
            if let Some(dialog) = state.signal_dialog.as_mut() {
                dialog.signal = kind;
            }
        },
    )
}

fn help_dialog(p: Palette) -> El {
    let mut card = dialog_card("help-dialog", p).child(arrive(
        text("Keyboard shortcuts").font(PANEL_TITLE).color(p.text),
    ));
    for line in HELP {
        card = card.child(arrive(text(*line).font(LABEL).color(p.muted)));
    }
    card.child(arrive(row().w_full().justify_end().child(chip_now(
        "close-help",
        "Close [Esc]",
        false,
        p,
        |state: &mut State| state.show_help = false,
    ))))
}

fn theme_label(mode: AppearanceMode, dark: bool) -> String {
    match mode {
        AppearanceMode::System if dark => "Auto · Dark".to_string(),
        AppearanceMode::System => "Auto · Light".to_string(),
        AppearanceMode::Dark => "Dark".to_string(),
        AppearanceMode::Light => "Light".to_string(),
    }
}

/// Appearance, color scheme, and monitor preferences. `dark` is the face on screen.
///
/// The card is centered in a 12px inset of the window and capped at 640×576, which fits the
/// 900×600 minimum. The body scrolls if a future row grows past that cap.
fn settings_modal(s: &State, dark: bool, system_dark: bool, p: Palette) -> El {
    col()
        .pin(Some(12.0), Some(12.0), Some(12.0), Some(12.0))
        .center()
        .child(
            col()
                .key("settings-dialog")
                .w_full()
                .max_w(640.0)
                .max_h(576.0)
                .min_h(0.0)
                .min_w(0.0)
                .padding(12.0)
                .gap(8.0)
                .radius(8.0)
                .fill(p.panel)
                .outline(1.0, 0.0, p.border_focus)
                .transition(Transition::none())
                .on_press(|_: &mut State| {})
                .child(arrive(
                    row()
                        .w_full()
                        .items_center()
                        .child(text("Settings").font(PANEL_TITLE).color(p.text).grow(1.0))
                        .child(chip_now(
                            "close-settings",
                            "Close",
                            false,
                            p,
                            |state: &mut State| state.show_settings = false,
                        )),
                ))
                .child(settings_body(s, dark, system_dark, p)),
        )
}

fn settings_body(s: &State, dark: bool, system_dark: bool, p: Palette) -> El {
    col()
        .key("settings-body")
        .w_full()
        .max_h(518.0)
        .min_h(0.0)
        .min_w(0.0)
        .gap(8.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .child(appearance_section(s, system_dark, p))
        .child(layout_section(s, p))
        .child(scheme_section(s, dark, p))
        .child(monitor_section(s, p))
}

fn layout_section(s: &State, p: Palette) -> El {
    let mut chips = row().gap(6.0).flex_wrap();
    for preset in LayoutPreset::ALL {
        chips = chips.child(chip_now(
            format!("layout-{}", preset.slug()),
            preset.label(),
            s.layout_preset == preset,
            p,
            move |state: &mut State| state.set_layout_preset(preset),
        ));
    }
    chips = chips.child(chip_now(
        "btn-reset-layout",
        "Reset Layout",
        false,
        p,
        |state: &mut State| state.reset_layout(),
    ));
    col()
        .w_full()
        .gap(4.0)
        .child(text("Dashboard Layout").font(PANEL_TITLE).color(p.text))
        .child(chips)
}

fn appearance_section(s: &State, system_dark: bool, p: Palette) -> El {
    let note = if system_dark {
        "System prefers Dark"
    } else {
        "System prefers Light"
    };
    col()
        .w_full()
        .gap(4.0)
        .child(text("Appearance Mode").font(PANEL_TITLE).color(p.text))
        .child(
            row()
                .gap(6.0)
                .flex_wrap()
                .child(appearance_chip(
                    s,
                    AppearanceMode::System,
                    "System (Auto)",
                    p,
                ))
                .child(appearance_chip(s, AppearanceMode::Dark, "Dark", p))
                .child(appearance_chip(s, AppearanceMode::Light, "Light", p)),
        )
        .child(text(note).font(LABEL).color(p.muted))
}

fn appearance_chip(s: &State, mode: AppearanceMode, label: &str, p: Palette) -> El {
    chip_now(
        format!("appearance-{}", mode.slug()),
        label,
        s.appearance_mode == mode,
        p,
        move |state: &mut State| state.set_appearance_mode(mode),
    )
}

fn scheme_section(s: &State, dark: bool, p: Palette) -> El {
    let mut list = col().w_full().gap(2.0);
    for scheme in ColorSchemeId::ALL {
        list = list.child(scheme_row(s, scheme, dark, p));
    }
    col()
        .w_full()
        .gap(4.0)
        .child(text("Color Scheme").font(PANEL_TITLE).color(p.text))
        .child(list)
}

fn scheme_row(s: &State, scheme: ColorSchemeId, dark: bool, p: Palette) -> El {
    let active = s.color_scheme == scheme;
    let preview = scheme.palette(dark, &s.system_theme);
    let title = if scheme == ColorSchemeId::System {
        format!("System ({})", s.system_theme.detected_name)
    } else {
        scheme.label().to_string()
    };
    let ink = if active { p.accent } else { p.text };
    let fill = if active {
        p.accent.alpha(0.16)
    } else {
        p.panel_alt
    };
    row()
        .key(format!("scheme-{}", scheme.slug()))
        .w_full()
        .h(22.0)
        .px(8.0)
        .gap(8.0)
        .items_center()
        .radius(4.0)
        .fill(fill)
        .cursor(Cursor::Pointer)
        .on_press(move |state: &mut State| state.set_color_scheme(scheme))
        .child(
            text(title)
                .font(LABEL)
                .color(ink)
                .truncate()
                .grow(1.0)
                .min_w(0.0),
        )
        .child(swatches(&preview, p))
}

fn swatches(preview: &Palette, p: Palette) -> El {
    let colors = [
        preview.base,
        preview.panel_alt,
        preview.accent,
        preview.ok,
        preview.warn,
    ];
    let mut dots = row().gap(4.0).items_center().shrink();
    for color in colors {
        dots = dots.child(
            el().size(10.0, 10.0)
                .radius(5.0)
                .fill(color)
                .outline(1.0, 0.0, p.border),
        );
    }
    dots
}

fn monitor_section(s: &State, p: Palette) -> El {
    col()
        .w_full()
        .gap(4.0)
        .child(text("Monitor Preferences").font(PANEL_TITLE).color(p.text))
        .child(pref_line(
            p,
            "Poll Interval",
            choice_row(s, p, ChoiceKind::Rate),
        ))
        .child(pref_line(
            p,
            "History Window",
            choice_row(s, p, ChoiceKind::Window),
        ))
        .child(pref_line(
            p,
            "UI Zoom",
            row()
                .gap(6.0)
                .flex_wrap()
                .child(chip_now(
                    "btn-zoom-out",
                    "-",
                    false,
                    p,
                    |state: &mut State| state.zoom_out(),
                ))
                .child(chip_now(
                    "btn-zoom-normal",
                    format!("{}%", s.ui_zoom_pct),
                    s.ui_zoom_pct != 100,
                    p,
                    |state: &mut State| state.reset_ui_zoom(),
                ))
                .child(chip_now(
                    "btn-zoom-in",
                    "+",
                    false,
                    p,
                    |state: &mut State| state.zoom_in(),
                )),
        ))
        .child(pref_line(
            p,
            "CPU Chart",
            row()
                .gap(6.0)
                .flex_wrap()
                .child(chip_now(
                    "pref-cpu-cores",
                    "Per-Core",
                    s.per_core_chart,
                    p,
                    |state: &mut State| state.per_core_chart = true,
                ))
                .child(chip_now(
                    "pref-cpu-total",
                    "Total",
                    !s.per_core_chart,
                    p,
                    |state: &mut State| state.per_core_chart = false,
                ))
                .child(text("Network").font(LABEL).color(p.muted))
                .child(chip_now(
                    "pref-loopback",
                    "Show Loopback",
                    s.show_loopback,
                    p,
                    |state: &mut State| state.show_loopback = !state.show_loopback,
                )),
        ))
        .child(chip_now(
            "pref-reset",
            "Reset to System Defaults",
            false,
            p,
            |state: &mut State| state.reset_to_system_defaults(),
        ))
}

fn pref_line(p: Palette, label: &str, controls: El) -> El {
    row()
        .w_full()
        .gap(8.0)
        .items_center()
        .flex_wrap()
        .child(text(label).font(LABEL).color(p.muted).min_w(108.0))
        .child(controls.grow(1.0).min_w(0.0))
}

#[derive(Clone, Copy)]
enum ChoiceKind {
    Rate,
    Window,
}

fn choice_row(s: &State, p: Palette, kind: ChoiceKind) -> El {
    let mut line = row().gap(6.0).flex_wrap().w_full();
    match kind {
        ChoiceKind::Rate => {
            for ms in RATE_CHOICES_MS {
                line = line.child(chip_now(
                    format!("pref-rate-{ms}"),
                    format!("{ms}ms"),
                    s.poll_interval_ms == ms,
                    p,
                    move |state: &mut State| state.poll_interval_ms = ms,
                ));
            }
        }
        ChoiceKind::Window => {
            for secs in WINDOW_CHOICES_SECS {
                line = line.child(chip_now(
                    format!("pref-window-{secs}"),
                    format!("{secs}s"),
                    s.time_window_secs == secs,
                    p,
                    move |state: &mut State| state.time_window_secs = secs,
                ));
            }
        }
    }
    line
}

fn arrive(node: El) -> El {
    node.transition(Transition::none())
}

fn dialog_card(key: &str, p: Palette) -> El {
    col()
        .key(key)
        .absolute(390.0, 148.0)
        .w(520.0)
        .padding(16.0)
        .gap(10.0)
        .radius(8.0)
        .fill(p.panel)
        .outline(1.0, 0.0, p.border_focus)
        .transition(Transition::none())
}

fn footer(p: Palette) -> El {
    row()
        .key("footer")
        .h(26.0)
        .w_full()
        .px(10.0)
        .items_center()
        .fill(p.chrome)
        .child(
            text(FOOTER)
                .font(MONO_SMALL)
                .color(p.muted)
                .truncate()
                .w_full(),
        )
}

fn hairline(p: Palette) -> El {
    el().h(1.0).w_full().fill(p.border)
}
