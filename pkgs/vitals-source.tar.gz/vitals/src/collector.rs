//! Linux `/proc` and `/sys` telemetry sampler and Polkit helper for Vitals.
//!
//! The first successful sample stores baselines and reports zero CPU and I/O
//! rates. Later samples with a forward `/proc/uptime` delta turn counter
//! differences into percentages and per-second rates. `root` is the filesystem
//! prefix, so tests can point the collector at a temporary tree.

use std::collections::{HashMap, HashSet};
use std::fs::{self, File};
use std::io::{BufRead, BufReader, BufWriter, Error, Read, Write};
use std::net::{Ipv4Addr, Ipv6Addr};
use std::os::unix::fs::MetadataExt;
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStderr, ChildStdin, ChildStdout, Command, ExitStatus, Stdio};
use std::sync::mpsc::{self, Receiver, Sender};
use std::sync::{Arc, RwLock, RwLockReadGuard, RwLockWriteGuard};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};

use crate::model::{
    BatteryMetrics, CoreMetrics, CpuMetrics, DiskMetrics, MemMetrics, NetInterfaceMetrics,
    NetSocketEntry, OpenFileEntry, OpenFileKind, PaneId, ProcessInfo, PsiMetrics, SensorMetrics,
    SignalKind, SystemSnapshot,
};

/// `/proc/<pid>/stat` comm is truncated at 15 characters plus a NUL (`TASK_COMM_LEN`).
const MAX_STAT_NAME_LEN: usize = 15;
/// Cadence in seconds for less-routine refreshes: passwd, statvfs, and device discovery.
const LESS_ROUTINE_INTERVAL: f64 = 60.0;
/// `PF_KTHREAD` from `include/linux/sched.h`.
const PF_KTHREAD: u32 = 0x00200000;
/// Fake `/proc` trees at or under this size still count fds so unit tests stay exact.
const SMALL_FIXTURE_PROCESSES: usize = 8;
const SCAN_WORKERS: usize = 4;
const MAX_SOCKET_ENTRIES: usize = 4096;
const MAX_PROC_OPEN_FILES: usize = 24;
const MAX_OPEN_FILE_ENTRIES: usize = 2_000;
const OPEN_FILES_REFRESH_LIVE: Duration = Duration::from_secs(3);
const LIVE_ACTIVE_SOCKET_INTERVAL: Duration = Duration::from_millis(500);
const LIVE_IDLE_SOCKET_INTERVAL: Duration = Duration::from_secs(2);

type CmdCache = HashMap<(u32, u64), String>;
type UidCache = HashMap<(u32, u64), u32>;

#[derive(Debug, Clone, Copy, Default)]
struct CpuTimes {
    user: u64,
    system: u64,
    idle: u64,
    iowait: u64,
}

impl CpuTimes {
    fn total(self) -> u64 {
        self.user
            .saturating_add(self.system)
            .saturating_add(self.idle)
            .saturating_add(self.iowait)
    }
}

#[derive(Debug, Clone, Copy, Default)]
struct NetCounters {
    rx_bytes: u64,
    tx_bytes: u64,
    rx_packets: u64,
    tx_packets: u64,
}

#[derive(Debug, Clone, Copy, Default)]
struct DiskCounters {
    reads_completed: u64,
    sectors_read: u64,
    read_time_ms: u64,
    writes_completed: u64,
    sectors_written: u64,
    write_time_ms: u64,
    io_ticks_ms: u64,
}

#[derive(Debug, Clone)]
struct RawSocket {
    local_port: u16,
    entry: NetSocketEntry,
}

#[derive(Debug, Clone, Copy, Default)]
struct ProcCounters {
    ticks: u64,
    read_bytes: u64,
    write_bytes: u64,
}

#[derive(Debug, Clone)]
struct ParsedCpu {
    model_name: String,
    aggregate: CpuTimes,
    cores: Vec<(usize, CpuTimes)>,
}

#[derive(Debug, Clone)]
struct ParsedNet {
    name: String,
    counters: NetCounters,
    is_loopback: bool,
}

#[derive(Debug)]
struct SampleParts {
    uptime: f64,
    hostname: String,
    kernel: String,
    load_avg: [f32; 3],
    cpu: ParsedCpu,
    psi: PsiMetrics,
    mem: MemMetrics,
    networks: Vec<ParsedNet>,
    raw_sockets: Vec<RawSocket>,
    disks: Vec<ParsedDisk>,
    sensors: Vec<SensorMetrics>,
    batteries: Vec<BatteryMetrics>,
    processes: Vec<ParsedProc>,
    open_files: Vec<OpenFileEntry>,
}

#[derive(Debug)]
struct ParsedDisk {
    device: String,
    mount_point: String,
    fs_type: String,
    total_bytes: u64,
    used_bytes: u64,
    free_bytes: u64,
    counters: DiskCounters,
}

#[derive(Debug, Clone)]
struct CachedMount {
    device: String,
    mount_point: String,
    fs_type: String,
    total_bytes: u64,
    used_bytes: u64,
    free_bytes: u64,
}

#[derive(Debug)]
struct ParsedProc {
    pid: u32,
    ppid: u32,
    name: String,
    cmdline: String,
    user: String,
    state: char,
    nice: i32,
    mem_bytes: u64,
    threads: u32,
    fds: Option<u32>,
    unit: Option<String>,
    cwd: Option<String>,
    exe: Option<String>,
    open_files: Vec<String>,
    socket_inodes: Vec<u64>,
    fds_scanned: bool,
    start_time: u64,
    counters: ProcCounters,
}

#[derive(Debug)]
pub struct LinuxCollector {
    root: PathBuf,
    prev_uptime: Option<f64>,
    prev_cpu: Option<CpuTimes>,
    prev_cores: HashMap<usize, CpuTimes>,
    prev_net: HashMap<String, NetCounters>,
    prev_disk: HashMap<String, DiskCounters>,
    prev_proc: HashMap<u32, ProcCounters>,
    /// Ticks and uptime at the last full process scan. Zoomed panes keep updating CPU
    /// counters without scanning `/proc/<pid>`, so process rates use this epoch.
    proc_epoch_ticks: Option<u64>,
    proc_epoch_uptime: Option<f64>,
    /// Reused for `/proc/<pid>/stat` and `/proc/<pid>/io` instead of a fresh `String` per file.
    buf: String,
    cmd_cache: HashMap<(u32, u64), String>,
    uid_cache: HashMap<(u32, u64), u32>,
    routine_at: Option<Instant>,
    cpu_model: Option<String>,
    users: Arc<HashMap<u32, String>>,
    disk_mounts: Vec<CachedMount>,
    sensors: Vec<SensorMetrics>,
    batteries: Vec<BatteryMetrics>,
    last_processes: Vec<ProcessInfo>,
    cached_raw_sockets: Vec<RawSocket>,
    sockets_at: Option<Instant>,
    sockets_selected_pid: Option<u32>,
    socket_owners: HashMap<u64, (u32, String)>,
    cached_open_files: Vec<OpenFileEntry>,
    open_files_at: Option<Instant>,
    /// Live clock for Network inode walks. A Files refresh sets this too, so a
    /// fresh open-file scan skips a second `/proc/<pid>/fd` walk. A Network
    /// owner walk must not write `open_files_at`.
    socket_owners_at: Option<Instant>,
    /// Reused `/proc` readers. Created on the first large live scan and joined on drop.
    scan_pool: Option<ScanPool>,
}

impl Default for LinuxCollector {
    fn default() -> Self {
        Self::new()
    }
}

impl LinuxCollector {
    pub fn new() -> Self {
        Self::with_root("/")
    }

    pub fn with_root(root: impl Into<PathBuf>) -> Self {
        Self {
            root: root.into(),
            prev_uptime: None,
            prev_cpu: None,
            prev_cores: HashMap::new(),
            prev_net: HashMap::new(),
            prev_disk: HashMap::new(),
            prev_proc: HashMap::new(),
            proc_epoch_ticks: None,
            proc_epoch_uptime: None,
            buf: String::with_capacity(512),
            cmd_cache: HashMap::new(),
            uid_cache: HashMap::new(),
            routine_at: None,
            cpu_model: None,
            users: Arc::new(HashMap::new()),
            disk_mounts: Vec::new(),
            sensors: Vec::new(),
            batteries: Vec::new(),
            last_processes: Vec::new(),
            cached_raw_sockets: Vec::new(),
            sockets_at: None,
            sockets_selected_pid: None,
            socket_owners: HashMap::new(),
            cached_open_files: Vec::new(),
            open_files_at: None,
            socket_owners_at: None,
            scan_pool: None,
        }
    }

    pub fn sample(&mut self) -> Result<SystemSnapshot, String> {
        self.sample_for(PaneId::Overview, None)
    }

    /// `active_pane` selects which widgets are worth a full `/proc/<pid>` walk.
    pub fn sample_with_options(
        &mut self,
        active_pane: PaneId,
        selected_pid: Option<u32>,
    ) -> Result<SystemSnapshot, String> {
        self.sample_for(active_pane, selected_pid)
    }

    /// Samples one tick. Zoomed CPU, memory, and disk panes on the live root
    /// reuse the previous process list instead of walking `/proc/<pid>`. The
    /// network pane does the same between socket-owner refreshes, then walks
    /// fds again once that cache is older than `OPEN_FILES_REFRESH_LIVE`.
    pub fn sample_for(
        &mut self,
        pane: PaneId,
        selected_pid: Option<u32>,
    ) -> Result<SystemSnapshot, String> {
        let skip_processes = self.reuse_processes(pane);
        let parts = self.read_parts(pane, skip_processes, selected_pid)?;
        let first = self.prev_uptime.is_none();
        let dt = self
            .prev_uptime
            .map(|previous| parts.uptime - previous)
            .unwrap_or(0.0);
        let accept_delta = !first && dt > 0.0;
        let commit = first || dt != 0.0;

        let core_count = parts.cpu.cores.len().max(1);
        let (total_usage_pct, user_pct, system_pct, iowait_pct) = match self.prev_cpu {
            Some(previous) if accept_delta => cpu_percents(previous, parts.cpu.aggregate),
            _ => (0.0, 0.0, 0.0, 0.0),
        };
        let mut cores = Vec::with_capacity(parts.cpu.cores.len());
        for (index, times) in &parts.cpu.cores {
            let (usage_pct, user_pct, system_pct, iowait_pct) = match self.prev_cores.get(index) {
                Some(previous) if accept_delta => cpu_percents(*previous, *times),
                _ => (0.0, 0.0, 0.0, 0.0),
            };
            cores.push(CoreMetrics {
                index: *index,
                usage_pct,
                user_pct,
                system_pct,
                iowait_pct,
                freq_mhz: read_core_freq(&self.root, *index),
                temp_c: core_temp(&parts.sensors, *index),
            });
        }

        let mut networks = Vec::with_capacity(parts.networks.len());
        let mut net_rx_total_bps = 0.0;
        let mut net_tx_total_bps = 0.0;
        for iface in &parts.networks {
            let (rx_bytes_per_sec, tx_bytes_per_sec, rx_packets_per_sec, tx_packets_per_sec) =
                match self.prev_net.get(&iface.name) {
                    Some(previous) if accept_delta => (
                        per_sec(previous.rx_bytes, iface.counters.rx_bytes, dt),
                        per_sec(previous.tx_bytes, iface.counters.tx_bytes, dt),
                        per_sec(previous.rx_packets, iface.counters.rx_packets, dt),
                        per_sec(previous.tx_packets, iface.counters.tx_packets, dt),
                    ),
                    _ => (0.0, 0.0, 0.0, 0.0),
                };
            if !iface.is_loopback {
                net_rx_total_bps += rx_bytes_per_sec;
                net_tx_total_bps += tx_bytes_per_sec;
            }
            networks.push(NetInterfaceMetrics {
                name: iface.name.clone(),
                is_loopback: iface.is_loopback,
                rx_bytes_per_sec,
                tx_bytes_per_sec,
                total_rx_bytes: iface.counters.rx_bytes,
                total_tx_bytes: iface.counters.tx_bytes,
                rx_packets_per_sec,
                tx_packets_per_sec,
            });
        }

        let mut disks = Vec::with_capacity(parts.disks.len());
        for disk in &parts.disks {
            let (read_bytes_per_sec, write_bytes_per_sec, busy_pct, await_ms) =
                match self.prev_disk.get(&disk.device) {
                    Some(previous) if accept_delta => disk_rates(*previous, disk.counters, dt),
                    _ => (0.0, 0.0, 0.0, 0.0),
                };
            let used_pct = percent(disk.used_bytes, disk.total_bytes);
            disks.push(DiskMetrics {
                device: disk.device.clone(),
                mount_point: disk.mount_point.clone(),
                fs_type: disk.fs_type.clone(),
                total_bytes: disk.total_bytes,
                used_bytes: disk.used_bytes,
                free_bytes: disk.free_bytes,
                used_pct,
                read_bytes_per_sec,
                write_bytes_per_sec,
                busy_pct,
                await_ms,
            });
        }

        let total_ticks = parts.cpu.aggregate.total();
        let epoch_ticks = self.proc_epoch_ticks.unwrap_or(0);
        let proc_dt = self
            .proc_epoch_uptime
            .map(|previous| parts.uptime - previous)
            .unwrap_or(0.0);
        let proc_ready = self.proc_epoch_uptime.is_some() && proc_dt > 0.0;
        let mem_total = parts.mem.total_bytes;
        let mut next_proc = None;
        let processes = if skip_processes {
            if pane == PaneId::Network
                && let Some(sel_pid) = selected_pid
                && let Some(proc_info) = self.last_processes.iter().find(|p| p.pid == sel_pid)
            {
                let fd_path = self.root.join("proc").join(sel_pid.to_string()).join("fd");
                let (_, socket_inodes) = scan_fds(&fd_path);
                self.socket_owners
                    .retain(|_, (owner_pid, _)| *owner_pid != sel_pid);
                for inode in socket_inodes {
                    self.socket_owners
                        .insert(inode, (sel_pid, proc_info.name.clone()));
                }
            }
            self.last_processes.clone()
        } else {
            let alive_pids: HashSet<u32> = parts.processes.iter().map(|proc| proc.pid).collect();
            let scanned_pids: HashSet<u32> = parts
                .processes
                .iter()
                .filter(|proc| proc.fds_scanned)
                .map(|proc| proc.pid)
                .collect();
            self.socket_owners.retain(|_, (owner_pid, _)| {
                alive_pids.contains(owner_pid) && !scanned_pids.contains(owner_pid)
            });

            let mut built = Vec::with_capacity(parts.processes.len());
            let mut counters = HashMap::with_capacity(parts.processes.len());
            for proc in parts.processes {
                let (cpu_pct, read_bytes_per_sec, write_bytes_per_sec) = match self
                    .prev_proc
                    .get(&proc.pid)
                {
                    Some(previous) if proc_ready => {
                        let cpu_pct = if total_ticks >= epoch_ticks
                            && proc.counters.ticks >= previous.ticks
                        {
                            let delta_ticks = total_ticks - epoch_ticks;
                            let delta_proc = proc.counters.ticks - previous.ticks;
                            if delta_ticks == 0 {
                                0.0
                            } else {
                                (delta_proc as f64 / delta_ticks as f64) * 100.0 * core_count as f64
                            }
                        } else {
                            0.0
                        };
                        (
                            cpu_pct as f32,
                            per_sec(previous.read_bytes, proc.counters.read_bytes, proc_dt),
                            per_sec(previous.write_bytes, proc.counters.write_bytes, proc_dt),
                        )
                    }
                    _ => (0.0, 0.0, 0.0),
                };
                let mut listening_ports = Vec::new();
                if proc.fds_scanned && !proc.socket_inodes.is_empty() {
                    let inode_set: HashSet<u64> = proc.socket_inodes.iter().copied().collect();
                    for &inode in &inode_set {
                        self.socket_owners
                            .insert(inode, (proc.pid, proc.name.clone()));
                    }
                    for sock in &parts.raw_sockets {
                        if sock.entry.inode > 0
                            && inode_set.contains(&sock.entry.inode)
                            && is_listening_socket(&sock.entry)
                        {
                            let label = listening_port_label(&sock.entry);
                            if !listening_ports.contains(&label) {
                                listening_ports.push(label);
                            }
                        }
                    }
                }
                counters.insert(proc.pid, proc.counters);
                built.push(ProcessInfo {
                    pid: proc.pid,
                    ppid: proc.ppid,
                    name: proc.name,
                    cmdline: proc.cmdline,
                    user: proc.user,
                    state: proc.state,
                    cpu_pct,
                    mem_bytes: proc.mem_bytes,
                    mem_pct: percent(proc.mem_bytes, mem_total),
                    read_bytes_per_sec,
                    write_bytes_per_sec,
                    threads: proc.threads,
                    fds: proc.fds,
                    nice: proc.nice,
                    unit: proc.unit,
                    cwd: proc.cwd,
                    exe: proc.exe,
                    listening_ports,
                    open_files: proc.open_files,
                });
            }
            next_proc = Some(counters);
            built
        };

        let mut sockets = Vec::with_capacity(parts.raw_sockets.len().min(MAX_SOCKET_ENTRIES));
        for mut raw in parts.raw_sockets.into_iter().take(MAX_SOCKET_ENTRIES) {
            if raw.entry.inode > 0
                && let Some((pid, proc_name)) = self.socket_owners.get(&raw.entry.inode)
            {
                raw.entry.pid = Some(*pid);
                raw.entry.process.clone_from(proc_name);
            }
            sockets.push(raw.entry);
        }

        if commit {
            self.prev_uptime = Some(parts.uptime);
            self.prev_cpu = Some(parts.cpu.aggregate);
            self.prev_cores = parts.cpu.cores.into_iter().collect();
            self.prev_net = parts
                .networks
                .into_iter()
                .map(|iface| (iface.name, iface.counters))
                .collect();
            self.prev_disk = parts
                .disks
                .into_iter()
                .map(|disk| (disk.device, disk.counters))
                .collect();
            if let Some(counters) = next_proc {
                self.proc_epoch_ticks = Some(total_ticks);
                self.proc_epoch_uptime = Some(parts.uptime);
                self.prev_proc = counters;
                self.last_processes.clone_from(&processes);
            }
        }

        let tasks_total = processes.len();
        let tasks_running = processes.iter().filter(|proc| proc.state == 'R').count();
        Ok(SystemSnapshot {
            timestamp_sec: unix_timestamp(),
            hostname: parts.hostname,
            kernel: parts.kernel,
            cpu: CpuMetrics {
                model_name: parts.cpu.model_name,
                total_usage_pct,
                user_pct,
                system_pct,
                iowait_pct,
                load_avg: parts.load_avg,
                cores,
                uptime_secs: parts.uptime.max(0.0) as u64,
                tasks_total,
                tasks_running,
            },
            mem: parts.mem,
            networks,
            net_rx_total_bps,
            net_tx_total_bps,
            disks,
            sensors: parts.sensors,
            batteries: parts.batteries,
            processes,
            psi: parts.psi,
            sockets,
            open_files: parts.open_files,
        })
    }

    fn reuse_processes(&self, pane: PaneId) -> bool {
        if self.root != Path::new("/") || self.last_processes.is_empty() {
            return false;
        }
        match pane {
            PaneId::Cpu | PaneId::Memory | PaneId::Disks => true,
            // Keep the process list between owner refreshes. A stale or missing
            // stamp means this tick has to scan `/proc/<pid>/fd` for socket inodes.
            PaneId::Network => self
                .socket_owners_at
                .is_some_and(|at| at.elapsed() < OPEN_FILES_REFRESH_LIVE),
            _ => false,
        }
    }

    fn routine_due(&self) -> bool {
        if self.root != Path::new("/") {
            return true;
        }
        match self.routine_at {
            Some(at) => at.elapsed().as_secs_f64() >= LESS_ROUTINE_INTERVAL,
            None => true,
        }
    }

    fn refresh_routine(&mut self, core_count: usize) {
        if !self.routine_due() {
            return;
        }
        self.cpu_model = Some(read_cpu_model(&self.root, core_count));
        self.users = Arc::new(load_users(&self.root));
        let counters = read_diskstats(&self.root);
        self.disk_mounts = read_disk_mounts(&self.root, &counters);
        self.sensors = read_sensors(&self.root);
        self.batteries = read_batteries(&self.root);
        if self.root == Path::new("/") {
            self.routine_at = Some(Instant::now());
            self.cmd_cache.shrink_to_fit();
            self.uid_cache.shrink_to_fit();
            self.prev_proc.shrink_to_fit();
        }
    }

    fn read_parts(
        &mut self,
        pane: PaneId,
        skip_processes: bool,
        selected_pid: Option<u32>,
    ) -> Result<SampleParts, String> {
        let uptime = read_uptime(&self.root);
        let stat_text = read_required(&self.root.join("proc/stat"), "/proc/stat")?;
        let mut cpu = parse_proc_stat(&stat_text)?;
        let core_count = cpu.cores.len();
        self.refresh_routine(core_count);
        cpu.model_name = self
            .cpu_model
            .clone()
            .unwrap_or_else(|| read_cpu_model(&self.root, core_count));
        let psi = read_psi(&self.root, &mut self.buf);
        let mem_text = read_required(&self.root.join("proc/meminfo"), "/proc/meminfo")?;
        let mem = parse_meminfo(&mem_text)?;
        let hostname = read_hostname(&self.root);
        let kernel = read_kernel(&self.root);
        let load_avg = read_loadavg(&self.root);
        let networks = read_networks(&self.root);
        let raw_sockets = self.read_sockets(pane, skip_processes, selected_pid);
        let disks = self.current_disks();
        let sensors = self.sensors.clone();
        let batteries = self.batteries.clone();
        let (processes, open_files) = if skip_processes {
            (Vec::new(), Vec::new())
        } else {
            self.read_processes(pane, selected_pid, &raw_sockets)
        };
        Ok(SampleParts {
            uptime,
            hostname,
            kernel,
            load_avg,
            cpu,
            psi,
            mem,
            networks,
            raw_sockets,
            disks,
            sensors,
            batteries,
            processes,
            open_files,
        })
    }

    fn read_sockets(
        &mut self,
        pane: PaneId,
        skip_processes: bool,
        selected_pid: Option<u32>,
    ) -> Vec<RawSocket> {
        let live = self.root == Path::new("/");
        if !live {
            return read_raw_sockets(&self.root);
        }
        if skip_processes && pane != PaneId::Network {
            return self.cached_raw_sockets.clone();
        }
        let active = pane == PaneId::Network || pane == PaneId::Files || selected_pid.is_some();
        let interval = if active {
            LIVE_ACTIVE_SOCKET_INTERVAL
        } else {
            LIVE_IDLE_SOCKET_INTERVAL
        };
        let need_refresh = match self.sockets_at {
            None => true,
            Some(at) => {
                pane == PaneId::Network
                    || (selected_pid.is_some() && selected_pid != self.sockets_selected_pid)
                    || at.elapsed() >= interval
            }
        };
        if need_refresh {
            self.cached_raw_sockets = read_raw_sockets(&self.root);
            self.sockets_at = Some(Instant::now());
            self.sockets_selected_pid = selected_pid;
        }
        self.cached_raw_sockets.clone()
    }

    fn current_disks(&self) -> Vec<ParsedDisk> {
        let counters = read_diskstats(&self.root);
        self.disk_mounts
            .iter()
            .map(|mount| ParsedDisk {
                device: mount.device.clone(),
                mount_point: mount.mount_point.clone(),
                fs_type: mount.fs_type.clone(),
                total_bytes: mount.total_bytes,
                used_bytes: mount.used_bytes,
                free_bytes: mount.free_bytes,
                counters: counters.get(&mount.device).copied().unwrap_or_default(),
            })
            .collect()
    }

    fn read_processes(
        &mut self,
        pane: PaneId,
        selected_pid: Option<u32>,
        raw_sockets: &[RawSocket],
    ) -> (Vec<ParsedProc>, Vec<OpenFileEntry>) {
        let pids = proc_pids(&self.root);
        let live = self.root == Path::new("/");
        let count_all_fds = !live && pids.len() <= SMALL_FIXTURE_PROCESSES;
        let open_files_fresh = live
            && self
                .open_files_at
                .is_some_and(|at| at.elapsed() < OPEN_FILES_REFRESH_LIVE);
        let socket_owners_fresh = live
            && self
                .socket_owners_at
                .is_some_and(|at| at.elapsed() < OPEN_FILES_REFRESH_LIVE);
        let reuse_cached_open_files =
            pane == PaneId::Files && open_files_fresh && !self.cached_open_files.is_empty();
        // Network names sockets from inode walks. `socket_owners_fresh` (set by
        // a Files scan or a Network owner walk) keeps that walk off the fast
        // path. Large fixtures still walk owners so tests can attribute sockets.
        let collect_open_files =
            (pane == PaneId::Files && !reuse_cached_open_files) || count_all_fds;
        let scan_socket_owners = pane == PaneId::Network
            && ((!live && !count_all_fds) || (live && !socket_owners_fresh));
        let fd_walk = if collect_open_files {
            FdWalk::OpenFiles
        } else if scan_socket_owners {
            FdWalk::SocketOwners
        } else {
            FdWalk::Off
        };
        let socket_targets = if collect_open_files || scan_socket_owners || selected_pid.is_some() {
            Arc::new(build_socket_target_map(raw_sockets))
        } else {
            Arc::new(HashMap::new())
        };
        let cmds = RwLock::new(std::mem::take(&mut self.cmd_cache));
        let uids = RwLock::new(std::mem::take(&mut self.uid_cache));
        let (processes, mut harvested_files, cmd_cache, uid_cache) =
            if count_all_fds || pids.len() < 48 {
                let scan = ProcScan {
                    users: self.users.as_ref(),
                    selected_pid,
                    count_all_fds,
                    fd_walk,
                    fixture: !live,
                    socket_targets: socket_targets.as_ref(),
                    cmds: &cmds,
                    uids: &uids,
                };
                let (processes, open_files) = harvest_pids(&self.root, &pids, &scan, &mut self.buf);
                (
                    processes,
                    open_files,
                    cmds.into_inner().unwrap_or_else(|err| err.into_inner()),
                    uids.into_inner().unwrap_or_else(|err| err.into_inner()),
                )
            } else {
                // Creating the four readers costs about as much as one scan, so they stay
                // parked on the collector and only wake up for the next tick.
                self.scan_parallel(pids, selected_pid, fd_walk, socket_targets, cmds, uids)
            };
        self.cmd_cache = cmd_cache;
        self.uid_cache = uid_cache;
        let seen: HashSet<(u32, u64)> = processes
            .iter()
            .map(|proc| (proc.pid, proc.start_time))
            .collect();
        self.cmd_cache.retain(|key, _| seen.contains(key));
        self.uid_cache.retain(|key, _| seen.contains(key));

        let open_files = if collect_open_files {
            harvested_files.sort_by(|a, b| {
                snapshot_open_file_priority(a.kind)
                    .cmp(&snapshot_open_file_priority(b.kind))
                    .then_with(|| a.pid.cmp(&b.pid))
                    .then_with(|| a.fd.cmp(&b.fd))
                    .then_with(|| a.path.cmp(&b.path))
            });
            harvested_files.truncate(MAX_OPEN_FILE_ENTRIES);
            if live && pane == PaneId::Files {
                self.cached_open_files.clone_from(&harvested_files);
                let now = Instant::now();
                self.open_files_at = Some(now);
                self.socket_owners_at = Some(now);
            }
            harvested_files
        } else if pane == PaneId::Files && reuse_cached_open_files {
            self.cached_open_files.clone()
        } else {
            Vec::new()
        };
        if live && scan_socket_owners {
            self.socket_owners_at = Some(Instant::now());
        }
        (processes, open_files)
    }

    fn scan_parallel(
        &mut self,
        pids: Vec<u32>,
        selected_pid: Option<u32>,
        fd_walk: FdWalk,
        socket_targets: Arc<HashMap<u64, String>>,
        cmds: RwLock<CmdCache>,
        uids: RwLock<UidCache>,
    ) -> (Vec<ParsedProc>, Vec<OpenFileEntry>, CmdCache, UidCache) {
        if self.scan_pool.is_none() {
            self.scan_pool = Some(ScanPool::start(SCAN_WORKERS));
        }
        let cmds = Arc::new(cmds);
        let uids = Arc::new(uids);
        let users = Arc::clone(&self.users);
        let root = self.root.clone();
        let fixture = self.root != Path::new("/");
        let size = pids.len().div_ceil(SCAN_WORKERS);
        let chunks: Vec<Vec<u32>> = pids.chunks(size).map(|chunk| chunk.to_vec()).collect();
        let chunk_count = chunks.len();
        let (processes, open_files) = {
            let pool = self.scan_pool.as_ref().expect("scan pool");
            for (index, chunk) in chunks.into_iter().enumerate() {
                pool.slots[index]
                    .send(Some(ScanOrder {
                        index,
                        root: root.clone(),
                        pids: chunk,
                        selected_pid,
                        fd_walk,
                        fixture,
                        socket_targets: Arc::clone(&socket_targets),
                        users: Arc::clone(&users),
                        cmds: Arc::clone(&cmds),
                        uids: Arc::clone(&uids),
                    }))
                    .expect("scan worker");
            }
            let mut grouped = Vec::with_capacity(chunk_count);
            for _ in 0..chunk_count {
                grouped.push(pool.done.recv().expect("scan result"));
            }
            grouped.sort_by_key(|done| done.index);
            let mut all_procs = Vec::with_capacity(pids.len());
            let mut all_files = Vec::new();
            for done in grouped {
                all_procs.extend(done.procs);
                all_files.extend(done.open_files);
            }
            (all_procs, all_files)
        };
        (
            processes,
            open_files,
            unwrap_arc_lock(cmds),
            unwrap_arc_lock(uids),
        )
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum FdWalk {
    Off,
    /// Socket inodes for the network table, without the Files list.
    SocketOwners,
    OpenFiles,
}

struct ProcScan<'a> {
    users: &'a HashMap<u32, String>,
    selected_pid: Option<u32>,
    count_all_fds: bool,
    fd_walk: FdWalk,
    fixture: bool,
    socket_targets: &'a HashMap<u64, String>,
    cmds: &'a RwLock<HashMap<(u32, u64), String>>,
    uids: &'a RwLock<HashMap<(u32, u64), u32>>,
}

fn harvest_pids(
    root: &Path,
    pids: &[u32],
    scan: &ProcScan<'_>,
    buf: &mut String,
) -> (Vec<ParsedProc>, Vec<OpenFileEntry>) {
    let mut processes = Vec::with_capacity(pids.len());
    let mut open_files = Vec::new();
    let mut dir = root.join("proc");
    let mut pid_buf = [0u8; 16];
    for &pid in pids {
        push_pid(&mut dir, pid, &mut pid_buf);
        if let Some(proc) = harvest_one(pid, &mut dir, buf, scan, &mut open_files) {
            processes.push(proc);
        }
        dir.pop();
    }
    (processes, open_files)
}

fn harvest_one(
    pid: u32,
    dir: &mut PathBuf,
    buf: &mut String,
    scan: &ProcScan<'_>,
    out_open_files: &mut Vec<OpenFileEntry>,
) -> Option<ParsedProc> {
    dir.push("stat");
    let stat_ok = read_into(dir, buf);
    dir.pop();
    if !stat_ok {
        return None;
    }
    let stat = parse_stat(buf)?;
    let (uid, ppid, mem_bytes, threads) = if scan.fixture {
        dir.push("status");
        let status = read_optional(dir).unwrap_or_default();
        dir.pop();
        let uid = status_uid(&status).or_else(|| fs::metadata(&*dir).ok().map(|meta| meta.uid()));
        let ppid = status_value(&status, "PPid")
            .and_then(|text| text.trim().parse().ok())
            .unwrap_or(stat.ppid);
        let mem_bytes = status_value(&status, "VmRSS")
            .and_then(|text| text.split_whitespace().next()?.parse::<u64>().ok())
            .map(|kb| kb.saturating_mul(1024))
            .unwrap_or_else(|| stat.rss_pages.saturating_mul(page_size()));
        let threads = status_value(&status, "Threads")
            .and_then(|text| text.trim().parse().ok())
            .unwrap_or(stat.threads);
        (uid, ppid, mem_bytes, threads)
    } else {
        let key = (pid, stat.start_time);
        let uid = if let Some(uid) = read_lock(scan.uids).get(&key).copied() {
            Some(uid)
        } else {
            let uid = fs::metadata(&*dir).ok().map(|meta| meta.uid());
            if let Some(uid) = uid {
                write_lock(scan.uids).insert(key, uid);
            }
            uid
        };
        (
            uid,
            stat.ppid,
            stat.rss_pages.saturating_mul(page_size()),
            stat.threads,
        )
    };
    let cmdline = cached_cmdline(scan.cmds, dir, pid, stat.start_time, stat.is_kernel_thread);
    let inspect_detail = scan.count_all_fds || scan.selected_pid == Some(pid);
    let user = uid
        .and_then(|uid| scan.users.get(&uid).cloned())
        .unwrap_or_else(|| {
            uid.map(|id| id.to_string())
                .unwrap_or_else(|| "unknown".to_string())
        });
    let name = process_name(stat.name, &cmdline);
    let (read_bytes, write_bytes) = if stat.is_kernel_thread {
        (0, 0)
    } else {
        dir.push("io");
        let io_ok = read_into(dir, buf);
        let bytes = if io_ok { io_bytes(buf) } else { (0, 0) };
        dir.pop();
        bytes
    };
    let (fds, socket_inodes, unit, cwd, exe, open_files, fds_scanned) = if inspect_detail {
        let detail = inspect_process_detail(dir, buf, stat.is_kernel_thread, scan.socket_targets);
        if scan.fd_walk == FdWalk::OpenFiles {
            append_open_file_entries(out_open_files, pid, &name, &user, detail.dedup_fds);
        }
        (
            detail.fds,
            detail.socket_inodes,
            detail.unit,
            detail.cwd,
            detail.exe,
            detail.open_files,
            true,
        )
    } else if scan.fd_walk != FdWalk::Off {
        dir.push("fd");
        let (fds, socket_inodes, dedup_fds) = scan_fds_detailed(dir, scan.socket_targets);
        dir.pop();
        if scan.fd_walk == FdWalk::OpenFiles {
            append_open_file_entries(out_open_files, pid, &name, &user, dedup_fds);
        }
        (fds, socket_inodes, None, None, None, Vec::new(), true)
    } else {
        (None, Vec::new(), None, None, None, Vec::new(), false)
    };
    Some(ParsedProc {
        pid,
        ppid,
        name,
        cmdline,
        user,
        state: stat.state,
        nice: stat.nice,
        mem_bytes,
        threads,
        fds,
        unit,
        cwd,
        exe,
        open_files,
        socket_inodes,
        fds_scanned,
        start_time: stat.start_time,
        counters: ProcCounters {
            ticks: stat.ticks,
            read_bytes,
            write_bytes,
        },
    })
}

fn cached_cmdline(
    cmds: &RwLock<HashMap<(u32, u64), String>>,
    dir: &mut PathBuf,
    pid: u32,
    start_time: u64,
    kernel: bool,
) -> String {
    let key = (pid, start_time);
    if let Some(cached) = read_lock(cmds).get(&key) {
        return cached.clone();
    }
    let cmdline = if kernel {
        String::new()
    } else {
        dir.push("cmdline");
        let cmdline = fs::read(&*dir)
            .map(|bytes| parse_cmdline(&bytes))
            .unwrap_or_default();
        dir.pop();
        cmdline
    };
    write_lock(cmds).insert(key, cmdline.clone());
    cmdline
}

fn read_lock<T>(lock: &RwLock<T>) -> RwLockReadGuard<'_, T> {
    lock.read().unwrap_or_else(|err| err.into_inner())
}

fn write_lock<T>(lock: &RwLock<T>) -> RwLockWriteGuard<'_, T> {
    lock.write().unwrap_or_else(|err| err.into_inner())
}

struct ScanPool {
    slots: Vec<Sender<Option<ScanOrder>>>,
    done: Receiver<ScanDone>,
    threads: Vec<thread::JoinHandle<()>>,
}

struct ScanOrder {
    index: usize,
    root: PathBuf,
    pids: Vec<u32>,
    selected_pid: Option<u32>,
    fd_walk: FdWalk,
    fixture: bool,
    socket_targets: Arc<HashMap<u64, String>>,
    users: Arc<HashMap<u32, String>>,
    cmds: Arc<RwLock<CmdCache>>,
    uids: Arc<RwLock<UidCache>>,
}

struct ScanDone {
    index: usize,
    procs: Vec<ParsedProc>,
    open_files: Vec<OpenFileEntry>,
}

impl std::fmt::Debug for ScanPool {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("ScanPool")
            .field("workers", &self.slots.len())
            .finish()
    }
}

impl ScanPool {
    fn start(workers: usize) -> Self {
        let (done_tx, done) = mpsc::channel();
        let mut slots = Vec::with_capacity(workers);
        let mut threads = Vec::with_capacity(workers);
        for index in 0..workers {
            let (tx, rx) = mpsc::channel();
            let done_tx = done_tx.clone();
            let thread = thread::Builder::new()
                .name(format!("vitals-scan-{index}"))
                .spawn(move || scan_worker(rx, done_tx))
                .expect("spawn vitals-scan");
            slots.push(tx);
            threads.push(thread);
        }
        Self {
            slots,
            done,
            threads,
        }
    }
}

impl Drop for ScanPool {
    fn drop(&mut self) {
        for slot in &self.slots {
            let _ = slot.send(None);
        }
        for thread in self.threads.drain(..) {
            let _ = thread.join();
        }
    }
}

fn scan_worker(rx: Receiver<Option<ScanOrder>>, tx: Sender<ScanDone>) {
    let mut buf = String::with_capacity(512);
    while let Ok(Some(order)) = rx.recv() {
        let index = order.index;
        let (procs, open_files) = {
            let scan = ProcScan {
                users: order.users.as_ref(),
                selected_pid: order.selected_pid,
                count_all_fds: false,
                fd_walk: order.fd_walk,
                fixture: order.fixture,
                socket_targets: order.socket_targets.as_ref(),
                cmds: order.cmds.as_ref(),
                uids: order.uids.as_ref(),
            };
            harvest_pids(&order.root, &order.pids, &scan, &mut buf)
        };
        drop(order);
        if tx
            .send(ScanDone {
                index,
                procs,
                open_files,
            })
            .is_err()
        {
            break;
        }
    }
}

fn unwrap_arc_lock<T>(lock: Arc<RwLock<T>>) -> T {
    Arc::try_unwrap(lock)
        .unwrap_or_else(|_| panic!("scan worker still holds a cache lock"))
        .into_inner()
        .unwrap_or_else(|err| err.into_inner())
}

pub fn send_process_signal(pid: u32, signal: SignalKind) -> Result<(), String> {
    if pid <= 1 {
        return Err(format!("refusing to signal pid {pid}"));
    }
    let Ok(pid) = i32::try_from(pid) else {
        return Err(format!("pid {pid} is outside the range libc::kill accepts"));
    };
    // Safety: `pid` is a positive process id other than init, and `signal.number()`
    // is one of the four fixed Linux signal numbers this dialog can send.
    let rc = unsafe { libc::kill(pid, signal.number()) };
    if rc == 0 {
        Ok(())
    } else {
        Err(Error::last_os_error().to_string())
    }
}

pub fn renice_process(pid: u32, delta: i32) -> Result<i32, String> {
    if pid <= 1 {
        return Err(format!("refusing to renice pid {pid}"));
    }
    if i32::try_from(pid).is_err() {
        return Err(format!("pid {pid} is outside the range libc accepts"));
    }
    let who = pid as libc::id_t;
    // Safety: `__errno_location` accesses thread-local errno; `getpriority` only reads
    // kernel scheduling priority for `who` (`pid > 1`). Clearing errno distinguishes a
    // legitimate `-1` nice value from an error return.
    let current = unsafe {
        *libc::__errno_location() = 0;
        let prio = libc::getpriority(libc::PRIO_PROCESS, who);
        if prio == -1 && *libc::__errno_location() != 0 {
            return Err(Error::last_os_error().to_string());
        }
        prio
    };
    let target = current.saturating_add(delta).clamp(-20, 19);
    // Safety: `who` is a validated positive pid other than init, and `target` is clamped
    // to the Linux nice range `-20..=19`.
    let rc = unsafe { libc::setpriority(libc::PRIO_PROCESS, who, target) };
    if rc != 0 {
        return Err(Error::last_os_error().to_string());
    }
    let actual = unsafe {
        *libc::__errno_location() = 0;
        let prio = libc::getpriority(libc::PRIO_PROCESS, who);
        if prio == -1 && *libc::__errno_location() != 0 {
            target
        } else {
            prio
        }
    };
    Ok(actual)
}

fn read_required(path: &Path, label: &str) -> Result<String, String> {
    fs::read_to_string(path).map_err(|err| format!("failed to read {label}: {err}"))
}

fn read_optional(path: &Path) -> Option<String> {
    fs::read_to_string(path).ok()
}

fn read_uptime(root: &Path) -> f64 {
    read_optional(&root.join("proc/uptime"))
        .and_then(|text| text.split_whitespace().next()?.parse().ok())
        .unwrap_or(0.0)
}

fn read_hostname(root: &Path) -> String {
    if let Some(name) = read_optional(&root.join("proc/sys/kernel/hostname")) {
        let name = name.trim();
        if !name.is_empty() {
            return name.to_string();
        }
    }
    if let Some(name) = read_optional(&root.join("etc/hostname")) {
        let name = name.trim();
        if !name.is_empty() {
            return name.to_string();
        }
    }
    if root == Path::new("/") {
        return hostname_from_libc();
    }
    "localhost".to_string()
}

fn hostname_from_libc() -> String {
    let mut buf = [0u8; 256];
    // Safety: `buf` is a writable 256-byte buffer and the length passed to
    // gethostname matches it. The result is copied out before the buffer ends.
    let rc = unsafe { libc::gethostname(buf.as_mut_ptr().cast(), buf.len()) };
    if rc != 0 {
        return "localhost".to_string();
    }
    let len = buf.iter().position(|byte| *byte == 0).unwrap_or(buf.len());
    let name = String::from_utf8_lossy(&buf[..len]).trim().to_string();
    if name.is_empty() {
        "localhost".to_string()
    } else {
        name
    }
}

fn read_kernel(root: &Path) -> String {
    read_optional(&root.join("proc/sys/kernel/osrelease"))
        .map(|text| text.trim().to_string())
        .filter(|text| !text.is_empty())
        .unwrap_or_else(|| "unknown".to_string())
}

fn read_loadavg(root: &Path) -> [f32; 3] {
    let Some(text) = read_optional(&root.join("proc/loadavg")) else {
        return [0.0, 0.0, 0.0];
    };
    let mut values = text
        .split_whitespace()
        .map(|part| part.parse().unwrap_or(0.0));
    [
        values.next().unwrap_or(0.0),
        values.next().unwrap_or(0.0),
        values.next().unwrap_or(0.0),
    ]
}

fn parse_proc_stat(text: &str) -> Result<ParsedCpu, String> {
    let mut aggregate = None;
    let mut cores = Vec::new();
    for line in text.lines() {
        let mut parts = line.split_whitespace();
        let Some(label) = parts.next() else {
            continue;
        };
        if label == "cpu" {
            aggregate = Some(parse_cpu_fields(&parts.collect::<Vec<_>>()));
        } else if let Some(index) = label.strip_prefix("cpu")
            && let Ok(index) = index.parse::<usize>()
        {
            cores.push((index, parse_cpu_fields(&parts.collect::<Vec<_>>())));
        }
    }
    let aggregate =
        aggregate.ok_or_else(|| "missing aggregate cpu line in /proc/stat".to_string())?;
    cores.sort_by_key(|(index, _)| *index);
    Ok(ParsedCpu {
        model_name: String::new(),
        aggregate,
        cores,
    })
}

fn parse_cpu_fields(fields: &[&str]) -> CpuTimes {
    let value = |index: usize| -> u64 {
        fields
            .get(index)
            .and_then(|text| text.parse().ok())
            .unwrap_or(0)
    };
    CpuTimes {
        user: value(0).saturating_add(value(1)),
        system: value(2)
            .saturating_add(value(5))
            .saturating_add(value(6))
            .saturating_add(value(7)),
        idle: value(3),
        iowait: value(4),
    }
}

fn cpu_percents(previous: CpuTimes, next: CpuTimes) -> (f32, f32, f32, f32) {
    if next.user < previous.user
        || next.system < previous.system
        || next.idle < previous.idle
        || next.iowait < previous.iowait
    {
        return (0.0, 0.0, 0.0, 0.0);
    }
    let user = next.user - previous.user;
    let system = next.system - previous.system;
    let idle = next.idle - previous.idle;
    let iowait = next.iowait - previous.iowait;
    let total = user + system + idle + iowait;
    (
        percent(user + system + iowait, total),
        percent(user, total),
        percent(system, total),
        percent(iowait, total),
    )
}

fn read_psi(root: &Path, buf: &mut String) -> PsiMetrics {
    let cpu_some_pct = if read_into(&root.join("proc/pressure/cpu"), buf) {
        parse_psi(buf).0
    } else {
        0.0
    };
    let (mem_some_pct, mem_full_pct) = if read_into(&root.join("proc/pressure/memory"), buf) {
        parse_psi(buf)
    } else {
        (0.0, 0.0)
    };
    let (io_some_pct, io_full_pct) = if read_into(&root.join("proc/pressure/io"), buf) {
        parse_psi(buf)
    } else {
        (0.0, 0.0)
    };
    PsiMetrics {
        cpu_some_pct,
        mem_some_pct,
        mem_full_pct,
        io_some_pct,
        io_full_pct,
    }
}

fn parse_psi(text: &str) -> (f32, f32) {
    let mut some = 0.0_f32;
    let mut full = 0.0_f32;
    for line in text.lines() {
        let mut parts = line.split_whitespace();
        let Some(kind) = parts.next() else {
            continue;
        };
        let avg10 = parts.find_map(|token| token.strip_prefix("avg10=")?.parse::<f32>().ok());
        if let Some(val) = avg10
            && val.is_finite()
        {
            let pct = val.clamp(0.0, 100.0);
            match kind {
                "some" => some = pct,
                "full" => full = pct,
                _ => {}
            }
        }
    }
    (some, full)
}

fn parse_meminfo(text: &str) -> Result<MemMetrics, String> {
    let mut total_kb = None;
    let mut free_kb = 0_u64;
    let mut available_kb = None;
    let mut buffers_kb = 0_u64;
    let mut cached_kb = 0_u64;
    let mut swap_total_kb = 0_u64;
    let mut swap_free_kb = 0_u64;
    let mut shmem_kb = 0_u64;
    let mut dirty_kb = 0_u64;
    let mut writeback_kb = 0_u64;
    let mut slab_kb = 0_u64;

    for line in text.lines() {
        let Some((label, rest)) = line.split_once(':') else {
            continue;
        };
        let Some(val) = rest
            .split_whitespace()
            .next()
            .and_then(|s| s.parse::<u64>().ok())
        else {
            continue;
        };
        match label.trim() {
            "MemTotal" => total_kb = Some(val),
            "MemFree" => free_kb = val,
            "MemAvailable" => available_kb = Some(val),
            "Buffers" => buffers_kb = val,
            "Cached" => cached_kb = val,
            "SwapTotal" => swap_total_kb = val,
            "SwapFree" => swap_free_kb = val,
            "Shmem" => shmem_kb = val,
            "Dirty" => dirty_kb = val,
            "Writeback" => writeback_kb = val,
            "Slab" => slab_kb = val,
            _ => {}
        }
    }

    let total_kb = total_kb.ok_or_else(|| "MemTotal missing from /proc/meminfo".to_string())?;
    let available_kb = available_kb
        .unwrap_or_else(|| free_kb.saturating_add(buffers_kb).saturating_add(cached_kb));
    let total_bytes = total_kb.saturating_mul(1024);
    let available_bytes = available_kb.saturating_mul(1024);
    let used_bytes = total_bytes.saturating_sub(available_bytes);
    let swap_total_bytes = swap_total_kb.saturating_mul(1024);
    let swap_used_bytes = swap_total_bytes.saturating_sub(swap_free_kb.saturating_mul(1024));
    Ok(MemMetrics {
        total_bytes,
        used_bytes,
        available_bytes,
        cached_bytes: cached_kb.saturating_mul(1024),
        buffers_bytes: buffers_kb.saturating_mul(1024),
        used_pct: percent(used_bytes, total_bytes),
        swap_total_bytes,
        swap_used_bytes,
        swap_pct: percent(swap_used_bytes, swap_total_bytes),
        shared_bytes: shmem_kb.saturating_mul(1024),
        dirty_bytes: dirty_kb.saturating_mul(1024),
        writeback_bytes: writeback_kb.saturating_mul(1024),
        slab_bytes: slab_kb.saturating_mul(1024),
    })
}

fn read_networks(root: &Path) -> Vec<ParsedNet> {
    let Some(text) = read_optional(&root.join("proc/net/dev")) else {
        return Vec::new();
    };
    let mut ifaces = Vec::new();
    for line in text.lines() {
        let Some((name, rest)) = line.split_once(':') else {
            continue;
        };
        let name = name.trim();
        if name.is_empty() || name.contains('|') {
            continue;
        }
        let fields: Vec<&str> = rest.split_whitespace().collect();
        let value = |index: usize| {
            fields
                .get(index)
                .and_then(|text| text.parse().ok())
                .unwrap_or(0)
        };
        ifaces.push(ParsedNet {
            is_loopback: is_loopback(root, name),
            counters: NetCounters {
                rx_bytes: value(0),
                rx_packets: value(1),
                tx_bytes: value(8),
                tx_packets: value(9),
            },
            name: name.to_string(),
        });
    }
    ifaces
}

fn is_loopback(root: &Path, name: &str) -> bool {
    if name == "lo" {
        return true;
    }
    let flags = read_optional(&root.join(format!("sys/class/net/{name}/flags")));
    flags
        .and_then(|text| u32::from_str_radix(text.trim().trim_start_matches("0x"), 16).ok())
        .is_some_and(|flags| flags & 0x8 != 0)
}

fn read_disk_mounts(root: &Path, counters: &HashMap<String, DiskCounters>) -> Vec<CachedMount> {
    let Some(text) = read_optional(&root.join("proc/mounts"))
        .or_else(|| read_optional(&root.join("proc/self/mounts")))
    else {
        return Vec::new();
    };
    let live = root == Path::new("/");
    let mut disks = Vec::new();
    let mut seen_mounts = HashSet::new();
    for line in text.lines() {
        let mut fields = line.split_whitespace();
        let Some(device_raw) = fields.next() else {
            continue;
        };
        let Some(mount_raw) = fields.next() else {
            continue;
        };
        let Some(fs_type) = fields.next() else {
            continue;
        };
        if !is_real_filesystem(fs_type) {
            continue;
        }
        let device_path = unescape_mount(device_raw);
        let mount_point = unescape_mount(mount_raw);
        if !seen_mounts.insert(mount_point.clone()) {
            continue;
        }
        let device = disk_key(root, &device_path, counters);
        let (total_bytes, used_bytes, free_bytes) = if live {
            statvfs_usage(Path::new(&mount_point)).unwrap_or((0, 0, 0))
        } else {
            (0, 0, 0)
        };
        disks.push(CachedMount {
            device,
            mount_point,
            fs_type: fs_type.to_string(),
            total_bytes,
            used_bytes,
            free_bytes,
        });
    }
    disks
}

fn disk_key(root: &Path, device_path: &str, counters: &HashMap<String, DiskCounters>) -> String {
    let base = Path::new(device_path)
        .file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .unwrap_or_else(|| device_path.to_string());
    if counters.contains_key(&base) {
        return base;
    }
    for name in counters.keys() {
        let uevent = root.join(format!("sys/class/block/{name}/uevent"));
        let Some(text) = read_optional(&uevent) else {
            continue;
        };
        for line in text.lines() {
            let Some(devname) = line.strip_prefix("DEVNAME=") else {
                continue;
            };
            let alias = Path::new(devname)
                .file_name()
                .map(|item| item.to_string_lossy().into_owned())
                .unwrap_or_else(|| devname.to_string());
            if alias == base {
                return name.clone();
            }
        }
    }
    base
}

fn read_raw_sockets(root: &Path) -> Vec<RawSocket> {
    const SOURCES: [(&str, &str, bool, bool); 4] = [
        ("proc/net/tcp", "TCP", false, false),
        ("proc/net/tcp6", "TCP6", true, false),
        ("proc/net/udp", "UDP", false, true),
        ("proc/net/udp6", "UDP6", true, true),
    ];
    let mut sockets = Vec::new();
    for (rel_path, proto, ipv6, udp) in SOURCES {
        let Some(text) = read_optional(&root.join(rel_path)) else {
            continue;
        };
        for line in text.lines() {
            if let Some(sock) = parse_proc_net_socket_line(line, proto, ipv6, udp) {
                sockets.push(sock);
            }
        }
    }
    sockets.sort_by(|a, b| {
        socket_priority(&a.entry.state)
            .cmp(&socket_priority(&b.entry.state))
            .then_with(|| a.local_port.cmp(&b.local_port))
            .then_with(|| a.entry.proto.cmp(&b.entry.proto))
            .then_with(|| a.entry.local_addr.cmp(&b.entry.local_addr))
            .then_with(|| a.entry.remote_addr.cmp(&b.entry.remote_addr))
            .then_with(|| a.entry.inode.cmp(&b.entry.inode))
    });
    sockets
}

fn parse_proc_net_socket_line(line: &str, proto: &str, ipv6: bool, udp: bool) -> Option<RawSocket> {
    let mut parts = line.split_whitespace();
    let slot = parts.next()?;
    if !slot.ends_with(':') {
        return None;
    }
    let local_raw = parts.next()?;
    let remote_raw = parts.next()?;
    let state_raw = parts.next()?;
    let inode_raw = parts.nth(5)?;

    let state_code = u8::from_str_radix(state_raw, 16).ok()?;
    let inode = inode_raw.parse::<u64>().ok()?;
    let (local_addr, local_port, _) = decode_socket_endpoint(local_raw, ipv6)?;
    let (remote_fmt, rem_port, rem_unspecified) = decode_socket_endpoint(remote_raw, ipv6)?;
    let remote_addr = if rem_unspecified && rem_port == 0 {
        "*".to_string()
    } else {
        remote_fmt
    };
    let state = socket_state_name(state_code, udp);
    Some(RawSocket {
        local_port,
        entry: NetSocketEntry {
            proto: proto.to_string(),
            local_addr,
            remote_addr,
            state,
            inode,
            pid: None,
            process: String::new(),
        },
    })
}

fn decode_socket_endpoint(raw: &str, ipv6: bool) -> Option<(String, u16, bool)> {
    let (ip_hex, port_hex) = raw.split_once(':')?;
    let port = u16::from_str_radix(port_hex, 16).ok()?;
    if ipv6 {
        if ip_hex.len() != 32 {
            return None;
        }
        let mut octets = [0_u8; 16];
        for (chunk_idx, slot) in octets.as_chunks_mut::<4>().0.iter_mut().enumerate() {
            let start = chunk_idx * 8;
            let word = u32::from_str_radix(&ip_hex[start..start + 8], 16).ok()?;
            *slot = word.to_le_bytes();
        }
        let addr = Ipv6Addr::from(octets);
        Some((format!("[{addr}]:{port}"), port, addr.is_unspecified()))
    } else {
        if ip_hex.len() != 8 {
            return None;
        }
        let word = u32::from_str_radix(ip_hex, 16).ok()?;
        let addr = Ipv4Addr::from(word.to_le_bytes());
        Some((format!("{addr}:{port}"), port, addr.is_unspecified()))
    }
}

fn socket_state_name(st: u8, udp: bool) -> String {
    if udp {
        return match st {
            0x01 => "ESTAB".to_string(),
            0x07 => "UNCONN".to_string(),
            other => tcp_state_name(other),
        };
    }
    tcp_state_name(st)
}

fn tcp_state_name(st: u8) -> String {
    match st {
        0x01 => "ESTAB",
        0x02 => "SYN_SENT",
        0x03 => "SYN_RECV",
        0x04 => "FIN_WAIT1",
        0x05 => "FIN_WAIT2",
        0x06 => "TIME_WAIT",
        0x07 => "CLOSE",
        0x08 => "CLOSE_WAIT",
        0x09 => "LAST_ACK",
        0x0A => "LISTEN",
        0x0B => "CLOSING",
        0x0C => "NEW_SYN_RECV",
        _ => return format!("0x{st:02X}"),
    }
    .to_string()
}

fn socket_priority(state: &str) -> u8 {
    match state {
        "LISTEN" => 0,
        "ESTAB" => 1,
        "UNCONN" => 2,
        _ => 3,
    }
}

fn is_listening_socket(entry: &NetSocketEntry) -> bool {
    entry.state == "LISTEN"
        || (entry.proto.starts_with("UDP") && entry.state == "UNCONN" && entry.remote_addr == "*")
}

fn listening_port_label(entry: &NetSocketEntry) -> String {
    let addr = if let Some(port) = entry.local_addr.strip_prefix("0.0.0.0:") {
        format!("*:{port}")
    } else if let Some(port) = entry.local_addr.strip_prefix("[::]:") {
        format!("*:{port}")
    } else {
        entry.local_addr.clone()
    };
    format!("{} {addr}", entry.proto)
}

fn read_diskstats(root: &Path) -> HashMap<String, DiskCounters> {
    let Some(text) = read_optional(&root.join("proc/diskstats")) else {
        return HashMap::new();
    };
    let mut map = HashMap::new();
    for line in text.lines() {
        let fields: Vec<&str> = line.split_whitespace().collect();
        if fields.len() < 10 {
            continue;
        }
        let name = fields[2].to_string();
        let after = &fields[3..];
        let val = |idx: usize| -> u64 { after.get(idx).and_then(|s| s.parse().ok()).unwrap_or(0) };
        map.insert(
            name,
            DiskCounters {
                reads_completed: val(0),
                sectors_read: val(2),
                read_time_ms: val(3),
                writes_completed: val(4),
                sectors_written: val(6),
                write_time_ms: val(7),
                io_ticks_ms: val(9),
            },
        );
    }
    map
}

fn disk_rates(previous: DiskCounters, next: DiskCounters, dt_secs: f64) -> (f64, f64, f32, f32) {
    let read_bps = per_sec(previous.sectors_read, next.sectors_read, dt_secs) * 512.0;
    let write_bps = per_sec(previous.sectors_written, next.sectors_written, dt_secs) * 512.0;
    let delta_io_ticks_ms = next.io_ticks_ms.saturating_sub(previous.io_ticks_ms);
    let busy_pct = if dt_secs > 0.0 {
        ((delta_io_ticks_ms as f64 / (dt_secs * 1000.0)) * 100.0).clamp(0.0, 100.0) as f32
    } else {
        0.0
    };
    let delta_reads = next
        .reads_completed
        .saturating_sub(previous.reads_completed);
    let delta_writes = next
        .writes_completed
        .saturating_sub(previous.writes_completed);
    let delta_read_ms = next.read_time_ms.saturating_sub(previous.read_time_ms);
    let delta_write_ms = next.write_time_ms.saturating_sub(previous.write_time_ms);
    let delta_ios = delta_reads.saturating_add(delta_writes);
    let delta_rw_ms = delta_read_ms.saturating_add(delta_write_ms);
    let await_ms = if delta_ios > 0 {
        ((delta_rw_ms as f64 / delta_ios as f64).max(0.0)) as f32
    } else {
        0.0
    };
    (read_bps, write_bps, busy_pct, await_ms)
}

fn is_real_filesystem(fs_type: &str) -> bool {
    matches!(
        fs_type,
        "ext2"
            | "ext3"
            | "ext4"
            | "xfs"
            | "btrfs"
            | "vfat"
            | "ntfs"
            | "ntfs3"
            | "zfs"
            | "f2fs"
            | "bcachefs"
            | "exfat"
            | "fuseblk"
            | "erofs"
            | "squashfs"
    )
}

fn unescape_mount(text: &str) -> String {
    let bytes = text.as_bytes();
    let mut decoded = Vec::with_capacity(text.len());
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'\\' && index + 3 < bytes.len() {
            let octal = &text[index + 1..index + 4];
            if let Ok(value) = u8::from_str_radix(octal, 8) {
                decoded.push(value);
                index += 4;
                continue;
            }
        }
        decoded.push(bytes[index]);
        index += 1;
    }
    String::from_utf8_lossy(&decoded).into_owned()
}

fn statvfs_usage(path: &Path) -> Option<(u64, u64, u64)> {
    use std::os::unix::ffi::OsStrExt;
    let c_path = std::ffi::CString::new(path.as_os_str().as_bytes()).ok()?;
    let mut buf = std::mem::MaybeUninit::<libc::statvfs>::uninit();
    // Safety: `c_path` is a NUL-terminated path and `buf` is writable storage
    // that `statvfs` initializes on success before we read it.
    let rc = unsafe { libc::statvfs(c_path.as_ptr(), buf.as_mut_ptr()) };
    if rc != 0 {
        return None;
    }
    let vfs = unsafe { buf.assume_init() };
    let frsize = vfs.f_frsize;
    let total = vfs.f_blocks.saturating_mul(frsize);
    let free_all = vfs.f_bfree.saturating_mul(frsize);
    let available = vfs.f_bavail.saturating_mul(frsize);
    Some((total, total.saturating_sub(free_all), available))
}

fn read_sensors(root: &Path) -> Vec<SensorMetrics> {
    let mut sensors = read_hwmon(root);
    if sensors.is_empty() {
        sensors = read_thermal(root);
    }
    sensors
}

fn read_hwmon(root: &Path) -> Vec<SensorMetrics> {
    let dir = root.join("sys/class/hwmon");
    let mut chips = dir_names(&dir);
    chips.sort();
    let mut sensors = Vec::new();
    for chip in chips {
        let chip_dir = dir.join(&chip);
        let chip_name = read_optional(&chip_dir.join("name"))
            .map(|text| text.trim().to_string())
            .filter(|text| !text.is_empty())
            .unwrap_or(chip);
        let mut inputs: Vec<usize> = fs::read_dir(&chip_dir)
            .ok()
            .into_iter()
            .flatten()
            .filter_map(|entry| entry.ok())
            .filter_map(|entry| {
                let name = entry.file_name().to_string_lossy().into_owned();
                let index = name.strip_prefix("temp")?.strip_suffix("_input")?;
                index.parse().ok()
            })
            .collect();
        inputs.sort_unstable();
        for index in inputs {
            let Some(temp_c) = read_millic(&chip_dir.join(format!("temp{index}_input"))) else {
                continue;
            };
            let label = read_optional(&chip_dir.join(format!("temp{index}_label")))
                .map(|text| text.trim().to_string())
                .filter(|text| !text.is_empty())
                .unwrap_or_else(|| format!("{chip_name} temp{index}"));
            sensors.push(SensorMetrics {
                label,
                temp_c,
                high_c: read_millic(&chip_dir.join(format!("temp{index}_max"))),
                crit_c: read_millic(&chip_dir.join(format!("temp{index}_crit"))),
            });
        }
    }
    sensors
}

fn read_thermal(root: &Path) -> Vec<SensorMetrics> {
    let dir = root.join("sys/class/thermal");
    let mut zones = dir_names(&dir);
    zones.sort();
    let mut sensors = Vec::new();
    for zone in zones {
        if !zone.starts_with("thermal_zone") {
            continue;
        }
        let zone_dir = dir.join(&zone);
        let Some(temp_c) = read_millic(&zone_dir.join("temp")) else {
            continue;
        };
        let label = read_optional(&zone_dir.join("type"))
            .map(|text| text.trim().to_string())
            .filter(|text| !text.is_empty())
            .unwrap_or(zone);
        sensors.push(SensorMetrics {
            label,
            temp_c,
            high_c: None,
            crit_c: None,
        });
    }
    sensors
}

fn read_millic(path: &Path) -> Option<f32> {
    let text = read_optional(path)?;
    let milli: f32 = text.trim().parse().ok()?;
    Some(milli / 1000.0)
}

fn core_temp(sensors: &[SensorMetrics], index: usize) -> Option<f32> {
    let wanted = [
        format!("Core {index}"),
        format!("CPU {index}"),
        format!("cpu{index}"),
    ];
    sensors
        .iter()
        .find(|sensor| {
            wanted
                .iter()
                .any(|label| sensor.label.eq_ignore_ascii_case(label))
        })
        .map(|sensor| sensor.temp_c)
}

fn read_core_freq(root: &Path, index: usize) -> Option<u32> {
    for name in ["scaling_cur_freq", "cpuinfo_cur_freq"] {
        let path = root.join(format!("sys/devices/system/cpu/cpu{index}/cpufreq/{name}"));
        if let Some(text) = read_optional(&path)
            && let Ok(khz) = text.trim().parse::<u32>()
        {
            return Some(khz / 1000);
        }
    }
    None
}

fn read_batteries(root: &Path) -> Vec<BatteryMetrics> {
    let dir = root.join("sys/class/power_supply");
    let mut names = dir_names(&dir);
    names.sort();
    let mut batteries = Vec::new();
    for name in names {
        let supply = dir.join(&name);
        let kind = read_optional(&supply.join("type"))
            .map(|text| text.trim().to_string())
            .unwrap_or_default();
        if !kind.eq_ignore_ascii_case("Battery") && !name.to_ascii_lowercase().starts_with("bat") {
            continue;
        }
        if kind.eq_ignore_ascii_case("Mains") || kind.eq_ignore_ascii_case("USB") {
            continue;
        }
        let capacity_pct = read_optional(&supply.join("capacity"))
            .and_then(|text| text.trim().parse().ok())
            .unwrap_or(0.0);
        let status = read_optional(&supply.join("status"))
            .map(|text| text.trim().to_string())
            .filter(|text| !text.is_empty())
            .unwrap_or_else(|| "Unknown".to_string());
        batteries.push(BatteryMetrics {
            name,
            status,
            capacity_pct,
            power_watts: battery_watts(&supply),
        });
    }
    batteries
}

fn battery_watts(supply: &Path) -> Option<f32> {
    if let Some(microwatts) =
        read_optional(&supply.join("power_now")).and_then(|text| text.trim().parse::<f32>().ok())
    {
        return Some(microwatts.abs() / 1_000_000.0);
    }
    let microvolts: f32 = read_optional(&supply.join("voltage_now"))?
        .trim()
        .parse()
        .ok()?;
    let microamps: f32 = read_optional(&supply.join("current_now"))?
        .trim()
        .parse()
        .ok()?;
    Some((microvolts * microamps).abs() / 1_000_000_000_000.0)
}

struct StatFields {
    name: String,
    state: char,
    ppid: u32,
    is_kernel_thread: bool,
    ticks: u64,
    nice: i32,
    threads: u32,
    start_time: u64,
    /// Virtual size in bytes. Parsed for parity with `/proc/<pid>/stat`; RSS is what we publish.
    #[allow(dead_code)]
    vsize: u64,
    rss_pages: u64,
}

fn parse_stat(text: &str) -> Option<StatFields> {
    let text = text.trim();
    let open = text.find('(')?;
    let close = text.rfind(')')?;
    if close <= open {
        return None;
    }
    let name = text[open + 1..close].to_string();
    let mut rest = text[close + 1..].split_whitespace();
    let state = rest.next()?.chars().next()?;
    let ppid = rest.next()?.parse().ok()?;
    // pgrp, session, tty_nr, tpgid, then flags.
    let flags = rest
        .nth(4)
        .and_then(|text| text.parse::<u32>().ok())
        .unwrap_or(0);
    // minflt, cminflt, majflt, cmajflt, then utime.
    let utime: u64 = rest.nth(4)?.parse().ok()?;
    let stime: u64 = rest.next()?.parse().ok()?;
    // cutime, cstime, priority, then nice (field 19 / index 16 after comm), then num_threads.
    let nice = rest.nth(3).and_then(|text| text.parse().ok()).unwrap_or(0);
    let threads = rest.next().and_then(|text| text.parse().ok()).unwrap_or(1);
    // itrealvalue, then starttime.
    let start_time = rest.nth(1).and_then(|text| text.parse().ok()).unwrap_or(0);
    let vsize = rest.next().and_then(|text| text.parse().ok()).unwrap_or(0);
    let rss_pages = rest.next().and_then(|text| text.parse().ok()).unwrap_or(0);
    Some(StatFields {
        name,
        state,
        ppid,
        is_kernel_thread: flags & PF_KTHREAD != 0,
        ticks: utime.saturating_add(stime),
        nice,
        threads,
        start_time,
        vsize,
        rss_pages,
    })
}

fn proc_pids(root: &Path) -> Vec<u32> {
    let mut pids = Vec::new();
    let Ok(entries) = fs::read_dir(root.join("proc")) else {
        return pids;
    };
    for entry in entries.flatten() {
        let name = entry.file_name();
        let Some(text) = name.to_str() else {
            continue;
        };
        if let Ok(pid) = text.parse::<u32>() {
            pids.push(pid);
        }
    }
    pids.sort_unstable();
    pids
}

fn push_pid(path: &mut PathBuf, pid: u32, buf: &mut [u8; 16]) {
    let mut value = pid;
    let mut index = buf.len();
    if value == 0 {
        buf[buf.len() - 1] = b'0';
        path.push(std::str::from_utf8(&buf[buf.len() - 1..]).unwrap());
        return;
    }
    while value > 0 {
        index -= 1;
        buf[index] = b'0' + (value % 10) as u8;
        value /= 10;
    }
    path.push(std::str::from_utf8(&buf[index..]).unwrap());
}

fn read_into(path: &Path, buf: &mut String) -> bool {
    buf.clear();
    let Ok(mut file) = File::open(path) else {
        return false;
    };
    file.read_to_string(buf).is_ok()
}

fn status_uid(text: &str) -> Option<u32> {
    status_value(text, "Uid").and_then(|text| text.split_whitespace().next()?.parse().ok())
}

fn status_value<'a>(text: &'a str, key: &str) -> Option<&'a str> {
    text.lines().find_map(|line| {
        let (label, rest) = line.split_once(':')?;
        if label.trim() == key {
            Some(rest.trim())
        } else {
            None
        }
    })
}

fn parse_cmdline(bytes: &[u8]) -> String {
    bytes
        .split(|byte| *byte == 0)
        .filter(|part| !part.is_empty())
        .map(|part| String::from_utf8_lossy(part).into_owned())
        .collect::<Vec<_>>()
        .join(" ")
}

fn io_bytes(text: &str) -> (u64, u64) {
    let mut read_bytes = None;
    let mut write_bytes = None;
    for line in text.lines() {
        let Some((label, rest)) = line.split_once(':') else {
            continue;
        };
        match label.trim() {
            "read_bytes" => read_bytes = rest.trim().parse().ok(),
            "write_bytes" => write_bytes = rest.trim().parse().ok(),
            _ => {}
        }
        if read_bytes.is_some() && write_bytes.is_some() {
            break;
        }
    }
    (read_bytes.unwrap_or(0), write_bytes.unwrap_or(0))
}

/// Basename of `argv[0]`, stripping flags, `: ` titles, and directory prefixes.
fn binary_name_from_cmdline(cmdline: &str) -> String {
    let argv0 = cmdline.split_once('\0').map_or(cmdline, |(argv0, _)| argv0);
    let executable = argv0
        .split_once(" -")
        .map_or(argv0, |(executable, _)| executable);
    let executable = executable
        .split_once(':')
        .map_or(executable, |(executable, _)| executable);
    executable
        .rsplit('/')
        .next()
        .unwrap_or(executable)
        .to_string()
}

fn process_name(comm: String, cmdline: &str) -> String {
    if comm.len() >= MAX_STAT_NAME_LEN && !cmdline.is_empty() {
        let derived = binary_name_from_cmdline(cmdline);
        let prefix = comm
            .as_bytes()
            .get(..MAX_STAT_NAME_LEN)
            .unwrap_or(comm.as_bytes());
        if derived.as_bytes().starts_with(prefix) {
            return derived;
        }
    }
    comm
}

struct DedupFd {
    fd: u32,
    count: u32,
    kind: OpenFileKind,
    path: String,
}

struct ProcessDetail {
    fds: Option<u32>,
    socket_inodes: Vec<u64>,
    unit: Option<String>,
    cwd: Option<String>,
    exe: Option<String>,
    open_files: Vec<String>,
    dedup_fds: Vec<DedupFd>,
}

fn proc_open_file_priority(kind: OpenFileKind) -> u8 {
    match kind {
        OpenFileKind::File => 0,
        OpenFileKind::Device => 1,
        OpenFileKind::Socket => 2,
        OpenFileKind::Pipe => 3,
    }
}

fn snapshot_open_file_priority(kind: OpenFileKind) -> u8 {
    match kind {
        OpenFileKind::File => 0,
        OpenFileKind::Socket => 1,
        OpenFileKind::Device => 2,
        OpenFileKind::Pipe => 3,
    }
}

fn build_socket_target_map(raw_sockets: &[RawSocket]) -> HashMap<u64, String> {
    let mut map = HashMap::with_capacity(raw_sockets.len());
    for sock in raw_sockets {
        let entry = &sock.entry;
        if entry.inode > 0 {
            map.entry(entry.inode).or_insert_with(|| {
                format!(
                    "{} {} -> {} ({})",
                    entry.proto, entry.local_addr, entry.remote_addr, entry.state
                )
            });
        }
    }
    map
}

fn classify_fd_target(target: &str) -> Option<OpenFileKind> {
    let trimmed = target.trim();
    if trimmed.is_empty() {
        return None;
    }
    if trimmed.starts_with("socket:[") {
        Some(OpenFileKind::Socket)
    } else if trimmed.starts_with("pipe:[") || trimmed.starts_with("anon_inode:") {
        Some(OpenFileKind::Pipe)
    } else if trimmed.starts_with("/dev/") {
        Some(OpenFileKind::Device)
    } else if trimmed.starts_with('/') {
        Some(OpenFileKind::File)
    } else {
        None
    }
}

fn inspect_process_detail(
    dir: &mut PathBuf,
    buf: &mut String,
    is_kernel_thread: bool,
    socket_targets: &HashMap<u64, String>,
) -> ProcessDetail {
    dir.push("fd");
    let (fds, socket_inodes, mut dedup_fds) = scan_fds_detailed(dir, socket_targets);
    dir.pop();

    dedup_fds.sort_by(|a, b| {
        proc_open_file_priority(a.kind)
            .cmp(&proc_open_file_priority(b.kind))
            .then_with(|| a.fd.cmp(&b.fd))
            .then_with(|| a.path.cmp(&b.path))
    });
    let open_files = dedup_fds
        .iter()
        .take(MAX_PROC_OPEN_FILES)
        .map(|item| item.path.clone())
        .collect();

    dir.push("cgroup");
    let unit = if read_into(dir, buf) {
        parse_cgroup_unit(buf)
    } else {
        None
    };
    dir.pop();

    let (cwd, exe) = if is_kernel_thread {
        (None, None)
    } else {
        dir.push("cwd");
        let cwd = read_link_string(dir);
        dir.pop();
        dir.push("exe");
        let exe = read_link_string(dir);
        dir.pop();
        (cwd, exe)
    };

    ProcessDetail {
        fds,
        socket_inodes,
        unit,
        cwd,
        exe,
        open_files,
        dedup_fds,
    }
}

fn append_open_file_entries(
    out: &mut Vec<OpenFileEntry>,
    pid: u32,
    process: &str,
    user: &str,
    dedup_fds: Vec<DedupFd>,
) {
    out.reserve(dedup_fds.len());
    for item in dedup_fds {
        out.push(OpenFileEntry {
            pid,
            process: process.to_string(),
            user: user.to_string(),
            fd: item.fd,
            count: item.count,
            kind: item.kind,
            path: item.path,
        });
    }
}

fn scan_fds(path: &Path) -> (Option<u32>, Vec<u64>) {
    let empty = HashMap::new();
    let (fds, socket_inodes, _) = scan_fds_detailed(path, &empty);
    (fds, socket_inodes)
}

fn scan_fds_detailed(
    path: &Path,
    socket_targets: &HashMap<u64, String>,
) -> (Option<u32>, Vec<u64>, Vec<DedupFd>) {
    let Ok(entries) = fs::read_dir(path) else {
        return (None, Vec::new(), Vec::new());
    };
    let mut count: usize = 0;
    let mut socket_inodes = Vec::new();
    let mut dedup: HashMap<(OpenFileKind, String), (u32, u32)> = HashMap::new();
    for entry in entries.flatten() {
        count += 1;
        let fd_num = entry
            .file_name()
            .to_str()
            .and_then(|s| s.parse::<u32>().ok())
            .unwrap_or(0);
        let Ok(target) = fs::read_link(entry.path()) else {
            continue;
        };
        let raw = target.to_string_lossy();
        let trimmed = raw.trim();
        let Some(kind) = classify_fd_target(trimmed) else {
            continue;
        };
        let resolved = if kind == OpenFileKind::Socket {
            if let Some(inode) = parse_socket_link(trimmed) {
                socket_inodes.push(inode);
                socket_targets
                    .get(&inode)
                    .cloned()
                    .unwrap_or_else(|| trimmed.to_string())
            } else {
                trimmed.to_string()
            }
        } else {
            trimmed.to_string()
        };
        dedup
            .entry((kind, resolved))
            .and_modify(|(min_fd, cnt)| {
                if fd_num < *min_fd {
                    *min_fd = fd_num;
                }
                *cnt = cnt.saturating_add(1);
            })
            .or_insert((fd_num, 1));
    }
    let items = dedup
        .into_iter()
        .map(|((kind, path), (fd, cnt))| DedupFd {
            fd,
            count: cnt,
            kind,
            path,
        })
        .collect();
    (u32::try_from(count).ok(), socket_inodes, items)
}

fn parse_socket_link(target: &str) -> Option<u64> {
    let inner = target.trim().strip_prefix("socket:[")?.strip_suffix(']')?;
    let inode: u64 = inner.parse().ok()?;
    (inode > 0).then_some(inode)
}

fn read_link_string(path: &Path) -> Option<String> {
    let target = fs::read_link(path).ok()?;
    let text = target.to_string_lossy();
    let trimmed = text.trim();
    (!trimmed.is_empty()).then(|| trimmed.to_string())
}

fn parse_cgroup_unit(text: &str) -> Option<String> {
    let mut fallback = None;
    for line in text.lines() {
        let mut parts = line.splitn(3, ':');
        let Some(hier) = parts.next() else {
            continue;
        };
        let Some(controllers) = parts.next() else {
            continue;
        };
        let Some(cgroup_path) = parts.next() else {
            continue;
        };
        let Some(unit) = cgroup_path.trim().rsplit('/').find(|seg| {
            !seg.is_empty()
                && (seg.ends_with(".service") || seg.ends_with(".scope") || seg.ends_with(".slice"))
        }) else {
            continue;
        };
        if hier == "0" || controllers.split(',').any(|ctrl| ctrl == "name=systemd") {
            return Some(unit.to_string());
        }
        if fallback.is_none() {
            fallback = Some(unit.to_string());
        }
    }
    fallback
}

fn load_users(root: &Path) -> HashMap<u32, String> {
    let preferred = root.join("etc/passwd");
    let path = if preferred.exists() {
        preferred
    } else if root == Path::new("/") {
        PathBuf::from("/etc/passwd")
    } else {
        return HashMap::new();
    };
    let Some(text) = read_optional(&path) else {
        return HashMap::new();
    };
    let mut users = HashMap::new();
    for line in text.lines() {
        let mut fields = line.split(':');
        let Some(name) = fields.next() else {
            continue;
        };
        let Some(uid) = fields.nth(1).and_then(|text| text.parse().ok()) else {
            continue;
        };
        users.entry(uid).or_insert_with(|| name.to_string());
    }
    users
}

fn read_cpu_model(root: &Path, core_count: usize) -> String {
    if let Some(text) = read_optional(&root.join("proc/cpuinfo")) {
        for key in ["model name", "Model", "Hardware", "Processor"] {
            if let Some(value) = cpuinfo_value(&text, key) {
                return value;
            }
        }
    }
    let core_count_or_unknown = if core_count == 0 {
        "unknown".to_string()
    } else {
        core_count.to_string()
    };
    format!("{} ({core_count_or_unknown} cores)", std::env::consts::ARCH)
}

fn cpuinfo_value(text: &str, key: &str) -> Option<String> {
    let skip_numeric_processor = key.eq_ignore_ascii_case("processor");
    text.lines().find_map(|line| {
        let (label, rest) = line.split_once(':')?;
        if !label.trim().eq_ignore_ascii_case(key) {
            return None;
        }
        let value = rest.trim();
        if value.is_empty()
            || (skip_numeric_processor && value.bytes().all(|byte| byte.is_ascii_digit()))
        {
            return None;
        }
        Some(value.to_string())
    })
}

fn dir_names(path: &Path) -> Vec<String> {
    fs::read_dir(path)
        .ok()
        .into_iter()
        .flatten()
        .filter_map(|entry| entry.ok())
        .map(|entry| entry.file_name().to_string_lossy().into_owned())
        .collect()
}

fn page_size() -> u64 {
    // Safety: querying the page size does not touch caller memory.
    let size = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
    u64::try_from(size).unwrap_or(4096).max(1)
}

fn percent(part: u64, total: u64) -> f32 {
    if total == 0 {
        0.0
    } else {
        (part as f64 / total as f64 * 100.0) as f32
    }
}

fn per_sec(previous: u64, next: u64, dt: f64) -> f64 {
    if dt <= 0.0 || next < previous {
        0.0
    } else {
        (next - previous) as f64 / dt
    }
}

fn unix_timestamp() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_secs_f64())
        .unwrap_or(0.0)
}

/// Line-delimited request from the unprivileged monitor to the collector helper.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum HelperRequest {
    Sample {
        pane: PaneId,
        selected_pid: Option<u32>,
    },
    Kill {
        pid: u32,
        signal: SignalKind,
    },
    Renice {
        pid: u32,
        delta: i32,
    },
    Exit,
}

/// One JSON line written by the collector helper.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", content = "data", rename_all = "snake_case")]
pub enum HelperResponse {
    Snapshot(Box<SystemSnapshot>),
    Error {
        message: String,
    },
    KillResult {
        ok: bool,
        error: Option<String>,
    },
    ReniceResult {
        ok: bool,
        new_nice: Option<i32>,
        error: Option<String>,
    },
}

/// Why `pkexec` or the helper exited before the ready handshake.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HelperStartError {
    pub exit_code: Option<i32>,
    pub message: String,
}

impl std::fmt::Display for HelperStartError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str(&self.message)
    }
}

/// Privileged sampler started with `--collector-helper`.
///
/// The process writes a ready handshake, then answers line-delimited JSON
/// requests on stdin with one JSON line on stdout. EOF or `Exit` ends it.
pub fn run_collector_helper() {
    let mut args = std::env::args().skip(1);
    let root = match args.next().as_deref() {
        Some("--collector-helper-root") => args.next(),
        _ => None,
    };
    let mut collector = match root {
        Some(path) => LinuxCollector::with_root(path),
        None => LinuxCollector::new(),
    };
    let stdout = std::io::stdout();
    let mut writer = BufWriter::new(stdout.lock());
    // Safety: `geteuid` only reads the process credential.
    let euid = unsafe { libc::geteuid() };
    if write_ready(&mut writer, euid).is_err() {
        return;
    }
    let stdin = std::io::stdin();
    let mut reader = BufReader::new(stdin.lock());
    serve_collector(&mut collector, &mut reader, &mut writer);
}

fn write_ready(writer: &mut impl Write, euid: u32) -> Result<(), String> {
    #[derive(Serialize)]
    struct Ready<'a> {
        #[serde(rename = "type")]
        kind: &'a str,
        euid: u32,
    }
    write_json_line(
        writer,
        &Ready {
            kind: "ready",
            euid,
        },
    )
}

fn serve_collector(
    collector: &mut LinuxCollector,
    reader: &mut impl BufRead,
    writer: &mut impl Write,
) {
    let mut line = String::new();
    loop {
        line.clear();
        match reader.read_line(&mut line) {
            Ok(0) => return,
            Ok(_) => {
                let trimmed = line.trim();
                if trimmed.is_empty() {
                    continue;
                }
                match serde_json::from_str::<HelperRequest>(trimmed) {
                    Err(err) => {
                        let _ = write_json_line(
                            writer,
                            &HelperResponse::Error {
                                message: err.to_string(),
                            },
                        );
                    }
                    Ok(HelperRequest::Exit) => return,
                    Ok(HelperRequest::Sample { pane, selected_pid }) => {
                        let response = match collector.sample_for(pane, selected_pid) {
                            Ok(snapshot) => HelperResponse::Snapshot(Box::new(snapshot)),
                            Err(message) => HelperResponse::Error { message },
                        };
                        if write_json_line(writer, &response).is_err() {
                            return;
                        }
                    }
                    Ok(HelperRequest::Kill { pid, signal }) => {
                        if write_json_line(writer, &perform_helper_kill(pid, signal)).is_err() {
                            return;
                        }
                    }
                    Ok(HelperRequest::Renice { pid, delta }) => {
                        if write_json_line(writer, &perform_helper_renice(pid, delta)).is_err() {
                            return;
                        }
                    }
                }
            }
            Err(err) => {
                let _ = write_json_line(
                    writer,
                    &HelperResponse::Error {
                        message: err.to_string(),
                    },
                );
                return;
            }
        }
    }
}

fn perform_helper_kill(pid: u32, signal: SignalKind) -> HelperResponse {
    let Ok(raw_pid) = i32::try_from(pid) else {
        return HelperResponse::KillResult {
            ok: false,
            error: Some(format!("pid {pid} is outside the range libc::kill accepts")),
        };
    };
    if raw_pid <= 1 {
        return HelperResponse::KillResult {
            ok: false,
            error: Some(format!("refusing to signal pid {raw_pid}")),
        };
    }
    // Safety: `raw_pid` is a positive process id other than init, and
    // `libc_signum` is one of the four fixed Linux signals this dialog sends.
    let rc = unsafe { libc::kill(raw_pid, signal.libc_signum()) };
    if rc == 0 {
        HelperResponse::KillResult {
            ok: true,
            error: None,
        }
    } else {
        HelperResponse::KillResult {
            ok: false,
            error: Some(Error::last_os_error().to_string()),
        }
    }
}

fn perform_helper_renice(pid: u32, delta: i32) -> HelperResponse {
    match renice_process(pid, delta) {
        Ok(nice) => HelperResponse::ReniceResult {
            ok: true,
            new_nice: Some(nice),
            error: None,
        },
        Err(err) => HelperResponse::ReniceResult {
            ok: false,
            new_nice: None,
            error: Some(err),
        },
    }
}

fn write_json_line(writer: &mut impl Write, value: &impl Serialize) -> Result<(), String> {
    serde_json::to_writer(&mut *writer, value).map_err(|err| err.to_string())?;
    writer.write_all(b"\n").map_err(|err| err.to_string())?;
    writer.flush().map_err(|err| err.to_string())
}

/// How long to poll `try_wait` after closing the helper's stdin, then again
/// after a same-uid `SIGKILL`. A root helper cannot be signalled (`EPERM`).
const HELPER_REAP_WAIT: Duration = Duration::from_millis(200);

/// Connected `--collector-helper` child.
///
/// Drop writes `Exit` and closes stdin before it waits. Once `pkexec` has
/// `setreuid`'d the helper to root, `SIGKILL` from this process returns
/// `EPERM`, so the open stdin pipe is what lets the child leave `read_line`.
pub struct HelperClient {
    child: Child,
    stdin: Option<BufWriter<ChildStdin>>,
    stdout: Option<BufReader<ChildStdout>>,
    stderr_thread: Option<JoinHandle<String>>,
    reaped: bool,
    /// `stop_and_reap` has already run. Drop must not wait a second time.
    released: bool,
    #[cfg(test)]
    sigkill_allowed: bool,
    #[cfg(test)]
    reaped_status: Option<Arc<std::sync::Mutex<Option<ExitStatus>>>>,
}

impl std::fmt::Debug for HelperClient {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("HelperClient")
            .field("pid", &self.child.id())
            .field("reaped", &self.reaped)
            .finish()
    }
}

impl HelperClient {
    pub fn spawn(command: Command) -> Result<Self, HelperStartError> {
        Self::spawn_with(command, |_| {})
    }

    /// `on_start` runs after `spawn` returns the pid, before the handshake is read.
    /// The callback can record the pid so another thread can cancel the dialog.
    pub fn spawn_with(
        mut command: Command,
        on_start: impl FnOnce(u32),
    ) -> Result<Self, HelperStartError> {
        command
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .process_group(0);
        let mut child = command.spawn().map_err(|err| HelperStartError {
            exit_code: None,
            message: format!("failed to start elevation helper: {err}"),
        })?;
        on_start(child.id());
        let stderr = child.stderr.take();
        let stderr_thread = thread::spawn(move || drain_stderr(stderr));
        let Some(stdout) = child.stdout.take() else {
            return Err(failed_stdio(&mut child, stderr_thread, "stdout"));
        };
        let Some(stdin) = child.stdin.take() else {
            return Err(failed_stdio(&mut child, stderr_thread, "stdin"));
        };
        let mut stdout = BufReader::new(stdout);
        let mut line = String::new();
        let read = stdout.read_line(&mut line);
        let ready = matches!(read, Ok(n) if n > 0 && handshake_euid(&line).is_some());
        if ready {
            return Ok(Self {
                child,
                stdin: Some(BufWriter::new(stdin)),
                stdout: Some(stdout),
                stderr_thread: Some(stderr_thread),
                reaped: false,
                released: false,
                #[cfg(test)]
                sigkill_allowed: true,
                #[cfg(test)]
                reaped_status: None,
            });
        }
        let status = terminate_child(&mut child);
        let stderr_text = stderr_thread.join().unwrap_or_default();
        Err(start_error(status, &stderr_text, &line, read.err()))
    }

    pub fn pid(&self) -> u32 {
        self.child.id()
    }

    pub fn sample_for(
        &mut self,
        pane: PaneId,
        selected_pid: Option<u32>,
    ) -> Result<SystemSnapshot, String> {
        self.send(&HelperRequest::Sample { pane, selected_pid })?;
        match self.recv()? {
            HelperResponse::Snapshot(snapshot) => Ok(*snapshot),
            HelperResponse::Error { message } => Err(message),
            HelperResponse::KillResult { .. } => {
                Err("helper returned a kill result for a sample request".to_string())
            }
            HelperResponse::ReniceResult { .. } => {
                Err("helper returned a renice result for a sample request".to_string())
            }
        }
    }

    pub fn send_signal(&mut self, pid: u32, signal: SignalKind) -> Result<(), String> {
        self.send(&HelperRequest::Kill { pid, signal })?;
        match self.recv()? {
            HelperResponse::KillResult { ok: true, .. } => Ok(()),
            HelperResponse::KillResult { ok: false, error } => {
                Err(error.unwrap_or_else(|| format!("failed to signal pid {pid}")))
            }
            HelperResponse::Error { message } => Err(message),
            HelperResponse::Snapshot(_) => {
                Err("helper returned a snapshot for a kill request".to_string())
            }
            HelperResponse::ReniceResult { .. } => {
                Err("helper returned a renice result for a kill request".to_string())
            }
        }
    }

    pub fn renice_process(&mut self, pid: u32, delta: i32) -> Result<i32, String> {
        self.send(&HelperRequest::Renice { pid, delta })?;
        match self.recv()? {
            HelperResponse::ReniceResult {
                ok: true,
                new_nice: Some(nice),
                ..
            } => Ok(nice),
            HelperResponse::ReniceResult {
                ok: true,
                new_nice: None,
                ..
            } => Err(format!(
                "helper reniced pid {pid} without reporting new nice"
            )),
            HelperResponse::ReniceResult {
                ok: false, error, ..
            } => Err(error.unwrap_or_else(|| format!("failed to renice pid {pid}"))),
            HelperResponse::Error { message } => Err(message),
            HelperResponse::Snapshot(_) => {
                Err("helper returned a snapshot for a renice request".to_string())
            }
            HelperResponse::KillResult { .. } => {
                Err("helper returned a kill result for a renice request".to_string())
            }
        }
    }

    /// Asks the helper to exit, then waits so the status is the helper's own exit code.
    pub fn shutdown(mut self) -> Result<ExitStatus, String> {
        self.stop_and_reap()
    }

    fn send(&mut self, request: &HelperRequest) -> Result<(), String> {
        let Some(stdin) = self.stdin.as_mut() else {
            return Err("helper stdin is closed".to_string());
        };
        write_json_line(stdin, request)
    }

    fn recv(&mut self) -> Result<HelperResponse, String> {
        let Some(stdout) = self.stdout.as_mut() else {
            return Err("helper stdout is closed".to_string());
        };
        let mut line = String::new();
        match stdout.read_line(&mut line) {
            Ok(0) => Err("helper closed stdout".to_string()),
            Ok(_) => serde_json::from_str(line.trim()).map_err(|err| err.to_string()),
            Err(err) => Err(err.to_string()),
        }
    }

    /// Write `Exit`, close stdin, then poll. `SIGKILL` is only a fallback for a
    /// same-uid child that is still alive. Closing the pipe is what stops a
    /// root helper: this process cannot signal it after `setreuid(0, 0)`.
    fn stop_and_reap(&mut self) -> Result<ExitStatus, String> {
        if self.reaped {
            return Err("helper already reaped".to_string());
        }
        if self.released {
            return Err("helper did not exit after stdin closed".to_string());
        }
        self.released = true;
        self.close_stdin();
        if let Some(status) = self.poll_exit(HELPER_REAP_WAIT) {
            self.note_reap(status);
            self.finish_stdio();
            return Ok(status);
        }
        if self.sigkill_allowed()
            && kill_process_group(self.child.id())
            && let Some(status) = self.poll_exit(HELPER_REAP_WAIT)
        {
            self.note_reap(status);
            self.finish_stdio();
            return Ok(status);
        }
        if let Ok(Some(status)) = self.child.try_wait() {
            self.reaped = true;
            self.note_reap(status);
            self.finish_stdio();
            return Ok(status);
        }
        // The child is still running (a root helper inside `sample_for` ignores
        // SIGKILL). Reap it off this thread so Drop cannot block, and so the
        // process does not stay a zombie after it finishes and exits.
        reap_detached(self.child.id());
        self.finish_stdio();
        Err("helper did not exit after stdin closed".to_string())
    }

    fn close_stdin(&mut self) {
        let Some(mut stdin) = self.stdin.take() else {
            return;
        };
        let _ = write_json_line(&mut stdin, &HelperRequest::Exit);
        drop(stdin);
    }

    fn poll_exit(&mut self, budget: Duration) -> Option<ExitStatus> {
        let start = Instant::now();
        loop {
            match self.child.try_wait() {
                Ok(Some(status)) => {
                    self.reaped = true;
                    return Some(status);
                }
                Ok(None) if start.elapsed() >= budget => return None,
                Ok(None) => thread::sleep(Duration::from_millis(10)),
                Err(_) => return None,
            }
        }
    }

    fn finish_stdio(&mut self) {
        drop(self.stdout.take());
        let Some(thread) = self.stderr_thread.take() else {
            return;
        };
        if self.reaped {
            let _ = thread.join();
        }
    }

    fn note_reap(&self, status: ExitStatus) {
        #[cfg(test)]
        if let Some(slot) = &self.reaped_status {
            *slot.lock().unwrap_or_else(|err| err.into_inner()) = Some(status);
        }
        #[cfg(not(test))]
        let _ = status;
    }

    fn sigkill_allowed(&self) -> bool {
        #[cfg(test)]
        {
            self.sigkill_allowed
        }
        #[cfg(not(test))]
        {
            true
        }
    }
}

impl Drop for HelperClient {
    fn drop(&mut self) {
        if !self.reaped && !self.released {
            let _ = self.stop_and_reap();
        }
    }
}

pub(crate) fn kill_process_group(pid: u32) -> bool {
    let Ok(pid) = i32::try_from(pid) else {
        return false;
    };
    if pid <= 0 {
        return false;
    }
    // Safety: `pid` is a process this program spawned into its own process group.
    // This fails with EPERM once pkexec has setreuid'd that process to root.
    // Pre-ready cancellation still uses it; a connected helper is stopped by
    // closing its stdin.
    let group = unsafe { libc::kill(-pid, libc::SIGKILL) };
    let one = unsafe { libc::kill(pid, libc::SIGKILL) };
    group == 0 || one == 0
}

fn reap_detached(pid: u32) {
    let _ = thread::spawn(move || {
        let Ok(pid) = i32::try_from(pid) else {
            return;
        };
        if pid <= 0 {
            return;
        }
        // Safety: `pid` is a child this process spawned and has not reaped.
        // Any thread in the parent may wait on it.
        unsafe {
            libc::waitpid(pid, std::ptr::null_mut(), 0);
        }
    });
}

fn failed_stdio(
    child: &mut Child,
    stderr_thread: JoinHandle<String>,
    which: &str,
) -> HelperStartError {
    let status = terminate_child(child);
    let stderr_text = stderr_thread.join().unwrap_or_default();
    let mut message = format!("elevation helper {which} was not piped");
    if !stderr_text.is_empty() {
        message.push_str(": ");
        message.push_str(&stderr_text);
    }
    HelperStartError {
        exit_code: status.and_then(|status| status.code()),
        message,
    }
}

fn terminate_child(child: &mut Child) -> Option<ExitStatus> {
    let _ = kill_process_group(child.id());
    let _ = child.kill();
    child.wait().ok()
}

fn handshake_euid(line: &str) -> Option<u32> {
    let value: serde_json::Value = serde_json::from_str(line.trim()).ok()?;
    if value.get("type")?.as_str()? != "ready" {
        return None;
    }
    u32::try_from(value.get("euid")?.as_u64()?).ok()
}

fn start_error(
    status: Option<ExitStatus>,
    stderr_text: &str,
    line: &str,
    read_error: Option<Error>,
) -> HelperStartError {
    let exit_code = status.and_then(|status| status.code());
    let mut message = match exit_code {
        Some(126) => "authentication cancelled".to_string(),
        Some(127) => "authorization failed or no Polkit agent is available".to_string(),
        Some(code) => format!("helper exited before ready (exit {code})"),
        None if status.is_some() => "helper terminated by a signal before ready".to_string(),
        None => match read_error {
            Some(err) => format!("failed to read helper handshake: {err}"),
            None => "helper closed stdout before ready".to_string(),
        },
    };
    let detail = stderr_text.trim();
    if !detail.is_empty() {
        message.push_str(": ");
        message.push_str(detail);
    } else if !line.trim().is_empty() && handshake_euid(line).is_none() {
        message.push_str(": ");
        message.push_str(line.trim());
    }
    HelperStartError { exit_code, message }
}

fn drain_stderr(stderr: Option<ChildStderr>) -> String {
    let Some(mut stderr) = stderr else {
        return String::new();
    };
    let mut buf = [0u8; 512];
    let mut out = Vec::new();
    loop {
        match stderr.read(&mut buf) {
            Ok(0) | Err(_) => break,
            Ok(n) => {
                if out.len() < 400 {
                    let room = 400 - out.len();
                    out.extend_from_slice(&buf[..n.min(room)]);
                }
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// `target/debug/vitals` (falling back to `btm-rune`), used by helper protocol tests.
#[cfg(test)]
pub(crate) fn helper_binary() -> PathBuf {
    for key in ["CARGO_BIN_EXE_vitals", "CARGO_BIN_EXE_btm-rune"] {
        if let Ok(path) = std::env::var(key) {
            let candidate = PathBuf::from(path);
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    let mut dir = std::env::current_exe().expect("current test executable");
    dir.pop();
    if dir.file_name().is_some_and(|name| name == "deps") {
        dir.pop();
    }
    resolve_helper_binary_in(&dir)
}

#[cfg(test)]
fn resolve_helper_binary_in(dir: &Path) -> PathBuf {
    let vitals = dir.join("vitals");
    if vitals.is_file() {
        return vitals;
    }
    let legacy = dir.join("btm-rune");
    if legacy.is_file() {
        return legacy;
    }
    vitals
}

#[cfg(test)]
mod tests {
    use super::*;

    fn write_file(path: &Path, body: &str) {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).unwrap();
        }
        fs::write(path, body).unwrap();
    }

    fn stat_line(pid: u32, comm: &str, state: char, ppid: u32, utime: u64, stime: u64) -> String {
        format!(
            "{pid} ({comm}) {state} {ppid} {pid} {pid} 0 -1 0 0 0 0 0 {utime} {stime} 0 0 20 0 4 0 0 0 {pid}"
        )
    }

    fn install_sample(
        root: &Path,
        uptime: &str,
        cpu: &str,
        net: &str,
        disk: &str,
        proc_stat: &str,
        io: &str,
    ) {
        write_file(&root.join("proc/uptime"), uptime);
        write_file(&root.join("proc/stat"), cpu);
        write_file(
            &root.join("proc/meminfo"),
            "\
MemTotal:       16384000 kB
MemFree:         1000000 kB
MemAvailable:    8192000 kB
Buffers:          102400 kB
Cached:          2048000 kB
SwapTotal:       8192000 kB
SwapFree:        4096000 kB
",
        );
        write_file(&root.join("proc/loadavg"), "0.50 0.25 0.10 1/2 999\n");
        write_file(&root.join("proc/cpuinfo"), "model name : Test CPU\n");
        write_file(&root.join("proc/sys/kernel/hostname"), "fixture-host\n");
        write_file(&root.join("proc/sys/kernel/osrelease"), "6.12.0-test\n");
        write_file(&root.join("proc/net/dev"), net);
        write_file(&root.join("proc/diskstats"), disk);
        write_file(
            &root.join("proc/mounts"),
            "/dev/nvme0n1p2 / ext4 rw,relatime 0 0\n/dev/sda1 /home ext4 rw,relatime 0 0\nproc /proc proc rw 0 0\n",
        );
        write_file(
            &root.join("etc/passwd"),
            "tester:x:1000:1000::/home/tester:/bin/sh\n",
        );
        write_file(&root.join("proc/4242/stat"), proc_stat);
        write_file(
            &root.join("proc/4242/status"),
            "\
Name:\tmy proc
State:\tS (sleeping)
PPid:\t1
Uid:\t1000\t1000\t1000\t1000
VmRSS:\t1024 kB
Threads:\t4
",
        );
        write_file(&root.join("proc/4242/cmdline"), "myapp\0--serve\0");
        write_file(&root.join("proc/4242/io"), io);
        write_file(&root.join("proc/4242/fd/0"), "");
        write_file(&root.join("proc/4242/fd/1"), "");
        write_file(&root.join("proc/4242/fd/2"), "");
        write_file(
            &root.join("sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"),
            "2400000\n",
        );
        write_file(
            &root.join("sys/devices/system/cpu/cpu1/cpufreq/scaling_cur_freq"),
            "1800000\n",
        );
        write_file(&root.join("sys/class/hwmon/hwmon0/name"), "k10temp\n");
        write_file(&root.join("sys/class/hwmon/hwmon0/temp1_input"), "45000\n");
        write_file(
            &root.join("sys/class/hwmon/hwmon0/temp1_label"),
            "Package id 0\n",
        );
        write_file(&root.join("sys/class/hwmon/hwmon0/temp1_max"), "90000\n");
        write_file(&root.join("sys/class/hwmon/hwmon0/temp1_crit"), "100000\n");
        write_file(&root.join("sys/class/hwmon/hwmon0/temp2_input"), "47000\n");
        write_file(&root.join("sys/class/hwmon/hwmon0/temp2_label"), "Core 0\n");
        write_file(&root.join("sys/class/power_supply/BAT0/type"), "Battery\n");
        write_file(&root.join("sys/class/power_supply/BAT0/capacity"), "73\n");
        write_file(
            &root.join("sys/class/power_supply/BAT0/status"),
            "Discharging\n",
        );
        write_file(
            &root.join("sys/class/power_supply/BAT0/power_now"),
            "12500000\n",
        );
        write_file(&root.join("sys/class/net/lo/flags"), "0x9\n");
    }

    const CPU_A: &str = "\
cpu  100 0 100 100 100 0 0 0 0 0
cpu0 40 0 40 40 40 0 0 0 0 0
cpu1 60 0 60 60 60 0 0 0 0 0
";
    const CPU_B: &str = "\
cpu  150 0 130 200 120 0 0 0 0 0
cpu0 65 0 55 90 50 0 0 0 0 0
cpu1 85 0 75 110 70 0 0 0 0 0
";

    const NET_A: &str = "\
Inter-|   Receive                                                |  Transmit
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
    lo: 50 5 0 0 0 0 0 0 20 2 0 0 0 0 0 0
  eth0: 1000 10 0 0 0 0 0 0 100 4 0 0 0 0 0 0
 wlan0: 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
";
    const NET_B: &str = "\
Inter-|   Receive                                                |  Transmit
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
    lo: 90 9 0 0 0 0 0 0 40 4 0 0 0 0 0 0
  eth0: 5000 30 0 0 0 0 0 0 4100 14 0 0 0 0 0 0
 wlan0: 2000 8 0 0 0 0 0 0 500 2 0 0 0 0 0 0
";

    const DISK_A: &str = "\
 259       2 nvme0n1p2 10 0 100 0 20 0 50 0 0 0 0 0 0 0 0
   8       1 sda1 4 0 10 0 4 0 8 0 0 0 0 0 0 0 0
";
    const DISK_B: &str = "\
 259       2 nvme0n1p2 14 0 104 0 28 0 58 0 0 0 0 0 0 0 0
   8       1 sda1 6 0 14 0 6 0 16 0 0 0 0 0 0 0 0
";

    #[test]
    fn fake_proc_deltas_meminfo_netdev_and_processes() {
        let temp = tempfile::tempdir().unwrap();
        let root = temp.path();
        install_sample(
            root,
            "100.00 0.00\n",
            CPU_A,
            NET_A,
            DISK_A,
            &stat_line(4242, "my proc", 'S', 1, 10, 0),
            "read_bytes: 1000\nwrite_bytes: 0\n",
        );
        let mut collector = LinuxCollector::with_root(root);
        let first = collector.sample().unwrap();
        assert_eq!(first.hostname, "fixture-host");
        assert_eq!(first.kernel, "6.12.0-test");
        assert_eq!(first.cpu.total_usage_pct, 0.0);
        assert_eq!(first.cpu.model_name, "Test CPU");
        assert_eq!(first.cpu.cores.len(), 2);
        assert_eq!(first.cpu.cores[0].freq_mhz, Some(2400));
        assert_eq!(first.cpu.cores[0].temp_c, Some(47.0));
        assert_eq!(first.cpu.cores[1].temp_c, None);
        assert_eq!(first.cpu.load_avg, [0.5, 0.25, 0.1]);
        assert_eq!(first.mem.total_bytes, 16_384_000 * 1024);
        assert_eq!(first.mem.available_bytes, 8_192_000 * 1024);
        assert_eq!(first.mem.used_bytes, 8_192_000 * 1024);
        assert_eq!(first.mem.used_pct, 50.0);
        assert_eq!(first.mem.buffers_bytes, 102_400 * 1024);
        assert_eq!(first.mem.cached_bytes, 2_048_000 * 1024);
        assert_eq!(first.mem.swap_used_bytes, 4_096_000 * 1024);
        assert_eq!(first.mem.swap_pct, 50.0);
        assert_eq!(first.net_rx_total_bps, 0.0);
        assert!(first.networks.iter().any(|iface| iface.is_loopback));
        assert_eq!(first.disks.len(), 2);
        assert_eq!(first.disks[0].read_bytes_per_sec, 0.0);
        assert_eq!(first.sensors[0].label, "Package id 0");
        assert_eq!(first.sensors[0].temp_c, 45.0);
        assert_eq!(first.sensors[0].high_c, Some(90.0));
        assert_eq!(first.sensors[0].crit_c, Some(100.0));
        assert_eq!(first.batteries[0].name, "BAT0");
        assert_eq!(first.batteries[0].capacity_pct, 73.0);
        assert_eq!(first.batteries[0].power_watts, Some(12.5));
        assert_eq!(first.processes.len(), 1);
        assert_eq!(first.processes[0].name, "my proc");
        assert_eq!(first.processes[0].cmdline, "myapp --serve");
        assert_eq!(first.processes[0].user, "tester");
        assert_eq!(first.processes[0].mem_bytes, 1024 * 1024);
        assert_eq!(first.processes[0].threads, 4);
        assert_eq!(first.processes[0].fds, Some(3));
        assert_eq!(first.processes[0].cpu_pct, 0.0);
        assert_eq!(first.cpu.tasks_total, 1);
        assert_eq!(first.cpu.tasks_running, 0);

        install_sample(
            root,
            "102.00 0.00\n",
            CPU_B,
            NET_B,
            DISK_B,
            &stat_line(4242, "my proc", 'R', 1, 20, 0),
            "read_bytes: 5000\nwrite_bytes: 1000\n",
        );
        let second = collector.sample().unwrap();
        assert_eq!(second.cpu.total_usage_pct, 50.0);
        assert_eq!(second.cpu.user_pct, 25.0);
        assert_eq!(second.cpu.system_pct, 15.0);
        assert_eq!(second.cpu.iowait_pct, 10.0);
        assert_eq!(second.cpu.cores[0].usage_pct, 50.0);
        assert_eq!(second.cpu.cores[0].user_pct, 25.0);
        assert_eq!(second.cpu.cores[1].system_pct, 15.0);
        assert_eq!(second.cpu.uptime_secs, 102);
        let eth0 = second
            .networks
            .iter()
            .find(|iface| iface.name == "eth0")
            .unwrap();
        assert!(!eth0.is_loopback);
        assert_eq!(eth0.rx_bytes_per_sec, 2000.0);
        assert_eq!(eth0.tx_bytes_per_sec, 2000.0);
        assert_eq!(eth0.rx_packets_per_sec, 10.0);
        assert_eq!(eth0.total_rx_bytes, 5000);
        let lo = second
            .networks
            .iter()
            .find(|iface| iface.name == "lo")
            .unwrap();
        assert!(lo.is_loopback);
        assert_eq!(lo.rx_bytes_per_sec, 20.0);
        assert_eq!(second.net_rx_total_bps, 3000.0);
        assert_eq!(second.net_tx_total_bps, 2250.0);
        assert_eq!(second.disks[0].device, "nvme0n1p2");
        assert_eq!(second.disks[0].mount_point, "/");
        assert_eq!(second.disks[0].fs_type, "ext4");
        assert_eq!(second.disks[0].read_bytes_per_sec, 1024.0);
        assert_eq!(second.disks[0].write_bytes_per_sec, 2048.0);
        assert_eq!(second.disks[1].device, "sda1");
        assert_eq!(second.disks[1].mount_point, "/home");
        assert_eq!(second.disks[1].read_bytes_per_sec, 1024.0);
        let proc = &second.processes[0];
        assert_eq!(proc.state, 'R');
        assert_eq!(proc.cpu_pct, 10.0);
        assert_eq!(proc.read_bytes_per_sec, 2000.0);
        assert_eq!(proc.write_bytes_per_sec, 500.0);
        assert_eq!(second.cpu.tasks_running, 1);
    }

    #[test]
    fn refuses_to_signal_init_and_can_continue_self() {
        let denied = send_process_signal(1, SignalKind::Kill).unwrap_err();
        assert!(denied.contains("refusing"));
        assert!(send_process_signal(0, SignalKind::Term).is_err());
        assert!(send_process_signal(std::process::id(), SignalKind::Cont).is_ok());
    }

    #[test]
    fn mount_paths_unescape_octal_spaces_and_utf8() {
        assert_eq!(unescape_mount(r"/mnt/My\040Disk"), "/mnt/My Disk");
        assert_eq!(unescape_mount(r"/mnt/caf\303\251"), "/mnt/café");
    }

    #[test]
    fn numeric_processor_lines_are_not_the_cpu_model() {
        let temp = tempfile::tempdir().unwrap();
        let root = temp.path();
        write_file(&root.join("proc/cpuinfo"), "processor : 0\nprocessor : 1\n");
        write_file(
            &root.join("proc/stat"),
            "\
cpu  10 0 10 10 0 0 0 0 0 0
cpu0 5 0 5 5 0 0 0 0 0 0
cpu1 5 0 5 5 0 0 0 0 0 0
",
        );
        write_file(
            &root.join("proc/meminfo"),
            "MemTotal: 2048 kB\nMemAvailable: 1024 kB\n",
        );
        let snap = LinuxCollector::with_root(root).sample().unwrap();
        assert_eq!(
            snap.cpu.model_name,
            format!("{} (2 cores)", std::env::consts::ARCH)
        );
    }

    #[test]
    fn helper_session_roundtrips_sample_and_kill_then_stops_on_exit() {
        let temp = tempfile::tempdir().unwrap();
        install_sample(
            temp.path(),
            "100.00 0.00\n",
            CPU_A,
            NET_A,
            DISK_A,
            &stat_line(4242, "my proc", 'S', 1, 10, 0),
            "read_bytes: 1000\nwrite_bytes: 0\n",
        );
        let sample = serde_json::to_string(&HelperRequest::Sample {
            pane: PaneId::Processes,
            selected_pid: Some(4242),
        })
        .unwrap();
        let kill = serde_json::to_string(&HelperRequest::Kill {
            pid: std::process::id(),
            signal: SignalKind::Cont,
        })
        .unwrap();
        let exit = serde_json::to_string(&HelperRequest::Exit).unwrap();
        let script = format!("{sample}\n{kill}\n{exit}\n{sample}\n");
        let mut reader = std::io::Cursor::new(script);
        let mut output = Vec::new();
        let mut collector = LinuxCollector::with_root(temp.path());
        super::serve_collector(&mut collector, &mut reader, &mut output);
        let text = String::from_utf8(output).unwrap();
        let lines: Vec<_> = text.lines().collect();
        assert_eq!(lines.len(), 2, "{text}");
        match serde_json::from_str::<HelperResponse>(lines[0]).unwrap() {
            HelperResponse::Snapshot(snapshot) => {
                assert_eq!(snapshot.hostname, "fixture-host");
                assert_eq!(snapshot.processes[0].pid, 4242);
            }
            other => panic!("expected snapshot, got {other:?}"),
        }
        assert_eq!(
            serde_json::from_str::<HelperResponse>(lines[1]).unwrap(),
            HelperResponse::KillResult {
                ok: true,
                error: None,
            }
        );

        let mut reader = std::io::Cursor::new(String::new());
        let mut output = Vec::new();
        super::serve_collector(&mut collector, &mut reader, &mut output);
        assert!(output.is_empty());
    }

    #[test]
    fn helper_client_roundtrips_over_the_monitor_binary_and_eof_exits() {
        let binary = helper_binary();
        assert!(
            binary.is_file(),
            "monitor binary missing at {}",
            binary.display()
        );
        let temp = tempfile::tempdir().unwrap();
        install_sample(
            temp.path(),
            "100.00 0.00\n",
            CPU_A,
            NET_A,
            DISK_A,
            &stat_line(4242, "my proc", 'S', 1, 10, 0),
            "read_bytes: 1000\nwrite_bytes: 0\n",
        );
        let mut command = Command::new(&binary);
        command.arg("--collector-helper-root").arg(temp.path());
        let mut client = HelperClient::spawn(command).expect("helper ready");
        let snapshot = client
            .sample_for(PaneId::Overview, Some(4242))
            .expect("sample");
        assert_eq!(snapshot.hostname, "fixture-host");
        assert!(snapshot.processes.iter().any(|proc| proc.pid == 4242));
        client
            .send_signal(std::process::id(), SignalKind::Cont)
            .expect("signal");
        let status = client.shutdown().expect("exit");
        assert!(status.success(), "{status}");

        let mut child = Command::new(&binary)
            .arg("--collector-helper-root")
            .arg(temp.path())
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .expect("spawn helper");
        let mut stdout = BufReader::new(child.stdout.take().expect("stdout"));
        let mut line = String::new();
        std::io::BufRead::read_line(&mut stdout, &mut line).expect("handshake");
        assert!(line.contains("\"type\":\"ready\""), "{line}");
        drop(child.stdin.take());
        let status = child.wait().expect("wait");
        assert!(status.success(), "eof exit: {status}");
    }

    #[test]
    fn helper_client_drop_reaps_exit_zero_without_sigkill() {
        let binary = helper_binary();
        assert!(
            binary.is_file(),
            "monitor binary missing at {}",
            binary.display()
        );
        let temp = tempfile::tempdir().unwrap();
        let mut command = Command::new(&binary);
        command.arg("--collector-helper-root").arg(temp.path());
        let mut client = HelperClient::spawn(command).expect("helper ready");
        let pid = client.pid();
        let slot = std::sync::Arc::new(std::sync::Mutex::new(None));
        client.reaped_status = Some(std::sync::Arc::clone(&slot));
        client.sigkill_allowed = false;
        drop(client);
        let status = slot
            .lock()
            .unwrap_or_else(|err| err.into_inner())
            .take()
            .expect("drop reaped the helper");
        assert_eq!(
            status.code(),
            Some(0),
            "drop must exit 0 via Exit/EOF without SIGKILL, got {status}"
        );
        assert!(
            !PathBuf::from(format!("/proc/{pid}")).exists(),
            "helper {pid} was not reaped"
        );
    }

    #[test]
    fn helper_spawn_reports_polkit_cancel_exit_126() {
        let mut command = Command::new("sh");
        command.args(["-c", "exit 126"]);
        let err = HelperClient::spawn(command).expect_err("exit 126");
        assert_eq!(err.exit_code, Some(126));
        assert!(err.message.contains("cancelled"), "{err}");
    }

    #[test]
    fn helper_binary_prefers_vitals_and_falls_back_to_btm_rune() {
        let dir = tempfile::tempdir().unwrap();
        assert_eq!(
            resolve_helper_binary_in(dir.path()),
            dir.path().join("vitals")
        );

        let legacy = dir.path().join("btm-rune");
        fs::write(&legacy, b"legacy").unwrap();
        assert_eq!(resolve_helper_binary_in(dir.path()), legacy);

        let vitals = dir.path().join("vitals");
        fs::write(&vitals, b"vitals").unwrap();
        assert_eq!(resolve_helper_binary_in(dir.path()), vitals);
    }

    #[test]
    fn parses_psi_extended_meminfo_disk_latency_sockets_and_proc_metadata() {
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().unwrap();
        let root = temp.path();
        install_sample(
            root,
            "100.00 0.00\n",
            CPU_A,
            NET_A,
            // device: reads rmerge sread r_ms writes wmerge swrite w_ms in_prog io_ticks w_ticks
            " 259 2 nvme0n1p2 100 0 1000 50 50 0 500 25 0 200 0\n   8 1 sda1 10 0 100 20 10 0 100 40 0 100 0\n",
            "4242 (postgres) S 1 4242 4242 0 -1 0 0 0 0 0 10 0 0 0 15 -5 4 0 0 0 4242",
            "read_bytes: 1000\nwrite_bytes: 0\n",
        );
        write_file(
            &root.join("proc/pressure/cpu"),
            "some avg10=4.25 avg60=1.50 avg300=0.80 total=12345\nfull avg10=0.00 avg60=0.00 avg300=0.00 total=0\n",
        );
        write_file(
            &root.join("proc/pressure/memory"),
            "some avg10=1.75 avg60=0.50 avg300=0.10 total=4000\nfull avg10=0.50 avg60=0.10 avg300=0.02 total=900\n",
        );
        write_file(
            &root.join("proc/pressure/io"),
            "some avg10=8.50 avg60=3.10 avg300=1.00 total=9999\nfull avg10=3.25 avg60=1.20 avg300=0.40 total=3333\n",
        );
        write_file(
            &root.join("proc/meminfo"),
            "\
MemTotal:       16384000 kB
MemFree:         1000000 kB
MemAvailable:    8192000 kB
Buffers:          102400 kB
Cached:          2048000 kB
SwapTotal:       8192000 kB
SwapFree:        4096000 kB
Dirty:              4096 kB
Writeback:           512 kB
Shmem:            262144 kB
Slab:             524288 kB
",
        );
        write_file(
            &root.join("proc/4242/cgroup"),
            "12:pids:/system.slice/postgresql.service\n0::/system.slice/postgresql.service/subproc\n",
        );
        symlink("/var/lib/postgresql/data", root.join("proc/4242/cwd")).unwrap();
        symlink("/usr/bin/postgres", root.join("proc/4242/exe")).unwrap();
        symlink("socket:[77001]", root.join("proc/4242/fd/3")).unwrap();
        symlink("socket:[77002]", root.join("proc/4242/fd/4")).unwrap();
        symlink("socket:[77003]", root.join("proc/4242/fd/5")).unwrap();

        // /proc/net/{tcp,tcp6,udp,udp6}
        // 127.0.0.1:5432 = 0100007F:1538 (LISTEN=0A, inode 77001)
        // 0.0.0.0:8080 = 00000000:1F90 (LISTEN=0A, inode 77002)
        // 10.0.0.2:5432 -> 10.0.0.5:51234 = 0200000A:1538 -> 0500000A:C822 (ESTAB=01, inode 88001)
        // TIME_WAIT = 06 on port 9090 (2382)
        write_file(
            &root.join("proc/net/tcp"),
            "\
  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode
   0: 0200000A:2382 0500000A:01BB 06 00000000:00000000 00:00000000 00000000  1000        0 0 1 0000000000000000 100 0 0 10 0
   1: 00000000:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000  1000        0 77002 1 0000000000000000 100 0 0 10 0
   2: 0100007F:1538 00000000:0000 0A 00000000:00000000 00:00000000 00000000  1000        0 77001 1 0000000000000000 100 0 0 10 0
   3: 0200000A:1538 0500000A:C822 01 00000000:00000000 00:00000000 00000000  1000        0 88001 1 0000000000000000 20 4 30 10 -1
",
        );
        // [::1]:9332 -> words 0,0,0, 01000000 : 2474 (LISTEN=0A, inode 88002)
        write_file(
            &root.join("proc/net/tcp6"),
            "\
  sl  local_address                         remote_address                        st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode
   0: 00000000000000000000000001000000:2474 00000000000000000000000000000000:0000 0A 00000000:00000000 00:00000000 00000000  1000        0 88002 1 0000000000000000 100 0 0 10 0
",
        );
        // UDP *:5353 -> 00000000:14E9 (UNCONN=07, inode 77003)
        write_file(
            &root.join("proc/net/udp"),
            "\
   sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode ref pointer drops
    0: 00000000:14E9 00000000:0000 07 00000000:00000000 00:00000000 00000000  1000        0 77003 2 0000000000000000 0
",
        );

        let mut collector = LinuxCollector::with_root(root);
        let first = collector.sample_for(PaneId::Network, Some(4242)).unwrap();
        assert_eq!(
            first.psi,
            PsiMetrics {
                cpu_some_pct: 4.25,
                mem_some_pct: 1.75,
                mem_full_pct: 0.50,
                io_some_pct: 8.50,
                io_full_pct: 3.25,
            }
        );
        assert_eq!(first.mem.shared_bytes, 262_144 * 1024);
        assert_eq!(first.mem.dirty_bytes, 4_096 * 1024);
        assert_eq!(first.mem.writeback_bytes, 512 * 1024);
        assert_eq!(first.mem.slab_bytes, 524_288 * 1024);
        assert_eq!(first.disks[0].busy_pct, 0.0);
        assert_eq!(first.disks[0].await_ms, 0.0);

        let proc = &first.processes[0];
        assert_eq!(proc.nice, -5);
        assert_eq!(proc.unit.as_deref(), Some("postgresql.service"));
        assert_eq!(proc.cwd.as_deref(), Some("/var/lib/postgresql/data"));
        assert_eq!(proc.exe.as_deref(), Some("/usr/bin/postgres"));
        assert_eq!(proc.fds, Some(6));
        assert_eq!(
            proc.listening_ports,
            vec![
                "TCP 127.0.0.1:5432".to_string(),
                "TCP *:8080".to_string(),
                "UDP *:5353".to_string(),
            ]
        );

        // Sockets sorted: LISTEN first by port (5432, 8080, 9332), then ESTAB (5432), then UNCONN (5353), then TIME_WAIT.
        assert_eq!(first.sockets.len(), 6);
        assert_eq!(first.sockets[0].proto, "TCP");
        assert_eq!(first.sockets[0].local_addr, "127.0.0.1:5432");
        assert_eq!(first.sockets[0].remote_addr, "*");
        assert_eq!(first.sockets[0].state, "LISTEN");
        assert_eq!(first.sockets[0].pid, Some(4242));
        assert_eq!(first.sockets[0].process, "postgres");

        assert_eq!(first.sockets[1].local_addr, "0.0.0.0:8080");
        assert_eq!(first.sockets[1].state, "LISTEN");
        assert_eq!(first.sockets[1].pid, Some(4242));

        assert_eq!(first.sockets[2].proto, "TCP6");
        assert_eq!(first.sockets[2].local_addr, "[::1]:9332");
        assert_eq!(first.sockets[2].remote_addr, "*");
        assert_eq!(first.sockets[2].state, "LISTEN");
        assert_eq!(first.sockets[2].pid, None);

        assert_eq!(first.sockets[3].local_addr, "10.0.0.2:5432");
        assert_eq!(first.sockets[3].remote_addr, "10.0.0.5:51234");
        assert_eq!(first.sockets[3].state, "ESTAB");

        assert_eq!(first.sockets[4].proto, "UDP");
        assert_eq!(first.sockets[4].local_addr, "0.0.0.0:5353");
        assert_eq!(first.sockets[4].state, "UNCONN");
        assert_eq!(first.sockets[4].pid, Some(4242));

        assert_eq!(first.sockets[5].state, "TIME_WAIT");

        // Advance uptime by 2.0s and disk counters:
        // nvme0n1p2: +20 reads (+30 ms), +20 writes (+50 ms), +500 io_ticks_ms over 2000ms => busy=25%, await=80/40=2.0ms
        // sda1: +5 reads (+45 ms), +0 writes (+0 ms), +3000 io_ticks_ms over 2000ms => busy clamped to 100%, await=45/5=9.0ms
        write_file(&root.join("proc/uptime"), "102.00 0.00\n");
        write_file(&root.join("proc/stat"), CPU_B);
        write_file(
            &root.join("proc/diskstats"),
            " 259 2 nvme0n1p2 120 0 1040 80 70 0 540 75 0 700 0\n   8 1 sda1 15 0 110 65 10 0 100 40 0 3100 0\n",
        );
        let second = collector.sample_for(PaneId::Disks, Some(4242)).unwrap();
        assert!((second.disks[0].busy_pct - 25.0).abs() < 0.01);
        assert!((second.disks[0].await_ms - 2.0).abs() < 0.01);
        assert_eq!(second.disks[1].busy_pct, 100.0);
        assert!((second.disks[1].await_ms - 9.0).abs() < 0.01);
    }

    #[test]
    fn socket_list_prioritizes_listen_and_estab_ahead_of_time_wait() {
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().unwrap();
        let root = temp.path();
        install_sample(
            root,
            "10.00 0.00\n",
            CPU_A,
            NET_A,
            DISK_A,
            &stat_line(4242, "my proc", 'S', 1, 10, 0),
            "read_bytes: 0\nwrite_bytes: 0\n",
        );
        let mut tcp = String::from(
            "  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode\n",
        );
        // 70 TIME_WAIT sockets followed by 70 LISTEN and 20 ESTAB sockets.
        // More listeners than the old 64-row cap must not hide ESTAB.
        for idx in 0..70_u16 {
            let port = 20_000 + idx;
            tcp.push_str(&format!(
                "  {idx}: 0100007F:{port:04X} 0100007F:9999 06 00000000:00000000 00:00000000 00000000 1000 0 {} 1 0\n",
                10_000 + u64::from(idx)
            ));
        }
        for idx in 0..70_u16 {
            let port = 8_000 + idx;
            tcp.push_str(&format!(
                "  {}: 00000000:{port:04X} 00000000:0000 0A 00000000:00000000 00:00000000 00000000 1000 0 {} 1 0\n",
                70 + idx,
                20_000 + u64::from(idx)
            ));
        }
        for idx in 0..20_u16 {
            let port = 9_000 + idx;
            tcp.push_str(&format!(
                "  {}: 0100007F:{port:04X} 0200000A:01BB 01 00000000:00000000 00:00000000 00000000 1000 0 {} 1 0\n",
                140 + idx,
                30_000 + u64::from(idx)
            ));
        }
        write_file(&root.join("proc/net/tcp"), &tcp);
        let mut udp = String::from(
            "  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode\n",
        );
        for idx in 0..4_u16 {
            let port = 5_353 + idx;
            udp.push_str(&format!(
                "  {idx}: 00000000:{port:04X} 00000000:0000 07 00000000:00000000 00:00000000 00000000 1000 0 {} 1 0\n",
                40_000 + u64::from(idx)
            ));
        }
        write_file(&root.join("proc/net/udp"), &udp);
        // inode 30000 is the first ESTAB row; inode 40000 is the first UDP row.
        symlink("socket:[30000]", root.join("proc/4242/fd/6")).unwrap();
        symlink("socket:[40000]", root.join("proc/4242/fd/7")).unwrap();
        // More than SMALL_FIXTURE_PROCESSES, and more than 16 dummy PIDs, so
        // Network takes FdWalk::SocketOwners instead of the full open-file harvest.
        for pid in 8_000..8_017_u32 {
            fs::create_dir_all(root.join(format!("proc/{pid}"))).unwrap();
        }
        let snap = LinuxCollector::with_root(root)
            .sample_for(PaneId::Network, None)
            .unwrap();
        assert_eq!(snap.sockets.len(), 164);
        assert!(snap.sockets[..70].iter().all(|s| s.state == "LISTEN"));
        assert_eq!(snap.sockets[0].local_addr, "0.0.0.0:8000");
        assert_eq!(snap.sockets[69].local_addr, "0.0.0.0:8069");
        assert!(snap.sockets[70..90].iter().all(|s| s.state == "ESTAB"));
        assert_eq!(snap.sockets[70].local_addr, "127.0.0.1:9000");
        assert_eq!(snap.sockets[89].local_addr, "127.0.0.1:9019");
        assert!(snap.sockets[90..94].iter().all(|s| s.proto == "UDP"));
        assert_eq!(snap.sockets[90].local_addr, "0.0.0.0:5353");
        assert!(snap.sockets[94..].iter().all(|s| s.state == "TIME_WAIT"));
        assert_eq!(snap.sockets[94].local_addr, "127.0.0.1:20000");
        assert_eq!(
            snap.sockets.iter().filter(|s| s.state == "LISTEN").count(),
            70
        );
        assert_eq!(
            snap.sockets.iter().filter(|s| s.state == "ESTAB").count(),
            20
        );
        assert_eq!(snap.sockets.iter().filter(|s| s.proto == "UDP").count(), 4);
        assert_eq!(
            snap.sockets.iter().filter(|s| s.state == "TIME_WAIT").count(),
            70
        );
        let owned_estab = snap
            .sockets
            .iter()
            .find(|s| s.inode == 30_000)
            .expect("owned ESTAB");
        assert_eq!(owned_estab.state, "ESTAB");
        assert_eq!(owned_estab.pid, Some(4242));
        assert_eq!(owned_estab.process, "my proc");
        let owned_udp = snap
            .sockets
            .iter()
            .find(|s| s.inode == 40_000)
            .expect("owned UDP");
        assert_eq!(owned_udp.proto, "UDP");
        assert_eq!(owned_udp.pid, Some(4242));
        assert_eq!(owned_udp.process, "my proc");
        assert!(
            snap.open_files.is_empty(),
            "SocketOwners must not fill the Files list"
        );
    }

    #[test]
    fn renice_process_and_helper_client_renice_roundtrip() {
        assert!(renice_process(0, 1).unwrap_err().contains("refusing"));
        assert!(renice_process(1, 1).unwrap_err().contains("refusing"));

        let mut sleeper = Command::new("sh")
            .args(["-c", "sleep 30"])
            .spawn()
            .expect("spawn sleeper");
        let child_pid = sleeper.id();
        let base_nice = renice_process(child_pid, 0).expect("read nice via delta 0");
        let raised = renice_process(child_pid, 2).expect("increase nice by +2");
        assert_eq!(raised, (base_nice + 2).min(19));

        let binary = helper_binary();
        if binary.is_file() {
            let temp = tempfile::tempdir().unwrap();
            let mut command = Command::new(&binary);
            command.arg("--collector-helper-root").arg(temp.path());
            let mut client = HelperClient::spawn(command).expect("helper ready");
            let via_helper = client
                .renice_process(child_pid, 1)
                .expect("renice via helper");
            assert_eq!(via_helper, (raised + 1).min(19));
            assert!(client.renice_process(1, 1).is_err());
            let status = client.shutdown().expect("helper exit");
            assert!(status.success());
        }

        let _ = sleeper.kill();
        let _ = sleeper.wait();
    }

    #[test]
    fn open_files_classify_deduplicate_resolve_sockets_and_scan_demand_driven() {
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().unwrap();
        let root = temp.path();
        install_sample(
            root,
            "10.00 0.00\n",
            CPU_A,
            NET_A,
            DISK_A,
            &stat_line(4242, "postgres", 'S', 1, 10, 0),
            "read_bytes: 0\nwrite_bytes: 0\n",
        );
        fs::remove_file(root.join("proc/4242/fd/0")).unwrap();
        fs::remove_file(root.join("proc/4242/fd/1")).unwrap();
        fs::remove_file(root.join("proc/4242/fd/2")).unwrap();

        write_file(
            &root.join("proc/net/tcp"),
            "\
  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode
   0: 0100007F:1538 00000000:0000 0A 00000000:00000000 00:00000000 00000000  1000        0 77001 1 0 100 0 0 10 0
",
        );

        // Device, File, resolved Socket, unresolved Socket, Pipe, and 50 identical eventfds.
        symlink("/dev/null", root.join("proc/4242/fd/0")).unwrap();
        symlink(
            "/var/lib/postgresql/data/PG_VERSION",
            root.join("proc/4242/fd/3"),
        )
        .unwrap();
        symlink("socket:[77001]", root.join("proc/4242/fd/6")).unwrap();
        symlink("socket:[99999]", root.join("proc/4242/fd/7")).unwrap();
        symlink("pipe:[12345]", root.join("proc/4242/fd/8")).unwrap();
        for idx in 0..50_u32 {
            symlink(
                "anon_inode:[eventfd]",
                root.join(format!("proc/4242/fd/{}", 10 + idx)),
            )
            .unwrap();
        }

        // Small fixture (1 process <= SMALL_FIXTURE_PROCESSES): collects both proc and snapshot open_files.
        let mut small = LinuxCollector::with_root(root);
        let snap_small = small.sample_for(PaneId::Overview, Some(4242)).unwrap();
        let pg = &snap_small.processes[0];
        // Prioritizes File, Device, Socket before Pipe in proc.open_files.
        assert_eq!(pg.open_files[0], "/var/lib/postgresql/data/PG_VERSION");
        assert_eq!(pg.open_files[1], "/dev/null");
        assert_eq!(pg.open_files[2], "TCP 127.0.0.1:5432 -> * (LISTEN)");
        assert_eq!(pg.open_files[3], "socket:[99999]");
        assert_eq!(pg.open_files.len(), 6);

        // Snapshot open_files deduplicates 50 eventfds into 1 entry with fd=10 and count=50,
        // sorted with File and Socket first.
        assert_eq!(snap_small.open_files.len(), 6);
        assert_eq!(snap_small.open_files[0].kind, OpenFileKind::File);
        assert_eq!(snap_small.open_files[1].kind, OpenFileKind::Socket);
        let eventfd = snap_small
            .open_files
            .iter()
            .find(|e| e.path == "anon_inode:[eventfd]")
            .expect("deduplicated eventfd");
        assert_eq!(eventfd.fd, 10);
        assert_eq!(eventfd.count, 50);
        assert_eq!(eventfd.kind, OpenFileKind::Pipe);

        // Add 50 more processes (>= 48 so parallel ScanPool runs, > SMALL_FIXTURE_PROCESSES).
        for pid in 5000..5050_u32 {
            write_file(
                &root.join(format!("proc/{pid}/stat")),
                &stat_line(pid, "worker", 'S', 1, 1, 0),
            );
            write_file(
                &root.join(format!("proc/{pid}/status")),
                "Name:\tworker\nState:\tS\nPPid:\t1\nUid:\t1000\t1000\t1000\t1000\nVmRSS:\t256 kB\nThreads:\t1\n",
            );
            fs::create_dir_all(root.join(format!("proc/{pid}/fd"))).unwrap();
            symlink(
                format!("/var/log/worker-{pid}.log"),
                root.join(format!("proc/{pid}/fd/4")),
            )
            .unwrap();
        }

        // On Overview, system-wide open_files is NOT collected, while selected_pid (4242) still gets open_files!
        let mut large = LinuxCollector::with_root(root);
        let overview_snap = large.sample_for(PaneId::Overview, Some(4242)).unwrap();
        assert!(overview_snap.open_files.is_empty());
        let sel = overview_snap
            .processes
            .iter()
            .find(|p| p.pid == 4242)
            .unwrap();
        assert!(!sel.open_files.is_empty());
        let unselected = overview_snap
            .processes
            .iter()
            .find(|p| p.pid == 5000)
            .unwrap();
        assert!(unselected.open_files.is_empty());

        // On PaneId::Files, parallel ScanPool harvests open_files across all 51 processes.
        let files_snap = large.sample_for(PaneId::Files, Some(4242)).unwrap();
        assert_eq!(files_snap.open_files.len(), 56);
        assert_eq!(files_snap.open_files[0].kind, OpenFileKind::File);
        assert!(
            files_snap
                .open_files
                .iter()
                .any(|e| e.pid == 5049 && e.path == "/var/log/worker-5049.log")
        );
    }
}
