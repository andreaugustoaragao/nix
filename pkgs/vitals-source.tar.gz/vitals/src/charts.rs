//! Vector charts for the BTM monitor. Coordinates are the element box: origin at the top-left,
//! `y` growing downward, values mapped so larger samples sit toward the top.

use rune::{Color, LineCap, Path, Shape};

const HAIRLINE: f32 = 0.75;
const SERIES_STROKE: f32 = 1.6;
const SPARK_STROKE: f32 = 1.25;
const SPARK_FILL: f32 = 0.18;
const MIRROR_FILL: f32 = 0.28;
const TREE_CELL_W: f32 = 14.0;
const TREE_PAD_RIGHT: f32 = 4.0;
const TREE_STROKE: f32 = 1.6;
const TREE_ALPHA: f32 = 0.82;
const MIN_THROUGHPUT: f64 = 1024.0;
const AREA_EPSILON: f32 = 1.0e-2;
const GRID_FRACTIONS: [f32; 3] = [0.25, 0.5, 0.75];

/// One overlaid curve: samples, ink, translucent area, and stroke width in points.
#[derive(Clone, Copy, Debug)]
pub struct Series<'a> {
    pub values: &'a [f32],
    pub color: Color,
    pub fill_alpha: f32,
    pub width: f32,
}

/// Area chart with 25/50/75% horizontal hairlines, a closed fill, and a round stroke.
#[allow(clippy::too_many_arguments)]
pub fn area_line_chart(
    samples: &[f32],
    min_val: f32,
    max_val: f32,
    line_color: Color,
    fill_alpha: f32,
    grid_color: Color,
    w: f32,
    h: f32,
) -> Shape {
    let Some((w, h)) = finite_size(w, h) else {
        return Shape::new();
    };
    let mut shape = stroke_grid(Shape::new(), w, h, grid_color, false);
    let (curve, fill_ok) = value_curve(samples, min_val, max_val, w, h);
    let alpha = if fill_ok { fill_alpha } else { 0.0 };
    shape = paint_curve(shape, &curve, line_color, alpha, SERIES_STROKE, h);
    shape.view_box(w, h)
}

/// Reference grid (horizontal and vertical hairlines) with one curve per series.
pub fn multi_series_chart(
    series: &[Series<'_>],
    min_val: f32,
    max_val: f32,
    grid_color: Color,
    w: f32,
    h: f32,
) -> Shape {
    let Some((w, h)) = finite_size(w, h) else {
        return Shape::new();
    };
    let mut shape = stroke_grid(Shape::new(), w, h, grid_color, false);
    shape = stroke_grid(shape, w, h, grid_color, true);
    for item in series {
        let (curve, fill_ok) = value_curve(item.values, min_val, max_val, w, h);
        let alpha = if fill_ok { item.fill_alpha } else { 0.0 };
        shape = paint_curve(shape, &curve, item.color, alpha, item.width, h);
    }
    shape.view_box(w, h)
}

/// RX above the horizon and TX below it. The shared scale is the peak rate, at least 1024 B/s.
pub fn dual_mirror_chart(
    top_samples: &[f64],
    bottom_samples: &[f64],
    top_color: Color,
    bottom_color: Color,
    grid_color: Color,
    w: f32,
    h: f32,
) -> (Shape, f64) {
    let peak = peak_scale(top_samples, bottom_samples);
    let Some((w, h)) = finite_size(w, h) else {
        return (Shape::new(), peak);
    };
    let mid = h * 0.5;
    let horizon = Path::new().move_to([0.0, mid]).line_to([w, mid]);
    let mut shape = Shape::new().stroke_path(&horizon, HAIRLINE, LineCap::Butt, grid_color);
    let top = mirror_curve(top_samples, peak, w, h, true);
    let bottom = mirror_curve(bottom_samples, peak, w, h, false);
    shape = paint_curve(shape, &top, top_color, MIRROR_FILL, SERIES_STROKE, mid);
    shape = paint_curve(
        shape,
        &bottom,
        bottom_color,
        MIRROR_FILL,
        SERIES_STROKE,
        mid,
    );
    (shape.view_box(w, h), peak)
}

/// Horizontal meter: full track, then a value fill clamped to 0..=100.
pub fn meter_bar_shape(pct: f32, track_color: Color, fill_color: Color, w: f32, h: f32) -> Shape {
    let Some((w, h)) = finite_size(w, h) else {
        return Shape::new();
    };
    let pct = if pct.is_nan() {
        0.0
    } else {
        pct.clamp(0.0, 100.0)
    };
    let mut shape = Shape::new().fill_path(&rect_path(0.0, 0.0, w, h), track_color);
    let fill_w = w * (pct / 100.0);
    if fill_w > 0.0 {
        shape = shape.fill_path(&rect_path(0.0, 0.0, fill_w, h), fill_color);
    }
    shape.view_box(w, h)
}

/// Compact badge sparkline. A flat or non-finite series is a center stroke with no fill.
pub fn sparkline_shape(samples: &[f32], color: Color, w: f32, h: f32) -> Shape {
    let Some((w, h)) = finite_size(w, h) else {
        return Shape::new();
    };
    if samples.is_empty() {
        return Shape::new().view_box(w, h);
    }
    let (curve, varies) = spark_curve(samples, w, h);
    let mut shape = Shape::new();
    if varies {
        shape = paint_curve(shape, &curve, color, SPARK_FILL, SPARK_STROKE, h);
    } else if curve.len() >= 2 {
        shape = shape.stroke_path(&polyline_path(&curve), SPARK_STROKE, LineCap::Round, color);
    }
    shape.view_box(w, h)
}

/// Mini inspector sparkline with a subtle mid-height reference hairline.
pub fn sparkline_chart(samples: &[f32], color: Color, grid_color: Color, w: f32, h: f32) -> Shape {
    let Some((w, h)) = finite_size(w, h) else {
        return Shape::new();
    };
    let mid = h * 0.5;
    let guide = Path::new().move_to([0.0, mid]).line_to([w, mid]);
    let mut shape = Shape::new().stroke_path(&guide, HAIRLINE, LineCap::Butt, grid_color);
    if !samples.is_empty() {
        let (curve, varies) = spark_curve(samples, w, h);
        if varies {
            shape = paint_curve(shape, &curve, color, SPARK_FILL, SPARK_STROKE, h);
        } else if curve.len() >= 2 {
            shape = shape.stroke_path(&polyline_path(&curve), SPARK_STROKE, LineCap::Round, color);
        }
    }
    shape.view_box(w, h)
}

/// Overlays a vertical crosshair cursor on `shape` when `hover_frac` (`0.0..=1.0`) is active.
pub fn with_hover_cursor(
    shape: Shape,
    hover_frac: Option<f32>,
    color: Color,
    w: f32,
    h: f32,
) -> Shape {
    let Some(frac) = hover_frac.filter(|v| v.is_finite()) else {
        return shape;
    };
    let Some((w, h)) = finite_size(w, h) else {
        return shape;
    };
    let x = (w * frac.clamp(0.0, 1.0)).clamp(0.5, (w - 0.5).max(0.5));
    let cursor = Path::new().move_to([x, 0.0]).line_to([x, h]);
    shape
        .stroke_path(&cursor, 1.0, LineCap::Butt, color.alpha(0.72))
        .view_box(w, h)
}

/// Full-height vector connector guides for one process-tree row (`"│  "`, `"├─ "`, `"└─ "`, `"   "`).
///
/// Vertical segments span `0.0..=row_height` with `LineCap::Butt`, so adjacent `row_height` rows
/// meet top-to-bottom and stem-to-branch with zero gap.
pub fn tree_connector_shape(
    prefix: &str,
    row_height: f32,
    colors: &[Color],
) -> Option<(Shape, f32)> {
    if prefix.is_empty() || !row_height.is_finite() || row_height <= 0.0 {
        return None;
    }
    let chars: Vec<char> = prefix.chars().collect();
    let depth = chars.len() / 3;
    if depth == 0 {
        return None;
    }
    let total_width = depth as f32 * TREE_CELL_W + TREE_PAD_RIGHT;
    let y_mid = row_height * 0.5;
    let corner_overlap = TREE_STROKE * 0.5;
    let mut shape = Shape::new();
    for d in 0..depth {
        let cell = &chars[d * 3..d * 3 + 3];
        let x = d as f32 * TREE_CELL_W + 6.0;
        let x_end = d as f32 * TREE_CELL_W + TREE_CELL_W;
        let base_color = if colors.is_empty() {
            Color::WHITE
        } else {
            colors[d % colors.len()]
        };
        let ink = base_color.alpha(TREE_ALPHA);
        match cell[0] {
            '│' => {
                shape = shape.line([x, 0.0], [x, row_height], TREE_STROKE, LineCap::Butt, ink);
            }
            '├' => {
                shape = shape
                    .line([x, 0.0], [x, row_height], TREE_STROKE, LineCap::Butt, ink)
                    .line([x, y_mid], [x_end, y_mid], TREE_STROKE, LineCap::Butt, ink);
            }
            '└' => {
                shape = shape
                    .line(
                        [x, 0.0],
                        [x, y_mid + corner_overlap],
                        TREE_STROKE,
                        LineCap::Butt,
                        ink,
                    )
                    .line([x, y_mid], [x_end, y_mid], TREE_STROKE, LineCap::Butt, ink);
            }
            _ => {}
        }
    }
    Some((shape.view_box(total_width, row_height), total_width))
}

fn finite_size(w: f32, h: f32) -> Option<(f32, f32)> {
    (w.is_finite() && h.is_finite() && w > 0.0 && h > 0.0).then_some((w, h))
}

fn axis_range(min_val: f32, max_val: f32) -> Option<(f32, f32)> {
    if !min_val.is_finite() || !max_val.is_finite() {
        return None;
    }
    if max_val > min_val {
        Some((min_val, max_val))
    } else if min_val > max_val {
        Some((max_val, min_val))
    } else {
        None
    }
}

fn stroke_grid(shape: Shape, w: f32, h: f32, color: Color, vertical: bool) -> Shape {
    shape.stroke_path(&grid_path(w, h, vertical), HAIRLINE, LineCap::Butt, color)
}

fn grid_path(w: f32, h: f32, vertical: bool) -> Path {
    let mut path = Path::new();
    for frac in GRID_FRACTIONS {
        path = if vertical {
            let x = w * frac;
            path.move_to([x, 0.0]).line_to([x, h])
        } else {
            let y = h * frac;
            path.move_to([0.0, y]).line_to([w, y])
        };
    }
    path
}

fn value_curve(
    samples: &[f32],
    min_val: f32,
    max_val: f32,
    w: f32,
    h: f32,
) -> (Vec<[f32; 2]>, bool) {
    if samples.is_empty() {
        return (Vec::new(), false);
    }
    let Some((lo, hi)) = axis_range(min_val, max_val) else {
        return (vec![[0.0, h * 0.5], [w, h * 0.5]], false);
    };
    let values = coerce_samples(samples, lo, hi);
    (project(&values, lo, hi, w, h), true)
}

fn project(values: &[f32], lo: f32, hi: f32, w: f32, h: f32) -> Vec<[f32; 2]> {
    if values.len() == 1 {
        let y = map_y(values[0], lo, hi, h);
        return vec![[0.0, y], [w, y]];
    }
    let span = (values.len() - 1) as f32;
    values
        .iter()
        .enumerate()
        .map(|(i, v)| [w * (i as f32) / span, map_y(*v, lo, hi, h)])
        .collect()
}

fn map_y(v: f32, lo: f32, hi: f32, h: f32) -> f32 {
    // f32 subtraction overflows to infinity when the axis spans more than about 1e38.
    let t =
        ((f64::from(v) - f64::from(lo)) / (f64::from(hi) - f64::from(lo))).clamp(0.0, 1.0) as f32;
    h * (1.0 - t)
}

/// NaN keeps the previous finite sample. Infinities clamp to the axis so a spike stays on the chart.
fn coerce_samples(samples: &[f32], lo: f32, hi: f32) -> Vec<f32> {
    let mut last = samples
        .iter()
        .copied()
        .find(|v| v.is_finite())
        .unwrap_or(lo);
    samples
        .iter()
        .map(|v| {
            if v.is_nan() {
                last
            } else {
                last = v.clamp(lo, hi);
                last
            }
        })
        .collect()
}

fn coerce_rates(samples: &[f64], peak: f64) -> Vec<f64> {
    let mut last = samples
        .iter()
        .copied()
        .find(|v| v.is_finite())
        .unwrap_or(0.0);
    samples
        .iter()
        .map(|v| {
            if v.is_nan() {
                last
            } else if v.is_finite() {
                last = *v;
                last
            } else {
                last = if v.is_sign_negative() { -peak } else { peak };
                last
            }
        })
        .collect()
}

fn paint_curve(
    mut shape: Shape,
    curve: &[[f32; 2]],
    color: Color,
    fill_alpha: f32,
    width: f32,
    baseline: f32,
) -> Shape {
    if curve.len() < 2 {
        return shape;
    }
    if let (Some(alpha), Some(poly)) = (positive_alpha(fill_alpha), area_polygon(curve, baseline)) {
        shape = shape.fill_path(&polygon_path(&poly), color.alpha(alpha));
    }
    if width.is_finite() && width > 0.0 {
        shape = shape.stroke_path(&polyline_path(curve), width, LineCap::Round, color);
    }
    shape
}

fn positive_alpha(alpha: f32) -> Option<f32> {
    (alpha.is_finite() && alpha > 0.0).then_some(alpha.clamp(0.0, 1.0))
}

fn area_polygon(curve: &[[f32; 2]], baseline: f32) -> Option<Vec<[f32; 2]>> {
    let last = *curve.last()?;
    let mut poly = Vec::with_capacity(curve.len() + 2);
    poly.extend_from_slice(curve);
    poly.push([last[0], baseline]);
    poly.push([curve[0][0], baseline]);
    dedup_points(&mut poly);
    if poly.len() >= 3 && polygon_area(&poly) >= AREA_EPSILON {
        Some(poly)
    } else {
        None
    }
}

fn dedup_points(points: &mut Vec<[f32; 2]>) {
    points.dedup_by(|a, b| nearly(*a, *b));
    if points.len() >= 2 && nearly(points[0], *points.last().expect("len checked")) {
        points.pop();
    }
}

fn nearly(a: [f32; 2], b: [f32; 2]) -> bool {
    (a[0] - b[0]).abs() <= 1.0e-3 && (a[1] - b[1]).abs() <= 1.0e-3
}

fn polygon_area(points: &[[f32; 2]]) -> f32 {
    let n = points.len();
    let sum: f32 = (0..n)
        .map(|i| {
            let (a, b) = (points[i], points[(i + 1) % n]);
            a[0] * b[1] - b[0] * a[1]
        })
        .sum();
    sum.abs() * 0.5
}

fn polyline_path(points: &[[f32; 2]]) -> Path {
    let mut path = Path::new().move_to(points[0]);
    for point in &points[1..] {
        path = path.line_to(*point);
    }
    path
}

fn polygon_path(points: &[[f32; 2]]) -> Path {
    polyline_path(points).close()
}

fn rect_path(x0: f32, y0: f32, x1: f32, y1: f32) -> Path {
    Path::new()
        .move_to([x0, y0])
        .line_to([x1, y0])
        .line_to([x1, y1])
        .line_to([x0, y1])
        .close()
}

fn peak_scale(top: &[f64], bottom: &[f64]) -> f64 {
    top.iter().chain(bottom).fold(MIN_THROUGHPUT, |peak, v| {
        if v.is_finite() {
            peak.max(v.abs())
        } else {
            peak
        }
    })
}

fn mirror_curve(samples: &[f64], peak: f64, w: f32, h: f32, top: bool) -> Vec<[f32; 2]> {
    if samples.is_empty() || !peak.is_finite() || peak <= 0.0 {
        return Vec::new();
    }
    let values = coerce_rates(samples, peak);
    let mid = h * 0.5;
    let y_of = |v: f64| {
        let t = (v.abs() / peak).clamp(0.0, 1.0) as f32;
        if top { mid - t * mid } else { mid + t * mid }
    };
    if values.len() == 1 {
        let y = y_of(values[0]);
        return vec![[0.0, y], [w, y]];
    }
    let span = (values.len() - 1) as f32;
    values
        .iter()
        .enumerate()
        .map(|(i, v)| [w * (i as f32) / span, y_of(*v)])
        .collect()
}

fn spark_curve(samples: &[f32], w: f32, h: f32) -> (Vec<[f32; 2]>, bool) {
    let mut lo = f32::INFINITY;
    let mut hi = f32::NEG_INFINITY;
    for value in samples.iter().copied().filter(|v| v.is_finite()) {
        lo = lo.min(value);
        hi = hi.max(value);
    }
    if !lo.is_finite() || hi <= lo {
        return (vec![[0.0, h * 0.5], [w, h * 0.5]], false);
    }
    let values = coerce_samples(samples, lo, hi);
    (project(&values, lo, hi, w, h), true)
}

#[cfg(test)]
mod tests {
    use super::*;

    const LINE: Color = Color {
        r: 0.2,
        g: 0.6,
        b: 1.0,
        a: 1.0,
    };
    const FILL: Color = Color {
        r: 0.1,
        g: 0.9,
        b: 0.5,
        a: 1.0,
    };
    const GRID: Color = Color {
        r: 0.4,
        g: 0.45,
        b: 0.5,
        a: 1.0,
    };
    const TRACK: Color = Color {
        r: 0.2,
        g: 0.2,
        b: 0.25,
        a: 1.0,
    };
    const TOP: Color = Color {
        r: 0.1,
        g: 0.8,
        b: 0.6,
        a: 1.0,
    };
    const BOTTOM: Color = Color {
        r: 0.95,
        g: 0.55,
        b: 0.2,
        a: 1.0,
    };

    fn assert_view(shape: &Shape, w: f32, h: f32) {
        let text = format!("{shape:?}");
        assert!(
            text.contains(&format!("view_box: Some([{w:?}, {h:?}])")),
            "{text}"
        );
    }

    fn assert_finite(shape: &Shape) {
        let text = format!("{shape:?}");
        assert!(!text.contains("NaN"), "{text}");
        assert!(!text.contains("inf"), "{text}");
    }

    fn h_grid(w: f32, h: f32) -> Shape {
        Shape::new()
            .line(
                [0.0, h * 0.25],
                [w, h * 0.25],
                HAIRLINE,
                LineCap::Butt,
                GRID,
            )
            .line([0.0, h * 0.5], [w, h * 0.5], HAIRLINE, LineCap::Butt, GRID)
            .line(
                [0.0, h * 0.75],
                [w, h * 0.75],
                HAIRLINE,
                LineCap::Butt,
                GRID,
            )
    }

    fn hv_grid(w: f32, h: f32) -> Shape {
        h_grid(w, h)
            .line(
                [w * 0.25, 0.0],
                [w * 0.25, h],
                HAIRLINE,
                LineCap::Butt,
                GRID,
            )
            .line([w * 0.5, 0.0], [w * 0.5, h], HAIRLINE, LineCap::Butt, GRID)
            .line(
                [w * 0.75, 0.0],
                [w * 0.75, h],
                HAIRLINE,
                LineCap::Butt,
                GRID,
            )
    }

    fn wave(n: usize) -> Vec<f32> {
        (0..n)
            .map(|i| ((i as f32) * 0.08).sin() * 35.0 + 50.0)
            .collect()
    }

    #[test]
    fn area_line_chart_geometry_and_edge_cases() {
        let empty = area_line_chart(&[], 0.0, 100.0, LINE, 0.3, GRID, 40.0, 40.0);
        assert_eq!(empty, h_grid(40.0, 40.0).view_box(40.0, 40.0));
        assert_view(&empty, 40.0, 40.0);

        let single = area_line_chart(&[50.0], 0.0, 100.0, LINE, 0.3, GRID, 40.0, 40.0);
        let single_curve = vec![[0.0, 20.0], [40.0, 20.0]];
        let expected_single = h_grid(40.0, 40.0)
            .fill(
                vec![[0.0, 20.0], [40.0, 20.0], [40.0, 40.0], [0.0, 40.0]],
                LINE.alpha(0.3),
            )
            .stroke(single_curve, SERIES_STROKE, LINE)
            .view_box(40.0, 40.0);
        assert_eq!(single, expected_single);

        let ramp = area_line_chart(&[0.0, 100.0], 0.0, 100.0, LINE, 0.3, GRID, 40.0, 40.0);
        let expected_ramp = h_grid(40.0, 40.0)
            .fill(
                vec![[0.0, 40.0], [40.0, 0.0], [40.0, 40.0]],
                LINE.alpha(0.3),
            )
            .stroke(vec![[0.0, 40.0], [40.0, 0.0]], SERIES_STROKE, LINE)
            .view_box(40.0, 40.0);
        assert_eq!(ramp, expected_ramp);

        let zeros = [0.0; 8];
        let flat = area_line_chart(&zeros, 0.0, 100.0, LINE, 0.4, GRID, 80.0, 40.0);
        let flat_pts: Vec<[f32; 2]> = (0..8).map(|i| [80.0 * i as f32 / 7.0, 40.0]).collect();
        assert_eq!(
            flat,
            h_grid(80.0, 40.0)
                .stroke(flat_pts, SERIES_STROKE, LINE)
                .view_box(80.0, 40.0)
        );

        let infinite = area_line_chart(&[f32::INFINITY], 0.0, 100.0, LINE, 0.25, GRID, 20.0, 10.0);
        assert_eq!(
            infinite,
            h_grid(20.0, 10.0)
                .fill(
                    vec![[0.0, 0.0], [20.0, 0.0], [20.0, 10.0], [0.0, 10.0]],
                    LINE.alpha(0.25)
                )
                .stroke(vec![[0.0, 0.0], [20.0, 0.0]], SERIES_STROKE, LINE)
                .view_box(20.0, 10.0)
        );

        let missing = area_line_chart(
            &[f32::NAN, f32::NAN],
            0.0,
            100.0,
            LINE,
            0.3,
            GRID,
            30.0,
            12.0,
        );
        assert_eq!(
            missing,
            h_grid(30.0, 12.0)
                .stroke(vec![[0.0, 12.0], [30.0, 12.0]], SERIES_STROKE, LINE)
                .view_box(30.0, 12.0)
        );

        let held = area_line_chart(
            &[10.0, f32::NAN, 90.0],
            0.0,
            100.0,
            LINE,
            0.2,
            GRID,
            20.0,
            10.0,
        );
        assert_finite(&held);
        assert_ne!(held, h_grid(20.0, 10.0).view_box(20.0, 10.0));

        let samples = wave(240);
        let full = area_line_chart(&samples, 0.0, 100.0, LINE, 0.25, GRID, 240.0, 64.0);
        assert!(!full.is_empty());
        assert_view(&full, 240.0, 64.0);
        assert_finite(&full);

        let mut nasty = samples.clone();
        nasty[0] = f32::NAN;
        nasty[3] = f32::INFINITY;
        nasty[120] = f32::NEG_INFINITY;
        let dirty = area_line_chart(&nasty, 0.0, 100.0, LINE, f32::NAN, GRID, 240.0, 64.0);
        assert_finite(&dirty);
        assert!(!dirty.is_empty());

        assert!(area_line_chart(&samples, 0.0, 100.0, LINE, 0.2, GRID, 0.0, 10.0).is_empty());
        assert!(
            !area_line_chart(&samples, f32::NAN, f32::NAN, LINE, 0.2, GRID, 40.0, 20.0).is_empty()
        );
    }

    #[test]
    fn multi_series_chart_overlays_and_survives_bad_samples() {
        let empty = multi_series_chart(&[], 0.0, 100.0, GRID, 40.0, 20.0);
        assert_eq!(empty, hv_grid(40.0, 20.0).view_box(40.0, 20.0));

        let blank = [Series {
            values: &[],
            color: LINE,
            fill_alpha: 0.4,
            width: 1.2,
        }];
        assert_eq!(
            multi_series_chart(&blank, 0.0, 100.0, GRID, 40.0, 20.0),
            empty
        );

        let cores = [50.0, 100.0];
        let one = [Series {
            values: &cores,
            color: LINE,
            fill_alpha: 0.25,
            width: 1.4,
        }];
        let chart = multi_series_chart(&one, 0.0, 100.0, GRID, 40.0, 20.0);
        let expected = hv_grid(40.0, 20.0)
            .fill(
                vec![[0.0, 10.0], [40.0, 0.0], [40.0, 20.0], [0.0, 20.0]],
                LINE.alpha(0.25),
            )
            .stroke(vec![[0.0, 10.0], [40.0, 0.0]], 1.4, LINE)
            .view_box(40.0, 20.0);
        assert_eq!(chart, expected);

        let zeros = [0.0; 4];
        let flat = [Series {
            values: &zeros,
            color: FILL,
            fill_alpha: 0.5,
            width: 1.0,
        }];
        let flat_chart = multi_series_chart(&flat, 0.0, 100.0, GRID, 30.0, 10.0);
        let pts: Vec<[f32; 2]> = (0..4).map(|i| [30.0 * i as f32 / 3.0, 10.0]).collect();
        assert_eq!(
            flat_chart,
            hv_grid(30.0, 10.0)
                .stroke(pts, 1.0, FILL)
                .view_box(30.0, 10.0)
        );

        let a = [f32::NAN];
        let b = [f32::INFINITY, f32::NEG_INFINITY];
        let messy = [
            Series {
                values: &a,
                color: LINE,
                fill_alpha: 0.2,
                width: 1.0,
            },
            Series {
                values: &b,
                color: FILL,
                fill_alpha: 0.2,
                width: 1.2,
            },
        ];
        let messy_chart = multi_series_chart(&messy, 0.0, 100.0, GRID, 48.0, 24.0);
        assert_finite(&messy_chart);
        assert_view(&messy_chart, 48.0, 24.0);

        let left = wave(240);
        let right: Vec<f32> = left.iter().map(|v| 100.0 - v).collect();
        let both = [
            Series {
                values: &left,
                color: LINE,
                fill_alpha: 0.15,
                width: 1.3,
            },
            Series {
                values: &right,
                color: FILL,
                fill_alpha: 0.15,
                width: 1.3,
            },
        ];
        let full = multi_series_chart(&both, 0.0, 100.0, GRID, 240.0, 80.0);
        assert!(!full.is_empty());
        assert_view(&full, 240.0, 80.0);
        assert_finite(&full);
        assert!(multi_series_chart(&both, 0.0, 100.0, GRID, f32::NAN, 10.0).is_empty());
    }

    #[test]
    fn dual_mirror_chart_scales_from_a_1kib_floor() {
        let (idle, peak) = dual_mirror_chart(&[], &[], TOP, BOTTOM, GRID, 80.0, 40.0);
        assert_eq!(peak, 1024.0);
        assert_eq!(
            idle,
            Shape::new()
                .line([0.0, 20.0], [80.0, 20.0], HAIRLINE, LineCap::Butt, GRID)
                .view_box(80.0, 40.0)
        );

        let (low, low_peak) = dual_mirror_chart(&[512.0], &[-20.0], TOP, BOTTOM, GRID, 80.0, 40.0);
        assert_eq!(low_peak, 1024.0);
        assert_finite(&low);

        let (full, full_peak) = dual_mirror_chart(&[1024.0], &[], TOP, BOTTOM, GRID, 80.0, 40.0);
        assert_eq!(full_peak, 1024.0);
        assert_eq!(
            full,
            Shape::new()
                .line([0.0, 20.0], [80.0, 20.0], HAIRLINE, LineCap::Butt, GRID)
                .fill(
                    vec![[0.0, 0.0], [80.0, 0.0], [80.0, 20.0], [0.0, 20.0]],
                    TOP.alpha(MIRROR_FILL)
                )
                .stroke(vec![[0.0, 0.0], [80.0, 0.0]], SERIES_STROKE, TOP)
                .view_box(80.0, 40.0)
        );

        let (scaled, scaled_peak) =
            dual_mirror_chart(&[512.0, f64::NAN], &[2048.0], TOP, BOTTOM, GRID, 40.0, 20.0);
        assert_eq!(scaled_peak, 2048.0);
        assert_finite(&scaled);
        assert_view(&scaled, 40.0, 20.0);

        let zeros = vec![0.0; 6];
        let (flat, flat_peak) = dual_mirror_chart(&zeros, &zeros, TOP, BOTTOM, GRID, 60.0, 30.0);
        assert_eq!(flat_peak, 1024.0);
        assert!(!flat.is_empty());
        assert_finite(&flat);

        let top: Vec<f64> = (0..240).map(|i| (i as f64) * 50.0).collect();
        let mut bottom = top.clone();
        bottom[4] = f64::NAN;
        bottom[9] = f64::INFINITY;
        bottom[200] = f64::NEG_INFINITY;
        let (busy, busy_peak) = dual_mirror_chart(&top, &bottom, TOP, BOTTOM, GRID, 240.0, 96.0);
        assert_eq!(busy_peak, 239.0 * 50.0);
        assert_view(&busy, 240.0, 96.0);
        assert_finite(&busy);

        let (broken, broken_peak) = dual_mirror_chart(
            &[f64::NAN, f64::INFINITY],
            &[],
            TOP,
            BOTTOM,
            GRID,
            10.0,
            8.0,
        );
        assert_eq!(broken_peak, 1024.0);
        assert_finite(&broken);
        assert!(
            dual_mirror_chart(&top, &bottom, TOP, BOTTOM, GRID, -1.0, 8.0)
                .0
                .is_empty()
        );
    }

    #[test]
    fn meter_bar_clamps_and_sparkline_handles_sparse_input() {
        assert!(meter_bar_shape(50.0, TRACK, FILL, 0.0, 8.0).is_empty());

        assert_eq!(
            meter_bar_shape(0.0, TRACK, FILL, 100.0, 8.0),
            Shape::new()
                .fill(
                    vec![[0.0, 0.0], [100.0, 0.0], [100.0, 8.0], [0.0, 8.0]],
                    TRACK
                )
                .view_box(100.0, 8.0)
        );
        assert_eq!(
            meter_bar_shape(f32::NAN, TRACK, FILL, 100.0, 8.0),
            meter_bar_shape(0.0, TRACK, FILL, 100.0, 8.0)
        );
        assert_eq!(
            meter_bar_shape(-20.0, TRACK, FILL, 100.0, 8.0),
            meter_bar_shape(0.0, TRACK, FILL, 100.0, 8.0)
        );

        let half = meter_bar_shape(50.0, TRACK, FILL, 100.0, 8.0);
        assert_eq!(
            half,
            Shape::new()
                .fill(
                    vec![[0.0, 0.0], [100.0, 0.0], [100.0, 8.0], [0.0, 8.0]],
                    TRACK
                )
                .fill(vec![[0.0, 0.0], [50.0, 0.0], [50.0, 8.0], [0.0, 8.0]], FILL)
                .view_box(100.0, 8.0)
        );
        assert_view(&half, 100.0, 8.0);

        let full = meter_bar_shape(f32::INFINITY, TRACK, FILL, 100.0, 8.0);
        assert_eq!(full, meter_bar_shape(100.0, TRACK, FILL, 100.0, 8.0));
        assert_eq!(meter_bar_shape(140.0, TRACK, FILL, 100.0, 8.0), full);
        assert_finite(&full);

        let empty = sparkline_shape(&[], LINE, 20.0, 8.0);
        assert_eq!(empty, Shape::new().view_box(20.0, 8.0));
        assert!(empty.is_empty());
        assert_view(&empty, 20.0, 8.0);

        let flat = sparkline_shape(&[0.0, 0.0, 0.0], LINE, 20.0, 8.0);
        assert_eq!(
            flat,
            Shape::new()
                .stroke(vec![[0.0, 4.0], [20.0, 4.0]], SPARK_STROKE, LINE)
                .view_box(20.0, 8.0)
        );
        assert_eq!(
            sparkline_shape(&[f32::NAN, f32::INFINITY], LINE, 20.0, 8.0),
            flat
        );
        assert_eq!(
            sparkline_shape(&[7.0], LINE, 20.0, 8.0),
            sparkline_shape(&[7.0, 7.0], LINE, 20.0, 8.0)
        );

        let peak = sparkline_shape(&[0.0, 1.0, 0.0], LINE, 20.0, 10.0);
        let pts = vec![[0.0, 10.0], [10.0, 0.0], [20.0, 10.0]];
        assert_eq!(
            peak,
            Shape::new()
                .fill(pts.clone(), LINE.alpha(SPARK_FILL))
                .stroke(pts, SPARK_STROKE, LINE)
                .view_box(20.0, 10.0)
        );

        let samples = wave(240);
        let badge = sparkline_shape(&samples, LINE, 96.0, 16.0);
        assert!(!badge.is_empty());
        assert_view(&badge, 96.0, 16.0);
        assert_finite(&badge);

        let mut dirty = samples.clone();
        dirty[1] = f32::NAN;
        dirty[80] = f32::INFINITY;
        dirty[200] = f32::NEG_INFINITY;
        let dirty_badge = sparkline_shape(&dirty, FILL, 96.0, 16.0);
        assert_finite(&dirty_badge);
        assert_view(&dirty_badge, 96.0, 16.0);
        assert!(sparkline_shape(&samples, LINE, 10.0, f32::NAN).is_empty());
    }

    #[test]
    fn tree_connector_shape_spans_full_row_height_and_wraps_depth_colors() {
        let palette = [LINE, FILL];
        assert_eq!(tree_connector_shape("", 24.0, &palette), None);
        assert_eq!(tree_connector_shape("├─ ", 0.0, &palette), None);
        assert_eq!(tree_connector_shape("├─ ", f32::NAN, &palette), None);

        let (tee, tee_w) = tree_connector_shape("├─ ", 24.0, &palette).expect("tee");
        assert_eq!(tee_w, 18.0);
        assert_eq!(
            tee,
            Shape::new()
                .line(
                    [6.0, 0.0],
                    [6.0, 24.0],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA)
                )
                .line(
                    [6.0, 12.0],
                    [14.0, 12.0],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA),
                )
                .view_box(18.0, 24.0)
        );

        let (elbow, elbow_w) = tree_connector_shape("└─ ", 24.0, &palette).expect("elbow");
        assert_eq!(elbow_w, 18.0);
        assert_eq!(
            elbow,
            Shape::new()
                .line(
                    [6.0, 0.0],
                    [6.0, 12.8],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA),
                )
                .line(
                    [6.0, 12.0],
                    [14.0, 12.0],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA),
                )
                .view_box(18.0, 24.0)
        );

        let (nested, nested_w) = tree_connector_shape("│     └─ ", 24.0, &palette).expect("nested");
        assert_eq!(nested_w, 46.0);
        assert_eq!(
            nested,
            Shape::new()
                .line(
                    [6.0, 0.0],
                    [6.0, 24.0],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA)
                )
                .line(
                    [34.0, 0.0],
                    [34.0, 12.8],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA),
                )
                .line(
                    [34.0, 12.0],
                    [42.0, 12.0],
                    TREE_STROKE,
                    LineCap::Butt,
                    LINE.alpha(TREE_ALPHA),
                )
                .view_box(46.0, 24.0)
        );
        assert_finite(&nested);

        let (fallback, fallback_w) =
            tree_connector_shape("│  ", 24.0, &[]).expect("empty color slice fallback");
        assert_eq!(fallback_w, 18.0);
        assert!(!fallback.is_empty());
    }

    #[test]
    fn sparkline_chart_and_hover_cursor_render_finite_geometry() {
        let empty = sparkline_chart(&[], LINE, GRID, 120.0, 28.0);
        assert!(!empty.is_empty());
        assert_view(&empty, 120.0, 28.0);
        assert_finite(&empty);

        let varied = sparkline_chart(&[5.0, 42.0, 18.0, 77.0], LINE, GRID, 120.0, 28.0);
        assert_ne!(varied, empty);
        assert_view(&varied, 120.0, 28.0);
        assert_finite(&varied);
        assert!(sparkline_chart(&[1.0, 2.0], LINE, GRID, 0.0, 28.0).is_empty());

        let untouched = with_hover_cursor(varied.clone(), None, FILL, 120.0, 28.0);
        assert_eq!(untouched, varied);
        let hovered = with_hover_cursor(varied.clone(), Some(0.5), FILL, 120.0, 28.0);
        assert_ne!(hovered, varied);
        assert_view(&hovered, 120.0, 28.0);
        assert_finite(&hovered);
    }
}
