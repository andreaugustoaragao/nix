//! Headless `Runtime` coverage for Vitals.

use std::thread;
use std::time::{Duration, Instant};

use rune::{App, Cursor, ElementInfo, Env, Key, KeyEvent, Mods, Runtime};

use crate::collector::LinuxCollector;
use crate::model::{
    FileKindFilter, OpenFileKind, PaneId, SignalKind, SocketKindFilter, format_bytes,
};
use crate::state::{
    CardId, ChartKind, DEFAULT_COL_SPLITS, DEFAULT_ROW_SPLITS, ElevationState, LayoutPreset, State,
};
use crate::theme::{AppearanceMode, ColorSchemeId};
use crate::ui;

fn boot() -> Runtime<State> {
    let mut runtime = App::new(ui::spec()).headless_runtime((1360.0, 880.0), Env::new(true, 1.0));
    runtime.frame(0.0);
    runtime.frame(0.0);
    runtime
}

fn click(runtime: &mut Runtime<State>, key: &str) {
    let Some((x, y)) = runtime.find(key) else {
        let keys = keys_of(runtime);
        panic!("missing {key}; have {keys:?}");
    };
    runtime.pointer_down(x, y);
    runtime.pointer_up(x, y);
    runtime.frame(0.0);
}

fn keys_of(runtime: &Runtime<State>) -> Vec<String> {
    runtime
        .elements()
        .into_iter()
        .filter_map(|element| element.key)
        .collect()
}

fn texts(runtime: &Runtime<State>) -> Vec<String> {
    runtime
        .elements()
        .into_iter()
        .filter_map(|element| element.text)
        .collect()
}

fn element_label(runtime: &Runtime<State>, key: &str) -> String {
    runtime
        .elements()
        .into_iter()
        .find(|element| element.key.as_deref() == Some(key))
        .and_then(|element| element.label)
        .unwrap_or_else(|| panic!("missing label for {key}"))
}

fn assert_laid_out(runtime: &Runtime<State>, key: &str) {
    assert!(runtime.find(key).is_some(), "missing {key}");
    let (rect, _) = runtime
        .presented(key)
        .unwrap_or_else(|| panic!("no box for {key}"));
    assert!(
        rect[2] > 1.0 && rect[3] > 1.0,
        "{key} collapsed to {rect:?}"
    );
}

fn assert_absent(runtime: &Runtime<State>, key: &str) {
    assert!(runtime.find(key).is_none(), "{key} still present");
}

fn proc_rows(runtime: &Runtime<State>) -> Vec<String> {
    runtime
        .elements()
        .into_iter()
        .filter_map(proc_row_key)
        .collect()
}

fn proc_row_key(element: ElementInfo) -> Option<String> {
    let key = element.key?;
    key.starts_with("proc-row-").then_some(key)
}

fn press_text(runtime: &mut Runtime<State>, text: &str) {
    runtime.key(KeyEvent::from(Key::Text(text.to_string())));
    runtime.frame(0.0);
}

#[test]
fn spec_names_the_monitor_scenes() {
    let spec = ui::spec();
    assert_eq!(spec.title, "Vitals — System Monitor");
    assert_eq!(spec.size, (1360.0, 880.0));
    assert_eq!(spec.min_size, Some((900.0, 600.0)));
    assert!(spec.poll.is_some());
    assert!(spec.on_key.is_some());
    let names: Vec<_> = spec.scenes.iter().map(|(name, _)| *name).collect();
    assert_eq!(names, ["dark", "light", "cpu", "processes"]);
}

#[test]
fn overview_renders_the_five_panels() {
    let runtime = boot();
    assert_eq!(runtime.state.pane, PaneId::Overview);
    for key in [
        "toolbar",
        "workspace",
        "footer",
        "cpu-panel",
        "memory-panel",
        "network-panel",
        "disks-panel",
        "processes-panel",
        "process-inspector",
        "process-stream",
        "search",
    ] {
        assert_laid_out(&runtime, key);
    }
    let lines = texts(&runtime);
    assert!(lines.iter().any(|line| line == "vitals"), "{lines:?}");
    assert_eq!(runtime.state.snapshot.hostname, "rune-node");
    assert_eq!(element_label(&runtime, "tab-overview"), "Overview [1]");
    assert_eq!(element_label(&runtime, "tab-files"), "Files [7]");
    assert!(
        lines.iter().any(|line| line.contains("1-7 panes")),
        "{lines:?}"
    );
    assert!(lines.iter().any(|line| line.contains("60s")), "{lines:?}");
    assert!(lines.iter().any(|line| line == "1s"), "{lines:?}");
    assert_eq!(element_label(&runtime, "btn-freeze"), "Live");
    assert_eq!(element_label(&runtime, "btn-theme"), "Auto · Dark");
    assert_eq!(element_label(&runtime, "btn-layout"), "Layout: 3×2 Grid");
    assert_eq!(element_label(&runtime, "btn-elevate-top"), "Elevate");
    assert_eq!(element_label(&runtime, "btn-help"), "Help [?]");
    assert_eq!(element_label(&runtime, "btn-settings"), "Settings [,]");
    assert!(runtime.find("btn-freeze").is_some());
    for key in [
        "btn-layout",
        "btn-elevate-top",
        "btn-freeze",
        "btn-theme",
        "btn-help",
        "btn-settings",
    ] {
        let (rect, _) = runtime.presented(key).unwrap_or_else(|| panic!("{key}"));
        assert!(
            (rect[2] - 26.0).abs() < 1.0 && (rect[3] - 26.0).abs() < 1.0,
            "{key} should be a 26×26 icon button, got {rect:?}"
        );
    }
    assert!(
        !proc_rows(&runtime).is_empty(),
        "process rows were not mounted"
    );
}

#[test]
fn tabs_switch_views() {
    let mut runtime = boot();

    click(&mut runtime, "tab-cpu");
    assert_eq!(runtime.state.pane, PaneId::Cpu);
    assert_laid_out(&runtime, "cpu-panel");
    for key in [
        "memory-panel",
        "network-panel",
        "disks-panel",
        "processes-panel",
        "process-inspector",
    ] {
        assert_absent(&runtime, key);
    }
    let (cpu_rect, _) = runtime.presented("cpu-panel").unwrap();
    assert!(
        cpu_rect[3] > 400.0,
        "zoomed cpu panel is short: {cpu_rect:?}"
    );

    click(&mut runtime, "tab-memory");
    assert_eq!(runtime.state.pane, PaneId::Memory);
    assert_laid_out(&runtime, "memory-panel");
    assert_absent(&runtime, "cpu-panel");
    assert_absent(&runtime, "processes-panel");

    click(&mut runtime, "tab-network");
    assert_eq!(runtime.state.pane, PaneId::Network);
    assert_laid_out(&runtime, "network-panel");
    assert_absent(&runtime, "memory-panel");
    assert_absent(&runtime, "disks-panel");

    click(&mut runtime, "tab-disks");
    assert_eq!(runtime.state.pane, PaneId::Disks);
    assert_laid_out(&runtime, "disks-panel");
    assert_absent(&runtime, "network-panel");
    assert_absent(&runtime, "cpu-panel");

    click(&mut runtime, "tab-processes");
    assert_eq!(runtime.state.pane, PaneId::Processes);
    assert_laid_out(&runtime, "processes-panel");
    assert_laid_out(&runtime, "process-inspector");
    assert_absent(&runtime, "cpu-panel");
    assert_absent(&runtime, "disks-panel");

    click(&mut runtime, "tab-overview");
    assert_eq!(runtime.state.pane, PaneId::Overview);
    for key in [
        "cpu-panel",
        "memory-panel",
        "network-panel",
        "disks-panel",
        "processes-panel",
        "process-inspector",
    ] {
        assert_laid_out(&runtime, key);
    }
}

#[test]
fn tab_icons_are_labeled_and_switch_panes() {
    for icon in [
        &ui::OVERVIEW_ICON,
        &ui::CPU_ICON,
        &ui::MEMORY_ICON,
        &ui::NETWORK_ICON,
        &ui::DISKS_ICON,
        &ui::PROCESSES_ICON,
        &ui::FILES_ICON,
    ] {
        let coverage = rune::text::icon_coverage(icon, 24);
        assert_eq!(coverage.len(), 24 * 24, "{}", icon.name);
        assert!(
            coverage.iter().any(|pixel| *pixel > 0),
            "{} rasterized empty",
            icon.name
        );
    }

    let mut runtime = boot();
    let tabs = [
        ("tab-overview", "Overview [1]", PaneId::Overview),
        ("tab-cpu", "CPU [2]", PaneId::Cpu),
        ("tab-memory", "Memory [3]", PaneId::Memory),
        ("tab-network", "Network [4]", PaneId::Network),
        ("tab-disks", "Disks [5]", PaneId::Disks),
        ("tab-processes", "Processes [6]", PaneId::Processes),
        ("tab-files", "Files [7]", PaneId::Files),
    ];
    for (key, label, pane) in tabs {
        assert_eq!(element_label(&runtime, key), label);
        click(&mut runtime, key);
        assert_eq!(runtime.state.pane, pane, "{key}");
    }
}

#[test]
fn network_view_filters_sockets_by_kind_and_query() {
    let mut runtime = boot();
    click(&mut runtime, "tab-network");
    runtime.frame(0.35);
    assert_eq!(runtime.state.pane, PaneId::Network);
    assert_eq!(runtime.state.socket_filter, SocketKindFilter::All);
    assert_eq!(
        runtime.state.socket_rows.len(),
        runtime.state.snapshot.sockets.len()
    );
    for key in [
        "sock-kind-all",
        "sock-kind-listen",
        "sock-kind-estab",
        "sock-kind-tcp",
        "sock-kind-udp",
        "search",
    ] {
        assert_laid_out(&runtime, key);
    }
    let lines = texts(&runtime);
    assert!(
        lines.iter().any(|line| line.starts_with("Sockets (")),
        "{lines:?}"
    );
    assert!(
        lines
            .iter()
            .any(|line| line.contains(" / ") && line.contains("sockets")),
        "{lines:?}"
    );

    click(&mut runtime, "sock-kind-listen");
    assert_eq!(runtime.state.socket_filter, SocketKindFilter::Listen);
    assert!(!runtime.state.socket_rows.is_empty());
    assert!(runtime.state.socket_rows.iter().all(|sock| {
        sock.state.eq_ignore_ascii_case("LISTEN") || sock.state.eq_ignore_ascii_case("UNCONN")
    }));

    click(&mut runtime, "sock-kind-estab");
    assert_eq!(runtime.state.socket_filter, SocketKindFilter::Established);
    assert!(runtime.state.socket_rows.iter().all(|sock| {
        sock.state.eq_ignore_ascii_case("ESTAB")
            || sock.state.eq_ignore_ascii_case("ESTABLISHED")
    }));
    assert!(runtime.state.socket_rows.len() < runtime.state.snapshot.sockets.len());

    click(&mut runtime, "sock-kind-tcp");
    assert!(
        runtime
            .state
            .socket_rows
            .iter()
            .all(|sock| sock.proto.starts_with("TCP"))
    );

    click(&mut runtime, "sock-kind-udp");
    assert_eq!(runtime.state.socket_filter, SocketKindFilter::Udp);
    assert!(runtime.state.socket_rows.is_empty());
    assert!(
        texts(&runtime)
            .iter()
            .any(|line| line == "No matching sockets"),
        "{:?}",
        texts(&runtime)
    );

    click(&mut runtime, "sock-kind-all");
    assert_eq!(
        runtime.state.socket_rows.len(),
        runtime.state.snapshot.sockets.len()
    );

    press_text(&mut runtime, "/");
    for ch in ["5", "4", "3", "2"] {
        press_text(&mut runtime, ch);
    }
    assert_eq!(runtime.state.query.text, "5432");
    assert!(!runtime.state.socket_rows.is_empty());
    assert!(runtime.state.socket_rows.iter().all(|sock| {
        sock.local_addr.to_lowercase().contains("5432")
            || sock.remote_addr.to_lowercase().contains("5432")
            || sock.state.to_lowercase().contains("5432")
            || sock.proto.to_lowercase().contains("5432")
            || sock.process.to_lowercase().contains("5432")
            || sock.pid.is_some_and(|pid| pid.to_string().contains("5432"))
    }));
    click(&mut runtime, "sock-row-0");
    assert_eq!(runtime.state.selected_pid, Some(700));

    click(&mut runtime, "clear-search");
    assert!(runtime.state.query.text.is_empty());
    assert_eq!(
        runtime.state.socket_rows.len(),
        runtime.state.snapshot.sockets.len()
    );
}

#[test]
fn modes_and_column_headers_update_process_rows() {
    let mut runtime = boot();
    let table = proc_rows(&runtime);
    assert!(!table.is_empty(), "table rows missing");

    click(&mut runtime, "mode-tree");
    assert_eq!(runtime.state.process_mode, crate::model::ProcessMode::Tree);
    let tree = proc_rows(&runtime);
    assert_ne!(tree, table, "tree did not change the mounted rows");
    assert!(
        runtime
            .state
            .rows
            .iter()
            .any(|row| row.depth > 0
                && (row.tree_prefix.contains('├') || row.tree_prefix.contains('└'))),
        "tree row hierarchy prefixes missing from state.rows"
    );
    let guide_keys: Vec<String> = keys_of(&runtime)
        .into_iter()
        .filter(|key| key.starts_with("tree-guide-"))
        .collect();
    assert!(
        !guide_keys.is_empty(),
        "vector tree-guide-* canvases missing"
    );
    for key in &guide_keys {
        let (rect, _) = runtime.presented(key).expect("tree guide box");
        assert!(
            rect[2] >= 17.5 && (rect[3] - 24.0).abs() < 0.5,
            "{key} must span full 24px row height, got {rect:?}"
        );
    }
    // Verify consecutive child rows have 0px vertical gap between their tree-guide canvases.
    let mut guide_rects: Vec<[f32; 4]> = guide_keys
        .iter()
        .filter_map(|key| runtime.presented(key).map(|(r, _)| r))
        .collect();
    guide_rects.sort_by(|a, b| a[1].total_cmp(&b[1]));
    assert!(
        guide_rects
            .windows(2)
            .any(|pair| (pair[1][1] - (pair[0][1] + pair[0][3])).abs() < 0.5),
        "expected adjacent tree-guide canvases to connect vertically with 0px gap: {guide_rects:?}"
    );
    let tree_text = texts(&runtime);
    assert!(
        tree_text
            .iter()
            .all(|line| !line.contains('├') && !line.contains('└') && !line.contains('│')),
        "disconnected font glyphs should be replaced by vector tree guides: {tree_text:?}"
    );

    click(&mut runtime, "mode-grouped");
    assert_eq!(
        runtime.state.process_mode,
        crate::model::ProcessMode::Grouped
    );
    let grouped = proc_rows(&runtime);
    assert_ne!(grouped, tree, "grouped did not change the mounted rows");
    let grouped_text = texts(&runtime);
    assert!(
        grouped_text.iter().any(|line| line.contains('×')),
        "grouped counts missing from {grouped_text:?}"
    );

    click(&mut runtime, "sort-mem");
    assert_eq!(runtime.state.sort_col, crate::model::SortColumn::Mem);
    let by_mem = proc_rows(&runtime);
    assert_ne!(by_mem, grouped, "sort-mem left the mounted rows unchanged");
    assert!(
        texts(&runtime)
            .iter()
            .any(|line| line.contains("Mem ▼") || line.contains("Mem ▲")),
        "mem header has no sort mark"
    );

    click(&mut runtime, "sort-pid");
    assert_eq!(runtime.state.sort_col, crate::model::SortColumn::Pid);
    let by_pid = proc_rows(&runtime);
    assert_ne!(by_pid, by_mem, "sort-pid left the mounted rows unchanged");

    click(&mut runtime, "sort-name");
    assert_eq!(runtime.state.sort_col, crate::model::SortColumn::Name);
    let by_name = proc_rows(&runtime);
    assert_ne!(by_name, by_pid, "sort-name left the mounted rows unchanged");
}

#[test]
fn search_filters_the_rendered_rows() {
    let mut runtime = boot();
    press_text(&mut runtime, "/");
    assert!(runtime.state.searching, "slash did not focus search");
    assert!(runtime.state.query.focused);
    for ch in ["n", "g", "i", "n", "x"] {
        press_text(&mut runtime, ch);
    }
    runtime.key(KeyEvent::from(Key::Escape));
    runtime.frame(0.0);

    assert_eq!(runtime.state.query.text, "nginx");
    assert!(!runtime.state.query.focused);
    assert!(
        runtime
            .state
            .rows
            .iter()
            .all(|row| row.display_name == "nginx")
    );
    assert!(!runtime.state.rows.is_empty());
    for row in &runtime.state.rows {
        assert_laid_out(&runtime, &format!("proc-row-{}", row.pid));
    }
    let rustc = runtime
        .state
        .snapshot
        .processes
        .iter()
        .find(|proc| proc.name == "rustc")
        .expect("fixture rustc");
    assert!(runtime.find(&format!("proc-row-{}", rustc.pid)).is_none());
    let lines = texts(&runtime);
    assert!(lines.iter().any(|line| line.contains("nginx")), "{lines:?}");
    assert!(!lines.iter().any(|line| line == "systemd"), "{lines:?}");
}

#[test]
fn signal_dialog_kills_the_selected_process() {
    let mut runtime = boot();
    let selected = runtime.state.selected_pid.expect("a process is selected");
    assert!(
        selected > 1,
        "refusing to signal pid {selected} in the fixture"
    );

    click(&mut runtime, "btn-signal");
    assert_laid_out(&runtime, "signal-dialog");
    let dialog = runtime
        .state
        .signal_dialog
        .clone()
        .expect("signal dialog closed");
    assert_eq!(dialog.pid, selected);
    assert_eq!(dialog.signal, SignalKind::Term);
    assert!(
        texts(&runtime)
            .iter()
            .any(|line| line.contains(&format!("pid {selected}")))
    );

    click(&mut runtime, "sig-kill");
    let dialog = runtime
        .state
        .signal_dialog
        .clone()
        .expect("signal dialog closed");
    assert_eq!(dialog.signal, SignalKind::Kill);
    assert!(texts(&runtime).iter().any(|line| line.contains("SIGKILL")));

    click(&mut runtime, "confirm-signal");
    assert!(runtime.state.signal_dialog.is_none());
    assert_laid_out(&runtime, "status-banner");
    assert!(runtime.find("signal-dialog").is_none());
    assert!(
        runtime
            .state
            .snapshot
            .processes
            .iter()
            .all(|proc| proc.pid != selected)
    );
    assert!(runtime.find(&format!("proc-row-{selected}")).is_none());
    let banner = texts(&runtime);
    assert!(
        banner
            .iter()
            .any(|line| line.contains("SIGKILL") && line.contains(&selected.to_string())),
        "{banner:?}"
    );
}

#[test]
fn help_dialog_opens_and_closes() {
    let mut runtime = boot();
    assert!(runtime.find("help-dialog").is_none());
    click(&mut runtime, "btn-help");
    assert!(runtime.state.show_help);
    assert_laid_out(&runtime, "help-dialog");
    let lines = texts(&runtime);
    assert!(
        lines.iter().any(|line| line.contains("Keyboard shortcuts")),
        "{lines:?}"
    );
    assert!(
        lines.iter().any(|line| line.contains("Close [Esc]")),
        "{lines:?}"
    );
    assert!(
        lines
            .iter()
            .any(|line| line.contains("appearance mode and color scheme")),
        "{lines:?}"
    );
    assert!(
        lines.iter().any(|line| line.contains("Files [7]")),
        "{lines:?}"
    );

    click(&mut runtime, "close-help");
    assert!(!runtime.state.show_help);
    assert!(runtime.find("help-dialog").is_none());
}

#[test]
fn toolbar_controls_and_clear_search() {
    let mut runtime = boot();
    assert!(!runtime.state.frozen);
    assert_eq!(element_label(&runtime, "btn-freeze"), "Live");
    click(&mut runtime, "btn-freeze");
    assert!(runtime.state.frozen);
    assert_eq!(element_label(&runtime, "btn-freeze"), "Frozen");

    assert!(runtime.state.dark.is_none());
    assert_eq!(runtime.state.appearance_mode, AppearanceMode::System);
    assert_eq!(element_label(&runtime, "btn-theme"), "Auto · Dark");
    click(&mut runtime, "btn-theme");
    assert_eq!(runtime.state.appearance_mode, AppearanceMode::Dark);
    assert_eq!(runtime.state.dark, Some(true));
    assert_eq!(element_label(&runtime, "btn-theme"), "Dark");
    click(&mut runtime, "btn-theme");
    assert_eq!(runtime.state.appearance_mode, AppearanceMode::Light);
    assert_eq!(runtime.state.dark, Some(false));
    assert_eq!(element_label(&runtime, "btn-theme"), "Light");

    assert_eq!(runtime.state.time_window_secs, 60);
    click(&mut runtime, "btn-window");
    assert_eq!(runtime.state.time_window_secs, 120);
    assert!(texts(&runtime).iter().any(|line| line == "120s"));

    assert_eq!(runtime.state.poll_interval_ms, 1000);
    click(&mut runtime, "btn-rate");
    assert_eq!(runtime.state.poll_interval_ms, 2000);
    assert!(texts(&runtime).iter().any(|line| line == "2s"));

    press_text(&mut runtime, "/");
    for ch in ["n", "g", "i", "n", "x"] {
        press_text(&mut runtime, ch);
    }
    assert_eq!(runtime.state.query.text, "nginx");
    assert_laid_out(&runtime, "clear-search");
    assert!(texts(&runtime).iter().any(|line| line == "Clear"));
    click(&mut runtime, "clear-search");
    assert!(runtime.state.query.text.is_empty());
    assert!(runtime.find("clear-search").is_none());
    assert!(
        runtime
            .state
            .rows
            .iter()
            .any(|row| row.display_name != "nginx"),
        "clear-search left the process filter in place"
    );
}

#[test]
fn poll_frame_goes_idle_instead_of_animating() {
    let mut runtime = boot();
    let mut clock = 0.0;
    let mut idle = false;
    for _ in 0..30 {
        let dt = 1.0 / 60.0;
        if clock + dt >= 0.99 {
            break;
        }
        idle = !runtime.frame(dt);
        clock += dt;
        if idle {
            break;
        }
    }
    assert!(idle, "initial layout kept animating at clock {clock}");
    let gap = 0.99 - clock;
    if gap > 0.0 {
        assert!(
            !runtime.frame(gap),
            "settled window started animating before the next poll"
        );
    }
    let revision = runtime.state.revision;
    let poll_animating = runtime.frame(1.0 / 60.0);
    assert!(
        runtime.state.revision > revision,
        "State::poll did not advance telemetry"
    );
    assert!(
        !runtime.frame(1.0 / 60.0),
        "window kept animating after the poll frame (poll frame animating={poll_animating})"
    );
}

#[test]
fn live_sample_latency() {
    // A quiet host samples in about 2.5ms. A full `cargo test` shares `/proc`
    // with 60+ other tests, so a debug build's warm sample can sit well above
    // that. Keep the fastest of several passes, then allow 15ms of that
    // contention. The zoomed sample still has to stay under 2ms: it skips the
    // process walk.
    const ATTEMPTS: u32 = 8;
    const WARM_BUDGET: f64 = 0.015;
    let mut best_cold = Duration::from_secs(1);
    let mut best_warm = best_cold;
    let mut best_zoomed = best_cold;
    for attempt in 0..ATTEMPTS {
        let mut collector = LinuxCollector::new();
        let started = Instant::now();
        collector.sample().expect("cold sample");
        let cold = started.elapsed();
        let rounds = 4u32;
        let started = Instant::now();
        for _ in 0..rounds {
            collector.sample().expect("warm sample");
        }
        let warm = started.elapsed() / rounds;
        let started = Instant::now();
        for _ in 0..rounds {
            collector
                .sample_for(PaneId::Cpu, Some(1))
                .expect("zoomed sample");
        }
        let zoomed = started.elapsed() / rounds;
        if warm < best_warm {
            best_cold = cold;
            best_warm = warm;
            best_zoomed = zoomed;
        }
        if best_warm.as_secs_f64() < WARM_BUDGET {
            break;
        }
        if attempt + 1 < ATTEMPTS {
            thread::sleep(Duration::from_millis(40));
        }
    }
    eprintln!("LATENCY cold={best_cold:?} warm={best_warm:?} zoomed={best_zoomed:?}");
    assert!(
        best_warm.as_secs_f64() < WARM_BUDGET,
        "warm sample {best_warm:?} is slower than 15ms"
    );
    assert!(
        best_zoomed.as_secs_f64() < 0.002,
        "zoomed sample {best_zoomed:?} did not skip the process walk"
    );
}

fn press_key(runtime: &mut Runtime<State>, key: Key) {
    runtime.key(KeyEvent::from(key));
    runtime.frame(0.0);
}

#[test]
fn gear_icon_paints_a_cog() {
    let coverage = rune::text::icon_coverage(&ui::GEAR_ICON, 24);
    assert_eq!(coverage.len(), 24 * 24);
    assert!(
        coverage.iter().any(|pixel| *pixel > 0),
        "gear icon rasterized empty"
    );
}

#[test]
fn settings_dialog_switches_scheme_and_appearance() {
    let mut runtime = boot();
    assert!(runtime.find("settings-dialog").is_none());
    assert!(runtime.find("btn-settings").is_some());

    click(&mut runtime, "btn-settings");
    assert!(runtime.state.show_settings);
    assert_laid_out(&runtime, "settings-dialog");
    assert_laid_out(&runtime, "scheme-gruvbox");
    assert_laid_out(&runtime, "appearance-system");
    let lines = texts(&runtime);
    assert!(
        lines.iter().any(|line| line == "Appearance Mode"),
        "{lines:?}"
    );
    assert!(lines.iter().any(|line| line == "Color Scheme"), "{lines:?}");
    assert!(
        lines.iter().any(|line| line == "Monitor Preferences"),
        "{lines:?}"
    );
    assert!(
        lines.iter().any(|line| line.contains("System (Obsidian)")),
        "{lines:?}"
    );
    assert!(
        lines.iter().any(|line| line.contains("System prefers")),
        "{lines:?}"
    );
    let (reset, _) = runtime.presented("pref-reset").expect("reset chip");
    assert!(
        reset[1] + reset[3] < 870.0,
        "reset chip is off the window: {reset:?}"
    );

    click(&mut runtime, "scheme-gruvbox");
    assert_eq!(runtime.state.color_scheme, ColorSchemeId::Gruvbox);
    click(&mut runtime, "appearance-light");
    assert_eq!(runtime.state.appearance_mode, AppearanceMode::Light);
    assert_eq!(runtime.state.dark, Some(false));
    assert!(texts(&runtime).iter().any(|line| line == "Light"));

    click(&mut runtime, "pref-rate-5000");
    assert_eq!(runtime.state.poll_interval_ms, 5_000);
    click(&mut runtime, "pref-window-300");
    assert_eq!(runtime.state.time_window_secs, 300);
    click(&mut runtime, "pref-cpu-total");
    assert!(!runtime.state.per_core_chart);
    click(&mut runtime, "pref-loopback");
    assert!(runtime.state.show_loopback);
    click(&mut runtime, "pref-reset");
    assert_eq!(runtime.state.poll_interval_ms, 1_000);
    assert_eq!(runtime.state.time_window_secs, 60);
    assert!(runtime.state.per_core_chart);
    assert!(!runtime.state.show_loopback);
    assert_eq!(runtime.state.appearance_mode, AppearanceMode::System);
    assert_eq!(runtime.state.color_scheme, ColorSchemeId::Obsidian);

    click(&mut runtime, "close-settings");
    assert!(!runtime.state.show_settings);
    assert!(runtime.find("settings-dialog").is_none());

    press_text(&mut runtime, ",");
    assert!(runtime.state.show_settings);
    assert_laid_out(&runtime, "settings-dialog");
    press_key(&mut runtime, Key::Escape);
    assert!(!runtime.state.show_settings);

    press_text(&mut runtime, ",");
    assert!(runtime.state.show_settings);
    runtime.pointer_down(24.0, 400.0);
    runtime.pointer_up(24.0, 400.0);
    runtime.frame(0.0);
    assert!(
        !runtime.state.show_settings,
        "scrim click should dismiss settings"
    );
}

#[test]
fn settings_dialog_fits_the_minimum_window() {
    let mut runtime = boot();
    click(&mut runtime, "btn-settings");
    runtime.set_viewport((900.0, 600.0), 1.0);
    runtime.frame(0.0);

    let (dialog, _) = runtime.presented("settings-dialog").expect("dialog");
    assert!(
        dialog[0] >= -0.5 && dialog[1] >= -0.5,
        "dialog origin is outside the window: {dialog:?}"
    );
    assert!(
        dialog[0] + dialog[2] <= 900.5 && dialog[1] + dialog[3] <= 600.5,
        "dialog runs past the 900x600 window: {dialog:?}"
    );

    let (reset, _) = runtime.presented("pref-reset").expect("reset chip");
    assert!(
        reset[0] >= dialog[0] - 0.5 && reset[1] >= dialog[1] - 0.5,
        "reset chip starts outside the dialog: {reset:?} {dialog:?}"
    );
    assert!(
        reset[0] + reset[2] <= dialog[0] + dialog[2] + 0.5
            && reset[1] + reset[3] <= dialog[1] + dialog[3] + 0.5,
        "reset chip clips past the dialog: {reset:?} {dialog:?}"
    );
    assert!(
        reset[0] + reset[2] <= 900.5 && reset[1] + reset[3] <= 600.5,
        "reset chip clips past the window: {reset:?}"
    );
}

fn zoom_mods(shift: bool) -> Mods {
    Mods {
        shift,
        ctrl: true,
        cmd: true,
        ..Mods::default()
    }
}

fn press_zoom(runtime: &mut Runtime<State>, key: Key, shift: bool) {
    runtime.key(KeyEvent {
        key,
        mods: zoom_mods(shift),
    });
    runtime.frame(0.0);
    runtime.frame(0.0);
}

fn assert_stage_scale(runtime: &Runtime<State>) {
    let zoom = runtime.state.ui_zoom();
    let elements = runtime.elements();
    let viewport = elements
        .iter()
        .find(|element| element.key.as_deref() == Some("zoom-viewport"))
        .expect("zoom viewport");
    let stage = elements
        .iter()
        .find(|element| element.key.as_deref() == Some("zoom-stage"))
        .expect("zoom stage");
    let (vw, vh) = (viewport.target[2], viewport.target[3]);
    assert!(vw > 100.0 && vh > 100.0, "viewport {vw}x{vh}");
    let (expect_w, expect_h) = if runtime.state.ui_zoom_pct == 100 {
        (vw, vh)
    } else {
        (vw / zoom, vh / zoom)
    };
    assert!(
        (stage.target[2] - expect_w).abs() < 1.5 && (stage.target[3] - expect_h).abs() < 1.5,
        "stage {:?} expected {expect_w}x{expect_h} at zoom {zoom} (viewport {vw}x{vh})",
        stage.target
    );
    assert!(
        (stage.scale - zoom).abs() < 0.02,
        "stage scale {} expected {zoom}",
        stage.scale
    );
}

#[test]
fn ui_zoom_keys_and_controls_scale_the_stage() {
    let mut runtime = boot();
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    assert!(runtime.find("btn-zoom-reset").is_none());
    assert_stage_scale(&runtime);
    assert!(
        texts(&runtime)
            .iter()
            .any(|line| line.contains("Ctrl+Shift++/-/0")),
        "footer should mention UI zoom"
    );

    press_zoom(&mut runtime, Key::Command('='), true);
    assert_eq!(runtime.state.ui_zoom_pct, 110);
    assert_stage_scale(&runtime);
    press_zoom(&mut runtime, Key::Command('+'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 120);
    let zoom_label = texts(&runtime);
    assert!(
        zoom_label.iter().any(|line| line == "120%"),
        "{zoom_label:?}"
    );
    assert_laid_out(&runtime, "btn-zoom-reset");

    press_text(&mut runtime, "d");
    assert!(runtime.state.signal_dialog.is_some());
    press_zoom(&mut runtime, Key::Command('-'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 110);
    assert!(runtime.state.signal_dialog.is_some());
    press_key(&mut runtime, Key::Escape);
    assert!(runtime.state.signal_dialog.is_none());
    assert_eq!(runtime.state.ui_zoom_pct, 110);

    press_text(&mut runtime, "/");
    press_text(&mut runtime, "n");
    assert!(runtime.state.searching);
    assert_eq!(runtime.state.query.text, "n");
    press_zoom(&mut runtime, Key::Command('-'), true);
    press_zoom(&mut runtime, Key::Command('_'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 90);
    assert_eq!(runtime.state.query.text, "n");
    assert!(runtime.state.searching);
    assert_stage_scale(&runtime);
    press_zoom(&mut runtime, Key::Command('0'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    assert_eq!(runtime.state.query.text, "n");
    assert!(runtime.find("btn-zoom-reset").is_none());

    press_zoom(&mut runtime, Key::Command('+'), false);
    assert_eq!(runtime.state.ui_zoom_pct, 110);
    press_zoom(&mut runtime, Key::Command('0'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    press_zoom(&mut runtime, Key::Command('='), true);
    press_zoom(&mut runtime, Key::Command(')'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    press_zoom(&mut runtime, Key::Command(')'), false);
    assert_eq!(runtime.state.ui_zoom_pct, 100);

    for _ in 0..15 {
        press_zoom(&mut runtime, Key::Command('+'), true);
    }
    assert_eq!(runtime.state.ui_zoom_pct, 200);
    press_zoom(&mut runtime, Key::Command('='), true);
    assert_eq!(runtime.state.ui_zoom_pct, 200);
    assert!((runtime.state.ui_zoom() - 2.0).abs() < 0.001);
    assert_stage_scale(&runtime);
    for _ in 0..20 {
        press_zoom(&mut runtime, Key::Command('-'), true);
    }
    assert_eq!(runtime.state.ui_zoom_pct, 50);
    press_zoom(&mut runtime, Key::Command('_'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 50);
    assert!((runtime.state.ui_zoom() - 0.5).abs() < 0.001);
    assert_stage_scale(&runtime);

    press_zoom(&mut runtime, Key::Command('0'), true);
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    assert_eq!(runtime.state.query.text, "n");
    assert!(runtime.find("btn-zoom-reset").is_none());
    assert_stage_scale(&runtime);

    click(&mut runtime, "btn-settings");
    assert_laid_out(&runtime, "btn-zoom-in");
    assert_laid_out(&runtime, "btn-zoom-out");
    assert_laid_out(&runtime, "btn-zoom-normal");
    let lines = texts(&runtime);
    assert!(lines.iter().any(|line| line == "UI Zoom"), "{lines:?}");
    assert!(
        lines.iter().any(|line| line.contains("Ctrl+Shift++/-/0")),
        "{lines:?}"
    );

    click(&mut runtime, "btn-zoom-in");
    assert_eq!(runtime.state.ui_zoom_pct, 110);
    assert_stage_scale(&runtime);
    click(&mut runtime, "btn-zoom-in");
    assert_eq!(runtime.state.ui_zoom_pct, 120);
    click(&mut runtime, "btn-zoom-out");
    assert_eq!(runtime.state.ui_zoom_pct, 110);
    assert_stage_scale(&runtime);
    click(&mut runtime, "btn-zoom-normal");
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    assert_stage_scale(&runtime);

    click(&mut runtime, "btn-zoom-out");
    assert_eq!(runtime.state.ui_zoom_pct, 90);
    click(&mut runtime, "close-settings");
    assert_laid_out(&runtime, "btn-zoom-reset");
    click(&mut runtime, "btn-zoom-reset");
    assert_eq!(runtime.state.ui_zoom_pct, 100);
    assert!(runtime.find("btn-zoom-reset").is_none());
    assert_stage_scale(&runtime);
}

#[test]
fn elevation_buttons_and_s_toggle_all_users() {
    let mut runtime = boot();
    assert_eq!(runtime.state.elevation, ElevationState::Unprivileged);
    assert_laid_out(&runtime, "btn-elevate");
    assert_laid_out(&runtime, "btn-elevate-top");
    let lines = texts(&runtime);
    assert!(
        lines.iter().any(|line| line == "All Users [S]"),
        "{lines:?}"
    );
    assert_eq!(element_label(&runtime, "btn-elevate-top"), "Elevate");
    assert!(
        lines.iter().any(|line| line.contains("shown /")
            && line.contains("total")
            && !line.contains("all users")),
        "{lines:?}"
    );
    assert!(
        lines
            .iter()
            .any(|line| line.contains("S all users / elevate")),
        "{lines:?}"
    );

    click(&mut runtime, "btn-elevate");
    assert_eq!(runtime.state.elevation, ElevationState::Elevated);
    let lines = texts(&runtime);
    assert!(
        lines.iter().any(|line| line == "All Users · Root [S]"),
        "{lines:?}"
    );
    assert_eq!(element_label(&runtime, "btn-elevate-top"), "Root");
    assert!(
        lines.iter().any(|line| line.contains("· all users")),
        "{lines:?}"
    );

    click(&mut runtime, "btn-elevate-top");
    assert_eq!(runtime.state.elevation, ElevationState::Unprivileged);
    assert_eq!(element_label(&runtime, "btn-elevate-top"), "Elevate");

    press_text(&mut runtime, "S");
    assert_eq!(runtime.state.elevation, ElevationState::Elevated);
    press_text(&mut runtime, "S");
    assert_eq!(runtime.state.elevation, ElevationState::Unprivileged);

    click(&mut runtime, "btn-help");
    assert!(
        texts(&runtime)
            .iter()
            .any(|line| line.contains("All Users / Elevate")),
        "{:?}",
        texts(&runtime)
    );
    click(&mut runtime, "close-help");

    press_text(&mut runtime, "/");
    press_text(&mut runtime, "S");
    assert_eq!(runtime.state.query.text, "S");
    assert_eq!(runtime.state.elevation, ElevationState::Unprivileged);
}

#[test]
fn layout_presets_cycle_from_toolbar_keyboard_and_settings() {
    let mut runtime = boot();
    assert_eq!(runtime.state.layout_preset, LayoutPreset::Grid);
    assert_laid_out(&runtime, "btn-layout");
    assert_eq!(element_label(&runtime, "btn-layout"), "Layout: 3×2 Grid");

    let assert_all_slots_and_panels = |rt: &Runtime<State>, ctx: &str| {
        for idx in 0..6 {
            let key = format!("card-slot-{idx}");
            assert!(rt.find(&key).is_some(), "{ctx}: missing {key}");
            let (rect, _) = rt.presented(&key).expect(&key);
            assert!(
                rect[2] > 80.0 && rect[3] > 60.0,
                "{ctx}: {key} too small: {rect:?}"
            );
            assert!(
                rt.find(&format!("drag-card-{idx}")).is_some(),
                "{ctx}: missing drag-card-{idx}"
            );
        }
        for panel in [
            "cpu-panel",
            "memory-panel",
            "network-panel",
            "disks-panel",
            "processes-panel",
            "process-inspector",
        ] {
            assert_laid_out(rt, panel);
        }
    };

    assert_all_slots_and_panels(&runtime, "grid");
    let (slot0_grid, _) = runtime.presented("card-slot-0").unwrap();
    let (slot4_grid, _) = runtime.presented("card-slot-4").unwrap();
    assert!(slot0_grid[1] < slot4_grid[1], "grid: slot 0 above slot 4");

    // Toolbar cycles to ProcessesTop.
    click(&mut runtime, "btn-layout");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::ProcessesTop);
    assert_eq!(
        element_label(&runtime, "btn-layout"),
        "Layout: Processes Top"
    );
    assert_all_slots_and_panels(&runtime, "processes-top");
    let (slot0_pt, _) = runtime.presented("card-slot-0").unwrap();
    let (slot4_pt, _) = runtime.presented("card-slot-4").unwrap();
    assert!(
        slot4_pt[1] < slot0_pt[1],
        "processes-top: slot 4 should be above slot 0 ({slot4_pt:?} vs {slot0_pt:?})"
    );

    // Keyboard `L` cycles to SplitColumns.
    press_text(&mut runtime, "L");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::SplitColumns);
    assert_eq!(
        element_label(&runtime, "btn-layout"),
        "Layout: Split Columns"
    );
    assert_all_slots_and_panels(&runtime, "split-columns");
    let (slot0_sc, _) = runtime.presented("card-slot-0").unwrap();
    let (slot4_sc, _) = runtime.presented("card-slot-4").unwrap();
    assert!(
        slot4_sc[0] + slot4_sc[2] <= slot0_sc[0] + 1.0,
        "split-columns: slot 4 column should sit left of slot 0 ({slot4_sc:?} vs {slot0_sc:?})"
    );

    // Keyboard `L` cycles to Wide2x3.
    press_text(&mut runtime, "L");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::Wide2x3);
    assert_eq!(element_label(&runtime, "btn-layout"), "Layout: 2×3 Wide");
    assert_all_slots_and_panels(&runtime, "wide-2x3");
    let (w0, _) = runtime.presented("card-slot-0").unwrap();
    let (w1, _) = runtime.presented("card-slot-1").unwrap();
    let (w2, _) = runtime.presented("card-slot-2").unwrap();
    let (w3, _) = runtime.presented("card-slot-3").unwrap();
    assert!((w0[1] - w1[1]).abs() < 1.0 && (w1[1] - w2[1]).abs() < 1.0);
    assert!(w0[0] < w1[0] && w1[0] < w2[0]);
    assert!(w3[1] > w0[1] + 50.0);

    // Settings modal layout chips and Reset Layout.
    click(&mut runtime, "btn-settings");
    assert_laid_out(&runtime, "layout-grid");
    assert_laid_out(&runtime, "layout-processes-top");
    assert_laid_out(&runtime, "layout-split-columns");
    assert_laid_out(&runtime, "layout-wide-2x3");
    assert_laid_out(&runtime, "btn-reset-layout");
    assert!(
        texts(&runtime)
            .iter()
            .any(|line| line == "Dashboard Layout")
    );

    click(&mut runtime, "layout-processes-top");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::ProcessesTop);
    click(&mut runtime, "btn-reset-layout");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::Grid);
    click(&mut runtime, "close-settings");

    // `L` inside search does not cycle preset.
    press_text(&mut runtime, "/");
    press_text(&mut runtime, "L");
    assert_eq!(runtime.state.query.text, "L");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::Grid);
}

#[test]
fn splitters_resize_rows_and_columns_and_double_click_resets() {
    let mut runtime = boot();
    let (row_split_x, row_split_y) = runtime.find("split-row-0").expect("split-row-0");
    runtime.pointer_move(row_split_x, row_split_y);
    runtime.frame(0.0);
    assert_eq!(runtime.cursor(), Cursor::ResizeRow);

    let (before_top, _) = runtime.presented("card-slot-0").unwrap();
    let (before_mid, _) = runtime.presented("card-slot-2").unwrap();

    // Drag split-row-0 downward by 96pt.
    runtime.pointer_down(row_split_x, row_split_y);
    runtime.frame(0.0);
    runtime.pointer_move(row_split_x, row_split_y + 96.0);
    runtime.frame(0.0);
    runtime.pointer_up(row_split_x, row_split_y + 96.0);
    runtime.frame(0.0);
    runtime.frame(0.5);

    let (after_top, _) = runtime.presented("card-slot-0").unwrap();
    let (after_mid, _) = runtime.presented("card-slot-2").unwrap();
    assert!(
        after_top[3] > before_top[3] + 30.0 && after_mid[3] < before_mid[3] - 30.0,
        "row splitter drag did not resize bands: top {before_top:?}->{after_top:?}, mid {before_mid:?}->{after_mid:?}"
    );

    // Double-click split-row-0 to reset.
    let (rx, ry) = runtime.find("split-row-0").expect("split-row-0");
    runtime.pointer_down(rx, ry);
    runtime.pointer_up(rx, ry);
    runtime.frame(0.05);
    runtime.pointer_down(rx, ry);
    runtime.pointer_up(rx, ry);
    runtime.frame(0.0);
    assert_eq!(runtime.state.row_splits, DEFAULT_ROW_SPLITS);

    // Column splitter cursor, drag, and double-click reset.
    let (col_split_x, col_split_y) = runtime.find("split-col-0").expect("split-col-0");
    runtime.pointer_move(col_split_x, col_split_y);
    runtime.frame(0.0);
    assert_eq!(runtime.cursor(), Cursor::ResizeColumn);

    let (before_left, _) = runtime.presented("card-slot-0").unwrap();
    let (before_right, _) = runtime.presented("card-slot-1").unwrap();

    runtime.pointer_down(col_split_x, col_split_y);
    runtime.frame(0.0);
    runtime.pointer_move(col_split_x + 140.0, col_split_y);
    runtime.frame(0.0);
    runtime.pointer_up(col_split_x + 140.0, col_split_y);
    runtime.frame(0.0);
    runtime.frame(0.5);

    let (after_left, _) = runtime.presented("card-slot-0").unwrap();
    let (after_right, _) = runtime.presented("card-slot-1").unwrap();
    assert!(
        after_left[2] > before_left[2] + 60.0 && after_right[2] < before_right[2] - 60.0,
        "col splitter drag did not resize columns: left {before_left:?}->{after_left:?}, right {before_right:?}->{after_right:?}"
    );

    let (cx, cy) = runtime.find("split-col-0").expect("split-col-0");
    runtime.pointer_down(cx, cy);
    runtime.pointer_up(cx, cy);
    runtime.frame(0.05);
    runtime.pointer_down(cx, cy);
    runtime.pointer_up(cx, cy);
    runtime.frame(0.0);
    assert_eq!(runtime.state.col_splits[0], DEFAULT_COL_SPLITS[0]);
}

#[test]
fn card_handles_support_click_to_swap_drag_to_swap_and_restart_persistence() {
    let dir = tempfile::tempdir().unwrap();
    let prefs_file = dir.path().join("settings.json");

    let mut runtime = boot();
    runtime.state.set_prefs_path(&prefs_file);

    let (hx0, hy0) = runtime.find("drag-card-0").expect("drag-card-0");
    runtime.pointer_move(hx0, hy0);
    runtime.frame(0.0);
    assert_eq!(runtime.cursor(), Cursor::Grab);

    // 1. Click-to-swap: slot 0 (Cpu) <-> slot 1 (Memory).
    click(&mut runtime, "drag-card-0");
    assert_eq!(runtime.state.swap_source_slot, Some(0));
    assert!(texts(&runtime).iter().any(|line| line == "Swap…"));
    click(&mut runtime, "drag-card-1");
    assert_eq!(runtime.state.swap_source_slot, None);
    assert_eq!(runtime.state.card_slots[0], CardId::Memory);
    assert_eq!(runtime.state.card_slots[1], CardId::Cpu);
    let (mem_rect, _) = runtime.presented("memory-panel").unwrap();
    let (cpu_rect, _) = runtime.presented("cpu-panel").unwrap();
    assert!(
        mem_rect[0] < cpu_rect[0],
        "Memory card should now sit left of CPU card: mem={mem_rect:?} cpu={cpu_rect:?}"
    );

    // 2. Drag-across-borders to swap: drag slot 0 (now Memory) onto slot 4 (Processes).
    let (start_x, start_y) = runtime.find("drag-card-0").expect("drag-card-0");
    let (target_x, target_y) = runtime.find("card-slot-4").expect("card-slot-4");
    runtime.pointer_down(start_x, start_y);
    runtime.frame(0.0);
    runtime.pointer_move(target_x, target_y);
    runtime.frame(0.0);
    assert_eq!(runtime.state.drag_hover_slot, Some(4));
    assert_eq!(runtime.cursor(), Cursor::Grabbing);
    runtime.pointer_up(target_x, target_y);
    runtime.frame(0.0);

    assert_eq!(runtime.state.swap_source_slot, None);
    assert_eq!(runtime.state.drag_hover_slot, None);
    assert_eq!(runtime.state.card_slots[0], CardId::Processes);
    assert_eq!(runtime.state.card_slots[4], CardId::Memory);

    // Also customize preset and splitter ratios, then verify full persistence across restart.
    click(&mut runtime, "btn-layout");
    assert_eq!(runtime.state.layout_preset, LayoutPreset::ProcessesTop);
    let (sx, sy) = runtime.find("split-col-2").expect("split-col-2");
    runtime.pointer_down(sx, sy);
    runtime.frame(0.0);
    runtime.pointer_move(sx - 110.0, sy);
    runtime.frame(0.0);
    runtime.pointer_up(sx - 110.0, sy);
    runtime.frame(0.0);

    let saved_preset = runtime.state.layout_preset;
    let saved_slots = runtime.state.card_slots;
    let saved_rows = runtime.state.row_splits;
    let saved_cols = runtime.state.col_splits;
    drop(runtime);

    // Boot a brand-new Runtime and reload settings.json as on restart.
    let mut restarted = App::new(ui::spec()).headless_runtime((1360.0, 880.0), Env::new(true, 1.0));
    restarted.state.set_prefs_path(&prefs_file);
    restarted.state.reload_user_prefs();
    restarted.frame(0.0);
    restarted.frame(0.0);

    assert_eq!(restarted.state.layout_preset, saved_preset);
    assert_eq!(restarted.state.card_slots, saved_slots);
    assert_eq!(restarted.state.row_splits, saved_rows);
    assert_eq!(restarted.state.col_splits, saved_cols);
    assert_eq!(
        element_label(&restarted, "btn-layout"),
        "Layout: Processes Top"
    );
}

#[test]
fn inspector_sparklines_metadata_and_process_action_buttons_work() {
    let mut runtime = boot();
    assert_laid_out(&runtime, "proc-cpu-spark");
    assert_laid_out(&runtime, "proc-mem-spark");
    assert_laid_out(&runtime, "btn-pin-proc");
    assert_laid_out(&runtime, "btn-renice-dec");
    assert_laid_out(&runtime, "btn-renice-inc");
    assert_laid_out(&runtime, "btn-copy-cmd");

    let (cpu_spark, _) = runtime.presented("proc-cpu-spark").unwrap();
    let (mem_spark, _) = runtime.presented("proc-mem-spark").unwrap();
    assert!((cpu_spark[3] - 28.0).abs() < 0.5, "{cpu_spark:?}");
    assert!((mem_spark[3] - 28.0).abs() < 0.5, "{mem_spark:?}");

    // Default selected process is rustc (pid 1001, nice 5, session-2.scope, no listening ports).
    let lines = texts(&runtime);
    assert!(lines.iter().any(|l| l == "Nice"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "Unit"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "session-2.scope"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "CWD"), "{lines:?}");
    assert!(
        lines.iter().any(|l| l == "/home/alice/projects/vitals"),
        "{lines:?}"
    );
    assert!(lines.iter().any(|l| l == "Exe"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "/usr/bin/rustc"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "Ports"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "none"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "Pin [P]"), "{lines:?}");

    // Renice -1 then +1 from Inspector buttons.
    click(&mut runtime, "btn-renice-dec");
    assert_eq!(runtime.state.selected_process().unwrap().nice, 4);
    assert_laid_out(&runtime, "status-banner");
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.contains("Reniced rustc (pid 1001) to nice 4"))
    );

    click(&mut runtime, "btn-renice-inc");
    assert_eq!(runtime.state.selected_process().unwrap().nice, 5);
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.contains("Reniced rustc (pid 1001) to nice 5"))
    );

    // Copy command from Inspector button.
    click(&mut runtime, "btn-copy-cmd");
    assert_eq!(
        runtime.state.copied_command.as_deref(),
        Some("/usr/bin/rustc --pid 1001")
    );
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.contains("Copied command for rustc (pid 1001)"))
    );

    // Pin from Inspector button toggles "Pinned ★ [P]" and watchlist.
    click(&mut runtime, "btn-pin-proc");
    assert!(runtime.state.pinned_pids.contains(&1001));
    assert!(texts(&runtime).iter().any(|l| l == "Pinned ★ [P]"));
    assert_laid_out(&runtime, "pinned-watchlist");
    click(&mut runtime, "btn-pin-proc");
    assert!(!runtime.state.pinned_pids.contains(&1001));
    assert_absent(&runtime, "pinned-watchlist");

    // Select postgres (pid 700) to verify listening ports, systemd unit, and CWD.
    runtime.update(|state, _| state.select_pid(700));
    runtime.frame(0.0);
    let pg_lines = texts(&runtime);
    assert!(
        pg_lines.iter().any(|l| l == "postgresql.service"),
        "{pg_lines:?}"
    );
    assert!(
        pg_lines.iter().any(|l| l == "/var/lib/postgresql/data"),
        "{pg_lines:?}"
    );
    assert!(
        pg_lines.iter().any(|l| l == "TCP 127.0.0.1:5432"),
        "{pg_lines:?}"
    );
}

#[test]
fn collapsible_tree_buttons_and_keyboard_shortcuts_hide_and_restore_subtrees() {
    let mut runtime = boot();
    click(&mut runtime, "mode-tree");
    assert_eq!(runtime.state.process_mode, crate::model::ProcessMode::Tree);

    // Filter to sshd/bash/vim/htop subtree so all rows fit in the viewport without scrolling.
    press_text(&mut runtime, "/");
    for ch in ["v", "i", "m"] {
        press_text(&mut runtime, ch);
    }
    press_key(&mut runtime, Key::Escape);
    assert_eq!(runtime.state.query.text, "vim");
    assert_laid_out(&runtime, "proc-row-320");
    assert_laid_out(&runtime, "proc-row-330");
    assert_laid_out(&runtime, "btn-tree-toggle-320");
    assert!(texts(&runtime).iter().any(|l| l == "▾"));

    // Click btn-tree-toggle-320 to collapse bash (320), hiding vim (330).
    click(&mut runtime, "btn-tree-toggle-320");
    assert!(runtime.state.collapsed_pids.contains(&320));
    assert_absent(&runtime, "proc-row-330");
    assert!(
        texts(&runtime).iter().any(|l| l == "▸ +1"),
        "expected collapsed badge ▸ +1, got {:?}",
        texts(&runtime)
    );

    // Click btn-tree-toggle-320 again to expand and restore vim (330).
    click(&mut runtime, "btn-tree-toggle-320");
    assert!(!runtime.state.collapsed_pids.contains(&320));
    assert_laid_out(&runtime, "proc-row-330");

    // Keyboard Left on leaf vim (330) selects parent bash (320); Left again collapses bash (320).
    click(&mut runtime, "proc-row-330");
    assert_eq!(runtime.state.selected_pid, Some(330));
    press_key(&mut runtime, Key::Left);
    assert_eq!(runtime.state.selected_pid, Some(320));
    press_key(&mut runtime, Key::Left);
    assert!(runtime.state.collapsed_pids.contains(&320));
    assert_absent(&runtime, "proc-row-330");

    // Right expands bash (320); `z` toggles collapse on and off.
    press_key(&mut runtime, Key::Right);
    assert!(!runtime.state.collapsed_pids.contains(&320));
    assert_laid_out(&runtime, "proc-row-330");

    press_text(&mut runtime, "z");
    assert!(runtime.state.collapsed_pids.contains(&320));
    assert_absent(&runtime, "proc-row-330");

    press_text(&mut runtime, "z");
    assert!(!runtime.state.collapsed_pids.contains(&320));
    assert_laid_out(&runtime, "proc-row-330");
}

#[test]
fn pinning_processes_renders_star_badges_and_clickable_watchlist_strip() {
    let mut runtime = boot();
    assert_absent(&runtime, "pinned-watchlist");
    assert_laid_out(&runtime, "btn-pin");

    // Select a lower-CPU process (vim, pid 330) and pin via `P`.
    runtime.update(|state, _| state.select_pid(330));
    runtime.frame(0.0);
    press_text(&mut runtime, "P");
    assert!(runtime.state.pinned_pids.contains(&330));
    assert_eq!(runtime.state.rows[0].pid, 330);
    assert_laid_out(&runtime, "pinned-watchlist");
    assert_laid_out(&runtime, "watch-chip-330");
    let lines = texts(&runtime);
    assert!(lines.iter().any(|l| l == "★"), "{lines:?}");
    assert!(
        lines
            .iter()
            .any(|l| l.starts_with("vim ") && l.ends_with('%')),
        "{lines:?}"
    );

    // Pin rustc (1001) via `btn-pin`, then click `watch-chip-330` to jump selection back to vim.
    runtime.update(|state, _| state.select_pid(1001));
    runtime.frame(0.0);
    click(&mut runtime, "btn-pin");
    assert!(runtime.state.pinned_pids.contains(&1001));
    assert_laid_out(&runtime, "watch-chip-1001");
    assert_eq!(runtime.state.selected_pid, Some(1001));

    click(&mut runtime, "watch-chip-330");
    assert_eq!(runtime.state.selected_pid, Some(330));

    // Unpin both and verify watchlist disappears.
    press_text(&mut runtime, "P");
    runtime.update(|state, _| state.select_pid(1001));
    runtime.frame(0.0);
    click(&mut runtime, "btn-pin");
    assert!(runtime.state.pinned_pids.is_empty());
    assert_absent(&runtime, "pinned-watchlist");
}

#[test]
fn psi_badges_sockets_memory_disk_latency_and_chart_hover_readouts_work() {
    let mut runtime = boot();
    let lines = texts(&runtime);

    // PSI badges across CPU, Memory, and Disks panels.
    assert!(lines.iter().any(|l| l.starts_with("PSI ")), "{lines:?}");
    assert!(
        lines
            .iter()
            .any(|l| l.starts_with("PSI ") && l.contains(" / ")),
        "missing memory some/full PSI in {lines:?}"
    );
    assert!(lines.iter().any(|l| l.starts_with("IO PSI ")), "{lines:?}");

    // Memory breakdown fields: Shared, Dirty, Slab.
    assert!(lines.iter().any(|l| l.starts_with("Shared ")), "{lines:?}");
    assert!(lines.iter().any(|l| l.starts_with("Dirty ")), "{lines:?}");
    assert!(lines.iter().any(|l| l.starts_with("Slab ")), "{lines:?}");

    // Network Sockets section & rows.
    assert!(
        lines.iter().any(|l| l.starts_with("Sockets (")),
        "{lines:?}"
    );
    assert_laid_out(&runtime, "sock-row-0");
    assert!(lines.iter().any(|l| l == "LISTEN"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "ESTAB"), "{lines:?}");
    assert!(lines.iter().any(|l| l.contains("postgres")), "{lines:?}");

    // Disk Busy & Await shared-width columns.
    assert!(lines.iter().any(|l| l == "Busy"), "{lines:?}");
    assert!(lines.iter().any(|l| l == "Await"), "{lines:?}");
    assert_laid_out(&runtime, "disk-busy-0");
    assert_laid_out(&runtime, "disk-await-0");
    assert!(lines.iter().any(|l| l.ends_with(" ms")), "{lines:?}");

    // Interactive Chart Hover Readouts across CPU, Memory, Network, and Disks.
    let (cpu_x, cpu_y) = runtime.find("cpu-chart").expect("cpu-chart");
    runtime.pointer_move(cpu_x, cpu_y);
    runtime.frame(0.0);
    assert!(matches!(
        runtime.state.chart_hover,
        Some((ChartKind::Cpu, f)) if (0.0..=1.0).contains(&f)
    ));
    assert_laid_out(&runtime, "cpu-hover-readout");
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.starts_with("Hover -") && l.ends_with('%'))
    );

    let (mem_x, mem_y) = runtime.find("mem-chart").expect("mem-chart");
    runtime.pointer_move(mem_x, mem_y);
    runtime.frame(0.0);
    assert!(matches!(
        runtime.state.chart_hover,
        Some((ChartKind::Memory, f)) if (0.0..=1.0).contains(&f)
    ));
    assert_laid_out(&runtime, "mem-hover-readout");
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.starts_with("Hover -") && l.contains("Swap"))
    );

    let (net_x, net_y) = runtime.find("net-chart").expect("net-chart");
    runtime.pointer_move(net_x, net_y);
    runtime.frame(0.0);
    assert!(matches!(
        runtime.state.chart_hover,
        Some((ChartKind::Network, f)) if (0.0..=1.0).contains(&f)
    ));
    assert_laid_out(&runtime, "net-hover-readout");
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.starts_with("Hover -") && l.contains("RX ") && l.contains("TX "))
    );

    click(&mut runtime, "tab-disks");
    let (disk_x, disk_y) = runtime.find("disk-io-chart").expect("disk-io-chart");
    runtime.pointer_move(disk_x, disk_y);
    runtime.frame(0.0);
    assert!(matches!(
        runtime.state.chart_hover,
        Some((ChartKind::Disks, f)) if (0.0..=1.0).contains(&f)
    ));
    assert_laid_out(&runtime, "disk-hover-readout");
    assert!(
        texts(&runtime)
            .iter()
            .any(|l| l.starts_with("Hover -") && l.contains("R ") && l.contains("W "))
    );
}

#[test]
fn files_pane_filters_rows_and_selects_a_process() {
    let mut runtime = boot();
    click(&mut runtime, "tab-files");
    runtime.frame(0.35);
    assert_eq!(runtime.state.pane, PaneId::Files);
    assert_laid_out(&runtime, "files-panel");
    assert_laid_out(&runtime, "process-inspector");
    assert_laid_out(&runtime, "file-stream");
    assert_laid_out(&runtime, "file-rows");
    assert_laid_out(&runtime, "search");
    for key in [
        "file-kind-all",
        "file-kind-file",
        "file-kind-socket",
        "file-kind-device",
        "file-kind-pipe",
        "btn-elevate",
    ] {
        assert_laid_out(&runtime, key);
    }
    let lines = texts(&runtime);
    assert!(
        lines
            .iter()
            .any(|line| line.contains("shown /") && line.contains("total")),
        "{lines:?}"
    );
    assert!(
        lines.iter().any(|line| line == "Target Path / Socket"),
        "{lines:?}"
    );
    assert!(!runtime.state.file_rows.is_empty());
    assert_eq!(runtime.state.file_filter, FileKindFilter::All);

    click(&mut runtime, "file-kind-socket");
    assert_eq!(runtime.state.file_filter, FileKindFilter::Sockets);
    assert!(!runtime.state.file_rows.is_empty());
    assert!(
        runtime
            .state
            .file_rows
            .iter()
            .all(|entry| entry.kind == OpenFileKind::Socket),
        "{:?}",
        runtime.state.file_rows
    );
    let socket_lines = texts(&runtime);
    assert!(
        socket_lines.iter().any(|line| line.contains("TCP ")),
        "{socket_lines:?}"
    );
    assert!(
        socket_lines
            .iter()
            .all(|line| line != "/etc/systemd/system.conf"),
        "{socket_lines:?}"
    );

    click(&mut runtime, "file-kind-file");
    assert_eq!(runtime.state.file_filter, FileKindFilter::Files);
    assert!(
        runtime
            .state
            .file_rows
            .iter()
            .all(|entry| entry.kind == OpenFileKind::File)
    );
    click(&mut runtime, "file-kind-device");
    assert!(
        runtime
            .state
            .file_rows
            .iter()
            .all(|entry| entry.kind == OpenFileKind::Device)
    );
    click(&mut runtime, "file-kind-pipe");
    assert!(
        runtime
            .state
            .file_rows
            .iter()
            .all(|entry| entry.kind == OpenFileKind::Pipe)
    );

    click(&mut runtime, "file-kind-all");
    runtime.frame(0.35);
    assert_eq!(runtime.state.file_filter, FileKindFilter::All);
    let pid = runtime.state.file_rows[0].pid;
    click(&mut runtime, "file-row-0");
    assert_eq!(runtime.state.selected_pid, Some(pid));
    assert_laid_out(&runtime, "proc-open-files");
    assert!(
        texts(&runtime).iter().any(|line| line == "Open Files"),
        "{:?}",
        texts(&runtime)
    );
}

#[test]
fn process_columns_follow_panel_width() {
    let mut runtime = boot();
    for key in ["sort-read", "sort-write", "sort-user", "sort-state"] {
        assert!(runtime.find(key).is_some(), "wide overview missing {key}");
    }

    runtime.set_viewport((1000.0, 880.0), 1.0);
    runtime.frame(0.0);
    runtime.frame(0.0);
    let (medium, _) = runtime.presented("card-slot-4").expect("processes slot");
    assert!(
        medium[2] >= 520.0 && medium[2] < 700.0,
        "expected a medium processes card, got {medium:?}"
    );
    assert!(runtime.find("sort-read").is_none());
    assert!(runtime.find("sort-write").is_none());
    assert!(runtime.find("sort-user").is_some());
    assert!(runtime.find("sort-state").is_some());
    assert!(runtime.find("sort-pid").is_some());
    assert!(runtime.find("sort-mem").is_some());

    runtime.set_viewport((780.0, 880.0), 1.0);
    runtime.frame(0.0);
    runtime.frame(0.0);
    let (compact, _) = runtime.presented("card-slot-4").expect("processes slot");
    assert!(
        compact[2] < 520.0,
        "expected a compact processes card, got {compact:?}"
    );
    for key in ["sort-read", "sort-write", "sort-user", "sort-state"] {
        assert!(
            runtime.find(key).is_none(),
            "{key} still shown at {compact:?}"
        );
    }
    for key in ["sort-pid", "sort-name", "sort-cpu", "sort-mem"] {
        assert!(
            runtime.find(key).is_some(),
            "compact overview missing {key}"
        );
    }
    let mem = runtime
        .state
        .rows
        .iter()
        .find(|row| row.pid == 1001)
        .expect("rustc");
    let compact_mem = format_bytes(mem.mem_bytes);
    let wide_mem = format!("{:.1}%  {}", mem.mem_pct, format_bytes(mem.mem_bytes));
    let lines = texts(&runtime);
    assert!(
        lines.iter().any(|line| line == &compact_mem),
        "compact memory missing {compact_mem} in {lines:?}"
    );
    assert!(
        lines.iter().all(|line| line != &wide_mem),
        "wide memory label still present: {wide_mem}"
    );
}
