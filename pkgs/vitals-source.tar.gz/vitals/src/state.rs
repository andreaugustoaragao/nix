//! Interactive state for Vitals: sampling, elevation, layout, preferences, and keyboard actions.

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::mpsc::{self, Receiver, Sender};
use std::sync::{Arc, Condvar, Mutex, MutexGuard};
use std::thread::{self, JoinHandle};
use std::time::Duration;

use rune::{Key, KeyEvent, PhysicalKeyCode, TextEdit, Tx};

use crate::collector::{
    HelperClient, LinuxCollector, kill_process_group, renice_process, send_process_signal,
};
use crate::fixture::{fixture_history, fixture_snapshot};
use crate::model::{
    FileKindFilter, HistoryRing, NetSocketEntry, OpenFileEntry, PaneId, ProcessInfo, ProcessMode,
    ProcessRow, SignalKind, SocketKindFilter, SortColumn, SystemSnapshot, TelemetryHistory,
    build_process_rows_ext, filter_open_files, filter_sockets,
};
use crate::theme::{
    AppearanceMode, ColorSchemeId, SystemThemeSnapshot, detect_system_theme_default,
};

const TIME_WINDOWS: [u32; 4] = [15, 30, 60, 120];
const POLL_INTERVALS_MS: [u64; 4] = [250, 500, 1_000, 2_000];
const FOCUS_ORDER: [PaneId; 5] = [
    PaneId::Cpu,
    PaneId::Memory,
    PaneId::Network,
    PaneId::Disks,
    PaneId::Processes,
];
const MIN_SAMPLES: usize = 8;
const BANNER_AUTHENTICATE: &str = "Authenticate in the Polkit dialog to view all users' processes…";
const BANNER_AUTH_CANCELLED: &str = "Authentication cancelled — showing current user processes";
const BANNER_ELEVATED: &str = "Elevated (root): showing all processes across all users";
const BANNER_DROPPED: &str = "Dropped elevated privileges — showing current user processes";

/// Whether process samples come from the current user or a root helper.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum ElevationState {
    #[default]
    Unprivileged,
    Authenticating,
    Elevated,
}

/// Telemetry history chart currently under the pointer.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ChartKind {
    Cpu,
    Memory,
    Network,
    Disks,
}

/// Lowest interface scale, in percent.
pub const MIN_ZOOM_PCT: u16 = 50;
/// Highest interface scale, in percent.
pub const MAX_ZOOM_PCT: u16 = 200;
/// Interface scale moves in this increment.
pub const ZOOM_STEP_PCT: u16 = 10;
/// Unscaled interface. `Ctrl+Shift+0` returns here.
pub const DEFAULT_ZOOM_PCT: u16 = 100;

/// Default row height flex weights for Overview rows.
pub const DEFAULT_ROW_SPLITS: [f32; 3] = [1.05, 0.85, 1.45];
/// Default horizontal split ratios (`0.0..=1.0`) for Overview column pairs.
pub const DEFAULT_COL_SPLITS: [f32; 4] = [0.556, 0.465, 0.63, 0.50];
/// Minimum row flex weight while dragging a row splitter.
pub const MIN_ROW_SPLIT: f32 = 0.35;
/// Maximum row flex weight while dragging a row splitter.
pub const MAX_ROW_SPLIT: f32 = 2.6;
/// Minimum column split ratio while dragging a column splitter.
pub const MIN_COL_SPLIT: f32 = 0.18;
/// Maximum column split ratio while dragging a column splitter.
pub const MAX_COL_SPLIT: f32 = 0.82;

/// Overview dashboard arrangement preset.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
pub enum LayoutPreset {
    #[default]
    #[serde(rename = "grid", alias = "Grid")]
    Grid,
    #[serde(
        rename = "processes-top",
        alias = "ProcessesTop",
        alias = "processes_top"
    )]
    ProcessesTop,
    #[serde(
        rename = "split-columns",
        alias = "SplitColumns",
        alias = "split_columns"
    )]
    SplitColumns,
    #[serde(rename = "wide-2x3", alias = "Wide2x3", alias = "wide_2x3")]
    Wide2x3,
}

impl LayoutPreset {
    pub const ALL: [LayoutPreset; 4] = [
        Self::Grid,
        Self::ProcessesTop,
        Self::SplitColumns,
        Self::Wide2x3,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Self::Grid => "3×2 Grid",
            Self::ProcessesTop => "Processes Top",
            Self::SplitColumns => "Split Columns",
            Self::Wide2x3 => "2×3 Wide",
        }
    }

    pub fn slug(self) -> &'static str {
        match self {
            Self::Grid => "grid",
            Self::ProcessesTop => "processes-top",
            Self::SplitColumns => "split-columns",
            Self::Wide2x3 => "wide-2x3",
        }
    }

    pub fn from_slug(value: &str) -> Option<Self> {
        let normalized = value.trim().to_ascii_lowercase().replace('_', "-");
        match normalized.as_str() {
            "grid" | "3x2-grid" => Some(Self::Grid),
            "processes-top" | "processestop" => Some(Self::ProcessesTop),
            "split-columns" | "splitcolumns" => Some(Self::SplitColumns),
            "wide-2x3" | "2x3-wide" | "wide2x3" => Some(Self::Wide2x3),
            _ => None,
        }
    }

    pub fn cycle(self) -> Self {
        let index = Self::ALL
            .iter()
            .position(|preset| *preset == self)
            .unwrap_or(0);
        Self::ALL[(index + 1) % Self::ALL.len()]
    }
}

/// Instrument card assignable to any of the six Overview dashboard slots.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub enum CardId {
    #[serde(rename = "cpu", alias = "Cpu")]
    Cpu,
    #[serde(rename = "memory", alias = "Memory")]
    Memory,
    #[serde(rename = "network", alias = "Network")]
    Network,
    #[serde(rename = "disks", alias = "Disks")]
    Disks,
    #[serde(rename = "processes", alias = "Processes")]
    Processes,
    #[serde(rename = "inspector", alias = "Inspector")]
    Inspector,
}

impl CardId {
    pub const DEFAULT_SLOTS: [CardId; 6] = [
        Self::Cpu,
        Self::Memory,
        Self::Network,
        Self::Disks,
        Self::Processes,
        Self::Inspector,
    ];

    pub fn slug(self) -> &'static str {
        match self {
            Self::Cpu => "cpu",
            Self::Memory => "memory",
            Self::Network => "network",
            Self::Disks => "disks",
            Self::Processes => "processes",
            Self::Inspector => "inspector",
        }
    }

    pub fn from_slug(value: &str) -> Option<Self> {
        let normalized = value.trim().to_ascii_lowercase();
        match normalized.as_str() {
            "cpu" => Some(Self::Cpu),
            "memory" | "mem" => Some(Self::Memory),
            "network" | "net" => Some(Self::Network),
            "disks" | "disk" => Some(Self::Disks),
            "processes" | "procs" => Some(Self::Processes),
            "inspector" | "process-inspector" | "process" => Some(Self::Inspector),
            _ => None,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Cpu => "CPU",
            Self::Memory => "Memory",
            Self::Network => "Network",
            Self::Disks => "Disks",
            Self::Processes => "Processes",
            Self::Inspector => "Inspector",
        }
    }
}

/// Where snapshots come from. Fixture playback is the deterministic default.
///
/// `Live(Box::default())` stays a synchronous collector so unit tests can sample
/// without starting the background thread. `State::new_live` uses `LiveWorker`.
#[derive(Debug)]
pub enum DataSource {
    Live(Box<LiveCollector>),
    Fixture { step: usize, killed: HashSet<u32> },
}

#[derive(Debug, Default)]
pub struct DirectSampler {
    collector: LinuxCollector,
    helper: Option<HelperClient>,
}

#[derive(Debug)]
pub enum LiveCollector {
    Direct(Box<DirectSampler>),
    Worker(LiveWorker),
}

impl Default for LiveCollector {
    fn default() -> Self {
        Self::Direct(Box::default())
    }
}

enum LivePull {
    Ready {
        result: Box<Result<SystemSnapshot, String>>,
        /// `u64::MAX` is an inline sample. Worker samples carry the helper generation.
        generation: u64,
    },
    Pending,
}

impl LiveCollector {
    fn pull(&mut self, pane: PaneId, selected_pid: Option<u32>) -> LivePull {
        match self {
            Self::Direct(sampler) => LivePull::Ready {
                result: Box::new(sample_direct(sampler, pane, selected_pid)),
                generation: u64::MAX,
            },
            Self::Worker(worker) => match worker.take() {
                Some((generation, result)) => LivePull::Ready {
                    result: Box::new(result),
                    generation,
                },
                None => LivePull::Pending,
            },
        }
    }

    fn configure(
        &self,
        poll_interval_ms: u64,
        frozen: bool,
        pane: PaneId,
        selected_pid: Option<u32>,
    ) {
        if let Self::Worker(worker) = self {
            worker.configure(poll_interval_ms, frozen, pane, selected_pid);
        }
    }

    fn install_helper(&mut self, helper: HelperClient, generation: u64) {
        match self {
            Self::Direct(sampler) => sampler.helper = Some(helper),
            Self::Worker(worker) => worker.install_helper(helper, generation),
        }
    }

    fn drop_helper(&mut self, generation: u64) {
        match self {
            Self::Direct(sampler) => sampler.helper = None,
            Self::Worker(worker) => worker.drop_helper(generation),
        }
    }

    fn send_signal(&mut self, pid: u32, signal: SignalKind) -> Result<(), String> {
        match self {
            Self::Direct(sampler) => {
                if let Some(helper) = sampler.helper.as_mut() {
                    helper.send_signal(pid, signal)
                } else {
                    send_process_signal(pid, signal)
                }
            }
            Self::Worker(worker) => worker.send_signal(pid, signal),
        }
    }

    fn send_renice(&mut self, pid: u32, delta: i32) -> Result<i32, String> {
        match self {
            Self::Direct(sampler) => {
                if let Some(helper) = sampler.helper.as_mut() {
                    helper.renice_process(pid, delta)
                } else {
                    renice_process(pid, delta)
                }
            }
            Self::Worker(worker) => worker.send_renice(pid, delta),
        }
    }
}

fn sample_direct(
    sampler: &mut DirectSampler,
    pane: PaneId,
    selected_pid: Option<u32>,
) -> Result<SystemSnapshot, String> {
    if let Some(helper) = sampler.helper.as_mut() {
        helper.sample_for(pane, selected_pid)
    } else {
        sampler.collector.sample_for(pane, selected_pid)
    }
}

#[derive(Debug, Clone, Copy)]
struct CollectorControl {
    poll_interval_ms: u64,
    frozen: bool,
    pane: PaneId,
    selected_pid: Option<u32>,
    shutdown: bool,
    immediate: bool,
}

struct ControlSlot {
    state: Mutex<CollectorControl>,
    wake: Condvar,
}

enum WorkerRequest {
    Install {
        helper: HelperClient,
        generation: u64,
    },
    DropHelper {
        generation: u64,
    },
    Signal {
        pid: u32,
        signal: SignalKind,
        reply: Sender<Result<(), String>>,
    },
    Renice {
        pid: u32,
        delta: i32,
        reply: Sender<Result<i32, String>>,
    },
}

type PublishedSample = (u64, Result<SystemSnapshot, String>);
type SampleInbox = Arc<Mutex<Option<PublishedSample>>>;

struct ActiveSampler {
    local: LinuxCollector,
    helper: Option<HelperClient>,
    generation: u64,
}

pub struct LiveWorker {
    control: Arc<ControlSlot>,
    requests: Arc<Mutex<Vec<WorkerRequest>>>,
    inbox: SampleInbox,
    helper_pid: Arc<AtomicU32>,
    drop_requested: Arc<AtomicBool>,
    thread: Option<JoinHandle<()>>,
}

impl std::fmt::Debug for LiveWorker {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("LiveWorker")
    }
}

impl LiveWorker {
    fn spawn(collector: LinuxCollector, poll_interval_ms: u64) -> Self {
        let control = Arc::new(ControlSlot {
            state: Mutex::new(CollectorControl {
                poll_interval_ms,
                frozen: false,
                pane: PaneId::Overview,
                selected_pid: None,
                shutdown: false,
                immediate: false,
            }),
            wake: Condvar::new(),
        });
        let requests = Arc::new(Mutex::new(Vec::new()));
        let inbox = Arc::new(Mutex::new(None));
        let helper_pid = Arc::new(AtomicU32::new(0));
        let drop_requested = Arc::new(AtomicBool::new(false));
        let thread = thread::Builder::new()
            .name("vitals-collector".to_string())
            .spawn({
                let control = Arc::clone(&control);
                let requests = Arc::clone(&requests);
                let inbox = Arc::clone(&inbox);
                let helper_pid = Arc::clone(&helper_pid);
                let drop_requested = Arc::clone(&drop_requested);
                move || {
                    collector_loop(
                        collector,
                        control,
                        requests,
                        inbox,
                        helper_pid,
                        drop_requested,
                    )
                }
            })
            .expect("spawn vitals-collector");
        Self {
            control,
            requests,
            inbox,
            helper_pid,
            drop_requested,
            thread: Some(thread),
        }
    }

    fn configure(
        &self,
        poll_interval_ms: u64,
        frozen: bool,
        pane: PaneId,
        selected_pid: Option<u32>,
    ) {
        let mut guard = lock_mutex(&self.control.state);
        if guard.shutdown {
            return;
        }
        let wake = guard.poll_interval_ms != poll_interval_ms
            || guard.frozen != frozen
            || (guard.pane != pane && pane == PaneId::Files);
        guard.poll_interval_ms = poll_interval_ms;
        guard.frozen = frozen;
        guard.pane = pane;
        guard.selected_pid = selected_pid;
        drop(guard);
        if wake {
            self.control.wake.notify_one();
        }
    }

    fn take(&self) -> Option<(u64, Result<SystemSnapshot, String>)> {
        lock_mutex(&self.inbox).take()
    }

    fn install_helper(&self, helper: HelperClient, generation: u64) {
        self.helper_pid.store(helper.pid(), Ordering::SeqCst);
        self.drop_requested.store(false, Ordering::SeqCst);
        self.enqueue(WorkerRequest::Install { helper, generation }, true);
    }

    fn drop_helper(&self, generation: u64) {
        // The connected helper may already be root, so this process cannot
        // SIGKILL it. The worker drops `HelperClient`, which closes stdin.
        // `drop_requested` makes an in-flight root sample be discarded.
        self.drop_requested.store(true, Ordering::SeqCst);
        self.enqueue(WorkerRequest::DropHelper { generation }, true);
    }

    fn send_signal(&self, pid: u32, signal: SignalKind) -> Result<(), String> {
        let (reply_tx, reply_rx) = mpsc::channel();
        self.enqueue(
            WorkerRequest::Signal {
                pid,
                signal,
                reply: reply_tx,
            },
            true,
        );
        reply_rx
            .recv()
            .unwrap_or_else(|_| Err("collector stopped".to_string()))
    }

    fn send_renice(&self, pid: u32, delta: i32) -> Result<i32, String> {
        let (reply_tx, reply_rx) = mpsc::channel();
        self.enqueue(
            WorkerRequest::Renice {
                pid,
                delta,
                reply: reply_tx,
            },
            true,
        );
        reply_rx
            .recv()
            .unwrap_or_else(|_| Err("collector stopped".to_string()))
    }

    fn enqueue(&self, request: WorkerRequest, immediate: bool) {
        let mut guard = lock_mutex(&self.control.state);
        if guard.shutdown {
            drop(guard);
            match request {
                WorkerRequest::Signal { reply, .. } => {
                    let _ = reply.send(Err("collector stopped".to_string()));
                }
                WorkerRequest::Renice { reply, .. } => {
                    let _ = reply.send(Err("collector stopped".to_string()));
                }
                WorkerRequest::Install { .. } | WorkerRequest::DropHelper { .. } => {}
            }
            return;
        }
        if immediate {
            guard.immediate = true;
        }
        lock_mutex(&self.requests).push(request);
        drop(guard);
        self.control.wake.notify_one();
    }
}

impl Drop for LiveWorker {
    fn drop(&mut self) {
        self.drop_requested.store(true, Ordering::SeqCst);
        let pid = self.helper_pid.load(Ordering::SeqCst);
        if pid > 0 {
            kill_process_group(pid);
        }
        {
            let mut guard = lock_mutex(&self.control.state);
            guard.shutdown = true;
            guard.immediate = true;
        }
        self.control.wake.notify_one();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn collector_loop(
    collector: LinuxCollector,
    control: Arc<ControlSlot>,
    requests: Arc<Mutex<Vec<WorkerRequest>>>,
    inbox: SampleInbox,
    helper_pid: Arc<AtomicU32>,
    drop_requested: Arc<AtomicBool>,
) {
    let mut sampler = ActiveSampler {
        local: collector,
        helper: None,
        generation: 0,
    };
    loop {
        if control_shutdown(&control) {
            fail_pending(&requests);
            return;
        }
        apply_requests(&mut sampler, &requests, &helper_pid, &drop_requested);
        let (interval, frozen, pane, selected_pid) = {
            let mut guard = lock_mutex(&control.state);
            if guard.shutdown {
                drop(guard);
                fail_pending(&requests);
                return;
            }
            guard.immediate = false;
            (
                guard.poll_interval_ms.clamp(100, 5_000),
                guard.frozen,
                guard.pane,
                guard.selected_pid,
            )
        };
        if !frozen {
            let sample = sample_active(
                &mut sampler,
                &helper_pid,
                &drop_requested,
                pane,
                selected_pid,
            );
            *lock_mutex(&inbox) = Some((sampler.generation, sample));
        }
        let mut guard = lock_mutex(&control.state);
        if guard.shutdown {
            drop(guard);
            fail_pending(&requests);
            return;
        }
        let pending = !lock_mutex(&requests).is_empty();
        if pending || guard.immediate {
            guard.immediate = false;
            continue;
        }
        let (guard, _) = control
            .wake
            .wait_timeout(guard, Duration::from_millis(interval))
            .unwrap_or_else(|err| err.into_inner());
        if guard.shutdown {
            drop(guard);
            fail_pending(&requests);
            return;
        }
    }
}

fn control_shutdown(control: &ControlSlot) -> bool {
    lock_mutex(&control.state).shutdown
}

fn apply_requests(
    sampler: &mut ActiveSampler,
    requests: &Mutex<Vec<WorkerRequest>>,
    helper_pid: &AtomicU32,
    drop_requested: &AtomicBool,
) {
    let pending = std::mem::take(&mut *lock_mutex(requests));
    for request in pending {
        match request {
            WorkerRequest::Install { helper, generation } => {
                helper_pid.store(helper.pid(), Ordering::SeqCst);
                sampler.helper = Some(helper);
                sampler.generation = generation;
            }
            WorkerRequest::DropHelper { generation } => {
                drop_requested.store(false, Ordering::SeqCst);
                release_helper(sampler, helper_pid);
                sampler.generation = generation;
            }
            WorkerRequest::Signal { pid, signal, reply } => {
                let result = if let Some(helper) = sampler.helper.as_mut() {
                    helper.send_signal(pid, signal)
                } else {
                    send_process_signal(pid, signal)
                };
                let _ = reply.send(result);
            }
            WorkerRequest::Renice { pid, delta, reply } => {
                let result = if let Some(helper) = sampler.helper.as_mut() {
                    helper.renice_process(pid, delta)
                } else {
                    renice_process(pid, delta)
                };
                let _ = reply.send(result);
            }
        }
    }
}

fn release_helper(sampler: &mut ActiveSampler, helper_pid: &AtomicU32) {
    if let Some(helper) = sampler.helper.take() {
        let pid = helper.pid();
        drop(helper);
        let _ = helper_pid.compare_exchange(pid, 0, Ordering::SeqCst, Ordering::SeqCst);
    }
}

fn sample_active(
    sampler: &mut ActiveSampler,
    helper_pid: &AtomicU32,
    drop_requested: &AtomicBool,
    pane: PaneId,
    selected_pid: Option<u32>,
) -> Result<SystemSnapshot, String> {
    // `SIGKILL` cannot reach a helper whose real uid is 0. Drop it before
    // sampling so the next snapshot comes from the unprivileged collector.
    if drop_requested.swap(false, Ordering::SeqCst) {
        release_helper(sampler, helper_pid);
    }
    let Some(helper) = sampler.helper.as_mut() else {
        return sampler.local.sample_for(pane, selected_pid);
    };
    let sampled = helper.sample_for(pane, selected_pid);
    // The drop arrived while this root sample was in flight. Do not publish it.
    if drop_requested.swap(false, Ordering::SeqCst) {
        release_helper(sampler, helper_pid);
        return sampler.local.sample_for(pane, selected_pid);
    }
    sampled
}

fn fail_pending(requests: &Mutex<Vec<WorkerRequest>>) {
    let pending = std::mem::take(&mut *lock_mutex(requests));
    for request in pending {
        match request {
            WorkerRequest::Signal { reply, .. } => {
                let _ = reply.send(Err("collector stopped".to_string()));
            }
            WorkerRequest::Renice { reply, .. } => {
                let _ = reply.send(Err("collector stopped".to_string()));
            }
            WorkerRequest::Install { .. } | WorkerRequest::DropHelper { .. } => {}
        }
    }
}

fn lock_mutex<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(|err| err.into_inner())
}

/// Process and signal chosen in the confirmation dialog.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SignalDialog {
    pub pid: u32,
    pub name: String,
    pub signal: SignalKind,
}

/// Application state for the monitor. `Default` is fixture playback so headless
/// tests do not touch `/proc`.
#[derive(Debug)]
pub struct State {
    pub source: DataSource,
    pub snapshot: SystemSnapshot,
    pub history: TelemetryHistory,
    pub rows: Vec<ProcessRow>,
    pub file_filter: FileKindFilter,
    pub file_rows: Vec<OpenFileEntry>,
    pub socket_filter: SocketKindFilter,
    pub socket_rows: Vec<NetSocketEntry>,
    pub revision: u64,
    pub pane: PaneId,
    pub focused_pane: PaneId,
    pub process_mode: ProcessMode,
    pub sort_col: SortColumn,
    pub sort_desc: bool,
    pub query: TextEdit,
    pub last_query: String,
    pub searching: bool,
    pub selected_pid: Option<u32>,
    pub selected_name: Option<String>,
    pub frozen: bool,
    pub time_window_secs: u32,
    pub poll_interval_ms: u64,
    pub last_poll_sec: f64,
    pub has_polled: bool,
    pub per_core_chart: bool,
    pub show_loopback: bool,
    /// Mirrors [`Self::appearance_mode`]. `None` is System; Dark and Light are explicit.
    pub dark: Option<bool>,
    pub appearance_mode: AppearanceMode,
    /// Fixture sessions stay on Obsidian so snapshots do not follow the host desktop.
    pub color_scheme: ColorSchemeId,
    /// Interface scale in percent. `100` is 1:1; values step by 10 from 50 through 200.
    pub ui_zoom_pct: u16,
    pub show_help: bool,
    pub show_settings: bool,
    pub system_theme: SystemThemeSnapshot,
    pub signal_dialog: Option<SignalDialog>,
    pub status_banner: Option<(String, bool)>,
    pub elevation: ElevationState,
    pub collapsed_pids: HashSet<u32>,
    pub pinned_pids: HashSet<u32>,
    pub copied_command: Option<String>,
    pub chart_hover: Option<(ChartKind, f32)>,
    pub layout_preset: LayoutPreset,
    pub card_slots: [CardId; 6],
    pub swap_source_slot: Option<usize>,
    pub drag_hover_slot: Option<usize>,
    pub slot_rects: [Option<[f32; 4]>; 6],
    pub row_splits: [f32; 3],
    pub col_splits: [f32; 4],
    pub drag_split_start: f32,
    pub(crate) drag_split_pair_start: f32,
    pub(crate) drag_prev_swap_source: Option<usize>,
    pub(crate) is_dragging_card: bool,
    prefs_path_override: Option<PathBuf>,
    /// Set when `--theme` supplied the appearance, so a later click does not overwrite the file.
    appearance_cli: bool,
    /// Set when `--color-scheme` supplied the scheme.
    scheme_cli: bool,
    last_theme_check: Option<f64>,
    pending_auth: Option<PendingAuth>,
    elevation_command: Option<ElevationCommand>,
    fixture_hook: FixtureElevationHook,
    fixture_nice: HashMap<u32, i32>,
    /// Signals go through the root helper while this is set.
    helper_routed: bool,
    helper_generation: u64,
    needed_generation: u64,
    force_sample: bool,
}

impl Default for State {
    fn default() -> Self {
        Self::new_fixture()
    }
}

impl State {
    pub fn new_fixture() -> Self {
        let (snapshot, history) = fixture_history(60);
        let mut state = Self::assemble(
            DataSource::Fixture {
                step: 60,
                killed: HashSet::new(),
            },
            snapshot,
            history,
        );
        if let Some(pid) = state.selected_pid {
            state.history.selected_proc = Default::default();
            for step in 0..60 {
                state
                    .history
                    .record_selected(Some(pid), &fixture_snapshot(step));
            }
        }
        state
    }

    /// Records one `/proc` sample so the window can open without a second walk.
    /// `LiveWorker` takes the next sample on its thread; that sample is the one
    /// that carries real rates. A read error falls back to the fixture and sets
    /// an error banner. `assemble` records the selected process from this snapshot.
    pub fn new_live() -> Self {
        let mut collector = LinuxCollector::new();
        let first = match collector.sample() {
            Ok(snapshot) => snapshot,
            Err(err) => return Self::fixture_fallback(err),
        };
        let mut history = TelemetryHistory::default();
        history.record(&first);
        let worker = LiveWorker::spawn(collector, 1_000);
        let mut state = Self::assemble(
            DataSource::Live(Box::new(LiveCollector::Worker(worker))),
            first,
            history,
        );
        state.load_user_prefs();
        state.system_theme = detect_system_theme_default();
        state
    }

    fn fixture_fallback(err: String) -> Self {
        let mut state = Self::new_fixture();
        state.status_banner = Some((format!("failed to sample /proc: {err}"), true));
        state
    }

    fn assemble(source: DataSource, snapshot: SystemSnapshot, history: TelemetryHistory) -> Self {
        let live = matches!(source, DataSource::Live(_));
        let mut state = Self {
            source,
            snapshot,
            history,
            rows: Vec::new(),
            file_filter: FileKindFilter::All,
            file_rows: Vec::new(),
            socket_filter: SocketKindFilter::All,
            socket_rows: Vec::new(),
            revision: 0,
            pane: PaneId::Overview,
            focused_pane: PaneId::Processes,
            process_mode: ProcessMode::Table,
            sort_col: SortColumn::Cpu,
            sort_desc: true,
            query: TextEdit::default(),
            last_query: String::new(),
            searching: false,
            selected_pid: None,
            selected_name: None,
            frozen: false,
            time_window_secs: 60,
            poll_interval_ms: 1_000,
            last_poll_sec: 0.0,
            has_polled: false,
            per_core_chart: true,
            show_loopback: false,
            dark: None,
            appearance_mode: AppearanceMode::System,
            color_scheme: if live {
                ColorSchemeId::System
            } else {
                ColorSchemeId::Obsidian
            },
            ui_zoom_pct: DEFAULT_ZOOM_PCT,
            show_help: false,
            show_settings: false,
            system_theme: SystemThemeSnapshot::default(),
            signal_dialog: None,
            status_banner: None,
            elevation: if live && current_euid() == 0 {
                ElevationState::Elevated
            } else {
                ElevationState::Unprivileged
            },
            collapsed_pids: HashSet::new(),
            pinned_pids: HashSet::new(),
            copied_command: None,
            chart_hover: None,
            layout_preset: LayoutPreset::Grid,
            card_slots: CardId::DEFAULT_SLOTS,
            swap_source_slot: None,
            drag_hover_slot: None,
            slot_rects: [None; 6],
            row_splits: DEFAULT_ROW_SPLITS,
            col_splits: DEFAULT_COL_SPLITS,
            drag_split_start: 0.0,
            drag_split_pair_start: 0.0,
            drag_prev_swap_source: None,
            is_dragging_card: false,
            prefs_path_override: None,
            appearance_cli: false,
            scheme_cli: false,
            last_theme_check: None,
            pending_auth: None,
            elevation_command: None,
            fixture_hook: FixtureElevationHook::default(),
            fixture_nice: HashMap::new(),
            helper_routed: false,
            helper_generation: 0,
            needed_generation: 0,
            force_sample: false,
        };
        state.rebuild_rows();
        state
    }

    pub fn rebuild_rows(&mut self) {
        self.rows = build_process_rows_ext(
            &self.snapshot.processes,
            self.process_mode,
            &self.query.text,
            self.sort_col,
            self.sort_desc,
            &self.collapsed_pids,
            &self.pinned_pids,
        );
        self.file_rows = filter_open_files(
            &self.snapshot.open_files,
            self.file_filter,
            &self.query.text,
        );
        self.socket_rows =
            filter_sockets(&self.snapshot.sockets, self.socket_filter, &self.query.text);
        let selected_visible = self.selected_pid.is_some_and(|pid| {
            self.rows.iter().any(|row| row.pid == pid)
                || (self.pane == PaneId::Files
                    && self.file_rows.iter().any(|entry| entry.pid == pid))
                || (self.pane == PaneId::Network
                    && self.socket_rows.iter().any(|entry| entry.pid == Some(pid)))
        });
        if !selected_visible {
            let by_name = self.selected_name.as_ref().and_then(|name| {
                self.rows
                    .iter()
                    .find(|row| row.display_name == *name)
                    .map(|row| row.pid)
            });
            self.selected_pid = by_name
                .or_else(|| {
                    (self.pane == PaneId::Files)
                        .then(|| self.file_rows.first().map(|entry| entry.pid))
                        .flatten()
                })
                .or_else(|| self.rows.first().map(|row| row.pid));
        }
        self.note_selection();
        self.revision = self.revision.wrapping_add(1);
    }

    /// Rebuilds process rows when the search text changed since the last build.
    pub fn sync_query(&mut self) -> bool {
        if self.query.text == self.last_query {
            return false;
        }
        self.last_query.clone_from(&self.query.text);
        self.rebuild_rows();
        true
    }

    /// View hook for a search field's input changes.
    pub fn on_query_change(&mut self) {
        self.sync_query();
    }

    fn note_selection(&mut self) {
        self.selected_name = self
            .selected_row()
            .map(|row| row.display_name.clone())
            .or_else(|| self.selected_process().map(|proc| proc.name.clone()));
        if self.history.selected_proc.pid != self.selected_pid {
            self.history
                .record_selected(self.selected_pid, &self.snapshot);
        }
    }

    pub fn selected_process(&self) -> Option<&ProcessInfo> {
        let pid = self.selected_pid?;
        self.snapshot.processes.iter().find(|proc| proc.pid == pid)
    }

    pub fn selected_row(&self) -> Option<&ProcessRow> {
        let pid = self.selected_pid?;
        self.rows.iter().find(|row| row.pid == pid)
    }

    /// Samples that fit in the visible window at the current poll rate.
    pub fn sample_count(&self) -> usize {
        let interval_ms = self.poll_interval_ms.max(1);
        let samples = usize::try_from(u64::from(self.time_window_secs) * 1_000 / interval_ms)
            .unwrap_or(HistoryRing::<f32>::DEFAULT_CAPACITY);
        samples.clamp(MIN_SAMPLES, HistoryRing::<f32>::DEFAULT_CAPACITY)
    }

    fn sync_collector_control(&self) {
        if let DataSource::Live(collector) = &self.source {
            collector.configure(
                self.poll_interval_ms,
                self.frozen,
                self.pane,
                self.selected_pid,
            );
        }
    }

    pub fn tick(&mut self) {
        self.pump_elevation();
        self.sync_collector_control();
        if self.frozen {
            return;
        }
        let live = matches!(self.source, DataSource::Live(_));
        let pane = self.pane;
        let selected_pid = self.selected_pid;
        let outcome = match &mut self.source {
            DataSource::Fixture { step, killed } => {
                let current = *step;
                *step = current.saturating_add(1);
                let mut next = fixture_snapshot(current);
                next.processes.retain(|proc| !killed.contains(&proc.pid));
                next.open_files.retain(|entry| !killed.contains(&entry.pid));
                if !self.fixture_nice.is_empty() {
                    for proc in &mut next.processes {
                        if let Some(&nice) = self.fixture_nice.get(&proc.pid) {
                            proc.nice = nice;
                        }
                    }
                }
                Ok(Box::new(next))
            }
            DataSource::Live(collector) => match collector.pull(pane, selected_pid) {
                LivePull::Pending => return,
                LivePull::Ready { result, generation } => {
                    if self.force_sample && generation >= self.needed_generation {
                        self.force_sample = false;
                    }
                    (*result).map(Box::new)
                }
            },
        };
        match outcome {
            Ok(snapshot) => {
                if live
                    && self
                        .status_banner
                        .as_ref()
                        .is_some_and(|(message, is_error)| {
                            *is_error && message.starts_with("failed to sample")
                        })
                {
                    self.status_banner = None;
                }
                let prev_tracked = self.history.selected_proc.pid;
                self.history.record(&snapshot);
                self.snapshot = *snapshot;
                self.rebuild_rows();
                if self.selected_pid == prev_tracked {
                    self.history
                        .record_selected(self.selected_pid, &self.snapshot);
                }
            }
            Err(err) => {
                self.status_banner = Some((format!("failed to sample /proc: {err}"), true));
            }
        }
    }

    pub fn poll(s: &mut State, now: f64, tx: &mut Tx) -> bool {
        let fast = s.elevation == ElevationState::Authenticating
            || s.force_sample
            || (s.is_live() && s.history.cpu_total.len() < 2);
        let wait_ms = if fast {
            50
        } else {
            s.poll_interval_ms.clamp(100, 5_000)
        };
        tx.wake_after(Duration::from_millis(wait_ms));
        let theme_changed = s.poll_system_theme(now);
        if theme_changed {
            tx.instant();
        }
        let elevation_before = s.elevation;
        let banner_before = s.status_banner.clone();
        s.pump_elevation();
        s.sync_collector_control();
        let query_changed = s.sync_query();
        let auth_changed = s.elevation != elevation_before || s.status_banner != banner_before;
        if auth_changed {
            tx.instant();
        }
        if s.frozen {
            return query_changed || theme_changed || auth_changed;
        }
        let interval = s.poll_interval_ms as f64 / 1_000.0;
        let due = fast || !s.has_polled || now - s.last_poll_sec >= interval;
        if !due {
            return query_changed || theme_changed || auth_changed;
        }
        s.has_polled = true;
        s.last_poll_sec = now;
        let revision = s.revision;
        let banner = s.status_banner.clone();
        let samples = s.history.cpu_total.len();
        s.tick();
        let updated = s.revision != revision
            || s.status_banner != banner
            || s.history.cpu_total.len() != samples;
        if updated {
            tx.instant();
        }
        true
    }

    pub fn set_pane(&mut self, pane: PaneId) {
        let changed = self.pane != pane;
        self.pane = pane;
        if pane != PaneId::Overview {
            self.focused_pane = pane;
        }
        if changed && pane == PaneId::Files && self.is_live() && self.snapshot.open_files.is_empty()
        {
            self.force_sample = true;
            self.sync_collector_control();
        }
    }

    pub fn toggle_zoom(&mut self) {
        if self.pane == PaneId::Overview {
            self.pane = self.focused_pane;
        } else {
            self.pane = PaneId::Overview;
        }
    }

    pub fn cycle_focused_pane(&mut self, reverse: bool) {
        let index = FOCUS_ORDER
            .iter()
            .position(|pane| *pane == self.focused_pane);
        let next = match (index, reverse) {
            (Some(index), true) => (index + FOCUS_ORDER.len() - 1) % FOCUS_ORDER.len(),
            (Some(index), false) => (index + 1) % FOCUS_ORDER.len(),
            (None, true) => FOCUS_ORDER.len() - 1,
            (None, false) => 0,
        };
        self.focused_pane = FOCUS_ORDER[next];
        if self.pane != PaneId::Overview {
            self.pane = self.focused_pane;
        }
    }

    pub fn set_process_mode(&mut self, mode: ProcessMode) {
        self.process_mode = mode;
        self.rebuild_rows();
    }

    pub fn set_file_filter(&mut self, filter: FileKindFilter) {
        self.file_filter = filter;
        self.rebuild_rows();
    }

    pub fn set_socket_filter(&mut self, filter: SocketKindFilter) {
        self.socket_filter = filter;
        self.rebuild_rows();
    }

    pub fn click_sort(&mut self, col: SortColumn) {
        if self.sort_col == col {
            self.sort_desc = !self.sort_desc;
        } else {
            self.sort_col = col;
            self.sort_desc = !matches!(
                col,
                SortColumn::Pid | SortColumn::Name | SortColumn::User | SortColumn::State
            );
        }
        self.rebuild_rows();
    }

    pub fn select_pid(&mut self, pid: u32) {
        self.selected_pid = Some(pid);
        self.note_selection();
    }

    pub fn toggle_pin_pid(&mut self, pid: u32) {
        if !self.pinned_pids.remove(&pid) {
            self.pinned_pids.insert(pid);
        }
        self.rebuild_rows();
    }

    pub fn toggle_pin_selected(&mut self) {
        if let Some(pid) = self.selected_pid {
            self.toggle_pin_pid(pid);
        }
    }

    fn pid_has_children(&self, pid: u32) -> bool {
        self.rows
            .iter()
            .find(|row| row.pid == pid)
            .is_some_and(|row| row.has_children)
            || self
                .snapshot
                .processes
                .iter()
                .any(|proc| proc.ppid == pid && proc.pid != pid)
    }

    fn is_descendant_of(&self, mut pid: u32, ancestor: u32) -> bool {
        let mut visited = HashSet::new();
        while visited.insert(pid) {
            let Some(proc) = self.snapshot.processes.iter().find(|p| p.pid == pid) else {
                return false;
            };
            if proc.ppid == ancestor {
                return true;
            }
            if proc.ppid == 0 || proc.ppid == pid {
                return false;
            }
            pid = proc.ppid;
        }
        false
    }

    pub fn toggle_collapse_pid(&mut self, pid: u32) {
        let now_collapsed = if self.collapsed_pids.remove(&pid) {
            false
        } else if self.pid_has_children(pid) {
            self.collapsed_pids.insert(pid);
            true
        } else {
            return;
        };
        if now_collapsed
            && let Some(sel) = self.selected_pid
            && sel != pid
            && self.is_descendant_of(sel, pid)
        {
            self.selected_pid = Some(pid);
        }
        self.rebuild_rows();
    }

    pub fn collapse_selected(&mut self) {
        let Some(pid) = self.selected_pid else {
            return;
        };
        if self.pid_has_children(pid) && self.collapsed_pids.insert(pid) {
            self.rebuild_rows();
        }
    }

    pub fn expand_selected(&mut self) {
        let Some(pid) = self.selected_pid else {
            return;
        };
        if self.collapsed_pids.remove(&pid) {
            self.rebuild_rows();
        }
    }

    pub fn renice_selected(&mut self, delta: i32) {
        let Some((pid, name)) = self
            .selected_process()
            .map(|proc| (proc.pid, proc.name.clone()))
        else {
            self.status_banner = Some(("No process selected".to_string(), true));
            return;
        };
        if pid <= 1 {
            self.status_banner = Some((format!("refusing to renice pid {pid}"), true));
            return;
        }
        if matches!(self.source, DataSource::Fixture { .. }) {
            if let Some(proc) = self.snapshot.processes.iter_mut().find(|p| p.pid == pid) {
                let new_nice = proc.nice.saturating_add(delta).clamp(-20, 19);
                proc.nice = new_nice;
                self.fixture_nice.insert(pid, new_nice);
                self.revision = self.revision.wrapping_add(1);
                self.status_banner = Some((
                    format!("Reniced {} (pid {pid}) to nice {new_nice}", proc.name),
                    false,
                ));
            }
            return;
        }
        let result = if self.helper_routed {
            self.renice_via_helper(pid, delta)
        } else {
            renice_process(pid, delta)
        };
        match result {
            Ok(new_nice) => {
                if let Some(proc) = self.snapshot.processes.iter_mut().find(|p| p.pid == pid) {
                    proc.nice = new_nice;
                }
                self.revision = self.revision.wrapping_add(1);
                self.status_banner = Some((
                    format!("Reniced {name} (pid {pid}) to nice {new_nice}"),
                    false,
                ));
            }
            Err(err) => {
                self.status_banner = Some((err, true));
            }
        }
    }

    fn renice_via_helper(&mut self, pid: u32, delta: i32) -> Result<i32, String> {
        match &mut self.source {
            DataSource::Live(collector) => collector.send_renice(pid, delta),
            DataSource::Fixture { .. } => Ok(0),
        }
    }

    pub fn copy_selected_command(&mut self) {
        let Some((pid, name, cmd)) = self.selected_process().map(|proc| {
            let cmd = if proc.cmdline.is_empty() {
                proc.name.clone()
            } else {
                proc.cmdline.clone()
            };
            (proc.pid, proc.name.clone(), cmd)
        }) else {
            self.status_banner = Some(("No process selected".to_string(), true));
            return;
        };
        self.copied_command = Some(cmd.clone());
        #[cfg(not(test))]
        if self.is_live() && std::env::var_os("WAYLAND_DISPLAY").is_some() {
            let _ = thread::Builder::new()
                .name("vitals-clipboard".to_string())
                .spawn(move || {
                    if let Ok(mut child) = Command::new("wl-copy")
                        .arg("--")
                        .arg(cmd)
                        .stdin(std::process::Stdio::null())
                        .stdout(std::process::Stdio::null())
                        .stderr(std::process::Stdio::null())
                        .spawn()
                    {
                        let _ = child.wait();
                    }
                });
        }
        self.status_banner = Some((format!("Copied command for {name} (pid {pid})"), false));
    }

    pub fn move_selection(&mut self, delta: isize) {
        let len = self.rows.len();
        if len == 0 {
            return;
        }
        let last = len - 1;
        let current = self
            .selected_pid
            .and_then(|pid| self.rows.iter().position(|row| row.pid == pid));
        let next = match current {
            Some(index) => {
                let last = isize::try_from(last).unwrap_or(isize::MAX);
                let index = isize::try_from(index).unwrap_or(0);
                let next = index.saturating_add(delta).clamp(0, last);
                usize::try_from(next).unwrap_or(0)
            }
            None if delta < 0 => last,
            None => 0,
        };
        self.selected_pid = Some(self.rows[next].pid);
        self.note_selection();
    }

    pub fn cycle_time_window(&mut self, shorter: bool) {
        self.time_window_secs = cycle_choice(self.time_window_secs, &TIME_WINDOWS, shorter);
    }

    pub fn cycle_poll_interval(&mut self, faster: bool) {
        self.poll_interval_ms = cycle_choice(self.poll_interval_ms, &POLL_INTERVALS_MS, faster);
    }

    /// Resolved dark face: the mode, then the desktop file, then the portal bit passed in.
    pub fn resolved_dark(&self, portal_dark: bool) -> bool {
        self.appearance_mode
            .resolve(self.system_prefers_dark(portal_dark))
    }

    /// Desktop preference, or the portal when no theme file named a mode.
    pub fn system_prefers_dark(&self, portal_dark: bool) -> bool {
        self.system_theme.system_dark.unwrap_or(portal_dark)
    }

    pub fn set_appearance_mode(&mut self, mode: AppearanceMode) {
        self.appearance_mode = mode;
        self.dark = mode.as_dark_option();
        self.persist_user_prefs();
    }

    pub fn cycle_appearance_mode(&mut self) {
        self.set_appearance_mode(self.appearance_mode.cycle());
    }

    pub fn set_color_scheme(&mut self, scheme: ColorSchemeId) {
        self.color_scheme = scheme;
        self.persist_user_prefs();
    }

    pub fn cycle_color_scheme(&mut self) {
        self.set_color_scheme(self.color_scheme.cycle());
    }

    /// Scale factor for the whole window. Out-of-range percents clamp to 50%–200%.
    pub fn ui_zoom(&self) -> f32 {
        f32::from(self.ui_zoom_pct.clamp(MIN_ZOOM_PCT, MAX_ZOOM_PCT)) / 100.0
    }

    /// Stores `pct` clamped to 50%–200% and rounded to the nearest 10, then saves it.
    pub fn set_ui_zoom_pct(&mut self, pct: u16) {
        self.ui_zoom_pct = normalize_zoom_pct(pct);
        self.persist_user_prefs();
    }

    /// Steps the interface scale up by 10 percent, stopping at 200%.
    pub fn zoom_in(&mut self) {
        self.ui_zoom_pct = self
            .ui_zoom_pct
            .saturating_add(ZOOM_STEP_PCT)
            .min(MAX_ZOOM_PCT);
        self.persist_user_prefs();
    }

    /// Steps the interface scale down by 10 percent, stopping at 50%.
    pub fn zoom_out(&mut self) {
        self.ui_zoom_pct = self
            .ui_zoom_pct
            .saturating_sub(ZOOM_STEP_PCT)
            .max(MIN_ZOOM_PCT);
        self.persist_user_prefs();
    }

    /// Returns the interface to 100%.
    pub fn reset_ui_zoom(&mut self) {
        self.ui_zoom_pct = DEFAULT_ZOOM_PCT;
        self.persist_user_prefs();
    }

    pub fn toggle_settings(&mut self) {
        self.show_settings = !self.show_settings;
        if self.show_settings {
            self.show_help = false;
            self.signal_dialog = None;
        }
    }

    pub fn set_layout_preset(&mut self, preset: LayoutPreset) {
        self.layout_preset = preset;
        self.swap_source_slot = None;
        self.drag_hover_slot = None;
        self.drag_prev_swap_source = None;
        self.persist_user_prefs();
    }

    pub fn cycle_layout_preset(&mut self) {
        self.set_layout_preset(self.layout_preset.cycle());
    }

    pub fn swap_card_slots(&mut self, a: usize, b: usize) {
        if a < 6 && b < 6 && a != b {
            self.card_slots.swap(a, b);
        }
        self.swap_source_slot = None;
        self.drag_hover_slot = None;
        self.drag_prev_swap_source = None;
        self.is_dragging_card = false;
        self.persist_user_prefs();
    }

    pub fn reset_row_split(&mut self, index: usize) {
        if index + 1 < self.row_splits.len() {
            self.row_splits[index] = DEFAULT_ROW_SPLITS[index];
            self.row_splits[index + 1] = DEFAULT_ROW_SPLITS[index + 1];
            self.persist_user_prefs();
        }
    }

    pub fn reset_col_split(&mut self, index: usize) {
        if index < self.col_splits.len() {
            self.col_splits[index] = DEFAULT_COL_SPLITS[index];
            self.persist_user_prefs();
        }
    }

    pub fn reset_layout(&mut self) {
        self.layout_preset = LayoutPreset::Grid;
        self.card_slots = CardId::DEFAULT_SLOTS;
        self.row_splits = DEFAULT_ROW_SPLITS;
        self.col_splits = DEFAULT_COL_SPLITS;
        self.swap_source_slot = None;
        self.drag_hover_slot = None;
        self.drag_prev_swap_source = None;
        self.is_dragging_card = false;
        self.persist_user_prefs();
    }

    /// Redirects settings reads and writes to `path` (used by restart persistence tests).
    pub fn set_prefs_path(&mut self, path: impl Into<PathBuf>) {
        self.prefs_path_override = Some(path.into());
    }

    /// Reloads persisted user preferences from the active settings file.
    pub fn reload_user_prefs(&mut self) {
        self.load_user_prefs();
    }

    pub(crate) fn persist_prefs(&self) {
        self.persist_user_prefs();
    }

    /// Restores monitor timing and the source's default appearance. Clears CLI locks so the
    /// reset is what the next ordinary launch reads.
    pub fn reset_to_system_defaults(&mut self) {
        self.poll_interval_ms = 1_000;
        self.time_window_secs = 60;
        self.per_core_chart = true;
        self.show_loopback = false;
        self.appearance_cli = false;
        self.scheme_cli = false;
        self.appearance_mode = AppearanceMode::System;
        self.dark = None;
        self.ui_zoom_pct = DEFAULT_ZOOM_PCT;
        self.color_scheme = if self.is_live() {
            ColorSchemeId::System
        } else {
            ColorSchemeId::Obsidian
        };
        self.layout_preset = LayoutPreset::Grid;
        self.card_slots = CardId::DEFAULT_SLOTS;
        self.row_splits = DEFAULT_ROW_SPLITS;
        self.col_splits = DEFAULT_COL_SPLITS;
        self.swap_source_slot = None;
        self.drag_hover_slot = None;
        self.drag_prev_swap_source = None;
        self.is_dragging_card = false;
        self.persist_user_prefs();
    }

    /// Applies CLI theme flags without writing them back to `settings.json`.
    pub fn apply_cli_theme(
        &mut self,
        appearance: Option<AppearanceMode>,
        scheme: Option<ColorSchemeId>,
    ) {
        if appearance.is_some() {
            self.appearance_cli = true;
        }
        if scheme.is_some() {
            self.scheme_cli = true;
        }
        if let Some(mode) = appearance {
            self.appearance_mode = mode;
            self.dark = mode.as_dark_option();
        }
        if let Some(scheme) = scheme {
            self.color_scheme = scheme;
        }
    }

    fn is_live(&self) -> bool {
        matches!(self.source, DataSource::Live(_))
    }

    fn poll_system_theme(&mut self, now: f64) -> bool {
        if !self.is_live() {
            return false;
        }
        if self.last_theme_check.is_some_and(|then| now - then < 2.0) {
            return false;
        }
        self.last_theme_check = Some(now);
        let next = detect_system_theme_default();
        if next == self.system_theme {
            return false;
        }
        self.system_theme = next;
        true
    }

    fn active_prefs_path(&self) -> Option<PathBuf> {
        if let Some(path) = &self.prefs_path_override {
            Some(path.clone())
        } else if self.is_live() {
            Some(prefs_path())
        } else {
            None
        }
    }

    fn load_user_prefs(&mut self) {
        let prefs = if let Some(path) = &self.prefs_path_override {
            read_prefs(path)
        } else if self.is_live() {
            read_prefs_from_config_dir(&crate::theme::config_dir())
        } else {
            None
        };
        let Some(prefs) = prefs else {
            return;
        };
        self.apply_user_prefs(prefs);
    }

    fn apply_user_prefs(&mut self, prefs: UserPrefs) {
        if !self.appearance_cli {
            self.appearance_mode = prefs.appearance;
            self.dark = prefs.appearance.as_dark_option();
        }
        if !self.scheme_cli {
            self.color_scheme = prefs.scheme;
        }
        self.ui_zoom_pct = prefs.ui_zoom_pct;
        self.layout_preset = prefs.layout_preset;
        self.card_slots = prefs.card_slots;
        self.row_splits = prefs.row_splits;
        self.col_splits = prefs.col_splits;
    }

    fn persist_user_prefs(&self) {
        let Some(path) = self.active_prefs_path() else {
            return;
        };
        let saved = if self.prefs_path_override.is_some() {
            read_prefs(&path)
        } else {
            read_prefs_with_legacy_fallback(&path, &legacy_prefs_path())
        };
        let Some(prefs) = merged_prefs_full(
            self.appearance_cli,
            self.scheme_cli,
            UserPrefs {
                appearance: self.appearance_mode,
                scheme: self.color_scheme,
                ui_zoom_pct: self.ui_zoom_pct,
                layout_preset: self.layout_preset,
                card_slots: self.card_slots,
                row_splits: self.row_splits,
                col_splits: self.col_splits,
            },
            saved,
        ) else {
            return;
        };
        let _ = write_prefs(&path, &prefs);
    }

    pub fn open_signal_dialog(&mut self, signal: SignalKind) {
        let selected = self
            .selected_process()
            .map(|proc| (proc.pid, proc.name.clone()));
        match selected {
            Some((pid, name)) if pid > 1 => {
                self.show_help = false;
                self.show_settings = false;
                self.signal_dialog = Some(SignalDialog { pid, name, signal });
            }
            Some((pid, _)) => {
                self.status_banner = Some((format!("refusing to signal pid {pid}"), true));
            }
            None => {
                self.status_banner = Some(("No process selected".to_string(), true));
            }
        }
    }

    pub fn toggle_elevation(&mut self) {
        if !self.is_live() {
            if let Some(hook) = self.fixture_hook.0 {
                hook(self);
                return;
            }
            self.elevation = match self.elevation {
                ElevationState::Elevated => ElevationState::Unprivileged,
                ElevationState::Unprivileged | ElevationState::Authenticating => {
                    ElevationState::Elevated
                }
            };
            return;
        }
        match self.elevation {
            ElevationState::Unprivileged => self.begin_authentication(),
            ElevationState::Authenticating | ElevationState::Elevated => self.drop_privileges(),
        }
    }

    /// Replaces `pkexec` so tests can drive the helper without a Polkit dialog.
    pub fn set_elevation_command(&mut self, program: impl Into<PathBuf>, args: Vec<String>) {
        self.elevation_command = Some(ElevationCommand {
            program: program.into(),
            args,
        });
    }

    /// Fixture sessions call this instead of flipping the simulated elevation flag.
    pub fn set_fixture_elevation_hook(&mut self, hook: fn(&mut State)) {
        self.fixture_hook = FixtureElevationHook(Some(hook));
    }

    pub fn confirm_signal(&mut self) {
        let Some(dialog) = self.signal_dialog.take() else {
            return;
        };
        if self.helper_routed {
            self.status_banner = Some(match self.signal_via_helper(dialog.pid, dialog.signal) {
                Ok(()) => (signal_notice(&dialog), false),
                Err(err) => (err, true),
            });
            return;
        }
        if matches!(self.source, DataSource::Live(_)) {
            self.status_banner = Some(match send_process_signal(dialog.pid, dialog.signal) {
                Ok(()) => (signal_notice(&dialog), false),
                Err(err) => (err, true),
            });
            return;
        }
        if let DataSource::Fixture { killed, .. } = &mut self.source {
            killed.insert(dialog.pid);
        }
        self.pinned_pids.remove(&dialog.pid);
        self.collapsed_pids.remove(&dialog.pid);
        self.fixture_nice.remove(&dialog.pid);
        self.snapshot
            .processes
            .retain(|proc| proc.pid != dialog.pid);
        self.snapshot
            .open_files
            .retain(|entry| entry.pid != dialog.pid);
        self.rebuild_rows();
        self.status_banner = Some((signal_notice(&dialog), false));
    }

    fn signal_via_helper(&mut self, pid: u32, signal: SignalKind) -> Result<(), String> {
        match &mut self.source {
            DataSource::Live(collector) => collector.send_signal(pid, signal),
            DataSource::Fixture { .. } => Ok(()),
        }
    }

    fn elevation_command(&self) -> Command {
        if let Some(custom) = &self.elevation_command {
            let mut command = Command::new(&custom.program);
            command.args(&custom.args);
            return command;
        }
        let pkexec = if Path::new("/run/wrappers/bin/pkexec").is_file() {
            "/run/wrappers/bin/pkexec"
        } else {
            "pkexec"
        };
        let exe = std::env::current_exe().unwrap_or_else(|_| PathBuf::from("vitals"));
        let mut command = Command::new(pkexec);
        command
            .arg("--disable-internal-agent")
            .arg(exe)
            .arg("--collector-helper");
        command
    }

    fn begin_authentication(&mut self) {
        self.pending_auth = None;
        self.elevation = ElevationState::Authenticating;
        self.status_banner = Some((BANNER_AUTHENTICATE.to_string(), false));
        let command = self.elevation_command();
        let (tx, rx) = mpsc::channel();
        let cancel = Arc::new(AtomicBool::new(false));
        let disarm = Arc::new(AtomicBool::new(false));
        let pid = Arc::new(AtomicU32::new(0));
        let cancel_thread = Arc::clone(&cancel);
        let pid_thread = Arc::clone(&pid);
        let thread = thread::Builder::new()
            .name("vitals-elevate".to_string())
            .spawn(move || authenticate(command, cancel_thread, pid_thread, tx))
            .expect("spawn vitals-elevate");
        self.pending_auth = Some(PendingAuth {
            cancel,
            disarm,
            pid,
            outcome: rx,
            thread: Some(thread),
        });
    }

    fn drop_privileges(&mut self) {
        let cancelling = self.elevation == ElevationState::Authenticating;
        self.pending_auth = None;
        self.helper_routed = false;
        self.helper_generation = self.helper_generation.saturating_add(1);
        let generation = self.helper_generation;
        if let DataSource::Live(collector) = &mut self.source {
            collector.drop_helper(generation);
        }
        self.needed_generation = generation;
        self.force_sample = true;
        self.elevation = ElevationState::Unprivileged;
        let banner = if cancelling {
            BANNER_AUTH_CANCELLED
        } else {
            BANNER_DROPPED
        };
        self.status_banner = Some((banner.to_string(), false));
    }

    fn pump_elevation(&mut self) -> bool {
        let outcome = {
            let Some(pending) = self.pending_auth.as_ref() else {
                return false;
            };
            match pending.outcome.try_recv() {
                Ok(outcome) => outcome,
                Err(mpsc::TryRecvError::Empty) => return false,
                Err(mpsc::TryRecvError::Disconnected) => AuthOutcome::Failed {
                    message: "authentication thread stopped before the Polkit dialog finished"
                        .to_string(),
                },
            }
        };
        if matches!(outcome, AuthOutcome::Ready(_))
            && let Some(pending) = self.pending_auth.as_ref()
        {
            pending.disarm.store(true, Ordering::SeqCst);
        }
        self.pending_auth = None;
        self.apply_auth_outcome(outcome);
        true
    }

    fn apply_auth_outcome(&mut self, outcome: AuthOutcome) {
        match outcome {
            AuthOutcome::Ready(helper) => {
                self.helper_generation = self.helper_generation.saturating_add(1);
                let generation = self.helper_generation;
                if let DataSource::Live(collector) = &mut self.source {
                    collector.install_helper(helper, generation);
                }
                self.needed_generation = generation;
                self.force_sample = true;
                self.helper_routed = true;
                self.elevation = ElevationState::Elevated;
                self.status_banner = Some((BANNER_ELEVATED.to_string(), false));
            }
            AuthOutcome::PolkitCancelled => {
                self.helper_routed = false;
                self.elevation = ElevationState::Unprivileged;
                self.status_banner = Some((BANNER_AUTH_CANCELLED.to_string(), false));
            }
            AuthOutcome::Failed { message } => {
                self.helper_routed = false;
                self.elevation = ElevationState::Unprivileged;
                self.status_banner = Some((message, true));
            }
            AuthOutcome::Superseded => {}
        }
    }

    pub fn on_key(s: &mut State, ev: &KeyEvent, tx: &mut Tx) -> bool {
        if s.searching && !s.query.focused {
            s.searching = false;
        }
        s.sync_query();
        if matches!(ev.key, Key::Escape) && !command_mods(ev) {
            return on_escape(s, tx);
        }
        // Zoom is global: it still runs while search or a dialog owns the keyboard.
        if on_zoom_key(s, ev, tx) {
            return true;
        }
        if s.signal_dialog.is_some() {
            return on_dialog_key(s, ev);
        }
        if is_find_shortcut(ev) {
            focus_search(s);
            return true;
        }
        if s.searching {
            return false;
        }
        on_global_key(s, ev, tx)
    }
}

#[derive(Debug, Clone)]
struct ElevationCommand {
    program: PathBuf,
    args: Vec<String>,
}

#[derive(Clone, Copy, Default)]
struct FixtureElevationHook(Option<fn(&mut State)>);

impl std::fmt::Debug for FixtureElevationHook {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self.0 {
            Some(_) => formatter.write_str("Some(hook)"),
            None => formatter.write_str("None"),
        }
    }
}

enum AuthOutcome {
    Ready(HelperClient),
    PolkitCancelled,
    Failed { message: String },
    Superseded,
}

struct PendingAuth {
    cancel: Arc<AtomicBool>,
    disarm: Arc<AtomicBool>,
    pid: Arc<AtomicU32>,
    outcome: Receiver<AuthOutcome>,
    thread: Option<JoinHandle<()>>,
}

impl std::fmt::Debug for PendingAuth {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("PendingAuth")
            .field("pid", &self.pid.load(Ordering::Relaxed))
            .field("cancel", &self.cancel.load(Ordering::Relaxed))
            .finish()
    }
}

impl Drop for PendingAuth {
    fn drop(&mut self) {
        if !self.disarm.load(Ordering::SeqCst) {
            self.cancel.store(true, Ordering::SeqCst);
            let pid = self.pid.load(Ordering::SeqCst);
            if pid > 0 {
                kill_process_group(pid);
            }
        }
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn authenticate(
    command: Command,
    cancel: Arc<AtomicBool>,
    pid_slot: Arc<AtomicU32>,
    tx: Sender<AuthOutcome>,
) {
    let outcome = match HelperClient::spawn_with(command, |pid| {
        pid_slot.store(pid, Ordering::SeqCst);
        if cancel.load(Ordering::SeqCst) {
            kill_process_group(pid);
        }
    }) {
        Ok(client) if cancel.load(Ordering::SeqCst) => {
            drop(client);
            AuthOutcome::Superseded
        }
        Ok(client) => AuthOutcome::Ready(client),
        Err(_) if cancel.load(Ordering::SeqCst) => AuthOutcome::Superseded,
        Err(err) => match err.exit_code {
            Some(126) => AuthOutcome::PolkitCancelled,
            _ => AuthOutcome::Failed {
                message: err.message,
            },
        },
    };
    let _ = tx.send(outcome);
}

fn current_euid() -> u32 {
    // Safety: `geteuid` only reads the process credential.
    unsafe { libc::geteuid() }
}

fn signal_notice(dialog: &SignalDialog) -> String {
    format!(
        "Sent {} to {} (pid {})",
        dialog.signal.label(),
        dialog.name,
        dialog.pid
    )
}

fn cycle_choice<T: Copy + PartialEq>(current: T, choices: &[T], toward_start: bool) -> T {
    let Some(index) = choices.iter().position(|choice| *choice == current) else {
        return choices.first().copied().unwrap_or(current);
    };
    let count = choices.len();
    let next = if toward_start {
        (index + count - 1) % count
    } else {
        (index + 1) % count
    };
    choices[next]
}

fn command_mods(ev: &KeyEvent) -> bool {
    ev.mods.ctrl || ev.mods.alt || ev.mods.cmd || ev.mods.logo
}

fn key_text(ev: &KeyEvent) -> Option<&str> {
    match &ev.key {
        Key::Text(text) => Some(text.as_str()),
        _ => None,
    }
}

fn is_find_shortcut(ev: &KeyEvent) -> bool {
    ev.is_command('f') || (ev.mods.ctrl && !ev.mods.alt && matches!(key_text(ev), Some("f" | "F")))
}

/// `Ctrl+Shift++`, `Ctrl+Shift+-`, and `Ctrl+Shift+0`.
///
/// On Linux/Wayland, winit reports Ctrl as both `ctrl` and `cmd`. Shift rewrites the logical
/// key (`=` → `+`, `-` → `_`, `0` → `)`) while [`Tx::key_base`] and [`Tx::physical_key`] still
/// name the unshifted key. A `+`, `_`, or `)` with the modifier chord also matches when the
/// layout consumed Shift. `Key::Command` is already that chord, so a headless event that sets
/// only `shift` still matches.
fn on_zoom_key(state: &mut State, ev: &KeyEvent, tx: &mut Tx) -> bool {
    if !zoom_chord_mods(ev) {
        return false;
    }
    let action = if is_zoom_in(ev, tx) {
        ZoomStep::In
    } else if is_zoom_out(ev, tx) {
        ZoomStep::Out
    } else if is_zoom_reset(ev, tx) {
        ZoomStep::Reset
    } else {
        return false;
    };
    tx.instant();
    match action {
        ZoomStep::In => state.zoom_in(),
        ZoomStep::Out => state.zoom_out(),
        ZoomStep::Reset => state.reset_ui_zoom(),
    }
    true
}

enum ZoomStep {
    In,
    Out,
    Reset,
}

fn zoom_chord_mods(ev: &KeyEvent) -> bool {
    !ev.mods.alt && (ev.mods.ctrl || ev.mods.cmd || matches!(ev.key, Key::Command(_)))
}

fn is_zoom_in(ev: &KeyEvent, tx: &Tx) -> bool {
    let shifted = ev.mods.shift
        && (matches!(ev.key, Key::Command('+' | '='))
            || matches!(key_text(ev), Some("+" | "="))
            || matches!(tx.key_base(), Some('+' | '='))
            || matches!(
                tx.physical_key(),
                Some(PhysicalKeyCode::Equal | PhysicalKeyCode::NumpadAdd)
            ));
    shifted || matches!(ev.key, Key::Command('+')) || matches!(key_text(ev), Some("+"))
}

fn is_zoom_out(ev: &KeyEvent, tx: &Tx) -> bool {
    let shifted = ev.mods.shift
        && (matches!(ev.key, Key::Command('-' | '_'))
            || matches!(key_text(ev), Some("-" | "_"))
            || matches!(tx.key_base(), Some('-' | '_'))
            || matches!(
                tx.physical_key(),
                Some(PhysicalKeyCode::Minus | PhysicalKeyCode::NumpadSubtract)
            ));
    shifted || matches!(ev.key, Key::Command('_')) || matches!(key_text(ev), Some("_"))
}

fn is_zoom_reset(ev: &KeyEvent, tx: &Tx) -> bool {
    let shifted = ev.mods.shift
        && (matches!(ev.key, Key::Command('0' | ')'))
            || matches!(key_text(ev), Some("0" | ")"))
            || matches!(tx.key_base(), Some('0' | ')'))
            || matches!(
                tx.physical_key(),
                Some(PhysicalKeyCode::Digit0 | PhysicalKeyCode::Numpad0)
            ));
    shifted || matches!(ev.key, Key::Command(')')) || matches!(key_text(ev), Some(")"))
}

/// Rune requests field focus by setting [`TextEdit::focused`] once. `Tx` can
/// drop it with [`Tx::blur`] but has no `focus` method at this revision. The
/// view should key the bound field `"search"`.
fn focus_search(state: &mut State) {
    state.searching = true;
    state.query.focused = true;
}

fn on_escape(state: &mut State, tx: &mut Tx) -> bool {
    if state.signal_dialog.take().is_some() {
        return true;
    }
    if state.show_settings {
        state.show_settings = false;
        return true;
    }
    if state.show_help {
        state.show_help = false;
        return true;
    }
    if state.swap_source_slot.take().is_some() {
        state.drag_hover_slot = None;
        state.drag_prev_swap_source = None;
        state.is_dragging_card = false;
        return true;
    }
    if state.searching {
        state.searching = false;
        state.query.focused = false;
        tx.blur();
        return true;
    }
    if !state.query.text.is_empty() {
        state.query.clear();
        state.last_query.clear();
        state.rebuild_rows();
        return true;
    }
    if state.pane != PaneId::Overview {
        state.pane = PaneId::Overview;
        return true;
    }
    false
}

fn on_dialog_key(state: &mut State, ev: &KeyEvent) -> bool {
    if matches!(ev.key, Key::Enter) && !command_mods(ev) {
        state.confirm_signal();
        return true;
    }
    let Some(text) = key_text(ev).filter(|_| !command_mods(ev)) else {
        return false;
    };
    match text {
        "y" => {
            state.confirm_signal();
            true
        }
        "1" | "t" => set_dialog_signal(state, SignalKind::Term),
        "2" | "k" => set_dialog_signal(state, SignalKind::Kill),
        "3" | "s" => set_dialog_signal(state, SignalKind::Stop),
        "4" | "c" => set_dialog_signal(state, SignalKind::Cont),
        _ => false,
    }
}

fn set_dialog_signal(state: &mut State, signal: SignalKind) -> bool {
    let Some(dialog) = state.signal_dialog.as_mut() else {
        return false;
    };
    dialog.signal = signal;
    true
}

fn on_global_key(state: &mut State, ev: &KeyEvent, tx: &mut Tx) -> bool {
    if command_mods(ev) {
        return false;
    }
    match &ev.key {
        Key::Tab => {
            state.cycle_focused_pane(ev.mods.shift);
            true
        }
        Key::Down => {
            nudge_selection(state, 1, tx);
            true
        }
        Key::Up => {
            nudge_selection(state, -1, tx);
            true
        }
        Key::PageDown => {
            nudge_selection(state, 12, tx);
            true
        }
        Key::PageUp => {
            nudge_selection(state, -12, tx);
            true
        }
        Key::Home => {
            jump_selection(state, false, tx);
            true
        }
        Key::End => {
            jump_selection(state, true, tx);
            true
        }
        Key::Delete => {
            state.open_signal_dialog(SignalKind::Term);
            true
        }
        Key::Left if state.process_mode == ProcessMode::Tree => {
            if let Some(row) = state.selected_row() {
                if row.has_children && !row.collapsed {
                    state.collapse_selected();
                    tx.instant();
                } else {
                    let ppid = row.ppid;
                    let pid = row.pid;
                    if ppid != pid && state.rows.iter().any(|r| r.pid == ppid) {
                        let prev = state.selected_pid;
                        state.select_pid(ppid);
                        reveal_selection(state, prev, tx);
                    }
                }
            }
            true
        }
        Key::Right if state.process_mode == ProcessMode::Tree => {
            if state.selected_row().is_some_and(|row| row.collapsed) {
                state.expand_selected();
                tx.instant();
            }
            true
        }
        Key::Enter if state.process_mode == ProcessMode::Tree => {
            if let Some(pid) = state.selected_pid {
                state.toggle_collapse_pid(pid);
                tx.instant();
            }
            true
        }
        Key::Text(text) => {
            if text == "S" || (text == "s" && ev.mods.shift) {
                state.toggle_elevation();
                return true;
            }
            if text == "L" || (text == "l" && ev.mods.shift) {
                state.cycle_layout_preset();
                tx.instant();
                return true;
            }
            if text == "P" || (text == "p" && ev.mods.shift) {
                state.toggle_pin_selected();
                tx.instant();
                return true;
            }
            on_text_key(state, text, tx)
        }
        _ => false,
    }
}

fn nudge_selection(state: &mut State, delta: isize, tx: &mut Tx) {
    let previous = state.selected_pid;
    state.move_selection(delta);
    reveal_selection(state, previous, tx);
}

fn reveal_selection(state: &State, previous: Option<u32>, tx: &mut Tx) {
    if state.selected_pid == previous {
        return;
    }
    if let Some(row) = state.selected_row() {
        tx.scroll_into_view_in("process-stream", row.id.clone());
    }
}

fn on_text_key(state: &mut State, text: &str, tx: &mut Tx) -> bool {
    match text {
        "1" => {
            state.set_pane(PaneId::Overview);
            true
        }
        "2" => {
            state.set_pane(PaneId::Cpu);
            true
        }
        "3" => {
            state.set_pane(PaneId::Memory);
            true
        }
        "4" => {
            state.set_pane(PaneId::Network);
            true
        }
        "5" => {
            state.set_pane(PaneId::Disks);
            true
        }
        "6" => {
            state.set_pane(PaneId::Processes);
            true
        }
        "7" => {
            state.set_pane(PaneId::Files);
            true
        }
        "e" => {
            state.toggle_zoom();
            true
        }
        "f" | " " => {
            state.frozen = !state.frozen;
            true
        }
        "t" => {
            toggle_mode(state, ProcessMode::Tree);
            true
        }
        "z" if state.process_mode == ProcessMode::Tree => {
            if let Some(pid) = state.selected_pid {
                state.toggle_collapse_pid(pid);
                tx.instant();
            }
            true
        }
        "g" => {
            toggle_mode(state, ProcessMode::Grouped);
            true
        }
        "a" => {
            state.per_core_chart = !state.per_core_chart;
            true
        }
        "l" => {
            state.show_loopback = !state.show_loopback;
            true
        }
        "c" => {
            state.click_sort(SortColumn::Cpu);
            true
        }
        "m" => {
            state.click_sort(SortColumn::Mem);
            true
        }
        "p" => {
            state.click_sort(SortColumn::Pid);
            true
        }
        "n" => {
            state.click_sort(SortColumn::Name);
            true
        }
        "I" => {
            state.sort_desc = !state.sort_desc;
            state.rebuild_rows();
            true
        }
        "/" => {
            focus_search(state);
            true
        }
        "j" => {
            nudge_selection(state, 1, tx);
            true
        }
        "k" => {
            nudge_selection(state, -1, tx);
            true
        }
        "d" | "K" => {
            state.open_signal_dialog(SignalKind::Term);
            true
        }
        "+" | "=" => {
            state.cycle_time_window(true);
            true
        }
        "-" => {
            state.cycle_time_window(false);
            true
        }
        "[" => {
            state.cycle_poll_interval(true);
            true
        }
        "]" => {
            state.cycle_poll_interval(false);
            true
        }
        "?" => {
            state.show_help = !state.show_help;
            if state.show_help {
                state.signal_dialog = None;
                state.show_settings = false;
            }
            true
        }
        "," => {
            state.toggle_settings();
            true
        }
        _ => false,
    }
}

fn jump_selection(state: &mut State, to_end: bool, tx: &mut Tx) {
    let previous = state.selected_pid;
    let pid = if to_end {
        state.rows.last().map(|row| row.pid)
    } else {
        state.rows.first().map(|row| row.pid)
    };
    if let Some(pid) = pid {
        state.select_pid(pid);
    }
    reveal_selection(state, previous, tx);
}

fn toggle_mode(state: &mut State, mode: ProcessMode) {
    let next = if state.process_mode == mode {
        ProcessMode::Table
    } else {
        mode
    };
    state.set_process_mode(next);
}

fn prefs_path_in(config_dir: &Path) -> PathBuf {
    config_dir.join("vitals").join("settings.json")
}

fn legacy_prefs_path_in(config_dir: &Path) -> PathBuf {
    config_dir.join("btm-rune").join("settings.json")
}

fn prefs_path() -> PathBuf {
    prefs_path_in(&crate::theme::config_dir())
}

fn legacy_prefs_path() -> PathBuf {
    legacy_prefs_path_in(&crate::theme::config_dir())
}

fn read_prefs_from_config_dir(config_dir: &Path) -> Option<UserPrefs> {
    read_prefs_with_legacy_fallback(
        &prefs_path_in(config_dir),
        &legacy_prefs_path_in(config_dir),
    )
}

fn read_prefs_with_legacy_fallback(primary: &Path, legacy: &Path) -> Option<UserPrefs> {
    if primary.exists() {
        read_prefs(primary)
    } else {
        read_prefs(legacy)
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
struct UserPrefs {
    appearance: AppearanceMode,
    scheme: ColorSchemeId,
    ui_zoom_pct: u16,
    layout_preset: LayoutPreset,
    card_slots: [CardId; 6],
    row_splits: [f32; 3],
    col_splits: [f32; 4],
}

impl Default for UserPrefs {
    fn default() -> Self {
        Self {
            appearance: AppearanceMode::System,
            scheme: ColorSchemeId::System,
            ui_zoom_pct: DEFAULT_ZOOM_PCT,
            layout_preset: LayoutPreset::Grid,
            card_slots: CardId::DEFAULT_SLOTS,
            row_splits: DEFAULT_ROW_SPLITS,
            col_splits: DEFAULT_COL_SPLITS,
        }
    }
}

/// `None` when both theme fields came from the CLI and all non-CLI fields match what is already
/// saved, so a theme flag does not rewrite `settings.json`. A locked field keeps the saved value,
/// or System when nothing was saved yet. Zoom and layout fields are never CLI-locked.
fn merged_prefs_full(
    appearance_cli: bool,
    scheme_cli: bool,
    mut current: UserPrefs,
    saved: Option<UserPrefs>,
) -> Option<UserPrefs> {
    current.ui_zoom_pct = normalize_zoom_pct(current.ui_zoom_pct);
    current.row_splits = sanitize_row_splits(current.row_splits);
    current.col_splits = sanitize_col_splits(current.col_splits);
    if appearance_cli && scheme_cli {
        let baseline = saved.unwrap_or_default();
        if current.ui_zoom_pct == baseline.ui_zoom_pct
            && current.layout_preset == baseline.layout_preset
            && current.card_slots == baseline.card_slots
            && current.row_splits == baseline.row_splits
            && current.col_splits == baseline.col_splits
        {
            return None;
        }
    }
    if appearance_cli {
        current.appearance = saved
            .map(|prefs| prefs.appearance)
            .unwrap_or(AppearanceMode::System);
    }
    if scheme_cli {
        current.scheme = saved
            .map(|prefs| prefs.scheme)
            .unwrap_or(ColorSchemeId::System);
    }
    Some(current)
}

#[cfg(test)]
fn merged_prefs(
    appearance_cli: bool,
    scheme_cli: bool,
    appearance: AppearanceMode,
    scheme: ColorSchemeId,
    zoom: u16,
    saved: Option<UserPrefs>,
) -> Option<UserPrefs> {
    merged_prefs_full(
        appearance_cli,
        scheme_cli,
        UserPrefs {
            appearance,
            scheme,
            ui_zoom_pct: zoom,
            ..saved.unwrap_or_default()
        },
        saved,
    )
}

fn read_prefs(path: &Path) -> Option<UserPrefs> {
    let text = std::fs::read_to_string(path).ok()?;
    parse_prefs_json(&text)
}

/// Reads theme and layout prefs. Omitted fields fall back to defaults so older `settings.json`
/// files still load cleanly.
fn parse_prefs_json(text: &str) -> Option<UserPrefs> {
    let value: serde_json::Value = serde_json::from_str(text).ok()?;
    let appearance = value
        .get("appearance_mode")
        .and_then(|entry| entry.as_str())
        .and_then(AppearanceMode::from_slug);
    let scheme = value
        .get("color_scheme")
        .and_then(|entry| entry.as_str())
        .and_then(ColorSchemeId::from_slug);
    let zoom = value.get("ui_zoom_pct").and_then(zoom_pct_value);
    let layout_preset = value
        .get("layout_preset")
        .and_then(|entry| entry.as_str())
        .and_then(LayoutPreset::from_slug);
    let card_slots = value.get("card_slots").and_then(parse_card_slots);
    let row_splits = value.get("row_splits").and_then(parse_row_splits);
    let col_splits = value.get("col_splits").and_then(parse_col_splits);
    if appearance.is_none()
        && scheme.is_none()
        && zoom.is_none()
        && layout_preset.is_none()
        && card_slots.is_none()
        && row_splits.is_none()
        && col_splits.is_none()
    {
        return None;
    }
    Some(UserPrefs {
        appearance: appearance.unwrap_or_default(),
        scheme: scheme.unwrap_or_default(),
        ui_zoom_pct: zoom.unwrap_or(DEFAULT_ZOOM_PCT),
        layout_preset: layout_preset.unwrap_or_default(),
        card_slots: card_slots.unwrap_or(CardId::DEFAULT_SLOTS),
        row_splits: row_splits.unwrap_or(DEFAULT_ROW_SPLITS),
        col_splits: col_splits.unwrap_or(DEFAULT_COL_SPLITS),
    })
}

fn parse_card_slots(value: &serde_json::Value) -> Option<[CardId; 6]> {
    let items = value.as_array()?;
    if items.len() != 6 {
        return None;
    }
    let mut slots = [CardId::Cpu; 6];
    let mut seen = HashSet::with_capacity(6);
    for (idx, item) in items.iter().enumerate() {
        let card = item.as_str().and_then(CardId::from_slug)?;
        if !seen.insert(card) {
            return None;
        }
        slots[idx] = card;
    }
    Some(slots)
}

fn parse_row_splits(value: &serde_json::Value) -> Option<[f32; 3]> {
    let items = value.as_array()?;
    if items.len() != 3 {
        return None;
    }
    let mut out = DEFAULT_ROW_SPLITS;
    for (idx, item) in items.iter().enumerate() {
        let raw = item.as_f64()? as f32;
        if !raw.is_finite() {
            return None;
        }
        out[idx] = raw.clamp(MIN_ROW_SPLIT, MAX_ROW_SPLIT);
    }
    Some(out)
}

fn parse_col_splits(value: &serde_json::Value) -> Option<[f32; 4]> {
    let items = value.as_array()?;
    if items.len() != 4 {
        return None;
    }
    let mut out = DEFAULT_COL_SPLITS;
    for (idx, item) in items.iter().enumerate() {
        let raw = item.as_f64()? as f32;
        if !raw.is_finite() {
            return None;
        }
        out[idx] = raw.clamp(MIN_COL_SPLIT, MAX_COL_SPLIT);
    }
    Some(out)
}

fn sanitize_row_splits(splits: [f32; 3]) -> [f32; 3] {
    std::array::from_fn(|idx| {
        let v = splits[idx];
        if v.is_finite() {
            v.clamp(MIN_ROW_SPLIT, MAX_ROW_SPLIT)
        } else {
            DEFAULT_ROW_SPLITS[idx]
        }
    })
}

fn sanitize_col_splits(splits: [f32; 4]) -> [f32; 4] {
    std::array::from_fn(|idx| {
        let v = splits[idx];
        if v.is_finite() {
            v.clamp(MIN_COL_SPLIT, MAX_COL_SPLIT)
        } else {
            DEFAULT_COL_SPLITS[idx]
        }
    })
}

fn zoom_pct_value(value: &serde_json::Value) -> Option<u16> {
    let number = value.as_f64()?;
    if !number.is_finite() || number < 0.0 || number > f64::from(u16::MAX) {
        return None;
    }
    let rounded = number.round();
    if rounded > f64::from(u16::MAX) {
        return None;
    }
    #[allow(clippy::cast_possible_truncation, clippy::cast_sign_loss)]
    let pct = rounded as u16;
    Some(normalize_zoom_pct(pct))
}

fn normalize_zoom_pct(pct: u16) -> u16 {
    let rounded = pct.saturating_add(ZOOM_STEP_PCT / 2) / ZOOM_STEP_PCT * ZOOM_STEP_PCT;
    rounded.clamp(MIN_ZOOM_PCT, MAX_ZOOM_PCT)
}

#[derive(serde::Serialize)]
struct PrefsDoc<'a> {
    appearance_mode: &'a str,
    color_scheme: &'a str,
    ui_zoom_pct: u16,
    layout_preset: LayoutPreset,
    card_slots: [CardId; 6],
    row_splits: [f32; 3],
    col_splits: [f32; 4],
}

fn format_prefs_json(prefs: &UserPrefs) -> std::io::Result<String> {
    let doc = PrefsDoc {
        appearance_mode: prefs.appearance.slug(),
        color_scheme: prefs.scheme.slug(),
        ui_zoom_pct: prefs.ui_zoom_pct,
        layout_preset: prefs.layout_preset,
        card_slots: prefs.card_slots,
        row_splits: prefs.row_splits,
        col_splits: prefs.col_splits,
    };
    let mut text = serde_json::to_string_pretty(&doc)
        .map_err(|err| std::io::Error::new(std::io::ErrorKind::InvalidData, err))?;
    text.push('\n');
    Ok(text)
}

fn write_prefs(path: &Path, prefs: &UserPrefs) -> std::io::Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let text = format_prefs_json(prefs)?;
    let temporary = path.with_extension("json.tmp");
    std::fs::write(&temporary, text)?;
    std::fs::rename(&temporary, path)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use super::{format_prefs_json, merged_prefs, parse_prefs_json, read_prefs, write_prefs};
    use crate::model::build_process_rows;
    use crate::theme::{AppearanceMode, ColorSchemeId};
    use rune::Mods;

    fn press(state: &mut State, key: Key) -> bool {
        let event = KeyEvent::from(key);
        let mut tx = Tx::default();
        State::on_key(state, &event, &mut tx)
    }

    fn press_text(state: &mut State, text: &str) -> bool {
        press(state, Key::Text(text.to_string()))
    }

    fn press_shift_tab(state: &mut State) -> bool {
        let event = KeyEvent {
            key: Key::Tab,
            mods: Mods {
                shift: true,
                ..Mods::default()
            },
        };
        let mut tx = Tx::default();
        State::on_key(state, &event, &mut tx)
    }

    fn fixture_step(state: &State) -> usize {
        match state.source {
            DataSource::Fixture { step, .. } => step,
            DataSource::Live(_) => panic!("expected fixture source"),
        }
    }

    fn pids(state: &State) -> Vec<u32> {
        state.rows.iter().map(|row| row.pid).collect()
    }

    #[test]
    fn fixture_init_is_deterministic_and_poll_advances_it() {
        let state = State::new_fixture();
        let again = State::default();
        assert!(matches!(state.source, DataSource::Fixture { step: 60, .. }));
        assert!(!state.has_polled);
        assert_eq!(state.snapshot, fixture_snapshot(59));
        assert_eq!(again.snapshot, state.snapshot);
        assert_eq!(state.history.cpu_total.len(), 60);
        assert_eq!(state.history.per_core.len(), 8);
        assert_eq!(
            again.history.cpu_total.as_vec(),
            state.history.cpu_total.as_vec()
        );
        let expected = build_process_rows(
            &state.snapshot.processes,
            ProcessMode::Table,
            "",
            SortColumn::Cpu,
            true,
        );
        assert_eq!(state.rows, expected);
        assert_eq!(again.rows, expected);
        assert_eq!(state.selected_pid, Some(expected[0].pid));
        assert_eq!(state.selected_row().map(|row| row.pid), state.selected_pid);
        assert_eq!(
            state.selected_process().map(|proc| proc.pid),
            state.selected_pid
        );
        assert_eq!(expected[0].display_name, "rustc");
        assert_eq!(state.revision, 1);
        assert_eq!(state.pane, PaneId::Overview);
        assert_eq!(state.focused_pane, PaneId::Processes);
        assert_eq!(state.process_mode, ProcessMode::Table);
        assert_eq!(state.sort_col, SortColumn::Cpu);
        assert!(state.sort_desc);
        assert_eq!(state.time_window_secs, 60);
        assert_eq!(state.poll_interval_ms, 1_000);
        assert_eq!(state.last_poll_sec, 0.0);
        assert!(state.per_core_chart);
        assert!(!state.show_loopback);
        assert_eq!(state.dark, None);
        assert!(!state.show_help);
        assert!(state.signal_dialog.is_none());
        assert!(state.status_banner.is_none());
        assert!(!state.frozen);
        assert!(!state.searching);

        let mut left = State::new_fixture();
        let mut right = State::new_fixture();
        let mut tx = Tx::default();
        assert!(State::poll(&mut left, 0.0, &mut tx));
        assert!(left.has_polled);
        assert_eq!(left.last_poll_sec, 0.0);
        assert_eq!(fixture_step(&left), 61);
        assert!(!State::poll(&mut left, 0.25, &mut tx));
        assert_eq!(fixture_step(&left), 61);
        assert!(State::poll(&mut left, 1.0, &mut tx));
        assert_eq!(fixture_step(&left), 62);
        assert!(State::poll(&mut right, 2.0, &mut tx));
        assert_eq!(right.snapshot, fixture_snapshot(60));
        assert_eq!(right.history.cpu_total.len(), 61);
        assert_eq!(fixture_step(&right), 61);
        assert!(!State::poll(&mut right, 2.5, &mut tx));
        assert_eq!(right.last_poll_sec, 2.0);
        assert!(State::poll(&mut right, 3.0, &mut tx));
        assert_eq!(right.snapshot, fixture_snapshot(61));
        left.tick();
        let frozen_revision = left.revision;
        let frozen_snapshot = left.snapshot.clone();
        left.frozen = true;
        left.tick();
        assert!(!State::poll(&mut left, 50.0, &mut tx));
        assert_eq!(left.revision, frozen_revision);
        assert_eq!(left.snapshot, frozen_snapshot);
        assert_eq!(left.last_poll_sec, 1.0);
    }

    #[test]
    fn live_collector_samples_once_or_falls_back() {
        let state = State::new_live();
        match &state.source {
            DataSource::Live(_) => {
                assert_eq!(state.history.cpu_total.len(), 1);
                if state.selected_pid.is_some() {
                    assert_eq!(state.history.selected_proc.pid, state.selected_pid);
                    assert_eq!(state.history.selected_proc.cpu_pct.len(), 1);
                }
                assert!(state.status_banner.is_none());
                assert_eq!(state.revision, 1);
                assert_eq!(state.selected_pid, state.rows.first().map(|row| row.pid));
                let expected = if current_euid() == 0 {
                    ElevationState::Elevated
                } else {
                    ElevationState::Unprivileged
                };
                assert_eq!(state.elevation, expected);
            }
            DataSource::Fixture { step: 60, .. } => {
                let (message, is_error) = state.status_banner.expect("fallback banner");
                assert!(is_error);
                assert!(message.contains("failed to sample"));
            }
            DataSource::Fixture { step, .. } => panic!("unexpected fixture step {step}"),
        }
    }

    #[test]
    fn sort_filter_modes_and_selection_follow_the_rows() {
        let mut state = State::new_fixture();
        let vim = 330;
        state.select_pid(vim);
        state.click_sort(SortColumn::Name);
        assert_eq!(state.sort_col, SortColumn::Name);
        assert!(!state.sort_desc);
        assert_eq!(state.selected_pid, Some(vim));
        state.click_sort(SortColumn::Name);
        assert!(state.sort_desc);
        state.click_sort(SortColumn::Pid);
        assert_eq!(state.sort_col, SortColumn::Pid);
        assert!(!state.sort_desc);
        state.click_sort(SortColumn::User);
        assert!(!state.sort_desc);
        state.click_sort(SortColumn::State);
        assert!(!state.sort_desc);
        state.click_sort(SortColumn::Mem);
        assert!(state.sort_desc);
        assert!(press_text(&mut state, "c"));
        assert_eq!(state.sort_col, SortColumn::Cpu);
        assert!(state.sort_desc);
        assert!(press_text(&mut state, "I"));
        assert!(!state.sort_desc);
        assert!(press_text(&mut state, "p"));
        assert_eq!(state.sort_col, SortColumn::Pid);
        assert!(press_text(&mut state, "n"));
        assert_eq!(state.sort_col, SortColumn::Name);
        assert!(press_text(&mut state, "m"));
        assert_eq!(state.sort_col, SortColumn::Mem);

        let all = state.rows.len();
        state.query.replace_text("nginx");
        state.rebuild_rows();
        assert!(state.rows.len() < all);
        assert!(state.rows.iter().all(|row| row.display_name == "nginx"));
        assert_eq!(state.rows.len(), 3);
        state.query.clear();
        state.last_query.clear();
        state.rebuild_rows();
        state.select_pid(602);
        assert_eq!(state.selected_name.as_deref(), Some("nginx"));
        state.set_process_mode(ProcessMode::Grouped);
        assert_eq!(state.process_mode, ProcessMode::Grouped);
        assert!(
            state
                .rows
                .iter()
                .any(|row| row.display_name == "nginx" && row.count == 3 && row.pid == 600)
        );
        assert_eq!(state.selected_pid, Some(600));
        assert_ne!(state.rows.first().map(|row| row.pid), Some(600));

        state.query.clear();
        state.rebuild_rows();
        state.select_pid(vim);
        assert!(press_text(&mut state, "t"));
        assert_eq!(state.process_mode, ProcessMode::Tree);
        assert_eq!(state.selected_pid, Some(vim));
        assert!(
            state
                .rows
                .iter()
                .any(|row| row.pid == vim && row.depth >= 3)
        );
        assert!(press_text(&mut state, "t"));
        assert_eq!(state.process_mode, ProcessMode::Table);
        assert!(press_text(&mut state, "g"));
        assert_eq!(state.process_mode, ProcessMode::Grouped);
        assert!(
            state
                .rows
                .iter()
                .any(|row| row.display_name == "firefox" && row.count == 4)
        );
        assert_eq!(state.selected_pid, Some(vim));
        assert!(press_text(&mut state, "g"));
        assert_eq!(state.process_mode, ProcessMode::Table);
        assert!(press_text(&mut state, "t"));
        assert!(press_text(&mut state, "g"));
        assert_eq!(state.process_mode, ProcessMode::Grouped);

        let listed = pids(&state);
        state.select_pid(listed[2]);
        assert!(press_text(&mut state, "j"));
        assert_eq!(state.selected_pid, Some(listed[3]));
        assert!(press(&mut state, Key::Down));
        assert_eq!(state.selected_pid, Some(listed[4]));
        assert!(press_text(&mut state, "k"));
        assert_eq!(state.selected_pid, Some(listed[3]));
        assert!(press(&mut state, Key::Up));
        assert_eq!(state.selected_pid, Some(listed[2]));
        assert!(press(&mut state, Key::End));
        assert_eq!(state.selected_pid, listed.last().copied());
        assert!(press(&mut state, Key::Home));
        assert_eq!(state.selected_pid, listed.first().copied());
        assert!(press(&mut state, Key::PageDown));
        assert_eq!(state.selected_pid, Some(listed[12]));
        assert!(press(&mut state, Key::PageUp));
        assert_eq!(state.selected_pid, listed.first().copied());

        state.snapshot.processes.clear();
        state.rebuild_rows();
        assert!(state.rows.is_empty());
        assert_eq!(state.selected_pid, None);
        state.move_selection(1);
        assert_eq!(state.selected_pid, None);
        state.open_signal_dialog(SignalKind::Kill);
        assert!(state.signal_dialog.is_none());
        assert_eq!(
            state.status_banner.as_ref().map(|(_, err)| *err),
            Some(true)
        );
    }

    #[test]
    fn panes_zoom_and_focus_cycle_from_the_keyboard() {
        let mut state = State::new_fixture();
        assert_eq!(state.focused_pane, PaneId::Processes);
        assert!(press_text(&mut state, "2"));
        assert_eq!(state.pane, PaneId::Cpu);
        assert_eq!(state.focused_pane, PaneId::Cpu);
        assert!(press_text(&mut state, "3"));
        assert_eq!(
            (state.pane, state.focused_pane),
            (PaneId::Memory, PaneId::Memory)
        );
        assert!(press_text(&mut state, "4"));
        assert_eq!(
            (state.pane, state.focused_pane),
            (PaneId::Network, PaneId::Network)
        );
        assert!(press_text(&mut state, "5"));
        assert_eq!(
            (state.pane, state.focused_pane),
            (PaneId::Disks, PaneId::Disks)
        );
        assert!(press_text(&mut state, "7"));
        assert_eq!(
            (state.pane, state.focused_pane),
            (PaneId::Files, PaneId::Files)
        );
        assert_eq!(state.file_filter, FileKindFilter::All);
        assert_eq!(state.file_rows.len(), state.snapshot.open_files.len());
        state.set_file_filter(FileKindFilter::Sockets);
        assert!(
            state
                .file_rows
                .iter()
                .all(|e| e.kind == crate::model::OpenFileKind::Socket)
        );
        state.set_file_filter(FileKindFilter::All);
        assert!(press_text(&mut state, "6"));
        assert_eq!(
            (state.pane, state.focused_pane),
            (PaneId::Processes, PaneId::Processes)
        );
        assert!(press_text(&mut state, "1"));
        assert_eq!(state.pane, PaneId::Overview);
        assert_eq!(state.focused_pane, PaneId::Processes);
        assert!(press_text(&mut state, "e"));
        assert_eq!(state.pane, PaneId::Processes);
        assert!(press_text(&mut state, "e"));
        assert_eq!(state.pane, PaneId::Overview);

        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Cpu);
        assert_eq!(state.pane, PaneId::Overview);
        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Memory);
        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Network);
        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Disks);
        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Processes);
        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Cpu);
        assert!(press_shift_tab(&mut state));
        assert_eq!(state.focused_pane, PaneId::Processes);
        assert_eq!(state.pane, PaneId::Overview);
        assert!(press_text(&mut state, "e"));
        assert_eq!(state.pane, PaneId::Processes);
        assert!(press(&mut state, Key::Tab));
        assert_eq!(state.focused_pane, PaneId::Cpu);
        assert_eq!(state.pane, PaneId::Cpu);
    }

    #[test]
    fn time_window_and_poll_rate_cycle_and_clamp_sample_count() {
        let mut state = State::new_fixture();
        assert_eq!(state.sample_count(), 60);
        assert!(press_text(&mut state, "+"));
        assert_eq!(state.time_window_secs, 30);
        assert!(press_text(&mut state, "="));
        assert_eq!(state.time_window_secs, 15);
        assert_eq!(state.sample_count(), 15);
        assert!(press_text(&mut state, "+"));
        assert_eq!(state.time_window_secs, 120);
        assert!(press_text(&mut state, "-"));
        assert_eq!(state.time_window_secs, 15);
        assert!(press_text(&mut state, "-"));
        assert_eq!(state.time_window_secs, 30);

        state.time_window_secs = 120;
        assert!(press_text(&mut state, "["));
        assert_eq!(state.poll_interval_ms, 500);
        assert_eq!(state.sample_count(), 240);
        assert!(press_text(&mut state, "["));
        assert_eq!(state.poll_interval_ms, 250);
        assert_eq!(state.sample_count(), HistoryRing::<f32>::DEFAULT_CAPACITY);
        assert!(press_text(&mut state, "["));
        assert_eq!(state.poll_interval_ms, 2_000);
        assert_eq!(state.sample_count(), 60);
        assert!(press_text(&mut state, "]"));
        assert_eq!(state.poll_interval_ms, 250);
        assert!(press_text(&mut state, "]"));
        assert_eq!(state.poll_interval_ms, 500);
        assert!(press_text(&mut state, "]"));
        assert_eq!(state.poll_interval_ms, 1_000);
        assert!(press_text(&mut state, "]"));
        assert_eq!(state.poll_interval_ms, 2_000);

        state.time_window_secs = 15;
        state.poll_interval_ms = 2_000;
        assert_eq!(state.sample_count(), 8);
        state.time_window_secs = 30;
        state.poll_interval_ms = 500;
        assert_eq!(state.sample_count(), 60);
        state.poll_interval_ms = 0;
        assert_eq!(state.sample_count(), HistoryRing::<f32>::DEFAULT_CAPACITY);
    }

    #[test]
    fn signal_dialog_confirms_in_the_fixture_and_escape_cancels() {
        let mut state = State::new_fixture();
        state.select_pid(1);
        assert!(press_text(&mut state, "d"));
        assert!(state.signal_dialog.is_none());
        let (message, is_error) = state.status_banner.clone().unwrap();
        assert!(is_error);
        assert!(message.contains("refusing to signal pid 1"));

        state.select_pid(330);
        assert!(press_text(&mut state, "d"));
        assert_eq!(
            state.signal_dialog,
            Some(SignalDialog {
                pid: 330,
                name: "vim".to_string(),
                signal: SignalKind::Term,
            })
        );
        assert!(press_text(&mut state, "2"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Kill
        );
        assert!(press_text(&mut state, "k"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Kill
        );
        assert!(press_text(&mut state, "3"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Stop
        );
        assert!(press_text(&mut state, "s"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Stop
        );
        assert!(press_text(&mut state, "4"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Cont
        );
        assert!(press_text(&mut state, "c"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Cont
        );
        assert!(press_text(&mut state, "1"));
        assert_eq!(
            state.signal_dialog.as_ref().unwrap().signal,
            SignalKind::Term
        );
        assert!(press_text(&mut state, "t"));
        assert_eq!(state.pane, PaneId::Overview);
        assert!(!press_text(&mut state, "e"));
        assert_eq!(state.pane, PaneId::Overview);
        assert!(state.snapshot.processes.iter().any(|proc| proc.pid == 330));
        assert!(press(&mut state, Key::Escape));
        assert!(state.signal_dialog.is_none());
        assert!(state.snapshot.processes.iter().any(|proc| proc.pid == 330));

        assert!(press_text(&mut state, "K"));
        assert_eq!(
            state.signal_dialog.as_ref().map(|dialog| dialog.signal),
            Some(SignalKind::Term)
        );
        assert!(press_text(&mut state, "y"));
        assert!(state.signal_dialog.is_none());
        assert!(state.snapshot.processes.iter().all(|proc| proc.pid != 330));
        state.tick();
        assert!(state.snapshot.processes.iter().all(|proc| proc.pid != 330));
        assert!(matches!(
            &state.source,
            DataSource::Fixture { killed, .. } if killed.contains(&330)
        ));
        assert_eq!(
            state.status_banner,
            Some(("Sent SIGTERM to vim (pid 330)".to_string(), false))
        );
        assert_ne!(state.selected_pid, Some(330));

        state.select_pid(331);
        assert!(press(&mut state, Key::Delete));
        assert!(press(&mut state, Key::Enter));
        assert!(state.snapshot.processes.iter().all(|proc| proc.pid != 331));
        assert_eq!(
            state.status_banner,
            Some(("Sent SIGTERM to htop (pid 331)".to_string(), false))
        );

        state.select_pid(999_999);
        state.open_signal_dialog(SignalKind::Kill);
        assert!(state.signal_dialog.is_none());
        assert_eq!(
            state
                .status_banner
                .as_ref()
                .map(|(text, err)| (text.as_str(), *err)),
            Some(("No process selected", true))
        );
    }

    #[test]
    fn live_confirm_reports_success_and_refusal_without_killing() {
        let mut state = State::new_fixture();
        state.source = DataSource::Live(Box::default());
        state.signal_dialog = Some(SignalDialog {
            pid: std::process::id(),
            name: "self".to_string(),
            signal: SignalKind::Cont,
        });
        state.confirm_signal();
        assert!(state.signal_dialog.is_none());
        let (message, is_error) = state.status_banner.clone().unwrap();
        assert!(!is_error);
        assert_eq!(
            message,
            format!("Sent SIGCONT to self (pid {})", std::process::id())
        );

        state.signal_dialog = Some(SignalDialog {
            pid: u32::MAX,
            name: "missing".to_string(),
            signal: SignalKind::Term,
        });
        state.confirm_signal();
        let (message, is_error) = state.status_banner.clone().unwrap();
        assert!(is_error);
        assert!(message.contains("outside the range"));
        state.confirm_signal();
        assert_eq!(
            state.status_banner.as_ref().map(|(text, _)| text.as_str()),
            Some(message.as_str())
        );
    }

    #[test]
    fn search_help_and_escape_unwind_in_order() {
        let mut state = State::new_fixture();
        let selected = state.selected_pid;
        state.set_pane(PaneId::Cpu);
        state.query.replace_text("vim");
        state.rebuild_rows();
        state.searching = true;
        state.query.focused = true;
        state.select_pid(330);
        state.open_signal_dialog(SignalKind::Term);
        assert!(state.signal_dialog.is_some());
        assert!(!state.show_help);
        state.show_help = true;

        assert!(press(&mut state, Key::Escape));
        assert!(state.signal_dialog.is_none());
        assert!(state.show_help);
        assert!(state.searching);
        assert_eq!(state.query.text, "vim");
        assert_eq!(state.pane, PaneId::Cpu);

        assert!(press(&mut state, Key::Escape));
        assert!(!state.show_help);
        assert!(state.searching);
        assert_eq!(state.query.text, "vim");

        assert!(press(&mut state, Key::Escape));
        assert!(!state.searching);
        assert!(!state.query.focused);
        assert_eq!(state.query.text, "vim");
        assert!(state.rows.iter().all(|row| row.display_name == "vim"));

        assert!(press(&mut state, Key::Escape));
        assert!(state.query.text.is_empty());
        assert!(state.rows.len() > 3);
        assert_eq!(state.pane, PaneId::Cpu);

        assert!(press(&mut state, Key::Escape));
        assert_eq!(state.pane, PaneId::Overview);
        assert!(!press(&mut state, Key::Escape));

        assert!(press_text(&mut state, "/"));
        assert!(state.searching);
        assert!(state.query.focused);
        let kept = state.selected_pid;
        assert!(!press_text(&mut state, "j"));
        assert!(!press_text(&mut state, "e"));
        assert!(!press_text(&mut state, "f"));
        assert_eq!(state.selected_pid, kept);
        assert_eq!(state.pane, PaneId::Overview);
        assert!(!state.frozen);
        assert!(press(&mut state, Key::Command('f')));
        assert!(state.searching);
        assert!(state.query.focused);

        let event = KeyEvent {
            key: Key::Text("f".to_string()),
            mods: Mods {
                ctrl: true,
                ..Mods::default()
            },
        };
        let mut tx = Tx::default();
        assert!(State::on_key(&mut state, &event, &mut tx));
        assert!(state.searching);

        assert!(press(&mut state, Key::Escape));
        assert!(!state.searching);
        assert!(press_text(&mut state, "f"));
        assert!(state.frozen);
        assert!(press_text(&mut state, " "));
        assert!(!state.frozen);
        assert!(press_text(&mut state, "a"));
        assert!(!state.per_core_chart);
        assert!(press_text(&mut state, "l"));
        assert!(state.show_loopback);
        assert!(press_text(&mut state, "?"));
        assert!(state.show_help);
        assert!(press_text(&mut state, "?"));
        assert!(!state.show_help);
        assert!(selected.is_some());
    }

    #[test]
    fn frozen_poll_applies_a_query_without_sampling() {
        let mut state = State::new_fixture();
        let step = fixture_step(&state);
        state.frozen = true;
        state.query.replace_text("nginx");
        let mut tx = Tx::default();
        assert!(State::poll(&mut state, 5.0, &mut tx));
        assert_eq!(fixture_step(&state), step);
        assert!(state.rows.iter().all(|row| row.display_name == "nginx"));
        assert!(!State::poll(&mut state, 6.0, &mut tx));
        state.query.replace_text("vim");
        state.on_query_change();
        assert!(state.rows.iter().all(|row| row.display_name == "vim"));
        assert_eq!(state.last_query, "vim");
    }

    #[test]
    fn live_recovery_clears_a_failed_sample_banner() {
        let mut state = State::new_fixture();
        state.source = DataSource::Live(Box::default());
        state.status_banner = Some(("failed to sample /proc: temporary".to_string(), true));
        let before = state.history.cpu_total.len();
        state.tick();
        if state.history.cpu_total.len() > before {
            assert!(state.status_banner.is_none());
        } else {
            let (message, is_error) = state.status_banner.clone().unwrap();
            assert!(is_error);
            assert!(message.starts_with("failed to sample"));
        }
        state.status_banner = Some(("Sent SIGCONT to self (pid 1)".to_string(), false));
        let marked = state.history.cpu_total.len();
        state.tick();
        if state.history.cpu_total.len() > marked {
            assert_eq!(
                state
                    .status_banner
                    .as_ref()
                    .map(|(text, err)| (text.as_str(), *err)),
                Some(("Sent SIGCONT to self (pid 1)", false))
            );
        }
    }

    fn search_view(state: &State, _: &mut rune::Cx<State>) -> rune::El {
        rune::text_input(&state.query, rune::TextStyle::new(14.0, 400.0))
            .key("search")
            .size(240.0, 32.0)
            .on_edit(|state: &mut State| &mut state.query)
    }

    #[test]
    fn mounted_search_filters_then_escape_lets_j_move_selection() {
        let mut state = State::new_fixture();
        state.searching = true;
        state.query.focused = true;
        let mut rt =
            rune::Runtime::new(state, search_view, (320.0, 48.0), rune::Env::new(true, 1.0));
        rt.on_key = Some(State::on_key);
        rt.poll = Some(State::poll);
        rt.frame(0.0);
        assert!(rt.state.searching);
        assert!(rt.state.query.focused);

        for ch in ["n", "g", "i", "n", "x"] {
            rt.key(KeyEvent::from(Key::Text(ch.to_string())));
            rt.frame(0.0);
        }
        rt.frame(0.0);
        assert_eq!(rt.state.query.text, "nginx");
        assert_eq!(rt.state.rows.len(), 3);
        assert!(rt.state.rows.iter().all(|row| row.display_name == "nginx"));
        let before = rt.state.selected_pid;
        assert!(before.is_some());

        rt.key(KeyEvent::from(Key::Escape));
        rt.frame(0.0);
        assert!(!rt.state.query.focused);
        assert_eq!(rt.state.query.text, "nginx");
        assert_eq!(rt.state.selected_pid, before);

        rt.key(KeyEvent::from(Key::Text("j".to_string())));
        rt.frame(0.0);
        assert!(!rt.state.searching);
        assert_ne!(rt.state.selected_pid, before);
        assert!(rt.state.rows.iter().all(|row| row.display_name == "nginx"));
    }

    #[test]
    fn appearance_scheme_and_settings_follow_the_keys() {
        let mut state = State::new_fixture();
        assert_eq!(state.color_scheme, ColorSchemeId::Obsidian);
        assert_eq!(state.appearance_mode, AppearanceMode::System);
        assert_eq!(state.dark, None);
        assert!(!state.show_settings);

        state.set_appearance_mode(AppearanceMode::Dark);
        assert_eq!(state.dark, Some(true));
        state.cycle_appearance_mode();
        assert_eq!(state.appearance_mode, AppearanceMode::Light);
        assert_eq!(state.dark, Some(false));
        state.cycle_appearance_mode();
        assert_eq!(state.appearance_mode, AppearanceMode::System);
        assert_eq!(state.dark, None);

        state.set_color_scheme(ColorSchemeId::Gruvbox);
        state.cycle_color_scheme();
        assert_eq!(state.color_scheme, ColorSchemeId::Catppuccin);

        state.searching = true;
        state.query.focused = true;
        assert!(!press_text(&mut state, ","));
        assert!(!state.show_settings);
        state.searching = false;
        state.query.focused = false;

        assert!(press_text(&mut state, ","));
        assert!(state.show_settings);
        assert!(!state.show_help);
        state.show_help = true;
        assert!(press(&mut state, Key::Escape));
        assert!(!state.show_settings);
        assert!(state.show_help);
        assert!(press(&mut state, Key::Escape));
        assert!(!state.show_help);

        state.poll_interval_ms = 5_000;
        state.time_window_secs = 300;
        state.per_core_chart = false;
        state.show_loopback = true;
        state.set_color_scheme(ColorSchemeId::Nord);
        state.set_ui_zoom_pct(170);
        assert_eq!(state.ui_zoom_pct, 170);
        state.reset_to_system_defaults();
        assert_eq!(state.poll_interval_ms, 1_000);
        assert_eq!(state.time_window_secs, 60);
        assert!(state.per_core_chart);
        assert!(!state.show_loopback);
        assert_eq!(state.appearance_mode, AppearanceMode::System);
        assert_eq!(state.color_scheme, ColorSchemeId::Obsidian);
        assert_eq!(state.ui_zoom_pct, DEFAULT_ZOOM_PCT);
    }

    fn prefs(appearance: AppearanceMode, scheme: ColorSchemeId, ui_zoom_pct: u16) -> UserPrefs {
        UserPrefs {
            appearance,
            scheme,
            ui_zoom_pct,
            ..UserPrefs::default()
        }
    }

    #[test]
    fn layout_presets_card_slots_and_persistence_round_trip() {
        for preset in LayoutPreset::ALL {
            assert_eq!(LayoutPreset::from_slug(preset.slug()), Some(preset));
            assert!(!preset.label().is_empty());
        }
        assert_eq!(LayoutPreset::Grid.cycle(), LayoutPreset::ProcessesTop);
        assert_eq!(
            LayoutPreset::ProcessesTop.cycle(),
            LayoutPreset::SplitColumns
        );
        assert_eq!(LayoutPreset::SplitColumns.cycle(), LayoutPreset::Wide2x3);
        assert_eq!(LayoutPreset::Wide2x3.cycle(), LayoutPreset::Grid);
        assert_eq!(LayoutPreset::from_slug("unknown"), None);

        for card in CardId::DEFAULT_SLOTS {
            assert_eq!(CardId::from_slug(card.slug()), Some(card));
            assert!(!card.label().is_empty());
        }
        assert_eq!(CardId::from_slug("nope"), None);

        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("settings.json");

        let mut first = State::new_fixture();
        first.set_prefs_path(&path);
        first.set_appearance_mode(AppearanceMode::Dark);
        first.set_color_scheme(ColorSchemeId::Gruvbox);
        first.set_ui_zoom_pct(120);

        assert!(press_text(&mut first, "L"));
        assert_eq!(first.layout_preset, LayoutPreset::ProcessesTop);
        assert!(press_text(&mut first, "L"));
        assert_eq!(first.layout_preset, LayoutPreset::SplitColumns);

        first.swap_card_slots(0, 4);
        assert_eq!(first.card_slots[0], CardId::Processes);
        assert_eq!(first.card_slots[4], CardId::Cpu);

        first.row_splits = [1.4, 0.7, 1.25];
        first.col_splits = [0.42, 0.61, 0.70, 0.36];
        first.persist_prefs();

        let mut restarted = State::new_fixture();
        restarted.set_prefs_path(&path);
        restarted.reload_user_prefs();
        assert_eq!(restarted.appearance_mode, AppearanceMode::Dark);
        assert_eq!(restarted.color_scheme, ColorSchemeId::Gruvbox);
        assert_eq!(restarted.ui_zoom_pct, 120);
        assert_eq!(restarted.layout_preset, LayoutPreset::SplitColumns);
        assert_eq!(restarted.card_slots, first.card_slots);
        assert_eq!(restarted.row_splits, [1.4, 0.7, 1.25]);
        assert_eq!(restarted.col_splits, [0.42, 0.61, 0.70, 0.36]);

        restarted.reset_layout();
        assert_eq!(restarted.layout_preset, LayoutPreset::Grid);
        assert_eq!(restarted.card_slots, CardId::DEFAULT_SLOTS);
        assert_eq!(restarted.row_splits, DEFAULT_ROW_SPLITS);
        assert_eq!(restarted.col_splits, DEFAULT_COL_SPLITS);

        let mut third = State::new_fixture();
        third.set_prefs_path(&path);
        third.reload_user_prefs();
        assert_eq!(third.layout_preset, LayoutPreset::Grid);
        assert_eq!(third.card_slots, CardId::DEFAULT_SLOTS);
        assert_eq!(third.row_splits, DEFAULT_ROW_SPLITS);
        assert_eq!(third.col_splits, DEFAULT_COL_SPLITS);

        // Duplicate cards in corrupted JSON fall back to DEFAULT_SLOTS, and out-of-range splits clamp.
        let malformed = parse_prefs_json(
            r#"{
              "layout_preset": "wide-2x3",
              "card_slots": ["cpu", "cpu", "network", "disks", "processes", "inspector"],
              "row_splits": [0.05, 9.9, 1.1],
              "col_splits": [0.01, 0.99, 0.5, 0.6]
            }"#,
        )
        .expect("partial layout prefs parse");
        assert_eq!(malformed.layout_preset, LayoutPreset::Wide2x3);
        assert_eq!(malformed.card_slots, CardId::DEFAULT_SLOTS);
        assert_eq!(malformed.row_splits, [MIN_ROW_SPLIT, MAX_ROW_SPLIT, 1.1]);
        assert_eq!(
            malformed.col_splits,
            [MIN_COL_SPLIT, MAX_COL_SPLIT, 0.5, 0.6]
        );
    }

    #[test]
    fn settings_json_round_trip_and_cli_locks_do_not_record_overrides() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("settings.json");
        let saved = prefs(AppearanceMode::Light, ColorSchemeId::Nord, 140);
        write_prefs(&path, &saved).unwrap();
        assert_eq!(read_prefs(&path), Some(saved));
        let text = std::fs::read_to_string(&path).unwrap();
        assert!(text.contains("\"ui_zoom_pct\": 140"), "{text}");
        assert_eq!(format_prefs_json(&saved).unwrap(), text);
        assert_eq!(
            parse_prefs_json(
                r#"{
  "appearance_mode": "dark",
  "color_scheme": "gruvbox"
}
"#
            ),
            Some(prefs(AppearanceMode::Dark, ColorSchemeId::Gruvbox, 100))
        );
        assert_eq!(
            parse_prefs_json(r#"{"ui_zoom_pct": 155}"#).map(|prefs| prefs.ui_zoom_pct),
            Some(160)
        );
        assert_eq!(
            parse_prefs_json(r#"{"appearance_mode":"light","ui_zoom_pct":15}"#)
                .map(|prefs| prefs.ui_zoom_pct),
            Some(MIN_ZOOM_PCT)
        );
        assert_eq!(
            parse_prefs_json(r#"{"appearance_mode":"light","ui_zoom_pct":999}"#)
                .map(|prefs| prefs.ui_zoom_pct),
            Some(MAX_ZOOM_PCT)
        );
        assert_eq!(parse_prefs_json("{}"), None);
        assert_eq!(
            merged_prefs(
                true,
                false,
                AppearanceMode::Dark,
                ColorSchemeId::RosePine,
                100,
                read_prefs(&path),
            ),
            Some(prefs(AppearanceMode::Light, ColorSchemeId::RosePine, 100))
        );
        assert_eq!(
            merged_prefs(
                true,
                true,
                AppearanceMode::Dark,
                ColorSchemeId::Nord,
                100,
                Some(prefs(AppearanceMode::Light, ColorSchemeId::Gruvbox, 100)),
            ),
            None
        );
        assert_eq!(
            merged_prefs(
                true,
                true,
                AppearanceMode::Dark,
                ColorSchemeId::Nord,
                150,
                Some(prefs(AppearanceMode::Light, ColorSchemeId::Gruvbox, 100)),
            ),
            Some(prefs(AppearanceMode::Light, ColorSchemeId::Gruvbox, 150))
        );
        assert_eq!(
            merged_prefs(
                false,
                true,
                AppearanceMode::Dark,
                ColorSchemeId::Nord,
                100,
                None
            ),
            Some(prefs(AppearanceMode::Dark, ColorSchemeId::System, 100))
        );
    }

    fn press_zoom(state: &mut State, key: Key, shift: bool) -> bool {
        let event = KeyEvent {
            key,
            mods: Mods {
                shift,
                ctrl: true,
                cmd: true,
                ..Mods::default()
            },
        };
        let mut tx = Tx::default();
        State::on_key(state, &event, &mut tx)
    }

    #[test]
    fn zoom_keys_step_clamp_reset_and_work_while_searching() {
        let mut state = State::new_fixture();
        assert_eq!(state.ui_zoom_pct, DEFAULT_ZOOM_PCT);
        assert!((state.ui_zoom() - 1.0).abs() < f32::EPSILON);
        state.set_ui_zoom_pct(155);
        assert_eq!(state.ui_zoom_pct, 160);
        state.set_ui_zoom_pct(0);
        assert_eq!(state.ui_zoom_pct, MIN_ZOOM_PCT);
        state.set_ui_zoom_pct(1_000);
        assert_eq!(state.ui_zoom_pct, MAX_ZOOM_PCT);
        state.reset_ui_zoom();
        assert_eq!(state.ui_zoom_pct, DEFAULT_ZOOM_PCT);
        assert!(!press_zoom(&mut state, Key::Command('='), false));
        assert!(!press_zoom(&mut state, Key::Command('-'), false));
        assert!(!press_zoom(&mut state, Key::Command('0'), false));
        let alt_plus = KeyEvent {
            key: Key::Command('+'),
            mods: Mods {
                shift: true,
                ctrl: true,
                cmd: true,
                alt: true,
                ..Mods::default()
            },
        };
        let mut tx = Tx::default();
        assert!(!State::on_key(&mut state, &alt_plus, &mut tx));
        assert_eq!(state.ui_zoom_pct, DEFAULT_ZOOM_PCT);

        state.searching = true;
        state.query.focused = true;
        state.query.replace_text("vim");
        assert!(press_zoom(&mut state, Key::Command('+'), true));
        assert!(press_zoom(&mut state, Key::Command('='), true));
        assert_eq!(state.ui_zoom_pct, 120);
        assert!(state.searching);
        assert_eq!(state.query.text, "vim");
        assert!(press_zoom(&mut state, Key::Command('-'), true));
        assert!(press_zoom(&mut state, Key::Command('_'), true));
        assert_eq!(state.ui_zoom_pct, 100);

        state.open_signal_dialog(SignalKind::Term);
        assert!(state.signal_dialog.is_some());
        assert!(press_zoom(&mut state, Key::Command('='), true));
        assert!(state.signal_dialog.is_some());
        assert_eq!(state.ui_zoom_pct, 110);
        assert!(press_zoom(&mut state, Key::Command('0'), true));
        assert_eq!(state.ui_zoom_pct, 100);
        assert!(press_zoom(&mut state, Key::Command(')'), true));
        assert_eq!(state.ui_zoom_pct, 100);

        for _ in 0..20 {
            assert!(press_zoom(&mut state, Key::Command('+'), true));
        }
        assert_eq!(state.ui_zoom_pct, MAX_ZOOM_PCT);
        assert!(press_zoom(&mut state, Key::Command('='), true));
        assert_eq!(state.ui_zoom_pct, MAX_ZOOM_PCT);
        for _ in 0..20 {
            assert!(press_zoom(&mut state, Key::Command('-'), true));
        }
        assert_eq!(state.ui_zoom_pct, MIN_ZOOM_PCT);
        assert!(press_zoom(&mut state, Key::Command('_'), true));
        assert_eq!(state.ui_zoom_pct, MIN_ZOOM_PCT);

        state.reset_ui_zoom();
        assert!(press_zoom(&mut state, Key::Command('+'), false));
        assert_eq!(state.ui_zoom_pct, 110);
        assert!(press_zoom(&mut state, Key::Command('_'), false));
        assert_eq!(state.ui_zoom_pct, 100);
        state.zoom_in();
        assert!(press_zoom(&mut state, Key::Command(')'), false));
        assert_eq!(state.ui_zoom_pct, 100);

        let typed = KeyEvent {
            key: Key::Text("+".to_string()),
            mods: Mods {
                ctrl: true,
                cmd: true,
                ..Mods::default()
            },
        };
        let mut tx = Tx::default();
        assert!(State::on_key(&mut state, &typed, &mut tx));
        assert_eq!(state.ui_zoom_pct, 110);
        assert_eq!(state.query.text, "vim");
    }

    fn write_host_proc(root: &std::path::Path, hostname: &str) {
        let proc_dir = root.join("proc");
        std::fs::create_dir_all(proc_dir.join("sys/kernel")).unwrap();
        std::fs::write(
            proc_dir.join("stat"),
            "cpu  10 0 10 80 0 0 0 0 0 0\ncpu0 10 0 10 80 0 0 0 0 0 0\n",
        )
        .unwrap();
        std::fs::write(
            proc_dir.join("meminfo"),
            "MemTotal: 2048 kB\nMemAvailable: 1024 kB\n",
        )
        .unwrap();
        std::fs::write(proc_dir.join("uptime"), "5.00 0.00\n").unwrap();
        std::fs::write(
            proc_dir.join("sys/kernel/hostname"),
            format!("{hostname}\n"),
        )
        .unwrap();
        std::fs::write(proc_dir.join("sys/kernel/osrelease"), "test-kernel\n").unwrap();
    }

    fn worker_state(root: &std::path::Path) -> State {
        let mut collector = LinuxCollector::with_root(root);
        let snapshot = collector.sample().expect("fixture sample");
        let worker = LiveWorker::spawn(collector, 1_000);
        State::assemble(
            DataSource::Live(Box::new(LiveCollector::Worker(worker))),
            snapshot,
            TelemetryHistory::default(),
        )
    }

    fn wait_until(state: &mut State, mut pred: impl FnMut(&State) -> bool) {
        let start = std::time::Instant::now();
        while start.elapsed() < Duration::from_secs(5) {
            state.tick();
            if pred(state) {
                return;
            }
            thread::sleep(Duration::from_millis(20));
        }
        panic!(
            "timed out elevation {:?} banner {:?}",
            state.elevation, state.status_banner
        );
    }

    #[test]
    fn fixture_elevation_toggles_and_shift_s_is_ignored_while_typing() {
        let mut state = State::new_fixture();
        assert_eq!(state.elevation, ElevationState::Unprivileged);
        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Elevated);
        assert!(press_text(&mut state, "S"));
        assert_eq!(state.elevation, ElevationState::Unprivileged);
        assert!(!press_text(&mut state, "s"));
        assert_eq!(state.elevation, ElevationState::Unprivileged);

        state.searching = true;
        state.query.focused = true;
        assert!(!press_text(&mut state, "S"));
        assert_eq!(state.elevation, ElevationState::Unprivileged);

        state.searching = false;
        state.query.focused = false;
        state.open_signal_dialog(SignalKind::Term);
        assert!(state.signal_dialog.is_some());
        assert!(!press_text(&mut state, "S"));
        assert_eq!(state.elevation, ElevationState::Unprivileged);

        fn mark_authenticating(state: &mut State) {
            state.elevation = ElevationState::Authenticating;
        }
        state.signal_dialog = None;
        state.set_fixture_elevation_hook(mark_authenticating);
        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Authenticating);
    }

    #[test]
    fn live_elevation_uses_the_helper_then_drops_and_cancel_is_not_an_error() {
        let temp = tempfile::tempdir().unwrap();
        let local = temp.path().join("local");
        let elevated = temp.path().join("elevated");
        write_host_proc(&local, "local-user");
        write_host_proc(&elevated, "all-users");
        let mut state = worker_state(&local);
        state.elevation = ElevationState::Unprivileged;
        state.helper_routed = false;
        let binary = crate::collector::helper_binary();
        assert!(binary.is_file(), "missing {}", binary.display());
        state.set_elevation_command(
            binary,
            vec![
                "--collector-helper-root".to_string(),
                elevated.display().to_string(),
            ],
        );

        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Authenticating);
        assert_eq!(
            state
                .status_banner
                .as_ref()
                .map(|(text, err)| (text.as_str(), *err)),
            Some((BANNER_AUTHENTICATE, false))
        );
        wait_until(&mut state, |state| {
            state.elevation == ElevationState::Elevated
        });
        assert_eq!(
            state
                .status_banner
                .as_ref()
                .map(|(text, err)| (text.as_str(), *err)),
            Some((BANNER_ELEVATED, false))
        );
        assert!(state.helper_routed);
        wait_until(&mut state, |state| state.snapshot.hostname == "all-users");

        state.signal_dialog = Some(SignalDialog {
            pid: std::process::id(),
            name: "self".to_string(),
            signal: SignalKind::Cont,
        });
        state.confirm_signal();
        let (message, is_error) = state.status_banner.clone().unwrap();
        assert!(!is_error, "{message}");
        assert!(message.contains("SIGCONT"), "{message}");

        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Unprivileged);
        assert!(!state.helper_routed);
        assert_eq!(
            state
                .status_banner
                .as_ref()
                .map(|(text, err)| (text.as_str(), *err)),
            Some((BANNER_DROPPED, false))
        );
        wait_until(&mut state, |state| state.snapshot.hostname == "local-user");

        state.set_elevation_command("sh", vec!["-c".to_string(), "exit 126".to_string()]);
        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Authenticating);
        wait_until(&mut state, |state| {
            state.elevation == ElevationState::Unprivileged
                && state
                    .status_banner
                    .as_ref()
                    .is_some_and(|(text, err)| text == BANNER_AUTH_CANCELLED && !err)
        });

        state.set_elevation_command(
            "sh",
            vec!["-c".to_string(), "echo denied >&2; exit 127".to_string()],
        );
        state.toggle_elevation();
        wait_until(&mut state, |state| {
            state.elevation == ElevationState::Unprivileged
                && state.status_banner.as_ref().is_some_and(|(text, err)| {
                    *err && (text.contains("127") || text.contains("authorization"))
                })
        });

        state.set_elevation_command("sh", vec!["-c".to_string(), "sleep 30".to_string()]);
        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Authenticating);
        state.toggle_elevation();
        assert_eq!(state.elevation, ElevationState::Unprivileged);
        assert!(
            state
                .status_banner
                .as_ref()
                .is_some_and(|(text, err)| text == BANNER_AUTH_CANCELLED && !err)
        );
    }

    #[test]
    fn prefs_path_uses_vitals_and_migrates_legacy_btm_rune_settings() {
        assert!(prefs_path().ends_with(Path::new("vitals/settings.json")));
        assert!(legacy_prefs_path().ends_with(Path::new("btm-rune/settings.json")));

        let temp = tempfile::tempdir().unwrap();
        let config_dir = temp.path();
        assert_eq!(read_prefs_from_config_dir(config_dir), None);

        let mut legacy = prefs(AppearanceMode::Light, ColorSchemeId::Gruvbox, 130);
        legacy.layout_preset = LayoutPreset::ProcessesTop;
        write_prefs(&legacy_prefs_path_in(config_dir), &legacy).unwrap();

        let mut migrated = State::new_fixture();
        if let Some(loaded) = read_prefs_from_config_dir(config_dir) {
            migrated.apply_user_prefs(loaded);
        }
        assert_eq!(migrated.appearance_mode, AppearanceMode::Light);
        assert_eq!(migrated.color_scheme, ColorSchemeId::Gruvbox);
        assert_eq!(migrated.ui_zoom_pct, 130);
        assert_eq!(migrated.layout_preset, LayoutPreset::ProcessesTop);

        let mut current = prefs(AppearanceMode::Dark, ColorSchemeId::TokyoNight, 110);
        current.layout_preset = LayoutPreset::Wide2x3;
        write_prefs(&prefs_path_in(config_dir), &current).unwrap();

        let mut overridden = State::new_fixture();
        if let Some(loaded) = read_prefs_from_config_dir(config_dir) {
            overridden.apply_user_prefs(loaded);
        }
        assert_eq!(overridden.appearance_mode, AppearanceMode::Dark);
        assert_eq!(overridden.color_scheme, ColorSchemeId::TokyoNight);
        assert_eq!(overridden.ui_zoom_pct, 110);
        assert_eq!(overridden.layout_preset, LayoutPreset::Wide2x3);
    }

    #[test]
    fn selected_process_history_renice_copy_pin_and_tree_collapse_work() {
        let mut state = State::new_fixture();
        let initial_pid = state.selected_pid.expect("initial selected pid");
        assert_eq!(state.history.selected_proc.pid, Some(initial_pid));
        assert_eq!(state.history.selected_proc.cpu_pct.len(), 60);
        assert_eq!(state.history.selected_proc.mem_pct.len(), 60);

        // Selecting a different PID resets and records 1 sample; selecting same PID again does not duplicate.
        state.select_pid(700);
        assert_eq!(state.history.selected_proc.pid, Some(700));
        assert_eq!(state.history.selected_proc.cpu_pct.len(), 1);
        state.select_pid(700);
        assert_eq!(state.history.selected_proc.cpu_pct.len(), 1);
        state.tick();
        assert_eq!(state.history.selected_proc.cpu_pct.len(), 2);

        // Copy command for normal process and kernel thread (empty cmdline falls back to name).
        state.copy_selected_command();
        assert_eq!(
            state.copied_command.as_deref(),
            Some("/usr/bin/postgres --pid 700")
        );
        assert_eq!(
            state.status_banner,
            Some(("Copied command for postgres (pid 700)".to_string(), false))
        );
        state.select_pid(2);
        state.copy_selected_command();
        assert_eq!(state.copied_command.as_deref(), Some("kthreadd"));
        assert_eq!(
            state.status_banner,
            Some(("Copied command for kthreadd (pid 2)".to_string(), false))
        );

        // Fixture renice clamps to -20..=19, persists across tick(), and refuses pid 1.
        state.select_pid(1001);
        assert_eq!(state.selected_process().unwrap().nice, 5);
        state.renice_selected(-2);
        assert_eq!(state.selected_process().unwrap().nice, 3);
        assert_eq!(
            state.status_banner,
            Some(("Reniced rustc (pid 1001) to nice 3".to_string(), false))
        );
        state.tick();
        assert_eq!(state.selected_process().unwrap().nice, 3);
        state.renice_selected(100);
        assert_eq!(state.selected_process().unwrap().nice, 19);
        state.renice_selected(-100);
        assert_eq!(state.selected_process().unwrap().nice, -20);
        state.select_pid(1);
        state.renice_selected(1);
        assert_eq!(
            state.status_banner,
            Some(("refusing to renice pid 1".to_string(), true))
        );

        // Pinning via `P` and `toggle_pin_pid`.
        state.select_pid(330);
        assert!(press_text(&mut state, "P"));
        assert!(state.pinned_pids.contains(&330));
        assert_eq!(state.rows.first().map(|r| r.pid), Some(330));
        assert!(state.rows[0].pinned);
        assert!(press_text(&mut state, "P"));
        assert!(!state.pinned_pids.contains(&330));

        // Collapsible tree via Left, Right, z, and Enter.
        state.set_process_mode(ProcessMode::Tree);
        state.select_pid(320); // bash (children: vim 330, htop 331, cargo 1000, python3 1100, btm 1500)
        assert!(state.rows.iter().any(|r| r.pid == 330));
        assert!(press(&mut state, Key::Left));
        assert!(state.collapsed_pids.contains(&320));
        assert!(!state.rows.iter().any(|r| r.pid == 330));
        let bash_row = state.rows.iter().find(|r| r.pid == 320).unwrap();
        assert!(bash_row.collapsed);
        assert!(bash_row.hidden_children >= 5);

        // Pressing Left again on an already-collapsed node moves selection to its parent (310).
        assert!(press(&mut state, Key::Left));
        assert_eq!(state.selected_pid, Some(310));

        // Select 320 and expand with Right, then toggle with z and Enter.
        state.select_pid(320);
        assert!(press(&mut state, Key::Right));
        assert!(!state.collapsed_pids.contains(&320));
        assert!(state.rows.iter().any(|r| r.pid == 330));
        assert!(press_text(&mut state, "z"));
        assert!(state.collapsed_pids.contains(&320));
        assert!(press(&mut state, Key::Enter));
        assert!(!state.collapsed_pids.contains(&320));
    }

    #[test]
    fn live_renice_selected_routes_direct_and_through_elevated_helper() {
        let mut child = Command::new("sh")
            .args(["-c", "sleep 30"])
            .spawn()
            .expect("spawn sleep child");
        let child_pid = child.id();

        let temp = tempfile::tempdir().unwrap();
        let local = temp.path().join("local");
        let elevated = temp.path().join("elevated");
        write_host_proc(&local, "local-user");
        write_host_proc(&elevated, "all-users");
        let mut state = worker_state(&local);
        state.elevation = ElevationState::Unprivileged;
        state.helper_routed = false;
        state.snapshot.processes.push(ProcessInfo {
            pid: child_pid,
            ppid: std::process::id(),
            name: "sleep".to_string(),
            cmdline: "sleep 30".to_string(),
            nice: 0,
            ..ProcessInfo::default()
        });
        state.rebuild_rows();
        state.select_pid(child_pid);

        let base_nice = renice_process(child_pid, 0).expect("read base nice");
        state.renice_selected(1);
        let expected_direct = (base_nice + 1).clamp(-20, 19);
        assert_eq!(
            state.selected_process().map(|p| p.nice),
            Some(expected_direct)
        );
        assert_eq!(
            state.status_banner,
            Some((
                format!("Reniced sleep (pid {child_pid}) to nice {expected_direct}"),
                false
            ))
        );

        let binary = crate::collector::helper_binary();
        if binary.is_file() {
            state.set_elevation_command(
                binary,
                vec![
                    "--collector-helper-root".to_string(),
                    elevated.display().to_string(),
                ],
            );
            state.toggle_elevation();
            wait_until(&mut state, |s| s.elevation == ElevationState::Elevated);
            assert!(state.helper_routed);
            state.snapshot.processes.push(ProcessInfo {
                pid: child_pid,
                ppid: std::process::id(),
                name: "sleep".to_string(),
                cmdline: "sleep 30".to_string(),
                nice: expected_direct,
                ..ProcessInfo::default()
            });
            state.rebuild_rows();
            state.select_pid(child_pid);
            state.renice_selected(1);
            let expected_helper = (expected_direct + 1).clamp(-20, 19);
            assert_eq!(
                state.selected_process().map(|p| p.nice),
                Some(expected_helper)
            );
            assert_eq!(
                state.status_banner,
                Some((
                    format!("Reniced sleep (pid {child_pid}) to nice {expected_helper}"),
                    false
                ))
            );
            state.toggle_elevation();
        }

        let _ = child.kill();
        let _ = child.wait();
    }
}
