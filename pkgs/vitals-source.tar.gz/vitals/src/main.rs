//! CLI for Vitals, a native GPU-accelerated Linux system monitor built from scratch on Anomaly Rune.
//!
//! Rune flags (`--snap`, `--scene`, `--tree`, `--at`, …) pass through.

use vitals::state::State;
use vitals::theme::{AppearanceMode, ColorSchemeId};

fn main() {
    prefer_gl_on_virtio_gpu();
    let args: Vec<String> = std::env::args().skip(1).collect();
    if is_collector_helper(&args) {
        vitals::collector::run_collector_helper();
        return;
    }
    let launch = match parse_launch(&args) {
        Ok(launch) => launch,
        Err(message) => {
            eprintln!("vitals: {message}");
            std::process::exit(2);
        }
    };
    let rune_args = launch.rune_args.clone();
    rune::App::new(vitals::ui::spec())
        .args(rune_args)
        .init(move || initial_state(launch))
        .run();
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SourceKind {
    Live,
    Fixture,
}

#[derive(Debug, PartialEq, Eq)]
struct Launch {
    source: SourceKind,
    rate_ms: Option<u64>,
    window_secs: Option<u32>,
    appearance: Option<AppearanceMode>,
    color_scheme: Option<ColorSchemeId>,
    rune_args: Vec<String>,
}

/// A virtio-gpu guest's Vulkan ICDs fail to connect and cost about a second
/// before the first frame. GLES can present, so choose it before wgpu builds
/// an instance.
fn prefer_gl_on_virtio_gpu() {
    #[cfg(target_os = "linux")]
    if std::env::var_os("WGPU_BACKEND").is_none()
        && std::path::Path::new("/sys/module/virtio_gpu").exists()
    {
        // `main` has not spawned a thread yet.
        unsafe { std::env::set_var("WGPU_BACKEND", "gl") };
    }
}

fn is_collector_helper(args: &[String]) -> bool {
    matches!(
        args.first().map(String::as_str),
        Some("--collector-helper" | "--collector-helper-root")
    )
}

fn parse_launch(args: &[String]) -> Result<Launch, String> {
    let mut fixture = false;
    let mut live = false;
    let mut headless = false;
    let mut rate_ms = None;
    let mut window_secs = None;
    let mut appearance = None;
    let mut color_scheme = None;
    let mut rune_args = Vec::new();
    let mut index = 0;
    while index < args.len() {
        match args[index].as_str() {
            "--fixture" => fixture = true,
            "--live" => live = true,
            "--rate" => {
                let value = take_value(args, &mut index, "--rate")?;
                rate_ms = Some(parse_u64(value, "--rate")?);
            }
            "--window" => {
                let value = take_value(args, &mut index, "--window")?;
                window_secs = Some(parse_u32(value, "--window")?);
            }
            "--theme" => {
                let value = take_value(args, &mut index, "--theme")?;
                appearance =
                    Some(AppearanceMode::from_slug(value).ok_or_else(|| {
                        format!("--theme is dark, light, or system, got {value}")
                    })?);
            }
            "--color-scheme" => {
                let value = take_value(args, &mut index, "--color-scheme")?;
                color_scheme = Some(ColorSchemeId::from_slug(value).ok_or_else(|| {
                    format!(
                        "--color-scheme is system, gruvbox, catppuccin, obsidian, tokyo-night, nord, or rose-pine, got {value}"
                    )
                })?);
            }
            "--snap" | "--scene" | "--tree" => {
                headless = true;
                rune_args.push(args[index].clone());
            }
            _ => rune_args.push(args[index].clone()),
        }
        index += 1;
    }
    let source = if fixture || (headless && !live) {
        SourceKind::Fixture
    } else {
        SourceKind::Live
    };
    Ok(Launch {
        source,
        rate_ms,
        window_secs,
        appearance,
        color_scheme,
        rune_args,
    })
}

fn take_value<'a>(args: &'a [String], index: &mut usize, flag: &str) -> Result<&'a str, String> {
    *index += 1;
    args.get(*index)
        .map(String::as_str)
        .ok_or_else(|| format!("{flag} needs a value"))
}

fn parse_u64(value: &str, flag: &str) -> Result<u64, String> {
    value
        .parse()
        .map_err(|_| format!("{flag} needs a non-negative integer, got {value}"))
}

fn parse_u32(value: &str, flag: &str) -> Result<u32, String> {
    value
        .parse()
        .map_err(|_| format!("{flag} needs a non-negative integer, got {value}"))
}

fn initial_state(launch: Launch) -> State {
    let mut state = match launch.source {
        SourceKind::Live => State::new_live(),
        SourceKind::Fixture => State::new_fixture(),
    };
    if let Some(rate_ms) = launch.rate_ms {
        state.poll_interval_ms = rate_ms;
    }
    if let Some(window_secs) = launch.window_secs {
        state.time_window_secs = window_secs;
    }
    state.apply_cli_theme(launch.appearance, launch.color_scheme);
    state
}

#[cfg(test)]
mod tests {
    use super::{Launch, SourceKind, initial_state, is_collector_helper, parse_launch};
    use vitals::theme::{AppearanceMode, ColorSchemeId};

    fn owned(args: &[&str]) -> Vec<String> {
        args.iter().map(|arg| (*arg).to_string()).collect()
    }

    #[test]
    fn collector_helper_flag_is_recognized_before_the_gui() {
        assert!(is_collector_helper(&owned(&["--collector-helper"])));
        assert!(is_collector_helper(&owned(&[
            "--collector-helper-root",
            "/tmp/proc"
        ])));
        assert!(!is_collector_helper(&owned(&["--live"])));
        assert!(!is_collector_helper(&owned(&[])));
    }

    #[test]
    fn default_launch_is_live_and_keeps_rune_flags() {
        let launch = parse_launch(&owned(&["--at", "1.5", "--size", "800x600"])).unwrap();
        assert_eq!(
            launch,
            Launch {
                source: SourceKind::Live,
                rate_ms: None,
                window_secs: None,
                appearance: None,
                color_scheme: None,
                rune_args: owned(&["--at", "1.5", "--size", "800x600"]),
            }
        );
    }

    #[test]
    fn fixture_and_headless_flags_select_the_fixture() {
        let fixture = parse_launch(&owned(&["--fixture", "--rate", "250"])).unwrap();
        assert_eq!(fixture.source, SourceKind::Fixture);
        assert_eq!(fixture.rate_ms, Some(250));
        assert!(fixture.rune_args.is_empty());

        let snap = parse_launch(&owned(&["--snap", "out.png", "--scene", "dark"])).unwrap();
        assert_eq!(snap.source, SourceKind::Fixture);
        assert_eq!(
            snap.rune_args,
            owned(&["--snap", "out.png", "--scene", "dark"])
        );

        let tree = parse_launch(&owned(&["--tree", "tree.json"])).unwrap();
        assert_eq!(tree.source, SourceKind::Fixture);
        assert_eq!(tree.rune_args, owned(&["--tree", "tree.json"]));
    }

    #[test]
    fn live_overrides_headless_fixture_default() {
        let launch =
            parse_launch(&owned(&["--snap", "out.png", "--live", "--window", "15"])).unwrap();
        assert_eq!(launch.source, SourceKind::Live);
        assert_eq!(launch.window_secs, Some(15));
        assert_eq!(launch.rune_args, owned(&["--snap", "out.png"]));
    }

    #[test]
    fn explicit_fixture_wins_over_live() {
        let launch = parse_launch(&owned(&["--live", "--fixture"])).unwrap();
        assert_eq!(launch.source, SourceKind::Fixture);
    }

    #[test]
    fn theme_rate_and_window_parse() {
        let launch = parse_launch(&owned(&[
            "--theme",
            "light",
            "--rate",
            "500",
            "--window",
            "30",
            "--fixture",
        ]))
        .unwrap();
        assert_eq!(launch.appearance, Some(AppearanceMode::Light));
        assert_eq!(launch.rate_ms, Some(500));
        assert_eq!(launch.window_secs, Some(30));
        assert_eq!(launch.source, SourceKind::Fixture);

        let dark = parse_launch(&owned(&["--theme", "dark"])).unwrap();
        assert_eq!(dark.appearance, Some(AppearanceMode::Dark));
        assert_eq!(dark.source, SourceKind::Live);

        let system = parse_launch(&owned(&[
            "--fixture",
            "--theme",
            "system",
            "--color-scheme",
            "rose-pine",
        ]))
        .unwrap();
        assert_eq!(system.appearance, Some(AppearanceMode::System));
        assert_eq!(system.color_scheme, Some(ColorSchemeId::RosePine));
        let state = initial_state(system);
        assert_eq!(state.appearance_mode, AppearanceMode::System);
        assert_eq!(state.dark, None);
        assert_eq!(state.color_scheme, ColorSchemeId::RosePine);
    }

    #[test]
    fn malformed_flags_report_the_flag() {
        assert!(
            parse_launch(&owned(&["--rate"]))
                .unwrap_err()
                .contains("--rate")
        );
        assert!(
            parse_launch(&owned(&["--window", "soon"]))
                .unwrap_err()
                .contains("--window")
        );
        assert!(
            parse_launch(&owned(&["--theme", "blue"]))
                .unwrap_err()
                .contains("--theme")
        );
        assert!(
            parse_launch(&owned(&["--color-scheme"]))
                .unwrap_err()
                .contains("--color-scheme")
        );
        assert!(
            parse_launch(&owned(&["--color-scheme", "solarized"]))
                .unwrap_err()
                .contains("--color-scheme")
        );
    }
}
