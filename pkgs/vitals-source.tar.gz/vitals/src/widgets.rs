//! Hardware and process inspector panels for Vitals.
//!
//! Each panel is a bordered instrument card: a 28pt title bar, a hairline, and a body of
//! vector charts plus dense readouts. History charts use the GPU shapes from [`crate::charts`].

#![allow(clippy::large_types_passed_by_value)]

use rune::{
    Align, Color, Cursor, El, ScrollSpec, Shape, TextStyle, Transition, Tx, canvas, col, el, row,
    text,
};

use crate::charts::*;
use crate::model::*;
use crate::state::{ChartKind, State};
use crate::theme::Palette;

/// Pointer hover parameters for an interactive telemetry history chart.
#[derive(Clone, Copy, Debug, Default)]
pub struct ChartHoverSpec {
    pub active_frac: Option<f32>,
    pub width_hint: f32,
    pub poll_interval_ms: u64,
    pub interactive: bool,
}

/// Panel title in the header bar.
pub const PANEL_TITLE: TextStyle = TextStyle::new(12.0, 600.0).lh(16.0).features("'tnum' 1");
/// Primary numeric readout.
pub const METRIC_VALUE: TextStyle = TextStyle::new(13.0, 600.0)
    .mono()
    .lh(16.0)
    .features("'tnum' 1");
/// Secondary labels under a title or beside a figure.
pub const LABEL: TextStyle = TextStyle::new(11.0, 500.0).lh(14.0);
/// Tabular figures for rates, bytes, and identifiers.
pub const MONO: TextStyle = TextStyle::new(12.0, 500.0)
    .mono()
    .lh(15.0)
    .features("'tnum' 1");
/// Dense rows: per-core lines, interface rates, command text.
pub const MONO_SMALL: TextStyle = TextStyle::new(10.5, 500.0)
    .mono()
    .lh(13.0)
    .features("'tnum' 1");
/// Header chip for the panel's headline number.
pub const BADGE: TextStyle = TextStyle::new(11.0, 650.0)
    .mono()
    .lh(13.0)
    .features("'tnum' 1");

const SCROLL: ScrollSpec = ScrollSpec {
    stick_bottom: false,
};

/// Bordered instrument card. `focused` swaps the outline to the focus color.
pub fn panel_frame(
    key: impl Into<String>,
    title: impl Into<String>,
    subtitle: impl Into<String>,
    right_badge: Option<(String, Color)>,
    focused: bool,
    p: Palette,
    body: El,
) -> El {
    panel_frame_slot(
        key,
        title,
        subtitle,
        right_badge,
        None,
        focused,
        false,
        p,
        body,
    )
}

/// Bordered instrument card with an optional header control and swap-target highlight.
#[allow(clippy::too_many_arguments)]
pub fn panel_frame_slot(
    key: impl Into<String>,
    title: impl Into<String>,
    subtitle: impl Into<String>,
    right_badge: Option<(String, Color)>,
    header_action: Option<El>,
    focused: bool,
    slot_highlight: bool,
    p: Palette,
    body: El,
) -> El {
    let mut card = col()
        .key(key)
        .fill(p.panel)
        .radius(6.0)
        .w_full()
        .h_full()
        .min_h(0.0)
        .min_w(0.0)
        .clip_soft(6.0);
    if slot_highlight {
        card = card.outline(1.5, 0.0, p.accent);
    } else if focused {
        card = card.outline(1.0, 0.0, p.border_focus);
    }
    card.child(header_bar(
        title.into(),
        subtitle.into(),
        right_badge,
        header_action,
        p,
    ))
    .child(body.w_full().grow(1.0).min_h(0.0))
}

/// Total CPU, per-core meters, and either one total series or a core overlay.
pub fn cpu_panel(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    per_core_chart: bool,
    zoomed: bool,
    focused: bool,
    p: Palette,
) -> El {
    cpu_panel_slot(
        snap,
        history,
        sample_count,
        per_core_chart,
        zoomed,
        focused,
        800.0,
        ChartHoverSpec::default(),
        None,
        false,
        p,
    )
}

/// [`cpu_panel`] with responsive width, optional slot header action, and highlight outline.
#[allow(clippy::too_many_arguments)]
pub fn cpu_panel_slot(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    per_core_chart: bool,
    zoomed: bool,
    focused: bool,
    panel_w: f32,
    hover: ChartHoverSpec,
    header_action: Option<El>,
    slot_highlight: bool,
    p: Palette,
) -> El {
    let cpu = &snap.cpu;
    let narrow = panel_w < 520.0;
    let badge = (
        format!("{:.1}%", cpu.total_usage_pct),
        p.usage_color(cpu.total_usage_pct),
    );
    let total_tail = history.cpu_total.tail(sample_count);
    let hover_text = hover.active_frac.map(|frac| {
        let (val, secs_ago) = sample_at_f32(&total_tail, frac, hover.poll_interval_ms);
        format!("Hover -{secs_ago}s: {val:.1}%")
    });
    let chart = cpu_chart(
        history,
        sample_count,
        per_core_chart,
        zoomed,
        narrow,
        hover,
        p,
    );
    let cores = scroll_list("cpu-cores", core_rows(cpu, narrow, p));
    let body = stack(zoomed)
        .child(cpu_stats(cpu, &snap.psi, hover_text, p))
        .child(split(zoomed || narrow, chart, cores));
    panel_frame_slot(
        "cpu-panel",
        "CPU",
        named(&cpu.model_name),
        Some(badge),
        header_action,
        focused,
        slot_highlight,
        p,
        body,
    )
}

/// RAM and swap meters with a two-series history.
pub fn memory_panel(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    zoomed: bool,
    focused: bool,
    p: Palette,
) -> El {
    memory_panel_slot(
        snap,
        history,
        sample_count,
        zoomed,
        focused,
        ChartHoverSpec::default(),
        None,
        false,
        p,
    )
}

/// [`memory_panel`] with an optional slot header action and highlight outline.
#[allow(clippy::too_many_arguments)]
pub fn memory_panel_slot(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    zoomed: bool,
    focused: bool,
    hover: ChartHoverSpec,
    header_action: Option<El>,
    slot_highlight: bool,
    p: Palette,
) -> El {
    let mem = &snap.mem;
    let badge = (format!("{:.1}%", mem.used_pct), p.usage_color(mem.used_pct));
    let ram = history.mem_pct.tail(sample_count);
    let swap = history.swap_pct.tail(sample_count);
    let series = [
        Series {
            values: &ram,
            color: p.mem_used,
            fill_alpha: 0.22,
            width: 1.6,
        },
        Series {
            values: &swap,
            color: p.swap_used,
            fill_alpha: 0.14,
            width: 1.45,
        },
    ];
    let shape = with_hover_cursor(
        multi_series_chart(&series, 0.0, 100.0, p.border, 360.0, 120.0),
        hover.active_frac,
        p.accent,
        360.0,
        120.0,
    );
    let chart_h = if zoomed { 220.0 } else { 64.0 };
    let mut breakdown = row()
        .w_full()
        .flex_wrap()
        .gap(10.0)
        .items_center()
        .child(minor(
            format!("Available {}", format_bytes(mem.available_bytes)),
            p.muted,
        ))
        .child(minor(
            format!("Cached {}", format_bytes(mem.cached_bytes)),
            p.muted,
        ))
        .child(minor(
            format!("Buffers {}", format_bytes(mem.buffers_bytes)),
            p.muted,
        ))
        .child(minor(
            format!("Shared {}", format_bytes(mem.shared_bytes)),
            p.muted,
        ))
        .child(minor(
            format!("Dirty {}", format_bytes(mem.dirty_bytes)),
            p.muted,
        ))
        .child(minor(
            format!("Slab {}", format_bytes(mem.slab_bytes)),
            p.muted,
        ))
        .child(badge_chip(
            format!(
                "PSI {:.1}% / {:.1}%",
                snap.psi.mem_some_pct, snap.psi.mem_full_pct
            ),
            p.usage_color(snap.psi.mem_some_pct * 4.0),
        ));
    if let Some(frac) = hover.active_frac {
        let (ram_v, secs_ago) = sample_at_f32(&ram, frac, hover.poll_interval_ms);
        let (swap_v, _) = sample_at_f32(&swap, frac, hover.poll_interval_ms);
        breakdown = breakdown.child(hover_badge(
            "mem-hover-readout",
            format!("Hover -{secs_ago}s: {ram_v:.1}% · Swap {swap_v:.1}%"),
            p,
        ));
    }
    let body = stack(zoomed)
        .child(quantity_row(
            format!(
                "RAM {} / {}",
                format_bytes(mem.used_bytes),
                format_bytes(mem.total_bytes)
            ),
            format!("{:.1}%", mem.used_pct),
            p.usage_color(mem.used_pct),
            p,
        ))
        .child(meter_wide(mem.used_pct, p.panel_alt, p.mem_used))
        .child(breakdown)
        .child(quantity_row(
            format!(
                "Swap {} / {}",
                format_bytes(mem.swap_used_bytes),
                format_bytes(mem.swap_total_bytes)
            ),
            format!("{:.1}%", mem.swap_pct),
            p.swap_used,
            p,
        ))
        .child(meter_wide(mem.swap_pct, p.panel_alt, p.swap_used))
        .child(chart_well_interactive(
            shape,
            "memory-chart",
            Some("mem-chart"),
            chart_h,
            ChartKind::Memory,
            hover,
            p,
        ));
    panel_frame_slot(
        "memory-panel",
        "Memory",
        "resident and swap",
        Some(badge),
        header_action,
        focused,
        slot_highlight,
        p,
        body,
    )
}

/// Aggregate RX/TX mirror chart plus a compact interface and active socket list.
pub fn network_panel(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    show_loopback: bool,
    zoomed: bool,
    focused: bool,
    p: Palette,
) -> El {
    network_panel_slot(
        snap,
        history,
        sample_count,
        show_loopback,
        zoomed,
        focused,
        800.0,
        ChartHoverSpec::default(),
        None,
        false,
        &snap.sockets,
        None,
        p,
    )
}

/// [`network_panel`] with responsive width, optional slot header action, and highlight outline.
#[allow(clippy::too_many_arguments)]
pub fn network_panel_slot(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    show_loopback: bool,
    zoomed: bool,
    focused: bool,
    panel_w: f32,
    hover: ChartHoverSpec,
    header_action: Option<El>,
    slot_highlight: bool,
    sockets: &[NetSocketEntry],
    socket_toolbar: Option<El>,
    p: Palette,
) -> El {
    let narrow = panel_w < 520.0;
    let rx = history.net_rx_bps.tail(sample_count);
    let tx = history.net_tx_bps.tail(sample_count);
    let (raw_shape, peak) = dual_mirror_chart(&rx, &tx, p.net_rx, p.net_tx, p.border, 360.0, 110.0);
    let shape = with_hover_cursor(raw_shape, hover.active_frac, p.accent, 360.0, 110.0);
    let ifaces: Vec<&NetInterfaceMetrics> = snap
        .networks
        .iter()
        .filter(|iface| show_loopback || !iface.is_loopback)
        .collect();
    let cols = iface_cols(&ifaces);
    let mut rows: Vec<El> = if ifaces.is_empty() {
        vec![quiet("No interfaces", p)]
    } else if narrow {
        ifaces
            .iter()
            .enumerate()
            .map(|(index, iface)| iface_row_compact(index, iface, p))
            .collect()
    } else {
        ifaces
            .iter()
            .enumerate()
            .map(|(index, iface)| iface_row(index, iface, &cols, p))
            .collect()
    };
    let socket_title = format!("Sockets ({} / {})", sockets.len(), snap.sockets.len());
    rows.push(section(&socket_title, p));
    if sockets.is_empty() {
        rows.push(quiet(
            if snap.sockets.is_empty() {
                "No active sockets"
            } else {
                "No matching sockets"
            },
            p,
        ));
    } else if narrow {
        rows.push(socket_header_row_compact(p));
        rows.extend(
            sockets
                .iter()
                .enumerate()
                .map(|(index, sock)| socket_row_compact(index, sock, p)),
        );
    } else {
        let sock_cols = socket_cols(sockets);
        rows.push(socket_header_row(&sock_cols, p));
        rows.extend(
            sockets
                .iter()
                .enumerate()
                .map(|(index, sock)| socket_row(index, sock, &sock_cols, p)),
        );
    }
    let chart_h = if zoomed { 200.0 } else { 56.0 };
    let badge = (
        format!("RX {}", format_rate(snap.net_rx_total_bps)),
        p.net_rx,
    );
    let mut top_row = row()
        .w_full()
        .flex_wrap()
        .gap(12.0)
        .items_center()
        .child(
            text(format!("RX {}", format_rate(snap.net_rx_total_bps)))
                .font(METRIC_VALUE)
                .color(p.net_rx),
        )
        .child(
            text(format!("TX {}", format_rate(snap.net_tx_total_bps)))
                .font(METRIC_VALUE)
                .color(p.net_tx),
        )
        .child(minor(format!("Peak {}", format_rate(peak)), p.muted));
    if let Some(frac) = hover.active_frac {
        let (rx_v, secs_ago) = sample_at_f64(&rx, frac, hover.poll_interval_ms);
        let (tx_v, _) = sample_at_f64(&tx, frac, hover.poll_interval_ms);
        top_row = top_row.child(hover_badge(
            "net-hover-readout",
            format!(
                "Hover -{secs_ago}s: RX {} · TX {}",
                format_rate(rx_v),
                format_rate(tx_v)
            ),
            p,
        ));
    }
    let list_el = scroll_list("network-ifaces", rows)
        .w_full()
        .grow(if zoomed { 1.0 } else { 1.8 })
        .min_h(24.0);
    let chart_el = chart_well_interactive(
        shape,
        "network-chart",
        Some("net-chart"),
        chart_h,
        ChartKind::Network,
        hover,
        p,
    );
    let mut body = stack(zoomed).child(top_row);
    if let Some(toolbar) = socket_toolbar {
        body = body.child(toolbar);
    }
    let body = body.child(split(true, chart_el, list_el));
    panel_frame_slot(
        "network-panel",
        "Network",
        format!(
            "{} interfaces · {} / {} sockets",
            ifaces.len(),
            sockets.len(),
            snap.sockets.len()
        ),
        Some(badge),
        header_action,
        focused,
        slot_highlight,
        p,
        body,
    )
}

/// Mount rows, thermals, batteries, and a disk I/O mirror chart while zoomed.
pub fn disks_sensors_panel(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    zoomed: bool,
    focused: bool,
    p: Palette,
) -> El {
    disks_sensors_panel_slot(
        snap,
        history,
        sample_count,
        zoomed,
        focused,
        800.0,
        ChartHoverSpec::default(),
        None,
        false,
        p,
    )
}

/// [`disks_sensors_panel`] with responsive width, optional slot header action, and highlight outline.
#[allow(clippy::too_many_arguments)]
pub fn disks_sensors_panel_slot(
    snap: &SystemSnapshot,
    history: &TelemetryHistory,
    sample_count: usize,
    zoomed: bool,
    focused: bool,
    panel_w: f32,
    hover: ChartHoverSpec,
    header_action: Option<El>,
    slot_highlight: bool,
    p: Palette,
) -> El {
    let compact_disks = !zoomed && panel_w < 540.0;
    let mounts: Vec<El> = if snap.disks.is_empty() {
        vec![quiet("No mounts", p)]
    } else if compact_disks {
        std::iter::once(disk_header_row_compact(p))
            .chain(
                snap.disks
                    .iter()
                    .enumerate()
                    .map(|(index, disk)| disk_row_compact(index, disk, p)),
            )
            .collect()
    } else {
        let disk_columns = disk_cols(&snap.disks);
        std::iter::once(disk_header_row(&disk_columns, p))
            .chain(
                snap.disks
                    .iter()
                    .enumerate()
                    .map(|(index, disk)| disk_row(index, disk, &disk_columns, p)),
            )
            .collect()
    };
    let sensors = if snap.sensors.is_empty() {
        vec![quiet("No sensors", p)]
    } else {
        snap.sensors
            .iter()
            .map(|sensor| sensor_row(sensor, p))
            .collect()
    };
    let battery_columns = battery_cols(&snap.batteries);
    let batteries = if snap.batteries.is_empty() {
        vec![quiet("No battery", p)]
    } else {
        snap.batteries
            .iter()
            .enumerate()
            .map(|(index, battery)| battery_row(index, battery, &battery_columns, p))
            .collect()
    };
    let mounts_header = row()
        .w_full()
        .gap(8.0)
        .items_center()
        .child(section("Mounts", p))
        .child(badge_chip(
            format!("IO PSI {:.1}%", snap.psi.io_some_pct),
            p.usage_color(snap.psi.io_some_pct * 4.0),
        ));
    let list = scroll_list(
        "disk-mounts",
        std::iter::once(mounts_header)
            .chain(mounts)
            .chain(std::iter::once(section("Sensors", p)))
            .chain(sensors)
            .chain(std::iter::once(section("Batteries", p)))
            .chain(batteries)
            .collect(),
    )
    .w_full()
    .grow(1.0)
    .gap(6.0);
    let mut body = stack(zoomed);
    if zoomed {
        let read = history.disk_read_bps.tail(sample_count);
        let write = history.disk_write_bps.tail(sample_count);
        let (raw_shape, peak) = dual_mirror_chart(
            &read,
            &write,
            p.disk_read,
            p.disk_write,
            p.border,
            360.0,
            110.0,
        );
        let shape = with_hover_cursor(raw_shape, hover.active_frac, p.accent, 360.0, 110.0);
        let mut chart_top = row()
            .w_full()
            .flex_wrap()
            .gap(10.0)
            .items_center()
            .child(minor("Read", p.disk_read))
            .child(minor("Write", p.disk_write))
            .child(minor(format!("Peak {}", format_rate(peak)), p.muted));
        if let Some(frac) = hover.active_frac {
            let (r_v, secs_ago) = sample_at_f64(&read, frac, hover.poll_interval_ms);
            let (w_v, _) = sample_at_f64(&write, frac, hover.poll_interval_ms);
            chart_top = chart_top.child(hover_badge(
                "disk-hover-readout",
                format!(
                    "Hover -{secs_ago}s: R {} · W {}",
                    format_rate(r_v),
                    format_rate(w_v)
                ),
                p,
            ));
        }
        body = body.child(chart_top).child(chart_well_interactive(
            shape,
            "disk-io-chart",
            None,
            160.0,
            ChartKind::Disks,
            hover,
            p,
        ));
    }
    let hottest = snap
        .sensors
        .iter()
        .max_by(|a, b| a.temp_c.total_cmp(&b.temp_c))
        .map(|sensor| {
            (
                format!("{:.0}°C", sensor.temp_c),
                p.temp_color(sensor.temp_c),
            )
        });
    panel_frame_slot(
        "disks-panel",
        "Disks",
        format!("{} mounts", snap.disks.len()),
        hottest,
        header_action,
        focused,
        slot_highlight,
        p,
        body.child(list),
    )
}

/// Side card for the selected process, or a prompt when nothing is selected.
pub fn process_inspector_card(proc: Option<&ProcessInfo>, p: Palette) -> El {
    process_inspector_card_slot(
        proc,
        &SelectedProcessHistory::default(),
        false,
        60,
        None,
        false,
        p,
    )
}

/// [`process_inspector_card`] with selected-process history, pin state, and optional slot chrome.
#[allow(clippy::too_many_arguments)]
pub fn process_inspector_card_slot(
    proc: Option<&ProcessInfo>,
    proc_history: &SelectedProcessHistory,
    pinned: bool,
    sample_count: usize,
    header_action: Option<El>,
    slot_highlight: bool,
    p: Palette,
) -> El {
    match proc {
        None => panel_frame_slot(
            "process-inspector",
            "Process",
            "none selected",
            None,
            header_action,
            false,
            slot_highlight,
            p,
            empty_process(p),
        ),
        Some(proc) => {
            let badge = (format!("{:.1}%", proc.cpu_pct), p.usage_color(proc.cpu_pct));
            panel_frame_slot(
                "process-inspector",
                "Process",
                proc.name.clone(),
                Some(badge),
                header_action,
                false,
                slot_highlight,
                p,
                process_body(proc, proc_history, pinned, sample_count, p),
            )
        }
    }
}

fn header_bar(
    title: String,
    subtitle: String,
    badge: Option<(String, Color)>,
    action: Option<El>,
    p: Palette,
) -> El {
    let mut bar = row()
        .h(28.0)
        .w_full()
        .px(8.0)
        .gap(6.0)
        .items_center()
        .fill(p.panel_alt)
        .child(text(title).font(PANEL_TITLE).color(p.text))
        .child(
            text(subtitle)
                .font(LABEL)
                .color(p.muted)
                .truncate()
                .grow(1.0),
        );
    if let Some((label, color)) = badge {
        bar = bar.child(badge_chip(label, color));
    }
    if let Some(action) = action {
        bar = bar.child(action);
    }
    bar
}

fn badge_chip(label: String, color: Color) -> El {
    el().h(18.0)
        .px(6.0)
        .radius(4.0)
        .items_center()
        .fill(color.alpha(0.18))
        .child(text(label).font(BADGE).color(color))
}

fn stack(zoomed: bool) -> El {
    col()
        .w_full()
        .h_full()
        .min_h(0.0)
        .min_w(0.0)
        .padding(if zoomed { 10.0 } else { 8.0 })
        .gap(if zoomed { 8.0 } else { 6.0 })
}

fn hover_badge(key: &str, label: String, p: Palette) -> El {
    el().key(key)
        .h(18.0)
        .px(6.0)
        .radius(4.0)
        .items_center()
        .fill(p.accent.alpha(0.18))
        .child(text(label).font(BADGE).color(p.accent))
}

fn sample_at_f32(samples: &[f32], frac: f32, poll_interval_ms: u64) -> (f32, u64) {
    if samples.is_empty() || !frac.is_finite() {
        return (0.0, 0);
    }
    let clamped = frac.clamp(0.0, 1.0);
    let last = samples.len() - 1;
    let idx = ((clamped * last as f32).round() as usize).min(last);
    let interval = if poll_interval_ms == 0 {
        1_000
    } else {
        poll_interval_ms
    };
    let secs_ago = ((last - idx) as f64 * (interval as f64 / 1_000.0)).round() as u64;
    let v = samples[idx];
    (if v.is_finite() { v } else { 0.0 }, secs_ago)
}

fn sample_at_f64(samples: &[f64], frac: f32, poll_interval_ms: u64) -> (f64, u64) {
    if samples.is_empty() || !frac.is_finite() {
        return (0.0, 0);
    }
    let clamped = frac.clamp(0.0, 1.0);
    let last = samples.len() - 1;
    let idx = ((clamped * last as f32).round() as usize).min(last);
    let interval = if poll_interval_ms == 0 {
        1_000
    } else {
        poll_interval_ms
    };
    let secs_ago = ((last - idx) as f64 * (interval as f64 / 1_000.0)).round() as u64;
    let v = samples[idx];
    (if v.is_finite() { v } else { 0.0 }, secs_ago)
}

fn chart_well_interactive(
    shape: Shape,
    key: &str,
    alias_key: Option<&str>,
    min_h: f32,
    kind: ChartKind,
    hover: ChartHoverSpec,
    p: Palette,
) -> El {
    let mut well = canvas(shape)
        .key(key)
        .w_full()
        .grow(1.0)
        .min_h(min_h)
        .min_w(0.0)
        .fill(p.base)
        .radius(4.0)
        .cursor(Cursor::Crosshair);
    if hover.interactive {
        let width_hint = if hover.width_hint > 1.0 {
            hover.width_hint
        } else {
            360.0
        };
        well = well
            .on_pointer_move_local(move |state: &mut State, ev, tx| {
                let frac = (ev.x / width_hint).clamp(0.0, 1.0);
                state.chart_hover = Some((kind, frac));
                tx.instant();
            })
            .on_hover_change(move |state: &mut State, inside, tx| {
                if !inside && state.chart_hover.is_some_and(|(k, _)| k == kind) {
                    state.chart_hover = None;
                    tx.instant();
                }
            });
    }
    if let Some(alias) = alias_key {
        el().key(alias)
            .w_full()
            .grow(1.0)
            .min_h(min_h)
            .min_w(0.0)
            .child(well.h_full())
    } else {
        well
    }
}

/// Chart on the left (or top, while stacked); the scroll list on the right (or bottom).
fn split(stacked: bool, chart: El, list: El) -> El {
    if stacked {
        col()
            .w_full()
            .grow(1.0)
            .min_h(0.0)
            .gap(6.0)
            .child(chart)
            .child(list.w_full().grow(1.0).min_h(0.0))
    } else {
        row()
            .w_full()
            .grow(1.0)
            .min_h(0.0)
            .min_w(0.0)
            .gap(8.0)
            .child(chart.min_w(80.0))
            .child(list.w(268.0).shrink().min_w(120.0).h_full().min_h(0.0))
    }
}

fn scroll_list(key: &str, rows: Vec<El>) -> El {
    col()
        .key(key)
        .scroll(SCROLL)
        .gap(3.0)
        .min_h(0.0)
        .min_w(0.0)
        .children(rows)
}

fn cpu_chart(
    history: &TelemetryHistory,
    sample_count: usize,
    per_core_chart: bool,
    zoomed: bool,
    narrow: bool,
    hover: ChartHoverSpec,
    p: Palette,
) -> El {
    let raw_shape = if per_core_chart && !history.per_core.is_empty() {
        let tails: Vec<Vec<f32>> = history
            .per_core
            .iter()
            .map(|ring| ring.tail(sample_count))
            .collect();
        let series: Vec<Series<'_>> = tails
            .iter()
            .enumerate()
            .map(|(index, values)| Series {
                values,
                color: p.core_color(index),
                fill_alpha: 0.0,
                width: 1.35,
            })
            .collect();
        multi_series_chart(&series, 0.0, 100.0, p.border, 360.0, 120.0)
    } else {
        area_line_chart(
            &history.cpu_total.tail(sample_count),
            0.0,
            100.0,
            p.cpu_total,
            0.22,
            p.border,
            360.0,
            120.0,
        )
    };
    let shape = with_hover_cursor(raw_shape, hover.active_frac, p.accent, 360.0, 120.0);
    let min_h = if zoomed {
        220.0
    } else if narrow {
        64.0
    } else {
        96.0
    };
    chart_well_interactive(shape, "cpu-chart", None, min_h, ChartKind::Cpu, hover, p)
}

fn cpu_stats(cpu: &CpuMetrics, psi: &PsiMetrics, hover_text: Option<String>, p: Palette) -> El {
    let [one, five, fifteen] = cpu.load_avg;
    let mut line = row()
        .w_full()
        .flex_wrap()
        .gap(10.0)
        .items_center()
        .child(
            text(format!("Load {one:.2} {five:.2} {fifteen:.2}"))
                .font(METRIC_VALUE)
                .color(p.text),
        )
        .child(minor(format!("user {:.1}%", cpu.user_pct), p.muted))
        .child(minor(format!("sys {:.1}%", cpu.system_pct), p.muted))
        .child(minor(
            format!("iowait {:.1}%", cpu.iowait_pct),
            p.usage_color(cpu.iowait_pct),
        ))
        .child(badge_chip(
            format!("PSI {:.1}%", psi.cpu_some_pct),
            p.usage_color(psi.cpu_some_pct * 4.0),
        ))
        .child(minor(
            format!("Up {}", format_uptime(cpu.uptime_secs)),
            p.text,
        ))
        .child(minor(
            format!("Tasks {} / {}", cpu.tasks_running, cpu.tasks_total),
            p.text,
        ));
    if let Some(label) = hover_text {
        line = line.child(hover_badge("cpu-hover-readout", label, p));
    }
    line
}

fn core_rows(cpu: &CpuMetrics, narrow: bool, p: Palette) -> Vec<El> {
    if cpu.cores.is_empty() {
        return vec![quiet("No cores reporting", p)];
    }
    cpu.cores
        .iter()
        .map(|core| core_row(core, narrow, p))
        .collect()
}

fn core_row(core: &CoreMetrics, narrow: bool, p: Palette) -> El {
    let bar = if narrow {
        canvas(meter_bar_shape(
            core.usage_pct,
            p.panel_alt,
            p.core_color(core.index),
            120.0,
            6.0,
        ))
        .w_full()
        .grow(1.0)
        .min_w(32.0)
        .h(6.0)
        .radius(3.0)
    } else {
        canvas(meter_bar_shape(
            core.usage_pct,
            p.panel_alt,
            p.core_color(core.index),
            72.0,
            6.0,
        ))
        .size(72.0, 6.0)
        .radius(3.0)
    };
    let mut line = row()
        .w_full()
        .h(16.0)
        .gap(6.0)
        .items_center()
        .child(
            text(format!("C{}", core.index))
                .font(MONO_SMALL)
                .color(p.core_color(core.index))
                .w(24.0),
        )
        .child(bar)
        .child(
            text(format!("{:.1}%", core.usage_pct))
                .font(MONO_SMALL)
                .color(p.usage_color(core.usage_pct))
                .w(40.0)
                .align(Align::End),
        );
    if !narrow && let Some(mhz) = core.freq_mhz {
        line = line.child(
            minor(format!("{mhz} MHz"), p.muted)
                .w(62.0)
                .align(Align::End),
        );
    }
    if let Some(temp) = core.temp_c {
        line = line.child(
            text(format!("{temp:.0}°C"))
                .font(MONO_SMALL)
                .color(p.temp_color(temp))
                .w(32.0)
                .align(Align::End),
        );
    }
    line
}

fn quantity_row(caption: String, percent: String, percent_color: Color, p: Palette) -> El {
    row()
        .w_full()
        .gap(8.0)
        .items_center()
        .child(
            text(caption)
                .font(METRIC_VALUE)
                .color(p.text)
                .truncate()
                .grow(1.0),
        )
        .child(
            text(percent)
                .font(METRIC_VALUE)
                .color(percent_color)
                .align(Align::End),
        )
}

fn meter_wide(pct: f32, track: Color, fill: Color) -> El {
    canvas(meter_bar_shape(pct, track, fill, 240.0, 6.0))
        .w_full()
        .h(6.0)
        .radius(3.0)
}

/// Shared track widths for one table. Every row uses these exact cell widths, so a longer
/// mount, device, or rate cannot push the next column.
struct DiskCols {
    mount: f32,
    device: f32,
    capacity: f32,
    bar: f32,
    read: f32,
    write: f32,
    busy: f32,
    await_ms: f32,
}

struct IfaceCols {
    name: f32,
    rx: f32,
    tx: f32,
    totals: f32,
}

struct SocketCols {
    proto: f32,
    local: f32,
    remote: f32,
    state: f32,
    process: f32,
}

struct BatteryCols {
    pct: f32,
    watts: f32,
}

const COLUMN_SLACK: f32 = 1.0;
const DISK_MOUNT_MIN: f32 = 96.0;
const DISK_MOUNT_MAX: f32 = 180.0;
const DISK_DEVICE_MIN: f32 = 56.0;
const DISK_DEVICE_MAX: f32 = 96.0;
const DISK_CAPACITY_MIN: f32 = 132.0;
const DISK_CAPACITY_MAX: f32 = 220.0;
const DISK_BAR_W: f32 = 52.0;
const DISK_RATE_MIN: f32 = 82.0;
const DISK_RATE_MAX: f32 = 140.0;
const DISK_BUSY_MIN: f32 = 38.0;
const DISK_BUSY_MAX: f32 = 64.0;
const DISK_AWAIT_MIN: f32 = 52.0;
const DISK_AWAIT_MAX: f32 = 88.0;
const IFACE_NAME_MIN: f32 = 64.0;
const IFACE_NAME_MAX: f32 = 140.0;
const IFACE_TOTAL_MIN: f32 = 148.0;
const IFACE_TOTAL_MAX: f32 = 220.0;
const SOCK_PROTO_MIN: f32 = 42.0;
const SOCK_PROTO_MAX: f32 = 64.0;
const SOCK_ADDR_MIN: f32 = 104.0;
const SOCK_ADDR_MAX: f32 = 196.0;
const SOCK_STATE_MIN: f32 = 56.0;
const SOCK_STATE_MAX: f32 = 96.0;
const SOCK_PROC_MIN: f32 = 76.0;
const SOCK_PROC_MAX: f32 = 160.0;
const BATTERY_PCT_MIN: f32 = 40.0;
const BATTERY_PCT_MAX: f32 = 72.0;
const BATTERY_WATTS_MIN: f32 = 56.0;
const BATTERY_WATTS_MAX: f32 = 96.0;

fn column_width<I, S>(samples: I, style: TextStyle, min: f32, max: f32) -> f32
where
    I: IntoIterator<Item = S>,
    S: AsRef<str>,
{
    let measured = samples
        .into_iter()
        .map(|sample| rune::text::measure(sample.as_ref(), &[], style, None).0)
        .fold(0.0_f32, f32::max);
    (measured + COLUMN_SLACK).clamp(min, max)
}

fn disk_cols(disks: &[DiskMetrics]) -> DiskCols {
    DiskCols {
        mount: column_width(
            disks.iter().map(|disk| disk.mount_point.as_str()),
            MONO,
            DISK_MOUNT_MIN,
            DISK_MOUNT_MAX,
        ),
        device: column_width(
            disks.iter().map(|disk| disk.device.as_str()),
            MONO_SMALL,
            DISK_DEVICE_MIN,
            DISK_DEVICE_MAX,
        ),
        capacity: column_width(
            disks.iter().map(capacity_label),
            MONO_SMALL,
            DISK_CAPACITY_MIN,
            DISK_CAPACITY_MAX,
        ),
        bar: DISK_BAR_W,
        read: column_width(
            disks.iter().map(read_label),
            MONO_SMALL,
            DISK_RATE_MIN,
            DISK_RATE_MAX,
        ),
        write: column_width(
            disks.iter().map(write_label),
            MONO_SMALL,
            DISK_RATE_MIN,
            DISK_RATE_MAX,
        ),
        busy: column_width(
            std::iter::once("Busy".to_string()).chain(disks.iter().map(busy_label)),
            MONO_SMALL,
            DISK_BUSY_MIN,
            DISK_BUSY_MAX,
        ),
        await_ms: column_width(
            std::iter::once("Await".to_string()).chain(disks.iter().map(await_label)),
            MONO_SMALL,
            DISK_AWAIT_MIN,
            DISK_AWAIT_MAX,
        ),
    }
}

fn socket_cols(sockets: &[NetSocketEntry]) -> SocketCols {
    SocketCols {
        proto: column_width(
            std::iter::once("Proto").chain(sockets.iter().map(|s| s.proto.as_str())),
            MONO_SMALL,
            SOCK_PROTO_MIN,
            SOCK_PROTO_MAX,
        ),
        local: column_width(
            std::iter::once("Local").chain(sockets.iter().map(|s| s.local_addr.as_str())),
            MONO_SMALL,
            SOCK_ADDR_MIN,
            SOCK_ADDR_MAX,
        ),
        remote: column_width(
            std::iter::once("Remote").chain(sockets.iter().map(|s| s.remote_addr.as_str())),
            MONO_SMALL,
            SOCK_ADDR_MIN,
            SOCK_ADDR_MAX,
        ),
        state: column_width(
            std::iter::once("State").chain(sockets.iter().map(|s| s.state.as_str())),
            MONO_SMALL,
            SOCK_STATE_MIN,
            SOCK_STATE_MAX,
        ),
        process: column_width(
            std::iter::once("Process".to_string()).chain(sockets.iter().map(socket_process_label)),
            MONO_SMALL,
            SOCK_PROC_MIN,
            SOCK_PROC_MAX,
        ),
    }
}

fn iface_cols(ifaces: &[&NetInterfaceMetrics]) -> IfaceCols {
    IfaceCols {
        name: column_width(
            ifaces.iter().map(|iface| iface.name.as_str()),
            MONO,
            IFACE_NAME_MIN,
            IFACE_NAME_MAX,
        ),
        rx: column_width(
            ifaces
                .iter()
                .map(|iface| format!("RX {}", format_rate(iface.rx_bytes_per_sec))),
            MONO_SMALL,
            DISK_RATE_MIN,
            DISK_RATE_MAX,
        ),
        tx: column_width(
            ifaces
                .iter()
                .map(|iface| format!("TX {}", format_rate(iface.tx_bytes_per_sec))),
            MONO_SMALL,
            DISK_RATE_MIN,
            DISK_RATE_MAX,
        ),
        totals: column_width(
            ifaces.iter().map(|iface| totals_label(iface)),
            MONO_SMALL,
            IFACE_TOTAL_MIN,
            IFACE_TOTAL_MAX,
        ),
    }
}

fn battery_cols(batteries: &[BatteryMetrics]) -> BatteryCols {
    BatteryCols {
        pct: column_width(
            batteries
                .iter()
                .map(|battery| format!("{:.0}%", battery.capacity_pct)),
            MONO,
            BATTERY_PCT_MIN,
            BATTERY_PCT_MAX,
        ),
        watts: column_width(
            batteries.iter().map(watts_label),
            MONO_SMALL,
            BATTERY_WATTS_MIN,
            BATTERY_WATTS_MAX,
        ),
    }
}

fn capacity_label(disk: &DiskMetrics) -> String {
    format!(
        "{} / {}",
        format_bytes(disk.used_bytes),
        format_bytes(disk.total_bytes)
    )
}

fn read_label(disk: &DiskMetrics) -> String {
    format!("R: {}", format_rate(disk.read_bytes_per_sec))
}

fn write_label(disk: &DiskMetrics) -> String {
    format!("W: {}", format_rate(disk.write_bytes_per_sec))
}

fn busy_label(disk: &DiskMetrics) -> String {
    format!("{:.0}%", disk.busy_pct)
}

fn await_label(disk: &DiskMetrics) -> String {
    format!("{:.1} ms", disk.await_ms)
}

fn await_color(await_ms: f32, p: Palette) -> Color {
    if await_ms >= 20.0 {
        p.crit
    } else if await_ms >= 8.0 {
        p.warn
    } else {
        p.muted
    }
}

fn socket_process_label(sock: &NetSocketEntry) -> String {
    match (sock.process.is_empty(), sock.pid) {
        (false, Some(pid)) => format!("{}/{pid}", sock.process),
        (false, None) => sock.process.clone(),
        (true, Some(pid)) => format!("pid {pid}"),
        (true, None) => "—".to_string(),
    }
}

fn socket_state_color(state: &str, p: Palette) -> Color {
    match state {
        "LISTEN" => p.accent,
        "ESTAB" => p.ok,
        _ => p.muted,
    }
}

fn totals_label(iface: &NetInterfaceMetrics) -> String {
    format!(
        "{} / {}",
        format_bytes(iface.total_rx_bytes),
        format_bytes(iface.total_tx_bytes)
    )
}

fn watts_label(battery: &BatteryMetrics) -> String {
    match battery.power_watts {
        Some(watts) => format!("{watts:.1} W"),
        None => "—".to_string(),
    }
}

/// Fixed track. `min_w` and `max_w` match `w`, so content size cannot grow or shrink the cell.
fn fixed_cell(key: String, width: f32, child: El) -> El {
    el().key(key)
        .w(width)
        .min_w(width)
        .max_w(width)
        .items_center()
        .child(child)
}

fn mono_text(content: String, style: TextStyle, color: Color, align: Align) -> El {
    let line = text(content).font(style).color(color).truncate();
    if align == Align::Start {
        line.w_full()
    } else {
        line.align(align).w_full()
    }
}

fn iface_row(index: usize, iface: &NetInterfaceMetrics, cols: &IfaceCols, p: Palette) -> El {
    row()
        .w_full()
        .h(18.0)
        .gap(8.0)
        .items_center()
        .child(fixed_cell(
            format!("iface-name-{index}"),
            cols.name,
            mono_text(iface.name.clone(), MONO, p.text, Align::Start),
        ))
        .child(fixed_cell(
            format!("iface-rx-{index}"),
            cols.rx,
            mono_text(
                format!("RX {}", format_rate(iface.rx_bytes_per_sec)),
                MONO_SMALL,
                p.net_rx,
                Align::Start,
            ),
        ))
        .child(fixed_cell(
            format!("iface-tx-{index}"),
            cols.tx,
            mono_text(
                format!("TX {}", format_rate(iface.tx_bytes_per_sec)),
                MONO_SMALL,
                p.net_tx,
                Align::Start,
            ),
        ))
        .child(fixed_cell(
            format!("iface-total-{index}"),
            cols.totals,
            mono_text(totals_label(iface), MONO_SMALL, p.muted, Align::Start),
        ))
}

fn iface_row_compact(index: usize, iface: &NetInterfaceMetrics, p: Palette) -> El {
    row()
        .w_full()
        .h(18.0)
        .gap(6.0)
        .items_center()
        .child(
            el().key(format!("iface-name-{index}"))
                .grow(1.0)
                .min_w(44.0)
                .items_center()
                .child(mono_text(iface.name.clone(), MONO, p.text, Align::Start)),
        )
        .child(fixed_cell(
            format!("iface-rx-{index}"),
            88.0,
            mono_text(
                format!("RX {}", format_rate(iface.rx_bytes_per_sec)),
                MONO_SMALL,
                p.net_rx,
                Align::End,
            ),
        ))
        .child(fixed_cell(
            format!("iface-tx-{index}"),
            88.0,
            mono_text(
                format!("TX {}", format_rate(iface.tx_bytes_per_sec)),
                MONO_SMALL,
                p.net_tx,
                Align::End,
            ),
        ))
}

fn header_cell(width: f32, label: &str, align: Align, p: Palette) -> El {
    el().w(width)
        .min_w(width)
        .max_w(width)
        .items_center()
        .child(mono_text(label.to_string(), MONO_SMALL, p.subtle, align))
}

fn socket_header_row(cols: &SocketCols, p: Palette) -> El {
    row()
        .w_full()
        .h(16.0)
        .gap(8.0)
        .items_center()
        .child(header_cell(cols.proto, "Proto", Align::Start, p))
        .child(header_cell(cols.local, "Local", Align::Start, p))
        .child(header_cell(cols.remote, "Remote", Align::Start, p))
        .child(header_cell(cols.state, "State", Align::Start, p))
        .child(header_cell(cols.process, "Process", Align::Start, p))
}

fn socket_row(index: usize, sock: &NetSocketEntry, cols: &SocketCols, p: Palette) -> El {
    press_socket(
        row().key(format!("sock-row-{index}")),
        sock,
    )
        .w_full()
        .h(18.0)
        .gap(8.0)
        .items_center()
        .child(fixed_cell(
            format!("sock-proto-{index}"),
            cols.proto,
            mono_text(sock.proto.clone(), MONO_SMALL, p.accent, Align::Start),
        ))
        .child(fixed_cell(
            format!("sock-local-{index}"),
            cols.local,
            mono_text(sock.local_addr.clone(), MONO_SMALL, p.text, Align::Start),
        ))
        .child(fixed_cell(
            format!("sock-remote-{index}"),
            cols.remote,
            mono_text(sock.remote_addr.clone(), MONO_SMALL, p.muted, Align::Start),
        ))
        .child(fixed_cell(
            format!("sock-state-{index}"),
            cols.state,
            mono_text(
                sock.state.clone(),
                MONO_SMALL,
                socket_state_color(&sock.state, p),
                Align::Start,
            ),
        ))
        .child(fixed_cell(
            format!("sock-proc-{index}"),
            cols.process,
            mono_text(socket_process_label(sock), MONO_SMALL, p.text, Align::Start),
        ))
}

fn socket_header_row_compact(p: Palette) -> El {
    row()
        .w_full()
        .h(16.0)
        .gap(6.0)
        .items_center()
        .child(header_cell(38.0, "Proto", Align::Start, p))
        .child(el().grow(1.0).min_w(64.0).items_center().child(mono_text(
            "Local".to_string(),
            MONO_SMALL,
            p.subtle,
            Align::Start,
        )))
        .child(header_cell(52.0, "State", Align::Start, p))
        .child(header_cell(76.0, "Process", Align::End, p))
}

fn press_socket(row: El, sock: &NetSocketEntry) -> El {
    match sock.pid {
        Some(pid) => row.cursor(Cursor::Pointer).on_press(move |state: &mut State| {
            state.select_pid(pid);
        }),
        None => row,
    }
}

fn socket_row_compact(index: usize, sock: &NetSocketEntry, p: Palette) -> El {
    press_socket(row().key(format!("sock-row-{index}")), sock)
        .w_full()
        .h(18.0)
        .gap(6.0)
        .items_center()
        .child(fixed_cell(
            format!("sock-proto-{index}"),
            38.0,
            mono_text(sock.proto.clone(), MONO_SMALL, p.accent, Align::Start),
        ))
        .child(
            el().key(format!("sock-local-{index}"))
                .grow(1.0)
                .min_w(64.0)
                .items_center()
                .child(mono_text(
                    sock.local_addr.clone(),
                    MONO_SMALL,
                    p.text,
                    Align::Start,
                )),
        )
        .child(fixed_cell(
            format!("sock-state-{index}"),
            52.0,
            mono_text(
                sock.state.clone(),
                MONO_SMALL,
                socket_state_color(&sock.state, p),
                Align::Start,
            ),
        ))
        .child(fixed_cell(
            format!("sock-proc-{index}"),
            76.0,
            mono_text(socket_process_label(sock), MONO_SMALL, p.text, Align::End),
        ))
}

fn disk_header_row(cols: &DiskCols, p: Palette) -> El {
    row()
        .w_full()
        .h(16.0)
        .gap(8.0)
        .items_center()
        .child(header_cell(cols.mount, "Mount", Align::Start, p))
        .child(header_cell(cols.device, "Device", Align::Start, p))
        .child(header_cell(cols.capacity, "Used", Align::End, p))
        .child(header_cell(cols.bar, "", Align::Start, p))
        .child(header_cell(cols.read, "Read", Align::Start, p))
        .child(header_cell(cols.write, "Write", Align::Start, p))
        .child(header_cell(cols.busy, "Busy", Align::End, p))
        .child(header_cell(cols.await_ms, "Await", Align::End, p))
}

fn disk_row(index: usize, disk: &DiskMetrics, cols: &DiskCols, p: Palette) -> El {
    row()
        .w_full()
        .min_h(18.0)
        .gap(8.0)
        .items_center()
        .child(fixed_cell(
            format!("disk-mount-{index}"),
            cols.mount,
            mono_text(disk.mount_point.clone(), MONO, p.text, Align::Start),
        ))
        .child(fixed_cell(
            format!("disk-dev-{index}"),
            cols.device,
            mono_text(disk.device.clone(), MONO_SMALL, p.muted, Align::Start),
        ))
        .child(fixed_cell(
            format!("disk-cap-{index}"),
            cols.capacity,
            mono_text(capacity_label(disk), MONO_SMALL, p.text, Align::End),
        ))
        .child(fixed_cell(
            format!("disk-bar-{index}"),
            cols.bar,
            canvas(meter_bar_shape(
                disk.used_pct,
                p.panel_alt,
                p.usage_color(disk.used_pct),
                cols.bar,
                6.0,
            ))
            .size(cols.bar, 6.0)
            .radius(3.0),
        ))
        .child(fixed_cell(
            format!("disk-read-{index}"),
            cols.read,
            mono_text(read_label(disk), MONO_SMALL, p.disk_read, Align::Start),
        ))
        .child(fixed_cell(
            format!("disk-write-{index}"),
            cols.write,
            mono_text(write_label(disk), MONO_SMALL, p.disk_write, Align::Start),
        ))
        .child(fixed_cell(
            format!("disk-busy-{index}"),
            cols.busy,
            mono_text(
                busy_label(disk),
                MONO_SMALL,
                p.usage_color(disk.busy_pct),
                Align::End,
            ),
        ))
        .child(fixed_cell(
            format!("disk-await-{index}"),
            cols.await_ms,
            mono_text(
                await_label(disk),
                MONO_SMALL,
                await_color(disk.await_ms, p),
                Align::End,
            ),
        ))
}

fn disk_header_row_compact(p: Palette) -> El {
    row()
        .w_full()
        .h(16.0)
        .gap(6.0)
        .items_center()
        .child(el().grow(1.0).min_w(52.0).items_center().child(mono_text(
            "Mount".to_string(),
            MONO_SMALL,
            p.subtle,
            Align::Start,
        )))
        .child(header_cell(124.0, "Used", Align::End, p))
        .child(header_cell(44.0, "", Align::Start, p))
        .child(header_cell(38.0, "Busy", Align::End, p))
}

fn disk_row_compact(index: usize, disk: &DiskMetrics, p: Palette) -> El {
    row()
        .w_full()
        .min_h(18.0)
        .gap(6.0)
        .items_center()
        .child(
            el().key(format!("disk-mount-{index}"))
                .grow(1.0)
                .min_w(52.0)
                .items_center()
                .child(mono_text(
                    disk.mount_point.clone(),
                    MONO,
                    p.text,
                    Align::Start,
                )),
        )
        .child(fixed_cell(
            format!("disk-cap-{index}"),
            124.0,
            mono_text(capacity_label(disk), MONO_SMALL, p.text, Align::End),
        ))
        .child(fixed_cell(
            format!("disk-bar-{index}"),
            44.0,
            canvas(meter_bar_shape(
                disk.used_pct,
                p.panel_alt,
                p.usage_color(disk.used_pct),
                44.0,
                6.0,
            ))
            .size(44.0, 6.0)
            .radius(3.0),
        ))
        .child(fixed_cell(
            format!("disk-busy-{index}"),
            38.0,
            mono_text(
                busy_label(disk),
                MONO_SMALL,
                p.usage_color(disk.busy_pct),
                Align::End,
            ),
        ))
}

fn sensor_row(sensor: &SensorMetrics, p: Palette) -> El {
    row()
        .w_full()
        .h(18.0)
        .gap(8.0)
        .items_center()
        .child(
            text(sensor.label.clone())
                .font(LABEL)
                .color(p.muted)
                .truncate()
                .grow(1.0),
        )
        .child(
            text(format!("{:.0}°C", sensor.temp_c))
                .font(MONO)
                .color(p.temp_color(sensor.temp_c))
                .align(Align::End),
        )
}

fn battery_row(index: usize, battery: &BatteryMetrics, cols: &BatteryCols, p: Palette) -> El {
    row()
        .w_full()
        .h(18.0)
        .gap(8.0)
        .items_center()
        .child(
            text(battery.name.clone())
                .font(MONO)
                .color(p.text)
                .truncate()
                .max_w(160.0),
        )
        .child(
            text(battery.status.clone())
                .font(LABEL)
                .color(p.muted)
                .truncate()
                .grow(1.0),
        )
        .child(fixed_cell(
            format!("bat-pct-{index}"),
            cols.pct,
            mono_text(
                format!("{:.0}%", battery.capacity_pct),
                MONO,
                charge_color(battery.capacity_pct, p),
                Align::End,
            ),
        ))
        .child(fixed_cell(
            format!("bat-watts-{index}"),
            cols.watts,
            mono_text(watts_label(battery), MONO_SMALL, p.subtle, Align::End),
        ))
}

fn charge_color(capacity_pct: f32, p: Palette) -> Color {
    if capacity_pct < 15.0 {
        p.crit
    } else if capacity_pct < 30.0 {
        p.warn
    } else {
        p.ok
    }
}

fn empty_process(p: Palette) -> El {
    col()
        .w_full()
        .h_full()
        .center()
        .gap(6.0)
        .padding(16.0)
        .child(
            text("Select a process")
                .font(PANEL_TITLE)
                .color(p.text)
                .align(Align::Center),
        )
        .child(
            text("Identity, memory, and I/O appear here.")
                .font(LABEL)
                .color(p.muted)
                .align(Align::Center)
                .wrap()
                .w_full(),
        )
}

fn inspector_chip(
    key: &str,
    label: &str,
    active: bool,
    p: Palette,
    on_press: impl Fn(&mut State, &mut Tx) + 'static,
) -> El {
    let ink = if active { p.accent } else { p.text };
    let fill = if active {
        p.accent.alpha(0.18)
    } else {
        p.panel_alt
    };
    row()
        .key(key)
        .h(22.0)
        .px(7.0)
        .items_center()
        .radius(4.0)
        .fill(fill)
        .cursor(Cursor::Pointer)
        .transition(Transition::none())
        .on_press_tx(on_press)
        .child(text(label).font(LABEL).color(ink))
}

fn process_body(
    proc: &ProcessInfo,
    proc_history: &SelectedProcessHistory,
    pinned: bool,
    sample_count: usize,
    p: Palette,
) -> El {
    let command = if proc.cmdline.is_empty() {
        "No command line".to_string()
    } else {
        proc.cmdline.clone()
    };
    let fds = match proc.fds {
        Some(count) => count.to_string(),
        None => "—".to_string(),
    };
    let ports_text = if proc.listening_ports.is_empty() {
        "none".to_string()
    } else {
        proc.listening_ports.join(", ")
    };
    let cpu_samples = if proc_history.pid == Some(proc.pid) && !proc_history.cpu_pct.is_empty() {
        proc_history.cpu_pct.tail(sample_count)
    } else {
        vec![proc.cpu_pct]
    };
    let mem_samples = if proc_history.pid == Some(proc.pid) && !proc_history.mem_pct.is_empty() {
        proc_history.mem_pct.tail(sample_count)
    } else {
        vec![proc.mem_pct]
    };
    let actions = row()
        .w_full()
        .flex_wrap()
        .gap(5.0)
        .items_center()
        .child(inspector_chip(
            "btn-pin-proc",
            if pinned { "Pinned ★ [P]" } else { "Pin [P]" },
            pinned,
            p,
            |state: &mut State, tx: &mut Tx| {
                tx.instant();
                state.toggle_pin_selected();
            },
        ))
        .child(inspector_chip(
            "btn-renice-dec",
            "Nice -",
            false,
            p,
            |state: &mut State, tx: &mut Tx| {
                tx.instant();
                state.renice_selected(-1);
            },
        ))
        .child(inspector_chip(
            "btn-renice-inc",
            "Nice +",
            false,
            p,
            |state: &mut State, tx: &mut Tx| {
                tx.instant();
                state.renice_selected(1);
            },
        ))
        .child(inspector_chip(
            "btn-copy-cmd",
            "Copy Cmd",
            false,
            p,
            |state: &mut State, tx: &mut Tx| {
                tx.instant();
                state.copy_selected_command();
                if let Some(cmd) = &state.copied_command {
                    tx.copy(cmd.clone());
                }
            },
        ));
    let sparklines = row()
        .w_full()
        .gap(8.0)
        .items_center()
        .child(
            col()
                .grow(1.0)
                .min_w(0.0)
                .gap(2.0)
                .child(
                    text(format!("CPU {:.1}%", proc.cpu_pct))
                        .font(LABEL)
                        .color(p.subtle),
                )
                .child(
                    canvas(sparkline_chart(
                        &cpu_samples,
                        p.cpu_total,
                        p.border,
                        140.0,
                        28.0,
                    ))
                    .key("proc-cpu-spark")
                    .w_full()
                    .h(28.0)
                    .fill(p.base)
                    .radius(4.0),
                ),
        )
        .child(
            col()
                .grow(1.0)
                .min_w(0.0)
                .gap(2.0)
                .child(
                    text(format!("Mem {:.1}%", proc.mem_pct))
                        .font(LABEL)
                        .color(p.subtle),
                )
                .child(
                    canvas(sparkline_chart(
                        &mem_samples,
                        p.mem_used,
                        p.border,
                        140.0,
                        28.0,
                    ))
                    .key("proc-mem-spark")
                    .w_full()
                    .h(28.0)
                    .fill(p.base)
                    .radius(4.0),
                ),
        );
    col()
        .w_full()
        .h_full()
        .min_h(0.0)
        .padding(8.0)
        .gap(5.0)
        .child(actions)
        .child(sparklines)
        .child(
            col()
                .w_full()
                .grow(1.0)
                .min_h(24.0)
                .scroll(SCROLL)
                .gap(5.0)
                .child(spec_pair(
                    ("PID", proc.pid.to_string(), p.text),
                    ("PPID", proc.ppid.to_string(), p.text),
                    p,
                ))
                .child(spec_pair(
                    ("Name", proc.name.clone(), p.text),
                    ("State", state_text(proc.state), state_color(proc.state, p)),
                    p,
                ))
                .child(spec_pair(
                    ("User", proc.user.clone(), p.text),
                    (
                        "Nice",
                        proc.nice.to_string(),
                        if proc.nice < 0 { p.accent } else { p.text },
                    ),
                    p,
                ))
                .child(spec_pair(
                    ("Threads", proc.threads.to_string(), p.text),
                    ("FDs", fds, p.text),
                    p,
                ))
                .child(spec_pair(
                    (
                        "CPU",
                        format!("{:.1}%", proc.cpu_pct),
                        p.usage_color(proc.cpu_pct),
                    ),
                    (
                        "Memory",
                        format!("{}  {:.1}%", format_bytes(proc.mem_bytes), proc.mem_pct),
                        p.text,
                    ),
                    p,
                ))
                .child(spec_full(
                    "Disk I/O",
                    format!(
                        "R {}   W {}",
                        format_rate(proc.read_bytes_per_sec),
                        format_rate(proc.write_bytes_per_sec)
                    ),
                    p.text,
                    p,
                ))
                .child(spec_pair(
                    (
                        "Unit",
                        proc.unit.as_deref().unwrap_or("—").to_string(),
                        p.text,
                    ),
                    (
                        "Ports",
                        ports_text,
                        if proc.listening_ports.is_empty() {
                            p.muted
                        } else {
                            p.accent
                        },
                    ),
                    p,
                ))
                .child(spec_full(
                    "CWD",
                    proc.cwd.as_deref().unwrap_or("—").to_string(),
                    p.text,
                    p,
                ))
                .child(spec_full(
                    "Exe",
                    proc.exe.as_deref().unwrap_or("—").to_string(),
                    p.text,
                    p,
                ))
                .child(
                    col()
                        .key("proc-open-files")
                        .w_full()
                        .gap(2.0)
                        .min_w(0.0)
                        .child(text("Open Files").font(LABEL).color(p.subtle))
                        .children(if proc.open_files.is_empty() {
                            vec![text("none").font(MONO_SMALL).color(p.muted)]
                        } else {
                            proc.open_files
                                .iter()
                                .take(8)
                                .map(|entry| {
                                    text(entry.clone())
                                        .font(MONO_SMALL)
                                        .color(p.text)
                                        .truncate()
                                        .w_full()
                                })
                                .chain((proc.open_files.len() > 8).then(|| {
                                    text(format!("+{} more", proc.open_files.len() - 8))
                                        .font(MONO_SMALL)
                                        .color(p.muted)
                                }))
                                .collect::<Vec<_>>()
                        }),
                ),
        )
        .child(
            col()
                .w_full()
                .shrink()
                .min_h(32.0)
                .max_h(72.0)
                .gap(4.0)
                .child(section("Command", p))
                .child(
                    scroll_list(
                        "process-command",
                        vec![
                            text(command)
                                .font(MONO_SMALL)
                                .color(p.text)
                                .wrap_anywhere()
                                .w_full()
                                .cursor(Cursor::Text),
                        ],
                    )
                    .w_full()
                    .grow(1.0)
                    .min_h(14.0),
                ),
        )
}

fn spec_pair(left: (&str, String, Color), right: (&str, String, Color), p: Palette) -> El {
    row()
        .w_full()
        .gap(12.0)
        .child(spec_cell(left.0, left.1, left.2, p).grow(1.0).min_w(0.0))
        .child(spec_cell(right.0, right.1, right.2, p).grow(1.0).min_w(0.0))
}

fn spec_full(label: &str, value: String, color: Color, p: Palette) -> El {
    spec_cell(label, value, color, p).w_full()
}

fn spec_cell(label: &str, value: String, color: Color, p: Palette) -> El {
    col()
        .gap(1.0)
        .min_w(0.0)
        .child(text(label).font(LABEL).color(p.subtle))
        .child(text(value).font(MONO).color(color).truncate())
}

fn state_text(state: char) -> String {
    let word = match state {
        'R' => "running",
        'S' => "sleeping",
        'D' => "disk sleep",
        'Z' => "zombie",
        'T' | 't' => "stopped",
        'I' => "idle",
        'X' | 'x' => "dead",
        _ => "other",
    };
    format!("{state} {word}")
}

fn state_color(state: char, p: Palette) -> Color {
    match state {
        'R' => p.ok,
        'Z' | 'X' | 'x' => p.crit,
        'D' | 'T' | 't' => p.warn,
        _ => p.text,
    }
}

fn section(title: &str, p: Palette) -> El {
    text(title).font(LABEL).color(p.subtle)
}

fn quiet(message: &str, p: Palette) -> El {
    text(message).font(LABEL).color(p.subtle)
}

fn minor(content: impl Into<String>, color: Color) -> El {
    text(content).font(MONO_SMALL).color(color)
}

fn named(value: &str) -> &str {
    if value.is_empty() { "—" } else { value }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::fixture::fixture_history;
    use crate::theme::palette;
    use rune::{Cx, Env, Runtime};

    #[derive(Clone, Copy)]
    enum Panel {
        Cpu,
        Memory,
        Network,
        Disks,
        Process,
    }

    struct Screen {
        snap: SystemSnapshot,
        history: TelemetryHistory,
        dark: bool,
        zoomed: bool,
        focused: bool,
        per_core: bool,
        show_loopback: bool,
        sample_count: usize,
        panel: Panel,
        proc_index: Option<usize>,
    }

    fn view(screen: &Screen, _: &mut Cx<Screen>) -> El {
        let p = palette(screen.dark);
        match screen.panel {
            Panel::Cpu => cpu_panel(
                &screen.snap,
                &screen.history,
                screen.sample_count,
                screen.per_core,
                screen.zoomed,
                screen.focused,
                p,
            ),
            Panel::Memory => memory_panel(
                &screen.snap,
                &screen.history,
                screen.sample_count,
                screen.zoomed,
                screen.focused,
                p,
            ),
            Panel::Network => network_panel(
                &screen.snap,
                &screen.history,
                screen.sample_count,
                screen.show_loopback,
                screen.zoomed,
                screen.focused,
                p,
            ),
            Panel::Disks => disks_sensors_panel(
                &screen.snap,
                &screen.history,
                screen.sample_count,
                screen.zoomed,
                screen.focused,
                p,
            ),
            Panel::Process => process_inspector_card(
                screen
                    .proc_index
                    .and_then(|index| screen.snap.processes.get(index)),
                p,
            ),
        }
    }

    struct Probe {
        dark: bool,
        zoomed: bool,
        panel: Panel,
        per_core: bool,
        show_loopback: bool,
        proc_index: Option<usize>,
    }

    fn show(
        rt: &mut Runtime<Screen>,
        snap: &SystemSnapshot,
        history: &TelemetryHistory,
        probe: Probe,
    ) {
        let snap = snap.clone();
        let history = history.clone();
        rt.update(move |screen, _| {
            screen.snap = snap;
            screen.history = history;
            screen.dark = probe.dark;
            screen.zoomed = probe.zoomed;
            screen.focused = probe.zoomed;
            screen.per_core = probe.per_core;
            screen.show_loopback = probe.show_loopback;
            screen.sample_count = 60;
            screen.panel = probe.panel;
            screen.proc_index = probe.proc_index;
        });
        rt.frame(0.0);
    }

    fn texts(rt: &Runtime<Screen>) -> Vec<String> {
        rt.elements()
            .into_iter()
            .filter_map(|element| element.text)
            .collect()
    }

    fn assert_laid_out(rt: &Runtime<Screen>, key: &str, ctx: &str) {
        assert!(rt.find(key).is_some(), "{ctx}: missing {key}");
        let (rect, _) = rt.presented(key).expect(key);
        assert!(
            rect[2] > 1.0 && rect[3] > 1.0,
            "{ctx}: {key} collapsed to {rect:?}"
        );
    }

    fn assert_has(lines: &[String], needle: &str, ctx: &str) {
        assert!(
            lines.iter().any(|line| line.contains(needle)),
            "{ctx}: missing {needle:?} in {lines:?}"
        );
    }

    fn probe(dark: bool, zoomed: bool, panel: Panel) -> Probe {
        Probe {
            dark,
            zoomed,
            panel,
            per_core: true,
            show_loopback: true,
            proc_index: None,
        }
    }

    #[test]
    fn panels_build_for_both_themes_histories_and_zoom() {
        let empty = (SystemSnapshot::default(), TelemetryHistory::default());
        let fixture = fixture_history(60);
        let histories = [
            ("empty", &empty.0, &empty.1),
            ("fixture", &fixture.0, &fixture.1),
        ];
        let mut rt = Runtime::new(
            Screen {
                snap: SystemSnapshot::default(),
                history: TelemetryHistory::default(),
                dark: true,
                zoomed: false,
                focused: false,
                per_core: true,
                show_loopback: true,
                sample_count: 60,
                panel: Panel::Cpu,
                proc_index: None,
            },
            view,
            (1280.0, 900.0),
            Env::new(true, 1.0),
        );

        for (label, snap, history) in histories {
            for dark in [true, false] {
                for zoomed in [false, true] {
                    let ctx = format!("{label} dark={dark} zoom={zoomed}");
                    show(&mut rt, snap, history, probe(dark, zoomed, Panel::Cpu));
                    assert_laid_out(&rt, "cpu-panel", &ctx);
                    assert_laid_out(&rt, "cpu-chart", &ctx);
                    assert_laid_out(&rt, "cpu-cores", &ctx);
                    let cpu_text = texts(&rt);
                    assert_has(&cpu_text, "Load ", &ctx);
                    assert_has(&cpu_text, "user ", &ctx);
                    assert_has(&cpu_text, "sys ", &ctx);
                    assert_has(&cpu_text, "iowait ", &ctx);
                    assert_has(&cpu_text, "PSI ", &ctx);
                    assert_has(&cpu_text, "Up ", &ctx);
                    assert_has(&cpu_text, "Tasks ", &ctx);
                    if label == "fixture" {
                        assert_has(&cpu_text, "AMD Ryzen 7 7840U", &ctx);
                        assert_has(&cpu_text, "C0", &ctx);
                    } else {
                        assert_has(&cpu_text, "No cores reporting", &ctx);
                    }

                    show(
                        &mut rt,
                        snap,
                        history,
                        Probe {
                            per_core: false,
                            ..probe(dark, zoomed, Panel::Cpu)
                        },
                    );
                    assert_laid_out(&rt, "cpu-chart", &format!("{ctx} total-series"));

                    show(&mut rt, snap, history, probe(dark, zoomed, Panel::Memory));
                    assert_laid_out(&rt, "memory-panel", &ctx);
                    assert_laid_out(&rt, "memory-chart", &ctx);
                    assert_laid_out(&rt, "mem-chart", &ctx);
                    let mem_text = texts(&rt);
                    assert_has(&mem_text, "RAM ", &ctx);
                    assert_has(&mem_text, "Swap ", &ctx);
                    assert_has(&mem_text, "Available ", &ctx);
                    assert_has(&mem_text, "Cached ", &ctx);
                    assert_has(&mem_text, "Buffers ", &ctx);
                    assert_has(&mem_text, "Shared ", &ctx);
                    assert_has(&mem_text, "Dirty ", &ctx);
                    assert_has(&mem_text, "Slab ", &ctx);
                    assert_has(&mem_text, "PSI ", &ctx);

                    for show_loopback in [true, false] {
                        show(
                            &mut rt,
                            snap,
                            history,
                            Probe {
                                show_loopback,
                                ..probe(dark, zoomed, Panel::Network)
                            },
                        );
                        let net_ctx = format!("{ctx} loopback={show_loopback}");
                        assert_laid_out(&rt, "network-panel", &net_ctx);
                        assert_laid_out(&rt, "network-chart", &net_ctx);
                        assert_laid_out(&rt, "net-chart", &net_ctx);
                        assert_laid_out(&rt, "network-ifaces", &net_ctx);
                        let net_text = texts(&rt);
                        assert_has(&net_text, "RX ", &net_ctx);
                        assert_has(&net_text, "TX ", &net_ctx);
                        assert_has(&net_text, "Peak ", &net_ctx);
                        assert_has(&net_text, "Sockets", &net_ctx);
                        if label == "fixture" {
                            assert_has(&net_text, "LISTEN", &net_ctx);
                            assert_has(&net_text, "postgres", &net_ctx);
                        } else {
                            assert_has(&net_text, "No active sockets", &net_ctx);
                        }
                        let has_lo = net_text.iter().any(|line| line == "lo");
                        if label == "fixture" && show_loopback {
                            assert!(has_lo, "{net_ctx}: loopback hidden");
                            assert_has(&net_text, "eth0", &net_ctx);
                        } else {
                            assert!(!has_lo, "{net_ctx}: loopback shown");
                        }
                    }

                    show(&mut rt, snap, history, probe(dark, zoomed, Panel::Disks));
                    assert_laid_out(&rt, "disks-panel", &ctx);
                    assert_laid_out(&rt, "disk-mounts", &ctx);
                    let disk_text = texts(&rt);
                    assert_has(&disk_text, "IO PSI ", &ctx);
                    if zoomed {
                        assert_laid_out(&rt, "disk-io-chart", &ctx);
                        assert_has(&disk_text, "Peak ", &ctx);
                    } else {
                        assert!(
                            rt.find("disk-io-chart").is_none(),
                            "{ctx}: disk chart while compact"
                        );
                    }
                    if label == "fixture" {
                        assert!(disk_text.iter().any(|line| line == "/"), "{ctx}: missing /");
                        assert_has(&disk_text, "nvme0n1p2", &ctx);
                        assert_has(&disk_text, "R: ", &ctx);
                        assert_has(&disk_text, "W: ", &ctx);
                        assert_has(&disk_text, "Busy", &ctx);
                        assert_has(&disk_text, "Await", &ctx);
                        assert_has(&disk_text, " ms", &ctx);
                        assert_has(&disk_text, "Package id 0", &ctx);
                        assert_has(&disk_text, "°C", &ctx);
                        assert_has(&disk_text, "BAT0", &ctx);
                        assert_has(&disk_text, "Discharging", &ctx);
                    } else {
                        assert_has(&disk_text, "No mounts", &ctx);
                        assert_has(&disk_text, "No sensors", &ctx);
                        assert_has(&disk_text, "No battery", &ctx);
                    }

                    show(&mut rt, snap, history, probe(dark, zoomed, Panel::Process));
                    assert_laid_out(&rt, "process-inspector", &ctx);
                    assert_has(&texts(&rt), "Select a process", &ctx);
                    assert!(
                        rt.find("process-command").is_none(),
                        "{ctx}: command without a process"
                    );

                    if label == "fixture" {
                        let systemd = snap
                            .processes
                            .iter()
                            .position(|proc| proc.name == "systemd")
                            .expect("systemd");
                        show(
                            &mut rt,
                            snap,
                            history,
                            Probe {
                                proc_index: Some(systemd),
                                ..probe(dark, zoomed, Panel::Process)
                            },
                        );
                        assert_laid_out(&rt, "process-inspector", &ctx);
                        assert_laid_out(&rt, "process-command", &ctx);
                        assert_laid_out(&rt, "proc-cpu-spark", &ctx);
                        assert_laid_out(&rt, "proc-mem-spark", &ctx);
                        assert_laid_out(&rt, "btn-pin-proc", &ctx);
                        assert_laid_out(&rt, "btn-renice-dec", &ctx);
                        assert_laid_out(&rt, "btn-renice-inc", &ctx);
                        assert_laid_out(&rt, "btn-copy-cmd", &ctx);
                        let proc_text = texts(&rt);
                        assert_has(&proc_text, "systemd", &ctx);
                        assert_has(&proc_text, "sleeping", &ctx);
                        assert_has(&proc_text, "/usr/bin/systemd", &ctx);
                        assert_has(&proc_text, "Disk I/O", &ctx);
                        assert_has(&proc_text, "Nice", &ctx);
                        assert_has(&proc_text, "Unit", &ctx);
                        assert_has(&proc_text, "init.scope", &ctx);
                        assert_has(&proc_text, "CWD", &ctx);
                        assert_has(&proc_text, "Exe", &ctx);
                        assert_has(&proc_text, "Ports", &ctx);
                        assert_has(&proc_text, "none", &ctx);

                        let kernel = snap
                            .processes
                            .iter()
                            .position(|proc| proc.name == "kthreadd")
                            .expect("kthreadd");
                        show(
                            &mut rt,
                            snap,
                            history,
                            Probe {
                                proc_index: Some(kernel),
                                ..probe(dark, zoomed, Panel::Process)
                            },
                        );
                        let kernel_text = texts(&rt);
                        assert_has(&kernel_text, "kthreadd", &ctx);
                        assert_has(&kernel_text, "No command line", &ctx);
                        assert_has(&kernel_text, "—", &ctx);
                    }
                }
            }
        }
    }

    fn gib(value: f64) -> u64 {
        (value * 1024.0 * 1024.0 * 1024.0).round() as u64
    }

    fn mib(value: f64) -> u64 {
        (value * 1024.0 * 1024.0).round() as u64
    }

    fn sample_disk(
        mount: &str,
        device: &str,
        used: u64,
        total: u64,
        read: f64,
        write: f64,
    ) -> DiskMetrics {
        let used_pct = if total == 0 {
            0.0
        } else {
            used as f32 / total as f32 * 100.0
        };
        DiskMetrics {
            device: device.to_string(),
            mount_point: mount.to_string(),
            fs_type: "ext4".to_string(),
            total_bytes: total,
            used_bytes: used,
            free_bytes: total.saturating_sub(used),
            used_pct,
            read_bytes_per_sec: read,
            write_bytes_per_sec: write,
            ..DiskMetrics::default()
        }
    }

    fn screenshot_disks() -> Vec<DiskMetrics> {
        let root_used = gib(514.5);
        let root_total = gib(1023.5);
        let write = 96.0 * 1024.0;
        vec![
            sample_disk("/", "sda2", root_used, root_total, 0.0, write),
            sample_disk("/nix", "sda2", root_used, root_total, 0.0, write),
            sample_disk("/nix/store", "sda2", root_used, root_total, 0.0, write),
            sample_disk("/.snapshots", "sda2", root_used, root_total, 0.0, write),
            sample_disk("/home/aragao", "sda2", root_used, root_total, 0.0, write),
            sample_disk("/boot", "sda1", mib(88.7), mib(511.0), 0.0, 0.0),
            sample_disk("/swap", "nvme0n1p2", root_used, root_total, 0.0, write),
            sample_disk(
                "/tmp",
                "sda2",
                root_used,
                root_total,
                12.0 * 1024.0 * 1024.0,
                write,
            ),
        ]
    }

    fn jagged_disks() -> Vec<DiskMetrics> {
        let mut disks = screenshot_disks();
        disks.push(sample_disk(
            "/var/lib/containers/storage/overlay/very-long-mount",
            "mapper/very-long-device-name",
            mib(1.0),
            mib(2.0),
            1024.0 * 1024.0 * 1024.0,
            3.0 * 1024.0 * 1024.0 * 1024.0,
        ));
        disks
    }

    #[test]
    fn disk_column_widths_follow_the_widest_cell_inside_the_clamps() {
        let tiny = disk_cols(&[sample_disk("/", "sda2", gib(1.0), gib(2.0), 0.0, 0.0)]);
        assert_eq!(tiny.mount, DISK_MOUNT_MIN);
        assert_eq!(tiny.device, DISK_DEVICE_MIN);
        assert!(tiny.capacity >= DISK_CAPACITY_MIN);
        assert_eq!(tiny.bar, DISK_BAR_W);
        assert!(tiny.read >= DISK_RATE_MIN && tiny.write >= DISK_RATE_MIN);
        assert!((DISK_BUSY_MIN..=DISK_BUSY_MAX).contains(&tiny.busy));
        assert!((DISK_AWAIT_MIN..=DISK_AWAIT_MAX).contains(&tiny.await_ms));

        let shown = disk_cols(&screenshot_disks());
        assert!((DISK_MOUNT_MIN..=DISK_MOUNT_MAX).contains(&shown.mount));
        assert!((DISK_DEVICE_MIN..=DISK_DEVICE_MAX).contains(&shown.device));
        assert!(shown.capacity >= DISK_CAPACITY_MIN);
        assert_eq!(shown.bar, DISK_BAR_W);
        for mount in ["/", "/.snapshots", "/home/aragao", "/nix/store"] {
            let width = rune::text::measure(mount, &[], MONO, None).0;
            assert!(
                shown.mount + 0.01 >= width,
                "{mount} measures {width}, column is {}",
                shown.mount
            );
        }
        let device = rune::text::measure("nvme0n1p2", &[], MONO_SMALL, None).0;
        assert!(
            shown.device + 0.01 >= device,
            "nvme0n1p2 measures {device}, column is {}",
            shown.device
        );

        let jagged = disk_cols(&jagged_disks());
        assert_eq!(jagged.mount, DISK_MOUNT_MAX);
        assert_eq!(jagged.device, DISK_DEVICE_MAX);
        assert!(jagged.read <= DISK_RATE_MAX && jagged.write <= DISK_RATE_MAX);
        assert!(jagged.capacity <= DISK_CAPACITY_MAX);
    }

    fn column_rects(rt: &Runtime<Screen>, prefix: &str, count: usize) -> Vec<[f32; 4]> {
        (0..count)
            .map(|index| {
                let key = format!("{prefix}-{index}");
                let (rect, _) = rt
                    .presented(&key)
                    .unwrap_or_else(|| panic!("missing {key}"));
                rect
            })
            .collect()
    }

    fn assert_shared_column(rects: &[[f32; 4]], label: &str) {
        let first = rects[0];
        assert!(first[2] > 1.0, "{label} collapsed to {first:?}");
        for rect in rects.iter().skip(1) {
            assert!(
                (rect[0] - first[0]).abs() < 0.5 && (rect[2] - first[2]).abs() < 0.5,
                "{label} drifted: {first:?} vs {rect:?}"
            );
        }
    }

    fn assert_follows(left: [f32; 4], right: [f32; 4], gap: f32, label: &str) {
        let delta = right[0] - (left[0] + left[2]);
        assert!(
            (delta - gap).abs() < 0.75,
            "{label} gap {delta} != {gap} ({left:?} -> {right:?})"
        );
    }

    fn open(panel: Panel, snap: SystemSnapshot) -> Runtime<Screen> {
        let mut rt = Runtime::new(
            Screen {
                snap,
                history: TelemetryHistory::default(),
                dark: true,
                zoomed: false,
                focused: false,
                per_core: true,
                show_loopback: true,
                sample_count: 60,
                panel,
                proc_index: None,
            },
            view,
            (1280.0, 900.0),
            Env::new(true, 1.0),
        );
        rt.frame(0.0);
        rt.frame(0.0);
        rt
    }

    #[test]
    fn mount_rate_and_battery_columns_share_one_width() {
        let snap = SystemSnapshot {
            disks: jagged_disks(),
            networks: vec![
                NetInterfaceMetrics {
                    name: "lo".to_string(),
                    is_loopback: true,
                    rx_bytes_per_sec: 1_200.0,
                    tx_bytes_per_sec: 1_200.0,
                    total_rx_bytes: 50_000_000,
                    total_tx_bytes: 50_000_000,
                    ..NetInterfaceMetrics::default()
                },
                NetInterfaceMetrics {
                    name: "eth0".to_string(),
                    is_loopback: false,
                    rx_bytes_per_sec: 80_000_000.0,
                    tx_bytes_per_sec: 12_000_000.0,
                    total_rx_bytes: 2_480_000_000,
                    total_tx_bytes: 400_000_000,
                    ..NetInterfaceMetrics::default()
                },
                NetInterfaceMetrics {
                    name: "enp0s31f6".to_string(),
                    is_loopback: false,
                    rx_bytes_per_sec: 40_000.0,
                    tx_bytes_per_sec: 14_000.0,
                    total_rx_bytes: 20_000_000,
                    total_tx_bytes: 5_000_000,
                    ..NetInterfaceMetrics::default()
                },
            ],
            batteries: vec![
                BatteryMetrics {
                    name: "BAT0".to_string(),
                    status: "Discharging".to_string(),
                    capacity_pct: 86.0,
                    power_watts: Some(13.4),
                },
                BatteryMetrics {
                    name: "InternalBattery-0".to_string(),
                    status: "Full".to_string(),
                    capacity_pct: 100.0,
                    power_watts: None,
                },
                BatteryMetrics {
                    name: "BAT1".to_string(),
                    status: "Charging".to_string(),
                    capacity_pct: 8.0,
                    power_watts: Some(0.4),
                },
            ],
            sockets: vec![
                NetSocketEntry {
                    proto: "TCP".to_string(),
                    local_addr: "0.0.0.0:22".to_string(),
                    remote_addr: "*".to_string(),
                    state: "LISTEN".to_string(),
                    inode: 11_022,
                    pid: Some(300),
                    process: "sshd".to_string(),
                },
                NetSocketEntry {
                    proto: "TCP6".to_string(),
                    local_addr: "[::]:443".to_string(),
                    remote_addr: "142.250.190.78:443".to_string(),
                    state: "ESTAB".to_string(),
                    inode: 16_443,
                    pid: Some(600),
                    process: "nginx".to_string(),
                },
            ],
            ..SystemSnapshot::default()
        };
        let disk_count = snap.disks.len();
        let expected = disk_cols(&snap.disks);
        let rt = open(Panel::Disks, snap.clone());
        let mounts = column_rects(&rt, "disk-mount", disk_count);
        let devices = column_rects(&rt, "disk-dev", disk_count);
        let caps = column_rects(&rt, "disk-cap", disk_count);
        let bars = column_rects(&rt, "disk-bar", disk_count);
        let reads = column_rects(&rt, "disk-read", disk_count);
        let writes = column_rects(&rt, "disk-write", disk_count);
        let busys = column_rects(&rt, "disk-busy", disk_count);
        let awaits = column_rects(&rt, "disk-await", disk_count);
        assert_shared_column(&mounts, "mount");
        assert_shared_column(&devices, "device");
        assert_shared_column(&caps, "capacity");
        assert_shared_column(&bars, "bar");
        assert_shared_column(&reads, "read");
        assert_shared_column(&writes, "write");
        assert_shared_column(&busys, "busy");
        assert_shared_column(&awaits, "await");
        assert!((mounts[0][2] - expected.mount).abs() < 0.5);
        assert!((devices[0][2] - expected.device).abs() < 0.5);
        assert!((caps[0][2] - expected.capacity).abs() < 0.5);
        assert!((bars[0][2] - DISK_BAR_W).abs() < 0.5);
        assert!((reads[0][2] - expected.read).abs() < 0.5);
        assert!((writes[0][2] - expected.write).abs() < 0.5);
        assert!((busys[0][2] - expected.busy).abs() < 0.5);
        assert!((awaits[0][2] - expected.await_ms).abs() < 0.5);
        assert_eq!(expected.mount, DISK_MOUNT_MAX);
        assert_eq!(expected.device, DISK_DEVICE_MAX);
        assert_follows(mounts[0], devices[0], 8.0, "mount->device");
        assert_follows(devices[0], caps[0], 8.0, "device->capacity");
        assert_follows(caps[0], bars[0], 8.0, "capacity->bar");
        assert_follows(bars[0], reads[0], 8.0, "bar->read");
        assert_follows(reads[0], writes[0], 8.0, "read->write");
        assert_follows(writes[0], busys[0], 8.0, "write->busy");
        assert_follows(busys[0], awaits[0], 8.0, "busy->await");
        let lines = texts(&rt);
        assert!(lines.iter().any(|line| line == "/home/aragao"));
        assert!(lines.iter().any(|line| line == "/.snapshots"));
        assert!(lines.iter().any(|line| line == "/"));

        let pct = column_rects(&rt, "bat-pct", snap.batteries.len());
        let watts = column_rects(&rt, "bat-watts", snap.batteries.len());
        assert_shared_column(&pct, "battery percent");
        assert_shared_column(&watts, "battery watts");
        let battery_columns = battery_cols(&snap.batteries);
        assert!((pct[0][2] - battery_columns.pct).abs() < 0.5);
        assert!((watts[0][2] - battery_columns.watts).abs() < 0.5);
        assert_follows(pct[0], watts[0], 8.0, "percent->watts");

        let rt = open(Panel::Network, snap.clone());
        let names = column_rects(&rt, "iface-name", snap.networks.len());
        let rx = column_rects(&rt, "iface-rx", snap.networks.len());
        let tx = column_rects(&rt, "iface-tx", snap.networks.len());
        let totals = column_rects(&rt, "iface-total", snap.networks.len());
        assert_shared_column(&names, "iface name");
        assert_shared_column(&rx, "rx");
        assert_shared_column(&tx, "tx");
        assert_shared_column(&totals, "totals");
        let iface_columns = iface_cols(&snap.networks.iter().collect::<Vec<_>>());
        assert!((names[0][2] - iface_columns.name).abs() < 0.5);
        assert!((rx[0][2] - iface_columns.rx).abs() < 0.5);
        assert!((tx[0][2] - iface_columns.tx).abs() < 0.5);
        assert!((totals[0][2] - iface_columns.totals).abs() < 0.5);
        assert!(names[0][2] >= IFACE_NAME_MIN - 0.5);
        assert!(rx[0][2] >= DISK_RATE_MIN - 0.5);
        assert!(totals[0][2] >= IFACE_TOTAL_MIN - 0.5);
        assert_follows(names[0], rx[0], 8.0, "name->rx");
        assert_follows(rx[0], tx[0], 8.0, "rx->tx");
        assert_follows(tx[0], totals[0], 8.0, "tx->totals");

        let sock_count = snap.sockets.len();
        let sock_protos = column_rects(&rt, "sock-proto", sock_count);
        let sock_locals = column_rects(&rt, "sock-local", sock_count);
        let sock_remotes = column_rects(&rt, "sock-remote", sock_count);
        let sock_states = column_rects(&rt, "sock-state", sock_count);
        let sock_procs = column_rects(&rt, "sock-proc", sock_count);
        assert_shared_column(&sock_protos, "sock proto");
        assert_shared_column(&sock_locals, "sock local");
        assert_shared_column(&sock_remotes, "sock remote");
        assert_shared_column(&sock_states, "sock state");
        assert_shared_column(&sock_procs, "sock proc");
        assert_follows(sock_protos[0], sock_locals[0], 8.0, "proto->local");
        assert_follows(sock_locals[0], sock_remotes[0], 8.0, "local->remote");
        assert_follows(sock_remotes[0], sock_states[0], 8.0, "remote->state");
        assert_follows(sock_states[0], sock_procs[0], 8.0, "state->proc");
    }
}
