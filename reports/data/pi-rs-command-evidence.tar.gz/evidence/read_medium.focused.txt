251:setting_250=critical_timeout=417
