#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <execinfo.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

static double millis(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec*1000.0 + t.tv_nsec/1000000.0;
}

static void delayed(const char *name, struct pollfd *fds, nfds_t n, int timeout,
                    double started, int result) {
    int saved = errno;
    double elapsed = millis()-started;
    if (elapsed > 200.0) {
        fprintf(stderr, "NATIVE_WAIT %.3f %s blocked %.3f ms timeout=%d nfds=%lu result=%d\n",
                started, name, elapsed, timeout, (unsigned long)n, result);
        for (nfds_t i=0; i<n && i<12; i++) {
            char path[80], target[256];
            snprintf(path,sizeof(path),"/proc/self/fd/%d",fds[i].fd);
            ssize_t len=readlink(path,target,sizeof(target)-1);
            if (len>=0) target[len]=0; else target[0]=0;
            fprintf(stderr,"NATIVE_FD fd=%d events=%x revents=%x target=%s\n",fds[i].fd,fds[i].events,fds[i].revents,target);
        }
        void *stack[48];
        int frames=backtrace(stack,48);
        backtrace_symbols_fd(stack,frames,STDERR_FILENO);
    }
    errno=saved;
}

int poll(struct pollfd *fds, nfds_t n, int timeout) {
    static int (*original)(struct pollfd*,nfds_t,int);
    if (!original) original=dlsym(RTLD_NEXT,"poll");
    double started=millis();
    int result=original(fds,n,timeout);
    delayed("poll",fds,n,timeout,started,result);
    return result;
}

int ppoll(struct pollfd *fds, nfds_t n, const struct timespec *timeout, const sigset_t *mask) {
    static int (*original)(struct pollfd*,nfds_t,const struct timespec*,const sigset_t*);
    if (!original) original=dlsym(RTLD_NEXT,"ppoll");
    double started=millis();
    int result=original(fds,n,timeout,mask);
    delayed("ppoll",fds,n,timeout?(int)(timeout->tv_sec*1000+timeout->tv_nsec/1000000):-1,started,result);
    return result;
}
