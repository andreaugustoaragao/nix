from pathlib import Path
p=Path('/opt/vmperf/diagnose.py')
s=p.read_text()
s=s.replace("import guest\n", "import guest\noriginal_render_environment=guest.render_environment\ndef instrumented_environment(app):\n    env,mode=original_render_environment(app)\n    if app=='kero':env['LD_PRELOAD']='/opt/vmperf/native-waits.so'\n    return env,mode\nguest.render_environment=instrumented_environment\n")
p.write_text(s)
