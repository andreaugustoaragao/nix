import subprocess,pathlib,time,re
v=pathlib.Path.home()/'Virtual Machines.localized/Hypervisor Benchmark Fusion.vmwarevm/Hypervisor Benchmark Fusion.vmx'
cli='/Applications/VMware Fusion.app/Contents/Library/vmrun'
for n in range(60):
 if str(v) not in subprocess.check_output([cli,'list'],text=True).splitlines():break
 time.sleep(1)
else:raise SystemExit('Refusing to modify a running VM')
s=v.read_text();v.with_suffix('.before-sata.backup').write_text(s)
values={'nvme0.present':'FALSE','nvme0:0.present':'FALSE','sata0:1.present':'TRUE','sata0:1.fileName':'Benchmark.vmdk','sata0:1.deviceType':'disk','sata0:1.startConnected':'TRUE'}
for k,value in values.items():
 line=f'{k} = "{value}"'
 pattern=r'^'+re.escape(k)+r'\s*=.*$'
 if re.search(pattern,s,re.M):s=re.sub(pattern,line,s,flags=re.M)
 else:s+='\n'+line+'\n'
v.write_text(s)
print('Attached the existing benchmark disk to SATA port 1')
subprocess.run([cli,'start',str(v),'nogui'],check=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
