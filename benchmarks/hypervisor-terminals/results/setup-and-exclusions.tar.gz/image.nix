let
  unstable =
    import /nix/store/2nq43zj33fl5hzlm5rjzpzkfyxkmdzzk-1w04vwgsncnwyxhrj7kb1m3fhhb53vb8-source
      {
        system = "aarch64-linux";
        config = { };
        overlays = [ ];
      };
  system =
    import
      /nix/store/zhwbg2cidhjb3pn0drqqki07492hsq38-rn86w1n361pzvxpapvqn058d8bws44ql-source/nixos/lib/eval-config.nix
      {
        system = "aarch64-linux";
        specialArgs.benchmarkGhostty = unstable.ghostty;
        modules = [ ./configuration.nix ];
      };
in
system.config.system.build.isoImage
