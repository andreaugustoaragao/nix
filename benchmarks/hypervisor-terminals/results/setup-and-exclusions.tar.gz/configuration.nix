{
  lib,
  pkgs,
  modulesPath,
  benchmarkGhostty,
  ...
}:
let
  herdr = pkgs.callPackage /home/aragao/projects/personal/nix/pkgs/herdr-app.nix { };
  kero = pkgs.callPackage /home/aragao/projects/personal/nix/pkgs/kero.nix { };
in
{
  imports = [ "${modulesPath}/installer/cd-dvd/installation-cd-minimal.nix" ];
  nixpkgs.config = { };
  nixpkgs.overlays = [ ];
  networking.hostName = "hypervisor-bench";
  networking.useDHCP = lib.mkForce true;
  services.openssh = {
    enable = true;
    settings.PasswordAuthentication = false;
    settings.KbdInteractiveAuthentication = false;
    settings.PermitRootLogin = "prohibit-password";
  };
  users.users.root.openssh.authorizedKeys.keyFiles = [ ./id_ed25519.pub ];
  users.users.tester = {
    isNormalUser = true;
    uid = 1000;
    initialPassword = "";
    extraGroups = [
      "video"
      "input"
    ];
  };
  virtualisation.vmware.guest.enable = true;
  hardware.graphics.enable = true;
  programs.niri.enable = true;
  programs.niri.useNautilus = false;
  services.greetd = {
    enable = true;
    settings.default_session = {
      command = "${pkgs.coreutils}/bin/env NIRI_CONFIG=/etc/niri/config.kdl ${pkgs.niri}/bin/niri-session";
      user = "tester";
    };
  };
  environment.etc."niri/config.kdl".text = ''
    hotkey-overlay { skip-at-startup; }
    output "Virtual-1" { mode "1280x800"; scale 1; }
    output "Virtual-2" { off; }
    output "Virtual-3" { off; }
    layout { gaps 0; default-column-width { proportion 1.0; }; }
    prefer-no-csd
    spawn-at-startup "sh" "-c" "env > /home/tester/session.env"
    binds { Mod+Return { spawn "ghostty"; }; }
  '';
  environment.etc."benchmark-packages.json".text = builtins.toJSON {
    ghostty = "${benchmarkGhostty}/bin/ghostty";
    herdr = "${herdr}/bin/herdr-app";
    kero = "${kero}/bin/kero";
    hc = "${
      herdr.passthru.herdr-core
        or (pkgs.callPackage /home/aragao/projects/personal/nix/pkgs/herdr-core.nix { })
    }/bin/hc";
    go = "${pkgs.go}/bin/go";
    python = "${pkgs.python3}/bin/python3";
    mesa = "${pkgs.mesa}";
  };
  environment.systemPackages = [
    benchmarkGhostty
    herdr
    kero
    pkgs.go
    pkgs.python3
    pkgs.mesa-demos
    pkgs.pciutils
    pkgs.jq
    pkgs.wtype
    pkgs.wl-clipboard
    pkgs.time
    pkgs.procps
    pkgs.util-linux
    pkgs.e2fsprogs
    (pkgs.callPackage /home/aragao/projects/personal/nix/pkgs/herdr-core.nix { })
  ];
  fonts.fontconfig.enable = true;
  fonts.packages = [ pkgs.dejavu_fonts ];
  systemd.services.publish-benchmark-host-key = {
    wantedBy = [ "multi-user.target" ];
    after = [ "sshd.service" ];
    requires = [ "sshd.service" ];
    serviceConfig.Type = "oneshot";
    script = ''
      key=$(cat /etc/ssh/ssh_host_ed25519_key.pub)
      for port in /dev/ttyAMA0 /dev/ttyS0; do
        if [ -c "$port" ]; then printf '\nBENCH_HOST_KEY %s\n' "$key" > "$port"; fi
      done
      if [ "$(systemd-detect-virt || true)" = vmware ]; then
        ${pkgs.open-vm-tools-headless}/bin/vmtoolsd --cmd "info-set guestinfo.bench-ssh-host-key $key"
      fi
    '';
  };
  isoImage.squashfsCompression = "zstd -Xcompression-level 3";
  system.stateVersion = "26.05";
}
