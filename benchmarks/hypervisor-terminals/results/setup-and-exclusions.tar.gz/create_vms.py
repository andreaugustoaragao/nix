#!/usr/bin/env python3
import argparse
import json
import subprocess
from pathlib import Path

home = Path.home()
work = home / "Downloads/hypervisor-benchmark-20261103"
iso = work / "benchmark.iso"
prl = "/usr/local/bin/prlctl"
fusion = "/Applications/VMware Fusion.app/Contents/Library"


def run(*args):
    subprocess.run([str(arg) for arg in args], check=True)


def main():
    side = argparse.ArgumentParser()
    side.add_argument("hypervisor", choices=["parallels", "fusion"])
    args = side.parse_args()
    if not iso.is_file():
        raise SystemExit("Common image is missing")
    if args.hypervisor == "parallels":
        name = "Hypervisor Benchmark Parallels"
        existing = subprocess.check_output([prl, "list", "-a", "--no-header", "-o", "name"], text=True)
        if name in existing.splitlines():
            raise SystemExit("Benchmark VM exists; refusing to overwrite it")
        run(prl, "create", name, "--ostype", "linux", "--no-hdd")
        options = [
            ["--cpus", "8", "--memsize", "16384"],
            ["--video-adapter-type", "virtio", "--3d-accelerate", "highest", "--vertical-sync", "on", "--high-resolution", "off"],
            ["--faster-vm", "on", "--longer-battery-life", "off", "--pause-idle", "off"],
            ["--isolate-vm", "on"],
            ["--shf-host", "off", "--shf-host-defined", "off", "--shf-host-automount", "off", "--shf-guest", "off"],
            ["--shared-profile", "off", "--shared-cloud", "off", "--smart-mount", "off"],
            ["--shared-clipboard", "off", "--sh-app-host-to-guest", "off", "--sh-app-guest-to-host", "off"],
            ["--device-add", "hdd", "--type", "expand", "--size", "32768", "--iface", "nvme"],
            ["--device-set", "net0", "--type", "shared", "--adapter-type", "virtio"],
            ["--device-set", "cdrom0", "--image", str(iso), "--connect"],
            ["--device-add", "serial", "--output", str(work / "parallels-serial.log")],
            ["--device-bootorder", "cdrom0 hdd0"],
        ]
        for setting in options:
            run(prl, "set", name, *setting)
        run(prl, "start", name)
        run(prl, "list", "-i", name)
    else:
        root = home / "Virtual Machines.localized/Hypervisor Benchmark Fusion.vmwarevm"
        root.mkdir(exist_ok=False)
        run(f"{fusion}/vmware-vdiskmanager", "-c", "-s", "32GB", "-a", "lsilogic", "-t", "0", root / "Benchmark.vmdk")
        values = {
            ".encoding": "UTF-8", "config.version": "8", "virtualHW.version": "22",
            "displayName": "Hypervisor Benchmark Fusion", "guestOS": "arm-other6xlinux-64",
            "firmware": "efi", "numvcpus": "8", "memsize": "16384",
            "pciBridge0.present": "TRUE", "vmci0.present": "TRUE",
            "sata0.present": "TRUE", "sata0:0.present": "TRUE", "sata0:0.deviceType": "cdrom-image",
            "sata0:0.fileName": str(iso), "sata0:0.startConnected": "TRUE", "bios.bootOrder": "cdrom",
            "nvme0.present": "TRUE", "nvme0:0.present": "TRUE", "nvme0:0.fileName": "Benchmark.vmdk",
            "usb.present": "TRUE", "usb_xhci.present": "TRUE", "floppy0.present": "FALSE",
            "ethernet0.present": "TRUE", "ethernet0.virtualDev": "e1000e",
            "ethernet0.connectionType": "nat", "ethernet0.addressType": "generated",
            "mks.enable3d": "TRUE", "svga.graphicsMemoryKB": "2097152", "svga.vramSize": "134217728",
            "svga.autodetect": "FALSE", "svga.maxWidth": "1920", "svga.maxHeight": "1200",
            "gui.fitGuestUsingNativeDisplayResolution": "FALSE", "tools.syncTime": "TRUE",
            "isolation.tools.hgfs.disable": "TRUE", "sharedFolder.maxNum": "0",
            "isolation.tools.copy.disable": "TRUE", "isolation.tools.paste.disable": "TRUE",
            "serial0.present": "TRUE", "serial0.fileType": "file", "serial0.fileName": str(work / "fusion-serial.log"),
        }
        for index in range(4, 8):
            values.update({f"pciBridge{index}.present": "TRUE", f"pciBridge{index}.virtualDev": "pcieRootPort", f"pciBridge{index}.functions": "8"})
        vmx = root / "Hypervisor Benchmark Fusion.vmx"
        vmx.write_text("".join(f"{key} = {json.dumps(value)}\n" for key, value in values.items()))
        run(f"{fusion}/vmrun", "start", vmx, "gui")
        print(vmx)


if __name__ == "__main__":
    main()
