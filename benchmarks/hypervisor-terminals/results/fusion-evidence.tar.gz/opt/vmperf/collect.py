import tarfile
from pathlib import Path
root=Path('/bench')
files=[]
for name in ['metadata.json','metadata-nvme.json','render-modes.json','storage/metadata.json']:
 p=root/name
 if p.is_file():files.append(p)
for p in (root/'runs').glob('*/*'):
 if not p.is_file():continue
 if p.parent.name.startswith('go--') and (p.name=='profile-top.txt' or p.suffix=='.pprof'):
  files.append(p)
 if any(f'-{trial}-' in p.parent.name for trial in range(10,15)) and (p.suffix in ['.png','.json','.log']):files.append(p)
 if p.parent.name=='herdr--1-idle' and p.name=='app.log':files.append(p)
files.extend(p for p in (root/'diagnostics').glob('*') if p.is_file())
for p in (root/'runs').glob('*--30-*/app.log'):
 files.append(p)
files.extend(p for p in Path('/opt/vmperf').glob('*.py') if p.is_file())
files.extend(p for p in Path('/opt/vmperf').glob('native*') if p.is_file())
files.extend([Path('/etc/benchmark-packages.json'),Path('/etc/niri/config.kdl')])
with tarfile.open('/tmp/vmperf-evidence.tgz','w:gz',dereference=True) as archive:
 for p in sorted(set(files)):
  archive.add(p,arcname=str(p).lstrip('/'),recursive=False)
print('Collected',len(set(files)),'evidence files')
