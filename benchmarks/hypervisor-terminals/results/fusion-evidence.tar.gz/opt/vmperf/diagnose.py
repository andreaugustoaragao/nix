import sys,time,json,threading,os
from pathlib import Path
sys.path.insert(0,'/opt/vmperf')
import guest
root=Path('/bench/diagnostics');root.mkdir(exist_ok=True)
guest.command(['chown','tester:users',root])

def threads(pid):
    result={}
    for p in Path(f'/proc/{pid}/task').iterdir():
        try:
            raw=(p/'stat').read_text();name=raw.split('(',1)[1].rsplit(')',1)[0];fields=raw.rsplit(')',1)[1].split()
            result[p.name]=(name,int(fields[11])+int(fields[12]))
        except (OSError,ProcessLookupError):pass
    return result

for app in ['ghostty','herdr','kero']:
    trial=-30
    folder=Path(f'/bench/runs/{app}-{trial}-paced')
    evidence={}
    def observe():
        try:
            guest.wait_for(lambda:(folder/'start').exists(),timeout=180)
            env=guest.session_environment(app)
            w=next(w for w in guest.windows(env) if w['app_id']=={'ghostty':'com.mitchellh.ghostty','herdr':'herdr-app','kero':'kero'}[app])
            pid=w['pid'];before=threads(pid);started=time.monotonic()
            time.sleep(.6)
            guest.as_user(['niri','msg','action','screenshot-window','--id',str(w['id']),'--path',str(root/f'{app}-changing-grid.png')],env)
            time.sleep(6)
            after=threads(pid);totals={}
            for tid,(name,ticks) in after.items():
                delta=ticks-before.get(tid,(name,0))[1]
                totals[name]=totals.get(name,0)+delta/os.sysconf('SC_CLK_TCK')
            evidence.update(pid=pid,observed_seconds=time.monotonic()-started,cpu_seconds_by_thread_name=totals)
        except Exception as e:evidence['error']=repr(e)
    t=threading.Thread(target=observe);t.start()
    value=guest.app_trial(app,trial,False)
    t.join()
    (root/f'{app}-threads.json').write_text(json.dumps(evidence,indent=2))
    (root/f'{app}-excluded-run.json').write_text(json.dumps(value))
print('Untimed diagnostics complete')
