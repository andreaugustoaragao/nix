import subprocess,shlex,time,json
from pathlib import Path
r=Path('/tmp/vmware-nvme-retest-20261104');cfg=str(r/'ssh_config');macssh='/tmp/ghostty-fusion-test-20261103/mac-ssh'
app='/Users/aragao/Downloads/vmware-nvme-retest-20261104/VMware Fusion.app'
cli=app+'/Contents/Library/vmrun'
def run(a,**kw):return subprocess.run(a,check=True,text=True,timeout=900,**kw)
def mac(a,redirect=False):return run([macssh,shlex.join(a)+(' </dev/null >/tmp/vmperf-retest-start.log 2>&1' if redirect else '')],capture_output=True).stdout
def vmx(name):return '/Users/aragao/Virtual Machines.localized/NVMe Retest '+name+'.vmwarevm/VM.vmx'
def guest(alias,args):return run(['ssh','-F',cfg,'retest-'+alias,shlex.join(args)],capture_output=True).stdout
def boot(name):
 mac([cli,'start',vmx(name),'nogui'],True)
 time.sleep(30)
def capture(name,alias,trial):
 dest=r/f'new-{name}-pilot-result.json'
 run(['scp','-F',cfg,f'retest-{alias}:/bench/retest-{trial}/pilot-result.json',str(dest)],capture_output=True)
 (r/f'new-{name}-vmware-log.txt').write_text(mac(['head','-8',str(Path(vmx(name)).parent/'vmware.log')]))
 return json.loads(dest.read_text())
def follow(name,alias,ip,trial):
 print('Booting '+name,flush=True);boot(name)
 run(['python3',str(r/'provision_guest.py'),alias,ip],stdout=(r/f'new-{name}-provision.log').open('w'),stderr=subprocess.STDOUT)
 run(['scp','-F',cfg,str(r/'pilot-generic.py'),f'retest-{alias}:/opt/vmperf/pilot-generic.py'],capture_output=True)
 print('Pilot '+name,flush=True)
 with (r/f'new-{name}-pilot.json').open('w') as out,(r/f'new-{name}-progress.log').open('w') as err:
  run(['ssh','-F',cfg,'retest-'+alias,'python3 /opt/vmperf/pilot-generic.py '+str(trial)],stdout=out,stderr=err)
 x=capture(name,alias,trial);bad=bool(x['errors'] or x['nvme_faults'])
 print(name+': '+json.dumps({'errors':x['errors'],'nvme_faults':x['nvme_faults']}),flush=True)
 if bad:guest(alias,['systemctl','poweroff'])
 else:mac([cli,'suspend',vmx(name),'hard'])
 return not bad
x=capture('default','default',2001)
print('Default NVMe: '+json.dumps({'errors':x['errors'],'nvme_faults':x['nvme_faults']}),flush=True)
guest('default',['systemctl','poweroff'])
# Both values 32/64 fail in the same unchanged Linux kernel. Retest the valid
# maximum of eight on the new hypervisor, rather than altering CPU count.
passed8=follow('cold8','cold8new','192.168.150.134',2002)
passedSata=follow('sata','satanew','192.168.150.136',2003)
(r/'new-status.json').write_text(json.dumps({'cold8_passed':passed8,'sata_passed':passedSata},indent=2))
