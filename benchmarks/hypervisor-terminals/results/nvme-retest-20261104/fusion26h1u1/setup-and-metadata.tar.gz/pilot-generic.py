import sys,json,subprocess,time
from pathlib import Path
sys.path.insert(0,'/opt/vmperf');import guest,storage
trial=int(sys.argv[1]);root=Path(f'/bench/retest-{trial}');root.mkdir(exist_ok=False)
cmdline=Path('/proc/cmdline').read_text().strip()
meta={'cmdline':cmdline,'cpus':guest.os.cpu_count(),'poll_queues':Path('/sys/module/nvme/parameters/poll_queues').read_text().strip() if Path('/sys/module/nvme/parameters/poll_queues').exists() else None,'nvme_queues':Path('/sys/class/nvme/nvme0/queue_count').read_text().strip() if Path('/sys/class/nvme/nvme0/queue_count').exists() else None,'interrupts_before':Path('/proc/interrupts').read_text(),'kernel_before':guest.command(['dmesg']).stdout}
result={'metadata':meta,'errors':[]}
try:
 print('Running storage suite',file=sys.stderr,flush=True)
 p=subprocess.run(['python3','/opt/vmperf/storage.py','run','--trial',str(trial)],capture_output=True,text=True,timeout=300)
 (root/'suite.stdout').write_text(p.stdout);(root/'suite.stderr').write_text(p.stderr)
 if p.returncode:raise RuntimeError('Storage suite failed: '+p.stderr[-2000:])
 result['storage']=json.loads(p.stdout)
 print('Running compiler build',file=sys.stderr,flush=True)
 if result['storage']['errors']:raise RuntimeError('Reliability gate failed: kernel I/O warnings during storage suite; further speed/stress tests skipped')
 result['go']=guest.go_trial(trial)
 print('Running 60-second mixed-I/O stress',file=sys.stderr,flush=True)
 result['stress']=storage.fio('/opt/vmperf/fio','retest-stress',Path('/bench/storage/random.dat'),['--rw=randrw','--rwmixread=50','--bs=4k','--size=2g','--ioengine=libaio','--iodepth=64','--time_based=1','--runtime=60','--ramp_time=2','--end_fsync=1'])
 result['integrity']=storage.fio('/opt/vmperf/fio','stress-crc',root/'proof.dat',['--rw=write','--bs=64k','--size=64m','--ioengine=libaio','--iodepth=8','--verify=crc32c','--verify_fatal=1','--do_verify=1','--end_fsync=1'])
except Exception as e:result['errors'].append(repr(e))
result['kernel_after']=guest.command(['dmesg']).stdout
result['interrupts_after']=Path('/proc/interrupts').read_text()
result['nvme_faults']=[line for line in result['kernel_after'].splitlines() if 'nvme' in line and any(s in line for s in ['timeout','resetting','I/O error','invalid for parameter'])]
(root/'pilot-result.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'errors':result['errors'],'nvme_faults':result['nvme_faults'],'poll_queues':meta['poll_queues'],'nvme_queues':meta['nvme_queues']}))
