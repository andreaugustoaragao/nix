import subprocess,sys,os
from pathlib import Path
name,ip=sys.argv[1:];r=Path('/tmp/vmware-nvme-retest-20261104');alias='retest-'+name
cfg=str(r/'ssh_config')
def run(a,**kw):subprocess.run(a,check=True,**kw)
run(['python3',str(r/'add_host.py'),name,ip])
run(['nix-copy-closure','--to',alias,'/nix/store/k2vfr5rajk1gjpsdzgqdfz1gkadrc7v7-go-1.26.10','/nix/store/djjxa3myk69ijmy3s6ilcjk1rsiq4i81-fio-3.41'],env=os.environ|{'NIX_SSHOPTS':'-F '+cfg})
run(['ssh','-F',cfg,alias,'mkdir -p /opt/vmperf'])
run(['scp','-F',cfg,'benchmarks/hypervisor-terminals/guest.py','benchmarks/hypervisor-terminals/terminal_workload.py','benchmarks/hypervisor-terminals/storage.py',str(r/'pilot-new.py'),alias+':/opt/vmperf/'])
code='''from pathlib import Path
import json
p=Path('/etc/benchmark-packages.json');v=json.loads(p.read_text());v['go']='/nix/store/k2vfr5rajk1gjpsdzgqdfz1gkadrc7v7-go-1.26.10/bin/go';p.unlink();p.write_text(json.dumps(v))
'''
run(['ssh','-F',cfg,alias,"ln -s /nix/store/djjxa3myk69ijmy3s6ilcjk1rsiq4i81-fio-3.41/bin/fio /opt/vmperf/fio\npython3 - <<'PYCODE'\n"+code+'PYCODE'])
with (r/f'new-{name}-metadata.json').open('w') as f:run(['ssh','-F',cfg,alias,'python3 /opt/vmperf/guest.py prepare'],stdout=f)
with (r/f'new-{name}-precondition.json').open('w') as f:run(['ssh','-F',cfg,alias,'python3 /opt/vmperf/storage.py prepare'],stdout=f)
print('Provisioned',alias,flush=True)
