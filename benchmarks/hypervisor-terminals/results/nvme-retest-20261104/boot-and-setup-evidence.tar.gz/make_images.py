import subprocess,re,shutil,hashlib,json
from pathlib import Path
r=Path('/tmp/vmware-nvme-retest-20261104')
x=(r/'xorriso-path.txt').read_text().splitlines()[-1]+'/bin/xorriso'
original='/tmp/hypervisor-benchmark-20261103/image/iso/nixos-minimal-26.05pre-git-aarch64-linux.iso'
config=(r/'grub.cfg').read_text()
for q in [32,64]:
 text=config.replace('set timeout=10','set timeout=1')
 text=re.sub(r'(?m)^(\s*linux .*)$',lambda m:m[1]+f' nvme.poll_queues={q}',text)
 cfg=r/f'grub-{q}.cfg';cfg.write_text(text)
 efi=r/f'efi-{q}.img';shutil.copy2(r/'efi.img',efi);efi.chmod(0o644)
 # The EFI FAT image may carry its own config in addition to ISO9660.
 listing=subprocess.check_output(['mdir','-i',str(efi),'::/EFI/BOOT'],text=True)
 if 'grub' in listing.lower() and 'cfg' in listing.lower():subprocess.run(['mcopy','-o','-i',str(efi),str(cfg),'::/EFI/BOOT/grub.cfg'],check=True)
 out=r/f'benchmark-poll{q}.iso'
 with (r/f'iso-{q}.log').open('w') as log:
  subprocess.run([x,'-indev',original,'-outdev',str(out),'-boot_image','any','replay','-map',str(cfg),'/EFI/BOOT/grub.cfg','-map',str(efi),'/boot/efi.img','-commit'],stdout=log,stderr=log,check=True)
 print(q,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
