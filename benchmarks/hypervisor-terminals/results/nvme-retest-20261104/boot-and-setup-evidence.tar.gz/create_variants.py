import pathlib,re,subprocess,json
home=pathlib.Path.home();out=home/'Downloads/vmware-nvme-retest-20261104'
source=home/'Virtual Machines.localized/Hypervisor Benchmark Fusion.vmwarevm'
config=(source/'Hypervisor Benchmark Fusion.vmx').read_text()
values={}
for line in config.splitlines():
 m=re.match(r'([^=]+)\s*=\s*"(.*)"\s*$',line)
 if m:values[m[1].strip()]=m[2]
manifest={}
for name,poll in [('default',0),('poll32',32),('poll64',64),('sata',None)]:
 d=home/f'Virtual Machines.localized/NVMe Retest {name}.vmwarevm'
 if d.exists():raise SystemExit(f'Refusing to overwrite {d}')
 d.mkdir()
 subprocess.run(['cp','-c',str(source/'Benchmark.vmdk'),str(d/'Benchmark.vmdk')],check=True)
 v={k:x for k,x in values.items() if not (k.startswith(('uuid.','vm.genid','ethernet0.generated','migrate.','vmotion.')) or k in ['checkpoint.vmState','extendedConfigFile','nvram','workingDir','vmx.stats.filename','sched.swap.derivedName','vmxstats.filename'])}
 v.update(displayName=f'NVMe Retest {name}',nvram='nvram',**{'checkpoint.vmState':'','msg.autoAnswer':'TRUE','serial0.present':'FALSE','sata0:0.fileName':str(out/f'benchmark-poll{poll}.iso') if poll in [32,64] else str(home/'Downloads/hypervisor-benchmark-20261103/benchmark.iso'),'nvme0.present':'TRUE' if poll is not None else 'FALSE','nvme0:0.present':'TRUE' if poll is not None else 'FALSE','nvme0:0.fileName':'Benchmark.vmdk','sata0:1.present':'TRUE' if poll is None else 'FALSE','sata0:1.fileName':'Benchmark.vmdk','ethernet0.addressType':'generated'})
 vmx=d/'VM.vmx';vmx.write_text(''.join(f'{k} = {json.dumps(x)}\n' for k,x in v.items()))
 manifest[name]={'vmx':str(vmx),'poll_queues_requested':poll,'disk_controller':'sata' if poll is None else 'nvme','cpus':v['numvcpus'],'memory_mib':v['memsize']}
(out/'variants.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest))
