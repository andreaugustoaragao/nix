# Vereda

Vereda is a native Linux file manager, navigator, and previewer built with Rust and Rune.

Browse with the mouse, standard desktop shortcuts, or Vim-style keys. Use independent panes and tabs to work across folders. Preview files alongside search results and file operations.

## Capabilities

- List, Details, and Grid views, with per-folder preferences.
- Split panes, tabs, breadcrumbs, and fuzzy path completion.
- Scoped filename and content search.
- Image thumbnails, including HEIC and camera RAW through installed Linux thumbnail services.
- Text, source, Markdown, HTML, image, PDF, and archive previews.
- Native Wayland file dragging between Vereda and other applications.
- Background copy and move operations, conflict comparisons, and failed-item retry.
- Favorites shared with GTK bookmarks, GIO devices, and remote locations.
- System fonts, light and dark schemes, and interface zoom.
- A desktop file-chooser portal backend.

## Build and configuration

See [Build Vereda](docs/build.md) and the [configuration reference](docs/configuration.md).

Vereda targets Linux. Its Nix flake supports x86_64-linux and aarch64-linux. Native external file dragging currently requires Wayland.

## Project origin and license

Vereda developed from a GUI prototype in a Yazi checkout and now has its own source tree, navigation implementation, keymap, configuration, and release process. It does not depend on the Yazi workspace or synchronize with Yazi upstream.

Vereda is MIT-licensed. See [LICENSE](LICENSE) and [third-party notices](THIRD_PARTY_NOTICES.md).
