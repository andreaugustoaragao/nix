# Attribution

Vereda was originally developed in a checkout of [Yazi](https://github.com/sxyazi/yazi), at revision `6882e1ac279b3df2722aaa0ab5dc049ce02d21eb`. It is now developed independently. Yazi is not an upstream dependency. Its MIT copyright and license are preserved in LICENSE.

The application uses [Rune](https://github.com/anomalyco/rune) and other dependencies under their respective licenses. Rune is pinned by nix/rune-source.nix; local integration patches are in nix/.

## Historical icon attribution

The originating checkout included the following icon license, retained conservatively for any inherited icon material:

```text
MIT License

Copyright (c) 2023 nvim-tree

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

The transitive Rust crate `yazi` is a DEFLATE implementation used by Swash in the font stack. It is unrelated to the Yazi terminal file manager.
