use std::{
    collections::BTreeMap,
    fs,
    io::Write,
    path::{Path, PathBuf},
};

use rune::{Latest, TextEdit, Tx, Waker};
use serde::{Deserialize, Serialize};

use crate::{
    font::Role,
    scheme::{self, Palette, Scheme},
    system_appearance,
    watcher::Watch,
};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Mode {
    #[default]
    System,
    Light,
    Dark,
}

impl Mode {
    pub fn name(self) -> &'static str {
        match self {
            Self::System => "system",
            Self::Light => "light",
            Self::Dark => "dark",
        }
    }
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct Options {
    pub mode: Mode,
    pub light_scheme: String,
    pub dark_scheme: String,
    pub ui_font: String,
    pub ui_font_size: Option<f32>,
    pub list_font: String,
    pub list_font_size: Option<f32>,
    pub preview_font: String,
    pub preview_font_size: Option<f32>,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            mode: Mode::System,
            light_scheme: "system".into(),
            dark_scheme: "system".into(),
            ui_font: "system".into(),
            ui_font_size: None,
            list_font: "monospace".into(),
            list_font_size: None,
            preview_font: "system".into(),
            preview_font_size: None,
        }
    }
}

struct Loaded {
    options: Options,
    schemes: Vec<Scheme>,
    desktop: Option<Palette>,
    ui_font: Option<crate::font::Font>,
    preview_font: Option<crate::font::Font>,
    files: Vec<PathBuf>,
}

pub struct Appearance {
    pub options: Options,
    pub schemes: Vec<Scheme>,
    pub open: bool,
    pub page_dark: bool,
    pub fonts_open: bool,
    pub font_role: Role,
    pub error: Option<String>,
    pub path: PathBuf,
    pub ui_editor: TextEdit,
    pub list_editor: TextEdit,
    pub preview_editor: TextEdit,
    gtk_ui_font: Option<crate::font::Font>,
    gtk_preview_font: Option<crate::font::Font>,
    applied_families: Option<(String, String)>,
    ui_resolved: crate::font::Font,
    list_resolved: crate::font::Font,
    list_family: rune::Family,
    preview_resolved: crate::font::Font,
    desktop: Option<Palette>,
    system: system_appearance::System,
    system_config: PathBuf,
    files: Vec<PathBuf>,
    watch: Watch,
    reader: Latest<Result<Loaded, String>>,
    writer: Latest<Result<(), String>>,
    writing: BTreeMap<String, Option<toml_edit::Value>>,
    pending: BTreeMap<String, Option<toml_edit::Value>>,
    reload: bool,
}

impl Appearance {
    pub fn new(directory: Option<PathBuf>) -> Self {
        let system_config = crate::state::xdg_config_home();
        let root = directory.unwrap_or_else(crate::state::default_config_dir);
        let loaded = load(&root, &system_config);
        let (loaded, error) = match loaded {
            Ok(loaded) => (loaded, None),
            Err(error) => (
                Loaded {
                    options: Options::default(),
                    schemes: scheme::builtins(),
                    desktop: None,
                    ui_font: None,
                    preview_font: None,
                    files: vec![root.join("config.toml"), root.join("schemes")],
                },
                Some(error),
            ),
        };
        let mut appearance = Self {
            options: loaded.options,
            schemes: loaded.schemes,
            desktop: loaded.desktop,
            files: loaded.files,
            path: root.join("config.toml"),
            ui_editor: TextEdit::new(""),
            list_editor: TextEdit::new(""),
            preview_editor: TextEdit::new(""),
            gtk_ui_font: loaded.ui_font,
            gtk_preview_font: loaded.preview_font,
            applied_families: None,
            ui_resolved: crate::font::fallback(false),
            list_resolved: crate::font::fallback(true),
            list_family: rune::Family::Sans,
            preview_resolved: crate::font::fallback(true),
            open: false,
            page_dark: true,
            fonts_open: false,
            font_role: Role::Interface,
            error,
            system: system_appearance::System::default(),
            system_config,
            watch: Watch::default(),
            reader: Latest::default(),
            writer: Latest::default(),
            pending: BTreeMap::new(),
            writing: BTreeMap::new(),
            reload: false,
        };
        appearance.refresh_fonts();
        appearance.refresh_editors();
        appearance
    }

    pub fn start(&mut self, waker: Waker, native: bool) {
        self.reader.set_waker(waker.clone());
        self.writer.set_waker(waker.clone());
        if let Err(error) = self.watch.start(waker.clone()) {
            self.error = Some(format!("Could not watch appearance settings: {error}"));
        }
        self.update_watch();
        if native {
            self.system.start(waker);
        }
    }

    pub fn dark(&self, system: bool, override_dark: Option<bool>) -> bool {
        override_dark.unwrap_or(match self.options.mode {
            Mode::System => system,
            Mode::Light => false,
            Mode::Dark => true,
        })
    }

    pub fn palette(&self, system_dark: bool, override_dark: Option<bool>) -> Palette {
        let dark = self.dark(system_dark, override_dark);
        let id = if dark {
            &self.options.dark_scheme
        } else {
            &self.options.light_scheme
        };
        self.scheme_palette(id, dark)
    }

    pub fn scheme_palette(&self, id: &str, dark: bool) -> Palette {
        if id == "system" {
            if let Some(palette) = self.desktop.filter(|palette| palette.dark == dark) {
                return palette;
            }
            let palette = self
                .schemes
                .iter()
                .find(|scheme| scheme.id == if dark { "vereda-dark" } else { "vereda-light" })
                .expect("built-in fallback")
                .palette;
            return self
                .system
                .accent
                .map_or(palette, |accent| palette.with_accent(accent));
        }
        self.schemes
            .iter()
            .find(|scheme| scheme.id == id)
            .expect("validated scheme")
            .palette
    }

    pub fn system_source(&self, dark: bool) -> &'static str {
        if self.desktop.is_some_and(|palette| palette.dark == dark) {
            "Desktop colors (GTK)"
        } else if self.system.accent.is_some() {
            "Desktop accent with Vereda colors"
        } else {
            "Vereda colors; desktop palette unavailable"
        }
    }

    pub fn set_mode(&mut self, mode: Mode) {
        self.options.mode = mode;
        self.change("mode", Some(toml_edit::Value::from(mode.name())));
    }

    pub fn select(&mut self, id: &str, dark: bool) {
        if id != "system"
            && !self
                .schemes
                .iter()
                .any(|scheme| scheme.id == id && scheme.palette.dark == dark)
        {
            return;
        }
        if dark {
            self.options.dark_scheme = id.into();
        } else {
            self.options.light_scheme = id.into();
        }
        self.change(
            if dark { "dark_scheme" } else { "light_scheme" },
            Some(toml_edit::Value::from(id)),
        );
    }

    pub fn font(&self, role: Role) -> &crate::font::Font {
        match role {
            Role::Interface => &self.ui_resolved,
            Role::Files => &self.list_resolved,
            Role::Preview => &self.preview_resolved,
        }
    }

    pub fn editor(&self, role: Role) -> &TextEdit {
        match role {
            Role::Interface => &self.ui_editor,
            Role::Files => &self.list_editor,
            Role::Preview => &self.preview_editor,
        }
    }

    pub fn editor_mut(&mut self, role: Role) -> &mut TextEdit {
        match role {
            Role::Interface => &mut self.ui_editor,
            Role::Files => &mut self.list_editor,
            Role::Preview => &mut self.preview_editor,
        }
    }

    pub fn font_options(&self, role: Role) -> (&str, Option<f32>) {
        match role {
            Role::Interface => (&self.options.ui_font, self.options.ui_font_size),
            Role::Files => (&self.options.list_font, self.options.list_font_size),
            Role::Preview => (&self.options.preview_font, self.options.preview_font_size),
        }
    }

    fn refresh_fonts(&mut self) {
        self.ui_resolved = self.resolve_font(Role::Interface);
        self.list_resolved = self.resolve_font(Role::Files);
        self.list_family = crate::font::named(&self.list_resolved.family);
        self.preview_resolved = self.resolve_font(Role::Preview);
    }

    fn resolve_font(&self, role: Role) -> crate::font::Font {
        let (choice, size) = self.font_options(role);
        let mut font = if role == Role::Files {
            self.ui_resolved.clone()
        } else {
            let (gtk, portal) = if role == Role::Preview {
                (&self.gtk_preview_font, &self.system.preview_font)
            } else {
                (&self.gtk_ui_font, &self.system.ui_font)
            };
            gtk.as_ref()
                .or(portal.as_ref())
                .cloned()
                .unwrap_or_else(|| crate::font::fallback(role == Role::Preview))
        };
        if role == Role::Files && choice == "monospace" {
            font.family = crate::font::fallback(true).family;
        } else if choice != "system" {
            font.family = choice.into();
        } else if crate::font::canonical(&font.family).is_none() {
            font.family = crate::font::fallback(role == Role::Preview).family;
        }
        if let Some(size) = size {
            font.points = size;
        }
        font
    }

    pub fn metrics(&self) -> crate::font::Metrics {
        let scale = 96.0 / 72.0 * self.system.text_scale;
        crate::font::Metrics {
            ui: self.ui_resolved.points * scale,
            list: self.list_resolved.points * scale,
            list_family: self.list_family,
            preview: self.preview_resolved.points * scale,
        }
    }

    pub fn apply_fonts(&mut self, tx: &mut Tx) {
        let quote = |name: &str| format!("'{}'", name.replace('\\', "\\\\").replace('\'', "\\'"));
        // Rune loads installed faces for the two app slots; the named file-list face is a fallback.
        let sans = format!(
            "{}, {}",
            quote(&self.ui_resolved.family),
            quote(&self.list_resolved.family)
        );
        let preview = &self.preview_resolved.family;
        if self
            .applied_families
            .as_ref()
            .is_none_or(|(a, b)| a != &sans || b != preview)
        {
            tx.set_font_families(sans.clone(), preview.clone());
            self.applied_families = Some((sans, preview.clone()));
        }
    }

    fn refresh_editors(&mut self) {
        for role in [Role::Interface, Role::Files, Role::Preview] {
            if !self.editor(role).focused {
                *self.editor_mut(role) = TextEdit::new(&self.font(role).family);
            }
        }
    }

    pub fn set_font(&mut self, role: Role, family: &str) {
        let family = family.trim();
        let family = if family == "system" || (role == Role::Files && family == "monospace") {
            family.into()
        } else if let Some(family) = crate::font::canonical(family) {
            family
        } else {
            self.error = Some(format!("Font family is not installed: {family}"));
            return;
        };
        match role {
            Role::Interface => self.options.ui_font = family.clone(),
            Role::Files => self.options.list_font = family.clone(),
            Role::Preview => self.options.preview_font = family.clone(),
        }
        self.editor_mut(role).focused = false;
        self.change(
            &format!("{}_font", role.prefix()),
            Some(toml_edit::Value::from(family)),
        );
        self.refresh_editors();
    }

    pub fn adjust_font_size(&mut self, role: Role, delta: Option<f32>) {
        let size = delta.map(|delta| {
            (self.font(role).points + delta)
                .clamp(8.0, if role == Role::Preview { 24.0 } else { 18.0 })
        });
        match role {
            Role::Interface => self.options.ui_font_size = size,
            Role::Files => self.options.list_font_size = size,
            Role::Preview => self.options.preview_font_size = size,
        }
        self.change(
            &format!("{}_font_size", role.prefix()),
            size.map(|size| toml_edit::Value::from(size as f64)),
        );
    }

    fn change(&mut self, field: &str, value: Option<toml_edit::Value>) {
        self.pending.insert(field.into(), value);
        self.error = None;
        self.reader.cancel();
        self.refresh_fonts();
    }

    pub fn retry(&mut self) {
        self.error = None;
        self.reload = true;
    }

    pub fn saving(&self) -> bool {
        !self.writing.is_empty() || (!self.pending.is_empty() && self.error.is_none())
    }

    fn update_watch(&mut self) {
        let mut paths = vec![existing_parent(self.path.parent().unwrap())];
        let schemes = self.path.parent().unwrap().join("schemes");
        if schemes.is_dir() {
            paths.push(schemes);
        }
        paths.extend(
            self.files
                .iter()
                .filter_map(|file| file.parent())
                .map(existing_parent),
        );
        if let Err(error) = self.watch.update(paths) {
            self.error = Some(error.to_string());
        }
    }

    pub fn poll(&mut self) -> bool {
        let mut changed = self.system.poll();
        let events = self.watch.take();
        if events.iter().any(|path| {
            !path.as_os_str().is_empty()
                && (path == &self.path
                    || path.starts_with(self.path.parent().unwrap().join("schemes"))
                    || path == self.path.parent().unwrap()
                    || self.files.iter().any(|file| file.starts_with(path)))
        }) {
            self.reload = true;
        }
        if let Some(error) = self.watch.error() {
            self.error = Some(format!("Could not watch appearance settings: {error}"));
            changed = true;
        }
        if let Some(result) = self.writer.take() {
            if let Err(error) = result {
                for (key, value) in std::mem::take(&mut self.writing) {
                    self.pending.entry(key).or_insert(value);
                }
                self.error = Some(error);
            } else {
                self.writing.clear();
                self.reload = true;
            }
            changed = true;
        }
        if self.error.is_some()
            && self.writing.is_empty()
            && events.iter().any(|path| path == &self.path)
        {
            self.pending.clear();
        }
        if !self.saving()
            && self.pending.is_empty()
            && let Some(result) = self.reader.take()
        {
            match result {
                Ok(loaded) => {
                    self.options = loaded.options;
                    self.schemes = loaded.schemes;
                    self.desktop = loaded.desktop;
                    self.gtk_ui_font = loaded.ui_font;
                    self.gtk_preview_font = loaded.preview_font;
                    self.files = loaded.files;
                    self.error = None;
                    self.update_watch();
                }
                Err(error) => self.error = Some(error),
            }
            changed = true;
        }
        if self.writing.is_empty() && !self.pending.is_empty() && self.error.is_none() {
            self.reader.cancel();
            self.writing = std::mem::take(&mut self.pending);
            self.writer.request(
                (self.path.clone(), self.writing.clone()),
                |(path, changes)| save(&path, changes),
            );
            changed = true;
        } else if self.reload && !self.saving() && self.pending.is_empty() {
            self.reload = false;
            let root = self.path.parent().unwrap().to_path_buf();
            self.reader
                .request((root, self.system_config.clone()), |(root, system)| {
                    load(&root, &system)
                });
        }
        if changed {
            self.refresh_fonts();
            self.refresh_editors();
        }
        changed
    }

    pub fn snapshot(&self) -> serde_json::Value {
        serde_json::json!({"options": self.options, "open": self.open, "page_dark": self.page_dark, "fonts_open": self.fonts_open, "font_role": self.font_role.prefix(),
            "error": self.error, "saving": self.saving(), "path": self.path,
            "ui_font": self.font(Role::Interface), "list_font": self.font(Role::Files), "preview_font": self.font(Role::Preview), "text_scale": self.system.text_scale,
            "system_dark_palette": self.desktop.is_some_and(|palette| palette.dark),
            "system_light_palette": self.desktop.is_some_and(|palette| !palette.dark),
            "system_accent": self.system.accent.map(|color| [color.r, color.g, color.b]),
            "schemes": self.schemes.iter().map(|scheme| serde_json::json!({"id":scheme.id,"name":scheme.name,"dark":scheme.palette.dark})).collect::<Vec<_>>()})
    }
}

fn existing_parent(path: &Path) -> PathBuf {
    path.ancestors()
        .find(|path| path.is_dir())
        .unwrap_or(Path::new("/"))
        .to_path_buf()
}

fn read(path: &Path) -> Result<String, String> {
    match fs::read_to_string(path) {
        Ok(source) => Ok(source),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(String::new()),
        Err(error) => Err(format!("{}: {error}", path.display())),
    }
}

pub(crate) fn options(source: &str) -> Result<Options, String> {
    let table: toml::Table = toml::from_str(source).map_err(|error| error.to_string())?;
    table
        .get("appearance")
        .cloned()
        .map(|value| value.try_into().map_err(|error| error.to_string()))
        .unwrap_or_else(|| Ok(Options::default()))
}

fn load(root: &Path, system: &Path) -> Result<Loaded, String> {
    let path = root.join("config.toml");
    let options = options(&read(&path)?).map_err(|error| format!("{}: {error}", path.display()))?;
    for (role, family) in [
        (Role::Interface, &options.ui_font),
        (Role::Files, &options.list_font),
        (Role::Preview, &options.preview_font),
    ] {
        if family != "system"
            && !(role == Role::Files && family == "monospace")
            && crate::font::canonical(family).is_none()
        {
            return Err(format!("Font family is not installed: {family}"));
        }
    }
    for (name, size, max) in [
        ("ui_font_size", options.ui_font_size, 18.0),
        ("list_font_size", options.list_font_size, 18.0),
        ("preview_font_size", options.preview_font_size, 24.0),
    ] {
        if size.is_some_and(|size| !size.is_finite() || !(8.0..=max).contains(&size)) {
            return Err(format!("{name} must be between 8 and {max} points"));
        }
    }
    let mut schemes = scheme::builtins();
    let builtins = schemes.clone();
    let directory = root.join("schemes");
    match fs::read_dir(&directory) {
        Ok(entries) => {
            let mut paths = entries
                .map(|entry| entry.map(|entry| entry.path()))
                .collect::<Result<Vec<_>, _>>()
                .map_err(|error| error.to_string())?;
            paths.sort();
            for path in paths.into_iter().filter(|path| {
                path.extension()
                    .is_some_and(|extension| extension == "toml")
            }) {
                let id = path
                    .file_stem()
                    .and_then(|name| name.to_str())
                    .ok_or("Scheme filenames must use UTF-8")?;
                if schemes.iter().any(|scheme| scheme.id == id) {
                    return Err(format!(
                        "{}: this id belongs to a built-in scheme",
                        path.display()
                    ));
                }
                let scheme = Scheme::parse(id, &read(&path)?, &builtins)
                    .map_err(|error| format!("{}: {error}", path.display()))?;
                schemes.push(scheme);
            }
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => return Err(format!("{}: {error}", directory.display())),
    }
    for (id, dark) in [(&options.light_scheme, false), (&options.dark_scheme, true)] {
        if id != "system"
            && !schemes
                .iter()
                .any(|scheme| &scheme.id == id && scheme.palette.dark == dark)
        {
            return Err(format!(
                "Choose a {} scheme for {}: {id}",
                if dark { "dark" } else { "light" },
                if dark { "dark_scheme" } else { "light_scheme" }
            ));
        }
    }
    let (desktop, mut files) = system_appearance::gtk(system, &builtins);
    let (ui_font, preview_font, font_files) = system_appearance::gtk_fonts(system);
    files.extend(font_files);
    files.extend([path, directory]);
    Ok(Loaded {
        options,
        schemes,
        desktop,
        ui_font,
        preview_font,
        files,
    })
}

fn save(path: &Path, changes: BTreeMap<String, Option<toml_edit::Value>>) -> Result<(), String> {
    let parent = path.parent().unwrap();
    fs::create_dir_all(parent).map_err(|error| error.to_string())?;
    let lock = fs::OpenOptions::new()
        .create(true)
        .truncate(false)
        .read(true)
        .write(true)
        .open(path.with_extension("lock"))
        .map_err(|error| error.to_string())?;
    lock.lock().map_err(|error| error.to_string())?;
    if let Ok(metadata) = fs::symlink_metadata(path)
        && (metadata.file_type().is_symlink() || metadata.permissions().readonly())
    {
        return Err(format!(
            "{} is managed externally or read-only. Edit its source to save appearance settings.",
            path.display()
        ));
    }
    let source = read(path)?;
    options(&source)?;
    let mut document: toml_edit::DocumentMut = source
        .parse()
        .map_err(|error: toml_edit::TomlError| error.to_string())?;
    if !document.contains_key("appearance") {
        document["appearance"] = toml_edit::Item::Table(toml_edit::Table::new());
    }
    for (key, value) in changes {
        if let Some(mut value) = value {
            if let Some(old) = document["appearance"]
                .get(&key)
                .and_then(toml_edit::Item::as_value)
            {
                *value.decor_mut() = old.decor().clone();
            }
            document["appearance"][&key] = toml_edit::Item::Value(value);
        } else if let Some(table) = document["appearance"].as_table_like_mut() {
            table.remove(&key);
        }
    }
    let mut temporary = tempfile::Builder::new()
        .prefix(".vereda-config-")
        .tempfile_in(parent)
        .map_err(|error| error.to_string())?;
    temporary
        .write_all(document.to_string().as_bytes())
        .map_err(|error| error.to_string())?;
    temporary
        .as_file()
        .sync_all()
        .map_err(|error| error.to_string())?;
    temporary.persist(path).map_err(|error| error.to_string())?;
    Ok(())
}
