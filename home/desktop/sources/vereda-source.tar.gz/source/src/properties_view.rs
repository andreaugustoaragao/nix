use rune::{Color, El, ScrollSpec, col, el, row, text};

use crate::{
    icon,
    locations::Properties,
    properties::Tab,
    state::State,
    theme::Theme,
    ui::{action_button, input},
};

fn check(checked: bool, p: Theme) -> El {
    el().w(16.0)
        .h(16.0)
        .radius(p.space(1))
        .fill(if checked {
            p.accent
        } else {
            Color::TRANSPARENT
        })
        .border(1.0, if checked { p.accent } else { p.line })
        .center()
        .child(if checked {
            rune::icon(&icon::CHECK, 13.0).color(p.background)
        } else {
            el()
        })
}

fn line(label: &str, value: impl Into<String>, p: Theme) -> El {
    let label_width = (p.font(12.0, 500.0).line_px() * 6.0).max(100.0);
    row()
        .w_full()
        .gap(p.space(3))
        .child(
            text(label)
                .font(p.font(12.0, 500.0))
                .color(p.muted)
                .w(label_width)
                .wrap_anywhere(),
        )
        .child(
            text(value)
                .font(p.font(13.0, 400.0))
                .color(p.text)
                .grow(1.0)
                .min_w(0.0)
                .wrap_anywhere(),
        )
}

fn general(s: &State, properties: &Properties, p: Theme) -> El {
    let dialog = &s.property_dialog;
    let mut body = col()
        .key("properties-general")
        .w_full()
        .gap(p.space(3))
        .child(text("Name").font(p.font(12.0, 500.0)).color(p.muted))
        .child(
            input(&dialog.name, p.font(14.0, 400.0), p.height(40.0), p)
                .key("properties-name")
                .label("Name")
                .w_full()
                .px(p.space(2))
                .fill(p.background)
                .border(1.0, p.line)
                .radius(p.space(1))
                .color(p.text)
                .disabled(properties.remote)
                .on_input_key(|s: &mut State, key, tx| {
                    if matches!(key.key, rune::Key::Escape) {
                        s.close_properties(tx);
                        true
                    } else {
                        false
                    }
                })
                .on_edit(|s: &mut State| &mut s.property_dialog.name)
                .on_submit(|s: &mut State, tx| s.apply_properties(tx)),
        )
        .child(line("Kind", &properties.kind, p))
        .child(line("MIME type", &properties.mime, p))
        .child(line("Size", &properties.size, p))
        .child(line("Location", s.display_location(&properties.path), p))
        .child(el().w_full().h(1.0).fill(p.line))
        .child(line("Modified", &properties.modified, p))
        .child(line("Created", &properties.created, p));
    if let Some(target) = &properties.link_target {
        body = body.child(line("Link target", target, p));
    }
    if properties.remote {
        body = body.child(
            text("Editing properties on remote locations is unavailable.")
                .font(p.font(12.0, 400.0))
                .color(p.muted)
                .w_full()
                .wrap(),
        );
    }
    body
}

fn permissions(s: &State, properties: &Properties, p: Theme, width: f32) -> El {
    let dialog = &s.property_dialog;
    let editable = properties.can_change_mode;
    let line_height = p.font(12.0, 600.0).line_px();
    let available = (width - p.space(10) - line_height * 5.0 - p.space(3)) / 3.0;
    let cell_width = (line_height * 4.5).max(74.0).min(available.max(48.0));
    let reason = if properties.remote {
        "Permission editing on remote locations is unavailable."
    } else if properties.kind == "Symbolic link" {
        "Symbolic link permissions are not editable."
    } else if properties.mode.is_none() {
        "This filesystem does not expose Unix permissions."
    } else if !editable {
        "Only the file owner can change these permissions."
    } else {
        "Changes apply to this item unless you choose its enclosed items."
    };
    let mut body = col()
        .key("properties-permissions")
        .w_full()
        .gap(p.space(3))
        .child(
            text(reason)
                .font(p.font(12.0, 400.0))
                .color(p.muted)
                .w_full()
                .wrap(),
        )
        .child(line("Owner", &properties.owner, p))
        .child(line("Group", &properties.group, p))
        .child(el().w_full().h(1.0).fill(p.line))
        .child(
            row()
                .w_full()
                .gap(p.space(1))
                .child(
                    text("Who")
                        .font(p.font(12.0, 600.0))
                        .color(p.muted)
                        .grow(1.0),
                )
                .child(
                    text("Read")
                        .font(p.font(12.0, 600.0))
                        .color(p.muted)
                        .w(cell_width)
                        .align(rune::Align::Center)
                        .wrap_anywhere(),
                )
                .child(
                    text("Write")
                        .font(p.font(12.0, 600.0))
                        .color(p.muted)
                        .w(cell_width)
                        .align(rune::Align::Center)
                        .wrap_anywhere(),
                )
                .child(
                    text("Execute")
                        .font(p.font(12.0, 600.0))
                        .color(p.muted)
                        .w(cell_width)
                        .align(rune::Align::Center)
                        .wrap_anywhere(),
                ),
        );
    for (who, shift) in [("Owner", 6), ("Group", 3), ("Others", 0)] {
        let mut rights = row()
            .w_full()
            .gap(p.space(1))
            .child(text(who).font(p.font(13.0, 400.0)).color(p.text).grow(1.0));
        for (right, offset) in [("Read", 2), ("Write", 1), ("Execute", 0)] {
            let bit = 1 << (shift + offset);
            let checked = dialog.mode & bit != 0;
            rights = rights.child(
                row()
                    .key(format!(
                        "permission-{}-{}",
                        who.to_lowercase(),
                        right.to_lowercase()
                    ))
                    .role("checkbox")
                    .label(format!("{who} {right}"))
                    .checked(checked)
                    .focusable(editable)
                    .disabled(!editable)
                    .opacity(if editable { 1.0 } else { 0.5 })
                    .focus_ring(2.0, 0.0, p.accent)
                    .cursor(if editable {
                        rune::Cursor::Pointer
                    } else {
                        rune::Cursor::Default
                    })
                    .on_press(move |s: &mut State| {
                        if !editable {
                            return;
                        }
                        s.property_dialog.toggle(bit);
                    })
                    .w(cell_width)
                    .h(p.height(32.0))
                    .center()
                    .child(check(checked, p)),
            );
        }
        body = body.child(rights);
    }
    if properties.directory {
        body = body.child(
            row()
                .key("properties-recursive")
                .role("checkbox")
                .label("Apply to enclosed items")
                .checked(dialog.recursive)
                .focusable(editable)
                .disabled(!editable)
                .opacity(if editable { 1.0 } else { 0.5 })
                .focus_ring(2.0, 0.0, p.accent)
                .cursor(if editable {
                    rune::Cursor::Pointer
                } else {
                    rune::Cursor::Default
                })
                .on_press(move |s: &mut State| {
                    if !editable {
                        return;
                    }
                    s.property_dialog.recursive = !s.property_dialog.recursive;
                })
                .w_full()
                .h(p.height(32.0))
                .gap(p.space(2))
                .center_y()
                .child(check(dialog.recursive, p))
                .child(
                    text("Apply to enclosed items")
                        .font(p.font(12.0, 400.0))
                        .color(p.text),
                ),
        );
        if dialog.recursive {
            body = body.child(text("Symbolic links are skipped. Regular files without execute access will remain non-executable. Special bits are preserved for each item.")
                .font(p.font(12.0, 400.0)).color(p.muted).w_full().wrap());
        }
    }
    body.child(
        action_button(
            if dialog.advanced {
                "▾ Advanced"
            } else {
                "▸ Advanced"
            },
            p,
            |s, _| {
                s.property_dialog.advanced = !s.property_dialog.advanced;
            },
        )
        .key("properties-advanced")
        .h(p.height(32.0)),
    )
    .child(if dialog.advanced {
        text(properties.mode.map_or_else(
            || "Numeric permissions unavailable".into(),
            |_| format!("Numeric permissions: {:04o}", dialog.mode),
        ))
        .font(p.font(12.0, 400.0))
        .color(p.muted)
    } else {
        el().h(0.0)
    })
}

pub fn view(s: &State, p: Theme, width: f32, height: f32) -> El {
    let dialog_width = (width - p.space(8)).clamp(240.0, 620.0);
    let properties = s.properties.as_ref();
    let dialog = &s.property_dialog;
    let selected = dialog.tab;
    let mut content = col().w_full().gap(p.space(3)).padding(p.space(5)).child(
        text("Properties")
            .font(p.font(20.0, 600.0))
            .color(p.text)
            .w_full(),
    );
    if let Some(properties) = properties {
        content = content
            .child(
                text(&properties.name)
                    .font(p.font(16.0, 600.0))
                    .color(p.text)
                    .w_full()
                    .truncate(),
            )
            .child(
                text(&properties.kind)
                    .font(p.font(12.0, 400.0))
                    .color(p.muted),
            )
            .child(
                row()
                    .w_full()
                    .gap(p.space(2))
                    .role("tablist")
                    .label("Property sections")
                    .child(
                        action_button("General", p, |s, _| {
                            s.property_dialog.tab = Tab::General;
                            s.property_dialog.name.focused = true;
                        })
                        .key("properties-general-tab")
                        .role("tab")
                        .checked(selected == Tab::General)
                        .fill(if selected == Tab::General {
                            p.selected
                        } else {
                            p.background
                        }),
                    )
                    .child(
                        action_button("Permissions", p, |s, tx| {
                            s.property_dialog.tab = Tab::Permissions;
                            s.property_dialog.name.focused = false;
                            tx.blur();
                        })
                        .key("properties-permissions-tab")
                        .role("tab")
                        .checked(selected == Tab::Permissions)
                        .fill(if selected == Tab::Permissions {
                            p.selected
                        } else {
                            p.background
                        }),
                    ),
            )
            .child(if selected == Tab::General {
                general(s, properties, p)
            } else {
                permissions(s, properties, p, dialog_width)
            });
    } else {
        content = content.child(
            text("Reading file properties…")
                .font(p.font(13.0, 400.0))
                .color(p.muted),
        );
    }
    let error = properties.and_then(|_| dialog.name_error());
    content = content.child(
        text(error.unwrap_or(""))
            .font(p.font(12.0, 400.0))
            .color(p.muted)
            .h(p.height(20.0)),
    );
    let can_apply =
        properties.is_some_and(|properties| !properties.remote && dialog.can_apply(properties));
    el().key("properties-dialog")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .role("dialog")
        .label("Properties")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| s.dismiss_properties())
        .focus_return(s.property_focus.as_deref().unwrap_or("current"))
        .child(
            col()
                .w(dialog_width)
                .max_h((height - p.space(8)).max(160.0))
                .fill(p.panel)
                .border(1.0, p.line)
                .radius(p.space(2))
                .child(
                    col()
                        .w_full()
                        .max_h((height - p.space(8) - p.height(64.0)).max(100.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(
                    row()
                        .w_full()
                        .gap(p.space(2))
                        .padding(p.space(3))
                        .child(el().grow(1.0))
                        .child(
                            action_button("Cancel", p, |s, tx| s.close_properties(tx))
                                .key("properties-cancel")
                                .h(p.height(36.0)),
                        )
                        .child(
                            action_button("Apply", p, |s, tx| s.apply_properties(tx))
                                .key("properties-apply")
                                .default_button()
                                .fill(p.selected)
                                .disabled(!can_apply)
                                .opacity(if can_apply { 1.0 } else { 0.4 })
                                .h(p.height(36.0)),
                        ),
                ),
        )
}
