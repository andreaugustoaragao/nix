//! Hover contents card. The row calls [`Peek::open`] after Rune's enter delay and
//! [`Peek::leave`] after the leave grace. The card's own hover uses no enter delay and a 150ms
//! leave grace, so the pointer can cross the gap without the card closing.
//!
//! `result` is `None` while a listing is in flight. A new folder clears it before the read
//! returns, so a previous folder's files are never shown under the new heading.

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

use rune::{Align, Color, El, Latest, ScrollSpec, Side, Waker, col, el, row, text};

use crate::file::{self, File};
use crate::icon;
use crate::preference::Preference;
use crate::state::State;
use crate::theme::Theme;

const ENUM_LIMIT: usize = 512;
const SHOW_LIMIT: usize = 60;
const REMOTE: &str = "Remote folders aren't listed on hover. Open the folder to browse it.";

#[derive(Clone)]
pub struct Target {
    pub path: PathBuf,
    pub anchor: String,
    pub side: usize,
    pub origin: PathBuf,
    pub scroll: f32,
}

#[derive(Clone)]
pub struct Contents {
    pub files: Vec<File>,
    pub truncated: bool,
}

struct Loaded {
    path: PathBuf,
    outcome: Result<Contents, String>,
}

#[derive(Default)]
pub struct Peek {
    pub target: Option<Target>,
    pub result: Option<Result<Contents, String>>,
    anchor_inside: bool,
    card_inside: bool,
    held_remote: bool,
    reads: Latest<Loaded>,
    stop: Option<Arc<AtomicBool>>,
}

impl Peek {
    pub fn set_waker(&self, waker: Waker) {
        self.reads.set_waker(waker);
    }

    /// Pointer entered `target`'s anchor. The same folder keeps its listing; any other folder
    /// drops the previous result and starts a new read. `remote` never touches the filesystem.
    pub fn open(&mut self, target: Target, preference: Preference, remote: bool) {
        let same = remote == self.held_remote
            && self
                .target
                .as_ref()
                .is_some_and(|current| current.path == target.path);
        self.anchor_inside = true;
        if same {
            self.target = Some(target);
            return;
        }

        self.card_inside = false;
        self.held_remote = remote;
        self.cancel_read();
        self.result = None;
        let path = target.path.clone();
        self.target = Some(target);
        if remote {
            self.result = Some(Err(REMOTE.into()));
            return;
        }

        let stop = Arc::new(AtomicBool::new(false));
        self.stop = Some(stop.clone());
        self.reads
            .request_opt((path, preference, stop), |(path, preference, stop)| {
                read_limited(&path, preference, &stop).map(|outcome| Loaded { path, outcome })
            });
    }

    /// Pointer left this anchor. The card stays up while the pointer is inside it.
    pub fn leave(&mut self, anchor: &str) {
        if self
            .target
            .as_ref()
            .is_some_and(|target| target.anchor == anchor)
        {
            self.anchor_inside = false;
            if !self.card_inside {
                self.close();
            }
        }
    }

    /// Card hover. `false` closes the card only after the anchor has also been left.
    pub fn card(&mut self, inside: bool) {
        if self.target.is_none() {
            return;
        }
        self.card_inside = inside;
        if !inside && !self.anchor_inside {
            self.close();
        }
    }

    pub fn close(&mut self) {
        self.cancel_read();
        self.target = None;
        self.result = None;
        self.anchor_inside = false;
        self.card_inside = false;
        self.held_remote = false;
    }

    /// Applies the newest listing when it is still the open folder. Returns whether `result` changed.
    pub fn poll(&mut self) -> bool {
        let Some(loaded) = self.reads.take() else {
            return false;
        };
        if self
            .target
            .as_ref()
            .is_some_and(|target| target.path == loaded.path)
        {
            self.result = Some(loaded.outcome);
            return true;
        }
        false
    }

    fn cancel_read(&mut self) {
        if let Some(stop) = &self.stop {
            stop.store(true, Ordering::Relaxed);
        }
        self.reads.cancel();
    }
}

/// First page of one directory. This does not call [`file::read_folder`] or [`file::read_dir`]:
/// those stat every child, and `read_folder` also reads the parent.
///
/// The walk itself stops at [`ENUM_LIMIT`] names or [`SHOW_LIMIT`] metadata attempts. A failed
/// stat still uses one attempt. `stop` is checked before every directory entry and around every
/// stat, so a huge directory is abandoned without publishing a partial page. Remote peeks never
/// reach here. Reaching the name cap marks the page truncated without reading another entry.
fn read_limited(
    path: &Path,
    preference: Preference,
    stop: &AtomicBool,
) -> Option<Result<Contents, String>> {
    if stop.load(Ordering::Relaxed) {
        return None;
    }
    let mut entries = match fs::read_dir(path) {
        Ok(entries) => entries,
        Err(error) => {
            return Some(Err(format!("Can't read {}: {error}", path.display())));
        }
    };

    let mut files = Vec::with_capacity(SHOW_LIMIT);
    let mut enumerated = 0usize;
    let mut attempts = 0usize;
    let mut truncated = false;
    loop {
        if stop.load(Ordering::Relaxed) {
            return None;
        }
        if enumerated == ENUM_LIMIT {
            truncated = true;
            break;
        }
        let Some(entry) = entries.next() else {
            break;
        };
        enumerated += 1;
        let entry = match entry {
            Ok(entry) => entry,
            Err(error) => return Some(Err(format!("Can't read {}: {error}", path.display()))),
        };
        let hidden = entry.file_name().as_encoded_bytes().first() == Some(&b'.');
        if hidden && !preference.show_hidden {
            continue;
        }
        if attempts == SHOW_LIMIT {
            truncated = true;
            break;
        }
        if stop.load(Ordering::Relaxed) {
            return None;
        }
        attempts += 1;
        let file = file::read_file(entry.path());
        if stop.load(Ordering::Relaxed) {
            return None;
        }
        if let Some(file) = file {
            files.push(file);
        }
    }
    if stop.load(Ordering::Relaxed) {
        return None;
    }

    file::sort(
        &mut files,
        preference.sort_by,
        preference.sort_reverse,
        preference.sort_sensitive,
        preference.sort_dir_first,
    );
    Some(Ok(Contents { files, truncated }))
}

pub fn view(s: &State, p: Theme) -> El {
    let Some(target) = s.peek.target.as_ref() else {
        return el();
    };
    let anchor = target.anchor.clone();
    let path = target.path.clone();
    let side = target.side;
    let title = path
        .file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .unwrap_or_else(|| "/".into());
    let open_path = path.clone();
    let heading = col()
        .w_full()
        .gap(p.space(1))
        .px(p.space(2))
        .py(p.space(1))
        .child(
            text(title.clone())
                .font(p.font(13.0, 600.0))
                .color(p.text)
                .truncate()
                .w_full(),
        )
        .child(
            text(summary(&s.peek.result))
                .font(p.font(11.0, 400.0))
                .color(p.muted)
                .truncate()
                .w_full(),
        );
    let body = match &s.peek.result {
        None => note("Loading…", p),
        Some(Err(error)) => note(error, p),
        Some(Ok(contents)) if contents.files.is_empty() && contents.truncated => note(
            "No items in this preview. Open the folder to see all items.",
            p,
        ),
        Some(Ok(contents)) if contents.files.is_empty() => note("Empty folder", p),
        Some(Ok(contents)) => listing(contents, side, p),
    };

    col()
        .key("folder-peek")
        .role("group")
        .label(format!("Contents of {title}"))
        .w(320.0)
        .max_h(440.0)
        .min_h(0.0)
        .shrink()
        .padding(p.space(2))
        .gap(p.space(1))
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .shadow(5.0, 18.0, Color::BLACK.alpha(0.28))
        .on_hover_change(|s: &mut State, inside, _| s.peek.card(inside))
        .hover_delays(Duration::ZERO, Duration::from_millis(150))
        .anchored_fit(&anchor, Side::Right, Align::Start, p.space(1))
        .child(heading)
        .child(body)
        .child(el().w_full().h(1.0).fill(p.line.alpha(0.65)))
        .child(footer(open_path, side, p))
}

fn summary(result: &Option<Result<Contents, String>>) -> String {
    match result {
        None => "Loading…".into(),
        Some(Err(_)) => "Can't preview".into(),
        Some(Ok(contents)) if contents.truncated => {
            format!("{} shown, more remain", contents.files.len())
        }
        Some(Ok(contents)) if contents.files.is_empty() => "Empty folder".into(),
        Some(Ok(contents)) if contents.files.len() == 1 => "1 item".into(),
        Some(Ok(contents)) => format!("{} items", contents.files.len()),
    }
}

fn note(message: &str, p: Theme) -> El {
    text(message)
        .key("folder-peek-status")
        .font(p.font(12.0, 400.0))
        .color(p.muted)
        .w_full()
        .px(p.space(2))
        .py(p.space(2))
        .wrap()
        .help(message)
}

fn listing(contents: &Contents, side: usize, p: Theme) -> El {
    let mut rows = col().key("folder-peek-rows").w_full();
    for file in &contents.files {
        rows = rows.child(item(file, side, p));
    }
    if contents.truncated {
        rows = rows.child(
            text("More items in this folder")
                .font(p.font(11.0, 400.0))
                .color(p.muted)
                .w_full()
                .px(p.space(2))
                .py(p.space(2)),
        );
    }
    col()
        .key("folder-peek-scroll")
        .w_full()
        .max_h(300.0)
        .min_h(0.0)
        .shrink()
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .child(rows)
}

fn item(file: &File, side: usize, p: Theme) -> El {
    let path = file.path.clone();
    let directory = file.directory;
    let mut row = row()
        .key(format!("folder-peek-{}", file.key))
        .w_full()
        .h(p.height(32.0))
        .px(p.space(2))
        .gap(p.space(2))
        .center_y()
        .radius(p.space(2))
        .hover(p.selected.alpha(0.7))
        .cursor(rune::Cursor::Pointer)
        .on_press_tx(move |s: &mut State, tx| s.open_peek(path.clone(), directory, side, tx))
        .child(
            rune::icon(icon::for_file(file), 16.0).color(if file.directory {
                p.folder
            } else {
                p.muted
            }),
        )
        .child(
            text(&file.name)
                .font(p.font(13.0, 400.0))
                .color(p.text)
                .truncate()
                .min_w(0.0)
                .grow(1.0),
        );
    if file.directory {
        row = row.child(rune::icon(&icon::CHEVRON, 12.0).color(p.folder.alpha(0.75)));
    }
    row
}

fn footer(path: PathBuf, side: usize, p: Theme) -> El {
    row()
        .key("folder-peek-open")
        .role("button")
        .label("Open folder")
        .w_full()
        .h(p.height(32.0))
        .px(p.space(2))
        .gap(p.space(2))
        .center_y()
        .radius(p.space(2))
        .hover(p.selected)
        .cursor(rune::Cursor::Pointer)
        .on_press_tx(move |s: &mut State, tx| s.open_peek(path.clone(), true, side, tx))
        .child(rune::icon(&icon::FOLDER, 16.0).color(p.folder))
        .child(
            text("Open folder")
                .font(p.font(13.0, 500.0))
                .color(p.text)
                .truncate()
                .grow(1.0),
        )
}
