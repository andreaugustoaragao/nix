use std::{
    collections::{BTreeSet, HashMap},
    path::{Path, PathBuf},
    sync::{
        Arc, OnceLock,
        atomic::{AtomicBool, Ordering},
    },
    time::UNIX_EPOCH,
};

use fff_search::{
    FFFMode, FilePicker, FilePickerIgnoreOptions, FilePickerOptions, FrecencyTracker,
    FuzzySearchOptions, GrepMode, GrepSearchOptions, PaginationArgs, QueryParser, SharedFilePicker,
    SharedFrecency,
};

use crate::file::{self, File};

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize)]
pub struct Hit {
    pub line: u64,
    pub text: String,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FilterKind {
    Type,
    Modified,
    Size,
}

impl FilterKind {
    pub const ALL: [Self; 3] = [Self::Type, Self::Modified, Self::Size];

    pub fn key(self) -> &'static str {
        match self {
            Self::Type => "type",
            Self::Modified => "modified",
            Self::Size => "size",
        }
    }

    pub fn title(self) -> &'static str {
        match self {
            Self::Type => "Type",
            Self::Modified => "Modified",
            Self::Size => "Size",
        }
    }

    pub fn options(self) -> &'static [&'static str] {
        match self {
            Self::Type => &[
                "All types",
                "Documents",
                "Images",
                "PDF",
                "Archives",
                "Folders",
                "Code",
            ],
            Self::Modified => &["Any time", "Today", "This week", "This month"],
            Self::Size => &[
                "Any size",
                "Small (< 1 MiB)",
                "Medium (1–10 MiB)",
                "Large (≥ 10 MiB)",
            ],
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct SearchFilters {
    pub file_type: usize,
    pub modified: usize,
    pub size: usize,
}

impl SearchFilters {
    pub fn selected(self, kind: FilterKind) -> usize {
        match kind {
            FilterKind::Type => self.file_type,
            FilterKind::Modified => self.modified,
            FilterKind::Size => self.size,
        }
    }

    pub fn set(&mut self, kind: FilterKind, option: usize) -> bool {
        if option >= kind.options().len() || self.selected(kind) == option {
            return false;
        }
        match kind {
            FilterKind::Type => self.file_type = option,
            FilterKind::Modified => self.modified = option,
            FilterKind::Size => self.size = option,
        }
        true
    }

    pub fn matches(self, file: &File, now: Option<&gio::glib::DateTime>) -> bool {
        if self.file_type != 0 {
            let extension = file
                .path
                .extension()
                .and_then(|ext| ext.to_str())
                .unwrap_or_default();
            let extension = extension.to_ascii_lowercase();
            let pdf = extension == "pdf";
            let image = crate::thumbnail::is_image(file)
                || matches!(extension.as_str(), "bmp" | "tif" | "tiff" | "avif");
            let archive = matches!(
                extension.as_str(),
                "zip" | "tar" | "gz" | "bz2" | "xz" | "7z" | "rar" | "zst" | "tgz"
            );
            let code = matches!(
                extension.as_str(),
                "rs" | "lua"
                    | "py"
                    | "js"
                    | "jsx"
                    | "ts"
                    | "tsx"
                    | "go"
                    | "c"
                    | "h"
                    | "cpp"
                    | "hpp"
                    | "java"
                    | "sh"
                    | "rb"
                    | "php"
                    | "html"
                    | "css"
                    | "json"
                    | "toml"
                    | "yaml"
                    | "yml"
                    | "nix"
            );
            let document = pdf
                || matches!(
                    extension.as_str(),
                    "txt"
                        | "md"
                        | "rst"
                        | "rtf"
                        | "odt"
                        | "doc"
                        | "docx"
                        | "csv"
                        | "ods"
                        | "xls"
                        | "xlsx"
                        | "odp"
                        | "ppt"
                        | "pptx"
                );
            let matches_type = match self.file_type {
                1 => !file.directory && document,
                2 => !file.directory && image,
                3 => !file.directory && pdf,
                4 => !file.directory && archive,
                5 => file.directory,
                6 => !file.directory && code,
                _ => false,
            };
            if !matches_type {
                return false;
            }
        }

        if self.modified != 0 {
            let Some(date) = file
                .modified
                .and_then(|time| time.duration_since(UNIX_EPOCH).ok())
                .and_then(|duration| i64::try_from(duration.as_secs()).ok())
                .and_then(|seconds| gio::glib::DateTime::from_unix_local(seconds).ok())
            else {
                return false;
            };
            let Some(now) = now else {
                return false;
            };
            let key = |date: &gio::glib::DateTime| (date.year(), date.month(), date.day_of_month());
            let matches_date = match self.modified {
                1 => key(&date) == key(now),
                2 => now
                    .add_days(1 - now.day_of_week())
                    .is_ok_and(|start| key(&date) >= key(&start) && key(&date) <= key(now)),
                3 => {
                    date.year() == now.year()
                        && date.month() == now.month()
                        && key(&date) <= key(now)
                }
                _ => false,
            };
            if !matches_date {
                return false;
            }
        }

        match self.size {
            0 => true,
            1 => !file.directory && file.size < 1024 * 1024,
            2 => !file.directory && (1024 * 1024..10 * 1024 * 1024).contains(&file.size),
            3 => !file.directory && file.size >= 10 * 1024 * 1024,
            _ => false,
        }
    }
}

pub struct Picker {
    pub root: PathBuf,
    pub query: String,
    pub all_files: bool,
    pub recursive: bool,
    pub content: bool,
    pub regex: bool,
    pub filters: SearchFilters,
    pub menu: Option<FilterKind>,
    pub files: Vec<File>,
    pub hits: HashMap<PathBuf, Hit>,
    pub cursor: usize,
    pub selected: BTreeSet<PathBuf>,
    pub scroll: rune::Live<f32>,
    pub loading: bool,
    pub indexed: usize,
    pub scanning: bool,
    pub watching: bool,
    pub error: Option<String>,
}

pub struct SearchRequest {
    query: String,
    all_files: bool,
    content: bool,
    regex: bool,
    filters: SearchFilters,
}

impl From<&Picker> for SearchRequest {
    fn from(picker: &Picker) -> Self {
        Self {
            query: picker.query.clone(),
            all_files: picker.all_files,
            content: picker.content,
            regex: picker.regex,
            filters: picker.filters,
        }
    }
}

impl Picker {
    pub fn new(folder: PathBuf) -> Self {
        Self {
            root: folder,
            query: String::new(),
            all_files: false,
            recursive: false,
            content: false,
            regex: false,
            filters: SearchFilters::default(),
            menu: None,
            files: Vec::new(),
            hits: HashMap::new(),
            cursor: 0,
            selected: BTreeSet::new(),
            scroll: rune::Live::new(0.0),
            loading: true,
            indexed: 0,
            scanning: true,
            watching: false,
            error: None,
        }
    }

    pub fn file(&self) -> Option<&File> {
        self.files.get(self.cursor)
    }
}

pub struct Matches {
    pub files: Vec<File>,
    pub hits: HashMap<PathBuf, Hit>,
    pub indexed: usize,
    pub scanning: bool,
    pub watching: bool,
    pub note: Option<String>,
}

pub struct Engine {
    pub index: SharedFilePicker,
    pub warning: Option<String>,
}

impl Engine {
    pub fn new(root: PathBuf, all_files: bool, recursive: bool) -> Result<Self, String> {
        Self::create(root, all_files, recursive, recursive)
    }

    pub fn navigation(root: PathBuf) -> Result<Self, String> {
        Self::create(root, false, true, false)
    }

    fn create(
        root: PathBuf,
        all_files: bool,
        recursive: bool,
        watch: bool,
    ) -> Result<Self, String> {
        if recursive && root.parent().is_none() {
            return Err("Choose a folder below / before including subfolders.".into());
        }
        let root = root
            .to_str()
            .ok_or("Find files requires a folder with a UTF-8 path.")?;
        let (history, warning) = match history() {
            Ok(history) => (history.clone(), None),
            Err(error) => (SharedFrecency::default(), Some(error.clone())),
        };
        let engine = Self {
            index: SharedFilePicker::default(),
            warning,
        };
        let mut extra_ignore: Vec<String> = Vec::new();
        if !recursive {
            extra_ignore.push("/*/*".into());
        }
        if !all_files {
            extra_ignore.push("**/.*".into());
        }

        FilePicker::new_with_shared_state_and_ignore_options(
            engine.index.clone(),
            history,
            FilePickerOptions {
                base_path: root.into(),
                mode: FFFMode::Neovim,
                enable_home_dir_scanning: true,
                enable_fs_root_scanning: !recursive,
                watch,
                ..Default::default()
            },
            FilePickerIgnoreOptions {
                extra_ignore: extra_ignore.into(),
                disable_git: all_files,
                disable_ignore_files: all_files,
            },
        )
        .map_err(|error| format!("Could not index this folder: {error}"))?;
        Ok(engine)
    }

    pub fn search(
        index: SharedFilePicker,
        request: SearchRequest,
        abort: Arc<AtomicBool>,
    ) -> Result<Matches, String> {
        let SearchRequest {
            query,
            all_files,
            content,
            regex,
            filters,
        } = request;
        let guard = index.read().map_err(|error| error.to_string())?;
        let picker = guard.as_ref().ok_or("File index is unavailable")?;
        let now = gio::glib::DateTime::now_local().ok();
        if content && filters.file_type == 5 {
            let progress = picker.get_scan_progress();
            return Ok(Matches {
                files: Vec::new(),
                hits: HashMap::new(),
                indexed: picker.live_file_count(),
                scanning: progress.is_scanning,
                watching: progress.is_watcher_ready,
                note: Some(
                    "Folders have no searchable contents. Switch to Names to find folders.".into(),
                ),
            });
        }
        if content {
            let query = fff_search::parse_grep_query(&query);
            let mut offset = 0;
            let mut note = None;
            let mut files = Vec::new();
            let mut hits = HashMap::new();
            loop {
                if abort.load(Ordering::Relaxed) {
                    break;
                }
                let result = picker.grep(
                    &query,
                    &GrepSearchOptions {
                        max_file_size: 32 * 1024 * 1024,
                        max_matches_per_file: 1,
                        page_limit: 100,
                        file_offset: offset,
                        mode: if regex {
                            GrepMode::Regex
                        } else {
                            GrepMode::PlainText
                        },
                        abort_signal: Some(abort.clone()),
                        ..Default::default()
                    },
                );
                if note.is_none() {
                    note = result.regex_fallback_error.as_ref().map(|error| {
                        format!("Invalid regular expression; showing literal matches: {error}")
                    });
                }
                let next = result.next_file_offset;
                for hit in result.matches {
                    if abort.load(Ordering::Relaxed) {
                        break;
                    }
                    let item = result.files[hit.file_index];
                    let relative = item.relative_path(picker);
                    if !all_files && relative.split('/').any(|part| part.starts_with('.')) {
                        continue;
                    }
                    if let Some(mut file) =
                        file::read_file(item.absolute_path(picker, picker.base_path()))
                    {
                        if !filters.matches(&file, now.as_ref()) {
                            continue;
                        }
                        file.name = relative;
                        hits.insert(
                            file.path.clone(),
                            Hit {
                                line: hit.line_number,
                                text: hit.line_content,
                            },
                        );
                        files.push(file);
                        if files.len() == 100 {
                            break;
                        }
                    }
                }
                if files.len() == 100 || next == 0 || next <= offset {
                    break;
                }
                offset = next;
            }
            let progress = picker.get_scan_progress();
            return Ok(Matches {
                files,
                hits,
                indexed: picker.live_file_count(),
                scanning: progress.is_scanning,
                watching: progress.is_watcher_ready,
                note,
            });
        }
        let parser = QueryParser::default();
        let query = parser.parse(&query);
        if filters.file_type == 5 {
            let mut files = Vec::new();
            let mut offset = 0;
            loop {
                if abort.load(Ordering::Relaxed) {
                    break;
                }
                let matches = picker.fuzzy_search_directories(
                    &query,
                    FuzzySearchOptions {
                        max_threads: 2,
                        pagination: PaginationArgs { offset, limit: 100 },
                        ..Default::default()
                    },
                );
                for item in &matches.items {
                    if abort.load(Ordering::Relaxed) {
                        break;
                    }
                    let relative = item.relative_path(picker);
                    if relative.is_empty()
                        || !all_files && relative.split('/').any(|part| part.starts_with('.'))
                    {
                        continue;
                    }
                    if let Some(mut file) =
                        file::read_file(item.absolute_path(picker, picker.base_path()))
                    {
                        if !file.directory || !filters.matches(&file, now.as_ref()) {
                            continue;
                        }
                        file.name = relative.trim_end_matches('/').to_owned();
                        files.push(file);
                        if files.len() == 100 {
                            break;
                        }
                    }
                }
                offset += matches.items.len();
                if files.len() == 100 || matches.items.is_empty() || offset >= matches.total_matched
                {
                    break;
                }
            }
            let progress = picker.get_scan_progress();
            return Ok(Matches {
                files,
                hits: HashMap::new(),
                indexed: picker.live_file_count(),
                scanning: progress.is_scanning,
                watching: progress.is_watcher_ready,
                note: None,
            });
        }
        let mut files = Vec::new();
        let mut offset = 0;
        loop {
            if abort.load(Ordering::Relaxed) {
                break;
            }
            let matches = picker.fuzzy_search(
                &query,
                None,
                FuzzySearchOptions {
                    max_threads: 2,
                    pagination: PaginationArgs { offset, limit: 100 },
                    ..Default::default()
                },
            );
            for item in &matches.items {
                if abort.load(Ordering::Relaxed) {
                    break;
                }
                let relative = item.relative_path(picker);
                if !all_files && relative.split('/').any(|part| part.starts_with('.')) {
                    continue;
                }
                if let Some(mut file) =
                    file::read_file(item.absolute_path(picker, picker.base_path()))
                {
                    if !filters.matches(&file, now.as_ref()) {
                        continue;
                    }
                    file.name = relative;
                    files.push(file);
                    if files.len() == 100 {
                        break;
                    }
                }
            }
            offset += matches.items.len();
            if files.len() == 100 || matches.items.is_empty() || offset >= matches.total_matched {
                break;
            }
        }
        let progress = picker.get_scan_progress();
        Ok(Matches {
            files,
            hits: HashMap::new(),
            indexed: picker.live_file_count(),
            scanning: progress.is_scanning,
            watching: progress.is_watcher_ready,
            note: None,
        })
    }
}

impl Drop for Engine {
    fn drop(&mut self) {
        self.index.cancel();
        if let Ok(mut guard) = self.index.write()
            && let Some(index) = guard.as_mut()
        {
            index.stop_background_monitor();
        }
    }
}

fn history() -> &'static Result<SharedFrecency, String> {
    static HISTORY: OnceLock<Result<SharedFrecency, String>> = OnceLock::new();
    HISTORY.get_or_init(|| {
        let path = crate::state::frecency_path();
        let tracker = FrecencyTracker::open(path)
            .map_err(|error| format!("Ranking history is unavailable: {error}"))?;
        let history = SharedFrecency::default();
        history.init(tracker).map_err(|error| error.to_string())?;
        Ok(history)
    })
}

pub fn record(path: &Path) -> Result<(), String> {
    let guard = history()
        .as_ref()
        .map_err(Clone::clone)?
        .read()
        .map_err(|error| error.to_string())?;
    if let Some(history) = guard.as_ref() {
        history
            .track_access(path)
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}
