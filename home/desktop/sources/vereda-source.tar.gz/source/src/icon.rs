use rune::Icon;

use crate::{
    file::File,
    locations::{Place, PlaceKind},
};

pub static FOLDER: Icon = Icon {
    name: "folder",
    view: 16.0,
    body: r#"<path d="M1.5 3h5l2 2h6v8h-13Z" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static FILE: Icon = Icon {
    name: "file",
    view: 16.0,
    body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static CODE: Icon = Icon {
    name: "source-code",
    view: 16.0,
    body: r#"<path d="m5 4-4 4 4 4m6-8 4 4-4 4m-2-10-2 12" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

static IMAGE: Icon = Icon {
    name: "image-file",
    view: 16.0,
    body: r#"<rect x="1.5" y="2" width="13" height="12" rx="1" stroke="currentColor"/><circle cx="5" cy="5.5" r="1" fill="currentColor"/><path d="m2 12 4-4 3 3 2-2 3 3" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static AUDIO: Icon = Icon {
    name: "audio-file",
    view: 16.0,
    body: r#"<path d="M6 11V3l7-1v8M6 5l7-1" stroke="currentColor"/><ellipse cx="4" cy="12" rx="2" ry="1.5" stroke="currentColor"/><ellipse cx="11" cy="11" rx="2" ry="1.5" stroke="currentColor"/>"#,
};

static VIDEO: Icon = Icon {
    name: "video-file",
    view: 16.0,
    body: r#"<rect x="1.5" y="3" width="9" height="10" rx="1" stroke="currentColor"/><path d="m10.5 6 4-2v8l-4-2" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static ARCHIVE: Icon = Icon {
    name: "archive-file",
    view: 16.0,
    body: r#"<rect x="2" y="2" width="12" height="3" rx=".5" stroke="currentColor"/><path d="M3 5v9h10V5M6 8h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static DOCUMENT: Icon = Icon {
    name: "document-file",
    view: 16.0,
    body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4M5 8h6M5 10h6M5 12h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static CONFIG: Icon = Icon {
    name: "configuration-file",
    view: 16.0,
    body: r#"<path d="M2 4h3m3 0h6M2 8h7m3 0h2M2 12h1m3 0h8" stroke="currentColor"/><circle cx="6.5" cy="4" r="1.5" stroke="currentColor"/><circle cx="10.5" cy="8" r="1.5" stroke="currentColor"/><circle cx="4.5" cy="12" r="1.5" stroke="currentColor"/>"#,
};

static DATABASE: Icon = Icon {
    name: "database-file",
    view: 16.0,
    body: r#"<ellipse cx="8" cy="3.5" rx="5.5" ry="2" stroke="currentColor"/><path d="M2.5 3.5v9c0 2.5 11 2.5 11 0v-9M2.5 8c0 2.5 11 2.5 11 0" stroke="currentColor"/>"#,
};

static TERMINAL: Icon = Icon {
    name: "shell-script",
    view: 16.0,
    body: r#"<path d="m2 4 4 4-4 4m6 0h6" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static LINK: Icon = Icon {
    name: "symbolic-link",
    view: 16.0,
    body: r#"<path d="M4 12 12 4M5 4h7v7" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static STAR: Icon = Icon {
    name: "favorite",
    view: 16.0,
    body: r#"<path d="m8 1.5 2.0 4.1 4.5.6-3.25 3.2.75 4.5L8 11.8l-4 2.1.75-4.5L1.5 6.2l4.5-.6Z" fill="none" stroke="currentColor" stroke-linejoin="round"/>"#,
};

pub static STAR_FILLED: Icon = Icon {
    name: "favorite-selected",
    view: 16.0,
    body: r#"<path d="m8 1.5 2.0 4.1 4.5.6-3.25 3.2.75 4.5L8 11.8l-4 2.1.75-4.5L1.5 6.2l4.5-.6Z" fill="currentColor" stroke="currentColor" stroke-linejoin="round"/>"#,
};

pub static CHECK: Icon = Icon {
    name: "selected",
    view: 16.0,
    body: r#"<path d="m2.5 8 3.5 3.5 7.5-7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static BACK: Icon = Icon {
    name: "back",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m10 3-5 5 5 5"/>"#,
};

pub static FORWARD: Icon = Icon {
    name: "forward",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m6 3 5 5-5 5"/>"#,
};

pub static UP: Icon = Icon {
    name: "up",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 14V2m-5 5 5-5 5 5"/>"#,
};

pub static SIDEBAR: Icon = Icon {
    name: "sidebar",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="1.5" y="2.5" width="13" height="11" rx="1.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M6 3v10"/>"#,
};

pub static SEARCH: Icon = Icon {
    name: "search",
    view: 16.0,
    body: r#"<circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="7" cy="7" r="4.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m10.5 10.5 4 4"/>"#,
};

pub static SPLIT: Icon = Icon {
    name: "split-view",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="1.5" y="2.5" width="13" height="11" rx="1.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 3v10"/>"#,
};

pub static SETTINGS: Icon = Icon {
    name: "settings",
    view: 24.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="m9.5 3-.6 2.2-1.7 1L5 5.6 2.6 9.8l1.6 1.6v2L2.6 15 5 19.2l2.2-.6 1.7 1 .6 2.2h5l.6-2.2 1.7-1 2.2.6 2.4-4.2-1.6-1.6v-2l1.6-1.6L19 5.6l-2.2.6-1.7-1L14.5 3Z"/><circle cx="12" cy="12.4" r="3.1" fill="none" stroke="currentColor" stroke-width="1.8"/>"#,
};

pub static SORT_DESCENDING: Icon = Icon {
    name: "sort-descending",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M3 2v12m-2-2 2 2 2-2M8 4h6M8 8h4M8 12h2"/>"#,
};
pub static SORT_ASCENDING: Icon = Icon {
    name: "sort-ascending",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M3 14V2M1 4l2-2 2 2M8 4h2M8 8h4M8 12h6"/>"#,
};
pub static SORT_BY: Icon = Icon {
    name: "sort-by",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M2 4h12M2 8h12M2 12h12"/><circle fill="none" stroke="currentColor" stroke-width="1.3" cx="5" cy="4" r="1.5"/><circle fill="none" stroke="currentColor" stroke-width="1.3" cx="11" cy="8" r="1.5"/><circle fill="none" stroke="currentColor" stroke-width="1.3" cx="6" cy="12" r="1.5"/>"#,
};

pub static EXPAND: Icon = Icon {
    name: "expand",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M10 2h4v4M2 10v4h4m8-12-5 5m-7 7 5-5"/>"#,
};

pub static RESTORE: Icon = Icon {
    name: "restore",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M14 6h-4V2M6 14v-4H2m8-4 4-4m-8 8-4 4"/>"#,
};

pub static HELP: Icon = Icon {
    name: "help",
    view: 16.0,
    body: r#"<circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="8" cy="8" r="6.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M6 5.5a2 2 0 1 1 3 1.7C8 7.7 8 8 8 9m0 2v.5"/>"#,
};

pub static CLOSE: Icon = Icon {
    name: "close",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m4 4 8 8m0-8-8 8"/>"#,
};

pub static PLUS: Icon = Icon {
    name: "new-tab",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 3v10M3 8h10"/>"#,
};

pub static CHEVRON: Icon = Icon {
    name: "open-folder",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m6 3 5 5-5 5"/>"#,
};

pub static HOME: Icon = Icon {
    name: "home",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m1.5 7 6.5-5 6.5 5M3 6v8h4v-4h2v4h4V6"/>"#,
};

static DRIVE: Icon = Icon {
    name: "drive",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="2" y="2" width="12" height="12" rx="2"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M2 10h12M4.5 12h.5m2 0h.5"/>"#,
};

static REMOVABLE: Icon = Icon {
    name: "removable-drive",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="4" y="5" width="8" height="9" rx="1.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M6 5V1.5h4V5M8 8v3"/>"#,
};

static OPTICAL: Icon = Icon {
    name: "optical-disc",
    view: 16.0,
    body: r#"<circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="8" cy="8" r="6.5"/><circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="8" cy="8" r="1.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m10 3 3 3M3 10l3 3"/>"#,
};

static TRASH: Icon = Icon {
    name: "trash",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M2 4h12M6 4V2h4v2M4 4l.5 10h7L12 4M7 7v4m2-4v4"/>"#,
};

static DOWNLOADS: Icon = Icon {
    name: "downloads",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 1.5v9m-3-3 3 3 3-3M2 11v3h12v-3"/>"#,
};

static DESKTOP: Icon = Icon {
    name: "desktop",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="1.5" y="2" width="13" height="9" rx="1"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 11v3M5 14h6"/>"#,
};

static FOLDER_DOCUMENTS: Icon = Icon {
    name: "documents-folder",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M1.5 3h5l2 2h6v8h-13ZM5 8h6m-6 2h4"/>"#,
};

static PICTURES: Icon = Icon {
    name: "pictures-folder",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M1.5 3h5l2 2h6v8h-13Zm2 9 3-4 3 3 2-2 2 3"/><circle fill="none" stroke="currentColor" stroke-width="1.3" cx="5" cy="7" r=".6"/>"#,
};

pub static NETWORK: Icon = Icon {
    name: "network",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="4" y="1.5" width="8" height="5" rx="1"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 6.5V10M3 10h10M3 10v2m10-2v2"/><rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="1" y="12" width="4" height="2.5" rx=".5"/><rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="11" y="12" width="4" height="2.5" rx=".5"/>"#,
};

static CLOUD: Icon = Icon {
    name: "cloud",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M4 12.5a3 3 0 0 1-.5-6A4.5 4.5 0 0 1 12 6a3.3 3.3 0 0 1 .5 6.5Z"/>"#,
};

pub static EJECT: Icon = Icon {
    name: "eject",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m8 2-5 7h10Z"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M3 12h10v2H3Z"/>"#,
};

pub static MORE: Icon = Icon {
    name: "more-actions",
    view: 16.0,
    body: r#"<circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="3" cy="8" r=".7"/><circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="8" cy="8" r=".7"/><circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="13" cy="8" r=".7"/>"#,
};

pub fn for_place(place: &Place) -> &'static Icon {
    if place.uri.starts_with("trash:") {
        return &TRASH;
    } else if place.uri == "file:///" {
        return &DRIVE;
    } else if place.kind == PlaceKind::Location && place.name == "Home" {
        return &HOME;
    }
    let theme = place.icon_name.as_deref().unwrap_or_default();
    let cloud = place.kind == PlaceKind::Device
        && ["icloud", "onedrive", "google drive", "dropbox"]
            .iter()
            .any(|name| place.name.eq_ignore_ascii_case(name));
    if cloud
        || place.uri.starts_with("dav:")
        || place.uri.starts_with("davs:")
        || theme.contains("cloud")
    {
        return &CLOUD;
    } else if theme.contains("optical") {
        return &OPTICAL;
    } else if theme.contains("usb") || theme.contains("removable") {
        return &REMOVABLE;
    } else if (!place.uri.is_empty() && !place.uri.starts_with("file:"))
        || theme.contains("network")
        || theme.contains("remote")
    {
        return &NETWORK;
    } else if place.kind == PlaceKind::Device {
        return &DRIVE;
    }
    let name = place
        .path
        .as_ref()
        .and_then(|path| path.file_name())
        .and_then(|name| name.to_str())
        .unwrap_or_default();
    match name {
        name if name.eq_ignore_ascii_case("downloads") => &DOWNLOADS,
        name if name.eq_ignore_ascii_case("desktop") => &DESKTOP,
        name if name.eq_ignore_ascii_case("documents") => &FOLDER_DOCUMENTS,
        name if name.eq_ignore_ascii_case("pictures")
            || name.eq_ignore_ascii_case("screenshots")
            || name.eq_ignore_ascii_case("images") =>
        {
            &PICTURES
        }
        name if name.eq_ignore_ascii_case("music") => &AUDIO,
        name if name.eq_ignore_ascii_case("videos") => &VIDEO,
        _ => &FOLDER,
    }
}

pub fn for_file(file: &File) -> &'static Icon {
    if file.directory {
        return &FOLDER;
    }
    let name = file.name.to_ascii_lowercase();
    match name.as_str() {
        "dockerfile" | "makefile" | "justfile" | "rakefile" => return &CODE,
        ".gitignore" | ".gitattributes" | ".gitmodules" | ".editorconfig" | ".env"
        | "cargo.lock" | "flake.lock" | "package-lock.json" => return &CONFIG,
        "license" | "licence" | "readme" | "changelog" | "authors" => return &DOCUMENT,
        _ => {}
    }
    let extension = file
        .path
        .extension()
        .unwrap_or_default()
        .to_string_lossy()
        .to_ascii_lowercase();
    match extension.as_str() {
        "rs" | "go" | "py" | "pyw" | "js" | "jsx" | "ts" | "tsx" | "c" | "h" | "cpp" | "hpp"
        | "cc" | "cs" | "java" | "kt" | "swift" | "rb" | "php" | "lua" | "nix" | "html" | "htm"
        | "css" | "scss" | "sass" | "vue" | "svelte" | "zig" | "ex" | "exs" | "erl" | "hs"
        | "r" | "dart" | "sql" | "wasm" => &CODE,
        "png" | "jpg" | "jpeg" | "gif" | "webp" | "bmp" | "tiff" | "tif" | "ico" | "svg"
        | "svgz" | "avif" | "heic" | "raw" | "psd" => &IMAGE,
        "mp3" | "flac" | "wav" | "ogg" | "opus" | "aac" | "m4a" | "aiff" | "mid" | "midi" => &AUDIO,
        "mp4" | "mkv" | "webm" | "mov" | "avi" | "m4v" | "mpeg" | "mpg" => &VIDEO,
        "zip" | "tar" | "gz" | "bz2" | "xz" | "zst" | "7z" | "rar" | "tgz" | "deb" | "rpm"
        | "iso" => &ARCHIVE,
        "txt" | "md" | "markdown" | "rst" | "pdf" | "doc" | "docx" | "odt" | "rtf" | "epub"
        | "csv" | "tsv" | "xls" | "xlsx" | "ods" | "ppt" | "pptx" | "tex" | "log" => &DOCUMENT,
        "json" | "jsonc" | "toml" | "yaml" | "yml" | "xml" | "ini" | "conf" | "cfg" | "env"
        | "lock" | "properties" => &CONFIG,
        "db" | "sqlite" | "sqlite3" | "mdb" => &DATABASE,
        "sh" | "bash" | "zsh" | "fish" | "ps1" | "bat" | "cmd" => &TERMINAL,
        _ => &FILE,
    }
}

pub static GRID: Icon = Icon {
    name: "grid-view",
    view: 16.0,
    body: r#"<path d="M2 2h4v4H2ZM10 2h4v4h-4ZM2 10h4v4H2ZM10 10h4v4h-4Z" stroke="currentColor" stroke-linejoin="round"/>"#,
};

pub static LIST: Icon = Icon {
    name: "list-view",
    view: 16.0,
    body: r#"<path d="M2 4h1m3 0h8M2 8h1m3 0h8M2 12h1m3 0h8" stroke="currentColor" stroke-linecap="round"/>"#,
};

pub static DETAILS: Icon = Icon {
    name: "details-view",
    view: 16.0,
    body: r#"<path d="M2 3h12v10H2ZM2 6h12M2 10h12M8 3v10" stroke="currentColor" stroke-linejoin="round"/>"#,
};

pub static OPEN_DEFAULT: Icon = Icon {
    name: "open-default-application",
    view: 16.0,
    body: r#"<path d="M9 2h5v5m0-5L7 9M7 3H2v11h11V9" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};
pub static PRINT: Icon = Icon {
    name: "print",
    view: 16.0,
    body: r#"<path d="M4 5V1.5h8V5M4 11H1.5V5h13v6H12M4 9h8v5.5H4Z" stroke="currentColor" stroke-linejoin="round"/><path d="M11 7h1" stroke="currentColor"/>"#,
};
pub static WRAP: Icon = Icon {
    name: "word-wrap",
    view: 16.0,
    body: r#"<path d="M1.5 3h13M1.5 7h10a3 3 0 0 1 0 6H8m2-2-2 2 2 2M1.5 11h3" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};
pub static SOURCE: Icon = Icon {
    name: "document-source",
    view: 16.0,
    body: r#"<path d="m5 4-4 4 4 4m6-8 4 4-4 4m-2-10-2 12" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};
