use std::{collections::HashMap, path::PathBuf};

use gio::prelude::CancellableExt;

use crate::{
    file,
    finder::{Matches, SearchFilters},
    operations::RemoteRoot,
};

pub fn remote(
    path: PathBuf,
    query: String,
    hidden: bool,
    recursive: bool,
    filters: SearchFilters,
    root: RemoteRoot,
    cancel: gio::Cancellable,
) -> Result<Matches, String> {
    let mut pending = vec![path.clone()];
    let mut files = Vec::new();
    let mut indexed = 0;
    let mut skipped = 0;
    let now = gio::glib::DateTime::now_local().ok();
    while let Some(directory) = pending.pop() {
        if cancel.is_cancelled() {
            break;
        }
        match file::read_dir_remote(&directory, &root, &cancel) {
            Ok(entries) => {
                for mut entry in entries {
                    if cancel.is_cancelled() {
                        break;
                    }
                    if !hidden && entry.name.starts_with('.') {
                        continue;
                    }
                    indexed += 1;
                    if recursive && entry.directory && !entry.symlink {
                        pending.push(entry.path.clone());
                    }
                    let relative = entry
                        .path
                        .strip_prefix(&path)
                        .expect("remote search descendant")
                        .to_string_lossy();
                    if crate::state::smart_contains(&relative, &query)
                        && filters.matches(&entry, now.as_ref())
                    {
                        entry.name = relative.into_owned();
                        files.push(entry);
                        if files.len() == 100 {
                            break;
                        }
                    }
                }
            }
            Err(error) if directory == path => return Err(error),
            Err(_) => skipped += 1,
        }
        if files.len() == 100 {
            break;
        }
    }
    let note = if files.len() == 100 {
        Some("Showing the first 100 matches. Refine the search for more specific results.".into())
    } else if skipped > 0 {
        Some(format!(
            "Search finished; {skipped} inaccessible locations skipped"
        ))
    } else {
        None
    };
    Ok(Matches {
        files,
        hits: HashMap::new(),
        indexed,
        scanning: false,
        watching: false,
        note,
    })
}
