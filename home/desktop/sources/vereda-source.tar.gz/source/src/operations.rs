use std::{
    collections::HashMap,
    ffi::OsString,
    fs::{self, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    process::{Command, Stdio},
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicU64, Ordering},
        mpsc::{self, Receiver, Sender},
    },
    thread,
    time::{Duration, Instant},
};

use crate::metadata::Metadata;
use gio::prelude::*;
use rune::Waker;
use serde::Serialize;

#[derive(Clone, Debug)]
pub enum Operation {
    Copy {
        sources: Vec<PathBuf>,
        destination: PathBuf,
    },
    Move {
        sources: Vec<PathBuf>,
        destination: PathBuf,
    },
    Rename(Vec<(PathBuf, PathBuf)>),
    Trash(Vec<PathBuf>),
    Delete(Vec<PathBuf>),
    Restore(Vec<String>),
    DeleteTrash(Vec<String>),
    Undo(Undo),
    Create {
        path: PathBuf,
        directory: bool,
    },
    Link {
        sources: Vec<PathBuf>,
        destination: PathBuf,
        relative: bool,
        hard: bool,
    },
    Permissions {
        sources: Vec<PathBuf>,
        mode: u32,
        recursive: bool,
    },
    Properties {
        source: PathBuf,
        destination: PathBuf,
        mode: Option<u32>,
        recursive: bool,
    },
    Archive {
        sources: Vec<PathBuf>,
        destination: PathBuf,
    },
    Extract {
        source: PathBuf,
        destination: PathBuf,
    },
}

impl Operation {
    pub fn title(&self) -> &'static str {
        match self {
            Self::Copy { .. } => "Copy",
            Self::Move { .. } => "Move",
            Self::Rename(_) => "Rename",
            Self::Trash(_) => "Move to trash",
            Self::Delete(_) => "Permanently delete",
            Self::Restore(_) => "Restore from trash",
            Self::DeleteTrash(_) => "Permanently delete from trash",
            Self::Undo(_) => "Undo",
            Self::Create {
                directory: true, ..
            } => "Create folder",
            Self::Create { .. } => "Create file",
            Self::Link { hard: true, .. } => "Create hard links",
            Self::Link { .. } => "Create symbolic links",
            Self::Permissions { .. } => "Change permissions",
            Self::Properties { .. } => "Apply properties",
            Self::Archive { .. } => "Create archive",
            Self::Extract { .. } => "Extract archive",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub enum Status {
    Queued,
    Running,
    Waiting,
    Completed,
    Failed,
    Cancelled,
}

#[derive(Clone, Debug, Serialize)]
pub struct Task {
    pub id: u64,
    pub title: String,
    pub sources: Vec<PathBuf>,
    pub destination: Option<PathBuf>,
    pub total_bytes: Option<u64>,
    pub total_entries: Option<u64>,
    pub rate_bps: Option<f64>,
    pub eta_seconds: Option<u64>,
    pub failures: Vec<Failure>,
    pub can_retry: bool,
    pub status: Status,
    pub current: PathBuf,
    pub result: Option<PathBuf>,
    pub bytes: u64,
    pub entries: u64,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
}

#[derive(Clone, Debug, Serialize)]
pub struct Failure {
    pub source: PathBuf,
    pub destination: Option<PathBuf>,
    pub error: String,
}

#[derive(Clone, Copy, Debug)]
pub enum Choice {
    Replace,
    Merge,
    KeepBoth,
    Skip,
    Cancel,
}

enum Destination {
    Publish { path: PathBuf, replace: bool },
    Merge(PathBuf),
    Skip,
}

pub struct Conflict {
    pub task: u64,
    pub source: PathBuf,
    pub destination: PathBuf,
    pub can_merge: bool,
    pub source_metadata: Option<Metadata>,
    pub destination_metadata: Option<Metadata>,
    answer: Sender<(Choice, bool)>,
}

#[derive(Clone, Debug, Default)]
pub struct Undo(Vec<UndoStep>);

#[derive(Clone)]
struct Rebase {
    before: Snapshot,
    after: Snapshot,
    trash: Option<String>,
}
impl Undo {
    fn rebase(&mut self, change: &Rebase) {
        fn relocated(root: &Path, relative: &Path) -> PathBuf {
            if relative.as_os_str().is_empty() {
                root.to_path_buf()
            } else {
                root.join(relative)
            }
        }
        fn snapshot(snapshot: &mut Snapshot, change: &Rebase) -> bool {
            let matched = change.before.versions.iter().any(|(path, version)| {
                path == &snapshot.root
                    && snapshot
                        .versions
                        .iter()
                        .any(|(stored, current)| stored == path && same_version(current, version))
            });
            for (path, version) in &mut snapshot.versions {
                if let Ok(relative) = path.strip_prefix(&change.before.root) {
                    let next = relocated(&change.after.root, relative);
                    if let Some((_, before)) = change
                        .before
                        .versions
                        .iter()
                        .find(|(previous, _)| previous == path)
                        && same_version(version, before)
                        && let Some((_, after)) = change
                            .after
                            .versions
                            .iter()
                            .find(|(updated, _)| updated == &next)
                    {
                        *version = after.clone();
                    }
                    *path = next;
                }
            }
            if let Ok(relative) = snapshot.root.strip_prefix(&change.before.root) {
                snapshot.root = relocated(&change.after.root, relative);
            }
            matched
        }
        for step in &mut self.0 {
            match step {
                UndoStep::Remove(stored) | UndoStep::Move(stored, _) => {
                    snapshot(stored, change);
                }
                UndoStep::Restore { uri, version, .. } => {
                    let relative = version
                        .root
                        .strip_prefix(&change.before.root)
                        .ok()
                        .map(Path::to_path_buf);
                    if snapshot(version, change)
                        && let Some(trash) = &change.trash
                        && let Some(relative) = relative
                    {
                        *uri = if relative.as_os_str().is_empty() {
                            trash.clone()
                        } else {
                            gio::File::for_uri(trash)
                                .resolve_relative_path(relative)
                                .uri()
                                .into()
                        };
                    }
                }
                UndoStep::Mode { path, version, .. } => {
                    if let Ok(relative) = path.strip_prefix(&change.before.root) {
                        let next = relocated(&change.after.root, relative);
                        if let Some((_, before)) = change
                            .before
                            .versions
                            .iter()
                            .find(|(previous, _)| previous == path)
                            && same_version(version, before)
                            && let Some((_, after)) = change
                                .after
                                .versions
                                .iter()
                                .find(|(updated, _)| updated == &next)
                        {
                            *version = after.clone();
                        }
                        *path = next;
                    }
                }
            }
        }
    }
}

#[derive(Clone, Debug)]
enum UndoStep {
    Remove(Snapshot),
    Move(Snapshot, PathBuf),
    Restore {
        uri: String,
        original: PathBuf,
        version: Snapshot,
    },
    Mode {
        path: PathBuf,
        version: Metadata,
        mode: u32,
    },
}

#[derive(Clone, Debug)]
struct Snapshot {
    root: PathBuf,
    versions: Vec<(PathBuf, Metadata)>,
}
impl Snapshot {
    fn single(path: &Path, version: Metadata) -> Self {
        Self {
            root: path.to_path_buf(),
            versions: vec![(path.to_path_buf(), version)],
        }
    }
    fn read(root: &Path) -> io::Result<Self> {
        let mut versions = Vec::new();
        for entry in walkdir::WalkDir::new(root).follow_links(false) {
            let entry = entry?;
            versions.push((
                entry.path().to_path_buf(),
                fs::symlink_metadata(entry.path())?.into(),
            ));
        }
        versions.sort_by(|a, b| a.0.cmp(&b.0));
        Ok(Self {
            root: root.to_path_buf(),
            versions,
        })
    }
    fn check(&self, now: Self) -> io::Result<()> {
        use std::os::unix::fs::PermissionsExt;
        if now.versions.len() != self.versions.len()
            || !self
                .versions
                .iter()
                .zip(&now.versions)
                .all(|((a, before), (b, after))| {
                    a == b
                        && same_version(before, after)
                        && before.permissions().mode() == after.permissions().mode()
                })
        {
            return Err(io::Error::other(
                "Item changed since the operation; undo was refused",
            ));
        }
        Ok(())
    }
}

enum Event {
    Rebased(Rebase),
    Started(u64),
    Totals {
        id: u64,
        bytes: Option<u64>,
        entries: Option<u64>,
    },
    Progress {
        id: u64,
        path: PathBuf,
        bytes: u64,
        entries: u64,
        rate_bps: Option<f64>,
    },
    Conflict(Box<Conflict>),
    Finished {
        id: u64,
        status: Status,
        result: Option<PathBuf>,
        errors: Vec<String>,
        failures: Vec<Failure>,
        retry: Vec<Operation>,
        finalize: Vec<Finalization>,
        remote_roots: Vec<RemoteRoot>,
        warnings: Vec<String>,
        undo: Option<Undo>,
        undoing: bool,
    },
}

#[derive(Clone)]
struct Cancellation {
    requested: Arc<AtomicBool>,
    io: gio::Cancellable,
}
impl Cancellation {
    fn new() -> Self {
        Self {
            requested: Arc::new(AtomicBool::new(false)),
            io: gio::Cancellable::new(),
        }
    }
    fn cancelled(&self) -> bool {
        self.requested.load(Ordering::Relaxed)
    }
    fn cancel(&self) {
        self.requested.store(true, Ordering::Relaxed);
        self.io.cancel();
    }
}

#[derive(Clone)]
pub(crate) struct RemoteRoot {
    pub path: PathBuf,
    pub uri: String,
}

fn remote_metadata(uri: &str, cancel: &gio::Cancellable) -> io::Result<Metadata> {
    let info = gio::File::for_uri(uri)
        .query_info(
            "standard::type,standard::size,unix::mode,time::*,etag::value,id::file",
            gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
            Some(cancel),
        )
        .map_err(|error| {
            let kind = if error.matches(gio::IOErrorEnum::NotFound) {
                io::ErrorKind::NotFound
            } else if error.matches(gio::IOErrorEnum::PermissionDenied) {
                io::ErrorKind::PermissionDenied
            } else if error.matches(gio::IOErrorEnum::Cancelled) {
                io::ErrorKind::Interrupted
            } else {
                io::ErrorKind::Other
            };
            io::Error::new(kind, error)
        })?;
    Ok(Metadata::remote(&info))
}

fn canonical_remote(
    path: &Path,
    root: &RemoteRoot,
    cancel: &gio::Cancellable,
) -> io::Result<PathBuf> {
    use std::{collections::VecDeque, path::Component};
    let relative = path.strip_prefix(&root.path).map_err(io::Error::other)?;
    let mut pending: VecDeque<_> = relative
        .components()
        .map(|part| part.as_os_str().to_os_string())
        .collect();
    let mut resolved = PathBuf::new();
    let mut links = 0;
    let directory = gio::File::for_uri(&root.uri);
    while let Some(part) = pending.pop_front() {
        match Path::new(&part).components().next() {
            Some(Component::CurDir) => continue,
            Some(Component::ParentDir) => {
                resolved.pop();
                continue;
            }
            Some(Component::RootDir) => {
                resolved.clear();
                continue;
            }
            _ => {}
        }
        let candidate = resolved.join(&part);
        let info = directory
            .resolve_relative_path(&candidate)
            .query_info(
                "standard::type,standard::is-symlink,standard::symlink-target",
                gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                Some(cancel),
            )
            .map_err(io::Error::other)?;
        if info.is_symlink() {
            links += 1;
            if links > 40 {
                return Err(io::Error::from_raw_os_error(libc::ELOOP));
            }
            let target = info
                .symlink_target()
                .ok_or_else(|| io::Error::other("Remote symlink target is unavailable"))?;
            for component in target.components().rev() {
                pending.push_front(component.as_os_str().to_os_string());
            }
        } else {
            resolved = candidate;
        }
    }
    Ok(root.path.join(resolved))
}

fn inspect_remote<T: Send + 'static>(
    cancellation: &gio::Cancellable,
    inspect: impl FnOnce() -> io::Result<T> + Send + 'static,
) -> io::Result<T> {
    let (output, result) = mpsc::channel();
    thread::spawn(move || {
        let _ = output.send(inspect());
    });
    RemoteStream::receive(&result, cancellation)
}

enum StreamRequest {
    Read(usize, Sender<io::Result<Vec<u8>>>),
    Write(Vec<u8>, Sender<io::Result<()>>),
    Close(Sender<io::Result<()>>),
}

struct RemoteStream {
    input: Sender<StreamRequest>,
    cancellation: gio::Cancellable,
    size: Option<u64>,
    uri: String,
}
impl RemoteStream {
    fn open(uri: String, writing: bool, cancellation: gio::Cancellable) -> io::Result<Self> {
        let (input, requests) = mpsc::channel();
        let (ready, opened) = mpsc::channel();
        let cancel = cancellation.clone();
        let opening = uri.clone();
        thread::spawn(move || {
            let file = gio::File::for_uri(&opening);
            if writing {
                let stream = match file.create(gio::FileCreateFlags::NONE, Some(&cancel)) {
                    Ok(stream) => stream,
                    Err(error) => {
                        let _ = ready.send(Err(io::Error::other(error)));
                        return;
                    }
                };
                let _ = ready.send(Ok(None));
                for request in requests {
                    match request {
                        StreamRequest::Write(bytes, result) => {
                            let written = gio::prelude::OutputStreamExtManual::write_all(
                                &stream,
                                &bytes,
                                Some(&cancel),
                            )
                            .map_err(io::Error::other)
                            .and_then(|(count, error)| {
                                if let Some(error) = error {
                                    return Err(io::Error::other(error));
                                }
                                if count != bytes.len() {
                                    return Err(io::Error::new(
                                        io::ErrorKind::WriteZero,
                                        "Incomplete remote write",
                                    ));
                                }
                                Ok(())
                            });
                            let _ = result.send(written);
                        }
                        StreamRequest::Close(result) => {
                            let _ =
                                result.send(stream.close(Some(&cancel)).map_err(io::Error::other));
                            return;
                        }
                        StreamRequest::Read(_, _) => unreachable!("Output stream cannot read"),
                    }
                    if cancel.is_cancelled() {
                        break;
                    }
                }
                let _ = stream.close(Some(&cancel));
            } else {
                let stream = match gio::prelude::FileExt::read(&file, Some(&cancel)) {
                    Ok(stream) => stream,
                    Err(error) => {
                        let _ = ready.send(Err(io::Error::other(error)));
                        return;
                    }
                };
                let size = match stream.query_info("standard::size", Some(&cancel)) {
                    Ok(info) => Ok(info
                        .has_attribute("standard::size")
                        .then(|| info.size() as u64)),
                    Err(error) if error.matches(gio::IOErrorEnum::NotSupported) => Ok(None),
                    Err(error) => Err(io::Error::other(error)),
                };
                if ready.send(size).is_ok() {
                    for request in requests {
                        match request {
                            StreamRequest::Read(size, result) => {
                                let mut bytes = vec![0; size];
                                let read = gio::prelude::InputStreamExtManual::read(
                                    &stream,
                                    &mut bytes,
                                    Some(&cancel),
                                )
                                .map_err(io::Error::other)
                                .map(|count| {
                                    bytes.truncate(count);
                                    bytes
                                });
                                let _ = result.send(read);
                            }
                            StreamRequest::Close(result) => {
                                let _ = result
                                    .send(stream.close(Some(&cancel)).map_err(io::Error::other));
                                return;
                            }
                            StreamRequest::Write(_, _) => unreachable!("Input stream cannot write"),
                        }
                        if cancel.is_cancelled() {
                            break;
                        }
                    }
                }
                let _ = stream.close(Some(&cancel));
            }
        });
        let size = Self::receive(&opened, &cancellation)?;
        Ok(Self {
            input,
            cancellation,
            size,
            uri,
        })
    }
    fn receive<T>(
        result: &Receiver<io::Result<T>>,
        cancellation: &gio::Cancellable,
    ) -> io::Result<T> {
        loop {
            if cancellation.is_cancelled() {
                return Err(io::Error::new(io::ErrorKind::Interrupted, "Cancelled"));
            }
            match result.recv_timeout(Duration::from_millis(20)) {
                Ok(result) => return result,
                Err(mpsc::RecvTimeoutError::Timeout) => {}
                Err(mpsc::RecvTimeoutError::Disconnected) => {
                    return Err(io::Error::other("Remote stream stopped"));
                }
            }
        }
    }
    fn read(&self, size: usize) -> io::Result<Vec<u8>> {
        let (result, receive) = mpsc::channel();
        self.input
            .send(StreamRequest::Read(size, result))
            .map_err(io::Error::other)?;
        Self::receive(&receive, &self.cancellation)
    }
    fn write(&self, bytes: &[u8]) -> io::Result<()> {
        let (result, receive) = mpsc::channel();
        self.input
            .send(StreamRequest::Write(bytes.to_vec(), result))
            .map_err(io::Error::other)?;
        Self::receive(&receive, &self.cancellation)
    }
    fn close(&self) -> io::Result<()> {
        let (result, receive) = mpsc::channel();
        self.input
            .send(StreamRequest::Close(result))
            .map_err(io::Error::other)?;
        Self::receive(&receive, &self.cancellation)
    }
}

enum SourceInput {
    Local(fs::File),
    Remote(RemoteStream),
}
impl Read for SourceInput {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        match self {
            Self::Local(file) => file.read(buffer),
            Self::Remote(stream) => {
                let bytes = stream.read(buffer.len())?;
                buffer[..bytes.len()].copy_from_slice(&bytes);
                Ok(bytes.len())
            }
        }
    }
}
impl SourceInput {
    fn check_metadata(&self, expected: &Metadata) -> io::Result<()> {
        let current = match self {
            Self::Local(file) => file.metadata()?.into(),
            Self::Remote(stream) => {
                if stream.size.is_some_and(|size| size != expected.len()) {
                    return Err(io::Error::other("Source changed before copying"));
                }
                let uri = stream.uri.clone();
                let cancel = stream.cancellation.clone();
                inspect_remote(&stream.cancellation, move || remote_metadata(&uri, &cancel))?
            }
        };
        if !same_version(expected, &current) {
            return Err(io::Error::other("Source changed before copying"));
        }
        Ok(())
    }
}

enum CopyOutput {
    Local(fs::File),
    Remote(RemoteStream),
}
impl CopyOutput {
    fn write_chunk(&mut self, bytes: &[u8]) -> io::Result<()> {
        match self {
            Self::Local(file) => {
                if bytes.iter().all(|byte| *byte == 0) {
                    file.seek(SeekFrom::Current(bytes.len() as i64))?;
                    Ok(())
                } else {
                    file.write_all(bytes)
                }
            }
            Self::Remote(stream) => stream.write(bytes),
        }
    }
    fn finish(&self, path: &Path, metadata: &Metadata) -> io::Result<()> {
        match self {
            Self::Local(file) => {
                file.set_len(metadata.len())?;
                file.sync_all()?;
            }
            Self::Remote(stream) => return stream.close(),
        }
        fs::set_permissions(path, metadata.permissions())?;
        preserve_times(path, metadata)
    }
}

#[derive(Clone)]
struct Finalization {
    path: PathBuf,
    device: u64,
    inode: u64,
}

struct Retry {
    operations: Vec<Operation>,
    remote_roots: Vec<RemoteRoot>,
    finalize: Vec<Finalization>,
}

struct Work {
    id: u64,
    operation: Operation,
    force: bool,
    cancel: Cancellation,
    remote_roots: Vec<RemoteRoot>,
    finalize: Vec<Finalization>,
}

#[derive(Default)]
pub struct Queue {
    pub tasks: Vec<Task>,
    pub conflict: Option<Conflict>,
    undo: Vec<Undo>,
    next: u64,
    input: Option<Sender<Work>>,
    events: Option<Receiver<Event>>,
    cancellations: HashMap<u64, Cancellation>,
    retries: HashMap<u64, Retry>,
    pub(crate) remote_roots: Vec<RemoteRoot>,
    worker: Option<std::thread::JoinHandle<()>>,
}

impl Queue {
    pub fn start(&mut self, waker: Waker) {
        let (input, jobs) = mpsc::channel::<Work>();
        let (output, events) = mpsc::channel();
        self.input = Some(input);
        self.events = Some(events);
        self.worker = Some(thread::spawn(move || {
            for work in jobs {
                let undoing = matches!(&work.operation, Operation::Undo(_));
                let reversible = !matches!(
                    &work.operation,
                    Operation::Delete(_) | Operation::DeleteTrash(_)
                );
                let mut context = Context {
                    id: work.id,
                    output: output.clone(),
                    waker: waker.clone(),
                    cancel: work.cancel,
                    remote_roots: work.remote_roots,
                    policy: work.force.then_some(Choice::Replace),
                    bytes: 0,
                    entries: 0,
                    last: Instant::now(),
                    started: Instant::now(),
                    waiting: Duration::ZERO,
                    failures: Vec::new(),
                    retry: Vec::new(),
                    finalize: work.finalize,
                    publications: Arc::new(AtomicU64::new(0)),
                    current: PathBuf::new(),
                    result: None,
                    warnings: Vec::new(),
                    allow_merge: false,
                    undo: reversible.then(Undo::default),
                    undoing,
                    rebases: Vec::new(),
                };
                context.emit(Event::Started(work.id));
                context.prepare(&work.operation);
                let errors = context.run(work.operation);
                if errors.is_empty() && !context.cancel.cancelled() {
                    context.finalize_moves();
                }
                let path = context.current.clone();
                context.progress(&path, true);
                let status = if context.cancel.cancelled() {
                    Status::Cancelled
                } else if errors.is_empty() {
                    Status::Completed
                } else {
                    Status::Failed
                };
                let warnings = std::mem::take(&mut context.warnings);
                let undo = context.undo.take();
                let result = context.result.take();
                let failures = std::mem::take(&mut context.failures);
                let retry = if status == Status::Failed {
                    std::mem::take(&mut context.retry)
                } else {
                    Vec::new()
                };
                let remote_roots = std::mem::take(&mut context.remote_roots);
                let finalize = std::mem::take(&mut context.finalize);
                context.emit(Event::Finished {
                    id: work.id,
                    status,
                    result,
                    errors,
                    failures,
                    retry,
                    finalize,
                    remote_roots,
                    warnings,
                    undo,
                    undoing,
                });
            }
        }));
    }

    pub fn push(&mut self, operation: Operation, force: bool) {
        self.enqueue(operation, force, self.remote_roots.clone(), Vec::new());
    }

    fn enqueue(
        &mut self,
        operation: Operation,
        force: bool,
        remote_roots: Vec<RemoteRoot>,
        finalize: Vec<Finalization>,
    ) {
        let (sources, destination) = match &operation {
            Operation::Copy {
                sources,
                destination,
            }
            | Operation::Move {
                sources,
                destination,
            }
            | Operation::Link {
                sources,
                destination,
                ..
            }
            | Operation::Archive {
                sources,
                destination,
            } => (sources.clone(), Some(destination.clone())),
            Operation::Extract {
                source,
                destination,
            }
            | Operation::Properties {
                source,
                destination,
                ..
            } => (vec![source.clone()], Some(destination.clone())),
            Operation::Rename(pairs) => (
                pairs.iter().map(|(source, _)| source.clone()).collect(),
                (pairs.len() == 1).then(|| pairs[0].1.clone()),
            ),
            Operation::Trash(sources)
            | Operation::Delete(sources)
            | Operation::Permissions { sources, .. } => (sources.clone(), None),
            Operation::Restore(uris) | Operation::DeleteTrash(uris) => {
                (uris.iter().map(PathBuf::from).collect(), None)
            }
            Operation::Create { path, .. } => (Vec::new(), Some(path.clone())),
            Operation::Undo(_) => (Vec::new(), None),
        };
        let id = self.next;
        self.next += 1;
        let cancel = Cancellation::new();
        let task = Task {
            id,
            title: operation.title().into(),
            sources,
            destination,
            total_bytes: None,
            total_entries: None,
            rate_bps: None,
            eta_seconds: None,
            failures: Vec::new(),
            can_retry: false,
            status: Status::Queued,
            current: PathBuf::new(),
            result: None,
            bytes: 0,
            entries: 0,
            errors: Vec::new(),
            warnings: Vec::new(),
        };
        if let Some(input) = &self.input
            && input
                .send(Work {
                    id,
                    operation,
                    force,
                    cancel: cancel.clone(),
                    remote_roots,
                    finalize,
                })
                .is_ok()
        {
            self.cancellations.insert(id, cancel);
            self.tasks.push(task);
        }
    }

    pub fn poll(&mut self) -> (bool, bool) {
        let events: Vec<_> = self
            .events
            .as_ref()
            .map(|r| r.try_iter().collect())
            .unwrap_or_default();
        let changed = !events.is_empty();
        let mut refresh = false;
        for event in events {
            match event {
                Event::Rebased(change) => {
                    for undo in &mut self.undo {
                        undo.rebase(&change);
                    }
                }
                Event::Started(id) => {
                    if let Some(task) = self.tasks.iter_mut().find(|t| t.id == id) {
                        task.status = Status::Running;
                    }
                }
                Event::Totals { id, bytes, entries } => {
                    if let Some(task) = self.tasks.iter_mut().find(|t| t.id == id) {
                        task.total_bytes = bytes;
                        task.total_entries = entries;
                    }
                }
                Event::Progress {
                    id,
                    path,
                    bytes,
                    entries,
                    rate_bps,
                } => {
                    if let Some(task) = self.tasks.iter_mut().find(|t| t.id == id) {
                        task.current = path;
                        task.bytes = bytes;
                        task.entries = entries;
                        task.rate_bps = rate_bps;
                        task.eta_seconds =
                            task.total_bytes.zip(rate_bps).and_then(|(total, rate)| {
                                (total > bytes && rate > 0.0)
                                    .then(|| ((total - bytes) as f64 / rate).ceil() as u64)
                            });
                    }
                }
                Event::Conflict(conflict) => {
                    if let Some(task) = self.tasks.iter_mut().find(|t| t.id == conflict.task) {
                        task.status = Status::Waiting;
                        task.rate_bps = None;
                        task.eta_seconds = None;
                    }
                    self.conflict = Some(*conflict);
                }
                Event::Finished {
                    id,
                    status,
                    result,
                    errors,
                    failures,
                    retry,
                    finalize,
                    remote_roots,
                    warnings,
                    undo,
                    undoing,
                } => {
                    if let Some(undo) = undo {
                        if !undo.0.is_empty() {
                            self.undo.push(undo);
                        }
                    } else if !undoing {
                        self.undo.clear();
                    }
                    if let Some(task) = self.tasks.iter_mut().find(|t| t.id == id) {
                        task.status = status;
                        task.result = result;
                        task.errors = errors;
                        task.failures = failures;
                        task.can_retry = !retry.is_empty();
                        task.rate_bps = None;
                        task.eta_seconds = None;
                        task.warnings = warnings;
                    }
                    if !retry.is_empty() {
                        self.retries.insert(
                            id,
                            Retry {
                                operations: retry,
                                remote_roots,
                                finalize,
                            },
                        );
                    }
                    self.cancellations.remove(&id);
                    if self.conflict.as_ref().is_some_and(|c| c.task == id) {
                        self.conflict = None;
                    }
                    refresh = true;
                }
            }
        }
        (changed, refresh)
    }

    pub fn answer(&mut self, choice: Choice, all: bool) {
        if matches!(choice, Choice::Merge) && self.conflict.as_ref().is_some_and(|c| !c.can_merge) {
            return;
        }
        if let Some(conflict) = self.conflict.take() {
            if let Some(task) = self.tasks.iter_mut().find(|t| t.id == conflict.task) {
                task.status = Status::Running;
            }
            let _ = conflict.answer.send((choice, all));
        }
    }

    pub fn retry(&mut self, id: u64) -> Result<(), String> {
        if self.input.is_none() {
            return Err("The operation queue is not running".into());
        }
        let retry = self
            .retries
            .remove(&id)
            .ok_or("There are no failed items available to retry")?;
        if let Some(task) = self.tasks.iter_mut().find(|task| task.id == id) {
            task.can_retry = false;
        }
        for operation in retry.operations {
            self.enqueue(
                operation,
                false,
                retry.remote_roots.clone(),
                retry.finalize.clone(),
            );
        }
        Ok(())
    }

    pub fn cancel(&mut self, id: u64) {
        if let Some(cancel) = self.cancellations.get(&id) {
            cancel.cancel();
        }
        if self.conflict.as_ref().is_some_and(|c| c.task == id) {
            self.answer(Choice::Cancel, false);
        }
    }

    pub fn undo_available(&self) -> bool {
        self.active().is_none() && !self.undo.is_empty()
    }

    pub fn undo(&mut self) -> Result<(), String> {
        if self.active().is_some() {
            return Err("Wait for active tasks before undoing".into());
        }
        let undo = self
            .undo
            .pop()
            .ok_or("The last operation cannot be undone")?;
        self.push(Operation::Undo(undo), false);
        Ok(())
    }

    pub fn cancel_all(&mut self) {
        for cancel in self.cancellations.values() {
            cancel.cancel();
        }
        self.answer(Choice::Cancel, false);
    }

    pub fn active(&self) -> Option<&Task> {
        self.tasks
            .iter()
            .find(|t| matches!(t.status, Status::Queued | Status::Running | Status::Waiting))
    }
}

impl Drop for Queue {
    fn drop(&mut self) {
        self.cancel_all();
        self.input = None;
        if let Some(worker) = self.worker.take() {
            let _ = worker.join();
        }
    }
}

struct Context {
    id: u64,
    output: Sender<Event>,
    waker: Waker,
    cancel: Cancellation,
    remote_roots: Vec<RemoteRoot>,
    policy: Option<Choice>,
    bytes: u64,
    entries: u64,
    last: Instant,
    started: Instant,
    waiting: Duration,
    failures: Vec<Failure>,
    retry: Vec<Operation>,
    finalize: Vec<Finalization>,
    publications: Arc<AtomicU64>,
    current: PathBuf,
    result: Option<PathBuf>,
    warnings: Vec<String>,
    allow_merge: bool,
    undo: Option<Undo>,
    undoing: bool,
    rebases: Vec<Rebase>,
}

impl Context {
    fn emit(&self, event: Event) {
        let _ = self.output.send(event);
        (self.waker)();
    }

    fn check(&self) -> io::Result<()> {
        if self.cancel.cancelled() {
            Err(io::Error::new(io::ErrorKind::Interrupted, "Cancelled"))
        } else {
            Ok(())
        }
    }

    fn rebase(&mut self, before: Snapshot, after: Snapshot, trash: Option<String>) {
        let change = Rebase {
            before,
            after,
            trash,
        };
        if let Some(undo) = &mut self.undo {
            undo.rebase(&change);
        }
        if self.undoing {
            self.rebases.push(change.clone());
        }
        self.emit(Event::Rebased(change));
    }

    fn parent_versions(&self, paths: &[&Path]) -> Vec<Snapshot> {
        let mut parents: Vec<_> = paths.iter().filter_map(|path| path.parent()).collect();
        parents.sort();
        parents.dedup();
        parents
            .into_iter()
            .filter_map(|path| {
                self.metadata(path)
                    .ok()
                    .map(|version| Snapshot::single(path, version))
            })
            .collect()
    }
    fn rebase_parents(&mut self, parents: Vec<Snapshot>) {
        use std::os::unix::fs::PermissionsExt;
        for before in parents {
            if let Ok(version) = self.metadata(&before.root)
                && version.permissions().mode() == before.versions[0].1.permissions().mode()
            {
                let after = Snapshot::single(&before.root, version);
                self.rebase(before, after, None);
            }
        }
    }

    fn finalize_moves(&mut self) {
        use std::os::unix::fs::MetadataExt;
        self.finalize
            .sort_by_key(|directory| std::cmp::Reverse(directory.path.components().count()));
        for directory in &self.finalize {
            if self.cancel.cancelled() {
                break;
            }
            let metadata = match fs::symlink_metadata(&directory.path) {
                Ok(metadata) => metadata,
                Err(error) if error.kind() == io::ErrorKind::NotFound => continue,
                Err(error) => {
                    self.warnings.push(format!(
                        "Files moved, but source folder could not be checked: {}: {error}",
                        directory.path.display()
                    ));
                    continue;
                }
            };
            if !metadata.is_dir()
                || metadata.dev() != directory.device
                || metadata.ino() != directory.inode
            {
                self.warnings.push(format!(
                    "Source folder changed and was retained: {}",
                    directory.path.display()
                ));
                continue;
            }
            if self.cancel.cancelled() {
                break;
            }
            // rmdir never deletes skipped or newly created children.
            match fs::remove_dir(&directory.path) {
                Ok(()) => self.undo = None,
                Err(error)
                    if matches!(
                        error.kind(),
                        io::ErrorKind::NotFound | io::ErrorKind::DirectoryNotEmpty
                    ) => {}
                Err(error) => self.warnings.push(format!(
                    "Files moved, but empty source folder could not be removed: {}: {error}",
                    directory.path.display()
                )),
            }
        }
    }

    fn prepare(&mut self, operation: &Operation) {
        let Operation::Copy { sources, .. } = operation else {
            return;
        };
        // Bound flat-file metadata work; directory and remote totals remain unknown.
        if sources.len() > 256 || sources.iter().any(|path| self.remote_file(path).is_some()) {
            return;
        }
        let mut sources = sources.clone();
        sources.sort();
        sources.dedup();
        let mut bytes = 0u64;
        for source in &sources {
            if self.check().is_err() {
                return;
            }
            let Ok(metadata) = self.metadata(source) else {
                return;
            };
            if !metadata.is_file() {
                return;
            }
            let Some(total) = bytes.checked_add(metadata.len()) else {
                return;
            };
            bytes = total;
        }
        self.emit(Event::Totals {
            id: self.id,
            bytes: Some(bytes),
            entries: Some(sources.len() as u64),
        });
        self.started = Instant::now();
    }

    fn progress(&mut self, path: &Path, force: bool) {
        self.current = path.to_path_buf();
        if force || self.last.elapsed() >= Duration::from_millis(60) {
            self.emit(Event::Progress {
                id: self.id,
                path: path.into(),
                bytes: self.bytes,
                entries: self.entries,
                rate_bps: {
                    let elapsed = self
                        .started
                        .elapsed()
                        .saturating_sub(self.waiting)
                        .as_secs_f64();
                    (self.bytes > 0 && elapsed >= 0.5).then(|| self.bytes as f64 / elapsed)
                },
            });
            self.last = Instant::now();
        }
    }

    fn metadata(&self, path: &Path) -> io::Result<Metadata> {
        if let Some(file) = self.remote_file(path) {
            let uri: String = file.uri().into();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || remote_metadata(&uri, &cancel))
        } else {
            fs::symlink_metadata(path).map(Into::into)
        }
    }

    fn make_directory(&self, path: &Path, parents: bool) -> io::Result<()> {
        if let Some(file) = self.remote_file(path) {
            let uri: String = file.uri().into();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                let file = gio::File::for_uri(&uri);
                if parents {
                    match file.query_info(
                        "standard::type",
                        gio::FileQueryInfoFlags::NONE,
                        Some(&cancel),
                    ) {
                        Ok(info) if info.file_type() == gio::FileType::Directory => return Ok(()),
                        Ok(_) => {
                            return Err(io::Error::new(
                                io::ErrorKind::AlreadyExists,
                                "Parent is not a directory",
                            ));
                        }
                        Err(error) if error.matches(gio::IOErrorEnum::NotFound) => {}
                        Err(error) => return Err(io::Error::other(error)),
                    }
                    file.make_directory_with_parents(Some(&cancel))
                } else {
                    file.make_directory(Some(&cancel))
                }
                .map_err(io::Error::other)
            })
        } else if parents {
            fs::create_dir_all(path)
        } else {
            fs::create_dir(path)
        }
    }

    fn rename(&self, source: &Path, destination: &Path) -> io::Result<()> {
        match (self.remote_file(source), self.remote_file(destination)) {
            (Some(source), Some(destination)) => {
                let source: String = source.uri().into();
                let destination: String = destination.uri().into();
                let cancel = self.cancel.io.clone();
                let publications = self.publications.clone();
                inspect_remote(&self.cancel.io, move || {
                    publications.fetch_add(1, Ordering::Relaxed);
                    gio::File::for_uri(&source)
                        .move_(
                            &gio::File::for_uri(&destination),
                            gio::FileCopyFlags::NOFOLLOW_SYMLINKS
                                | gio::FileCopyFlags::NO_FALLBACK_FOR_MOVE,
                            Some(&cancel),
                            None,
                        )
                        .map_err(|error| {
                            if error.matches(gio::IOErrorEnum::NotSupported) {
                                io::Error::from_raw_os_error(libc::EXDEV)
                            } else {
                                io::Error::other(error)
                            }
                        })
                })
            }
            (None, None) => rename_new(source, destination, &self.publications),
            _ => Err(io::Error::from_raw_os_error(libc::EXDEV)),
        }
    }

    fn remove(&self, path: &Path) -> io::Result<()> {
        if let Some(file) = self.remote_file(path) {
            if self.remote_roots.iter().any(|root| root.path == path) {
                return Err(io::Error::other("Cannot remove a mounted location's root"));
            }
            let uri: String = file.uri().into();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                remove_remote(&gio::File::for_uri(&uri), &cancel)
            })
        } else {
            remove(path)
        }
    }

    fn staging(&self, parent: &Path) -> io::Result<Staging> {
        if let Some(file) = self.remote_file(parent) {
            let uri: String = file.uri().into();
            let parent = parent.to_path_buf();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                Staging::remote(&parent, &uri, &cancel)
            })
        } else {
            Staging::new(parent)
        }
    }

    fn preserve_metadata(
        &self,
        source: &Path,
        destination: &Path,
        metadata: &Metadata,
    ) -> io::Result<()> {
        if self.remote_file(source).is_some() || self.remote_file(destination).is_some() {
            let from: String = self
                .remote_file(source)
                .unwrap_or_else(|| gio::File::for_path(source))
                .uri()
                .into();
            let to: String = self
                .remote_file(destination)
                .unwrap_or_else(|| gio::File::for_path(destination))
                .uri()
                .into();
            if self.remote_file(destination).is_none() {
                preserve_times(destination, metadata)?;
                if !metadata.is_symlink() {
                    fs::set_permissions(destination, metadata.permissions())?;
                }
            }
            let remote = self.remote_file(destination).is_some();
            let metadata = metadata.clone();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                let info = gio::File::for_uri(&from)
                    .query_info(
                        "xattr::*,xattr-sys::*",
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(&cancel),
                    )
                    .map_err(io::Error::other)?;
                for attribute in info.list_attributes(None) {
                    if !attribute.starts_with("xattr::") && !attribute.starts_with("xattr-sys::") {
                        info.remove_attribute(&attribute);
                    }
                }
                if remote {
                    use std::os::unix::fs::PermissionsExt;
                    if !metadata.is_symlink() {
                        info.set_attribute_uint32(
                            "unix::mode",
                            metadata.permissions().mode() & 0o7777,
                        );
                    }
                    for (attribute, time) in [
                        ("time::modified", metadata.modified()),
                        ("time::access", metadata.accessed()),
                    ] {
                        info.set_attribute_uint64(attribute, time.unix_seconds() as u64);
                        info.set_attribute_uint32(
                            &format!("{attribute}-usec"),
                            time.nanoseconds() / 1000,
                        );
                    }
                }
                if info.list_attributes(None).is_empty() {
                    return Ok(());
                }
                gio::File::for_uri(&to)
                    .set_attributes_from_info(
                        &info,
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(&cancel),
                    )
                    .map(|_| ())
                    .map_err(io::Error::other)
            })
        } else {
            preserve_times(destination, metadata)?;
            if !metadata.is_symlink() {
                fs::set_permissions(destination, metadata.permissions())?;
            }
            preserve_attributes(source, destination)
        }
    }

    fn symlink(&self, source: &Path, destination: &Path) -> io::Result<()> {
        if let Some(file) = self.remote_file(destination) {
            let uri: String = file.uri().into();
            let source = source.to_path_buf();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                gio::File::for_uri(&uri)
                    .make_symbolic_link(source, Some(&cancel))
                    .map_err(io::Error::other)
            })
        } else {
            std::os::unix::fs::symlink(source, destination)
        }
    }

    fn read_link(&self, path: &Path) -> io::Result<PathBuf> {
        if let Some(file) = self.remote_file(path) {
            let uri: String = file.uri().into();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                gio::File::for_uri(&uri)
                    .query_info(
                        "standard::symlink-target",
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(&cancel),
                    )
                    .map_err(io::Error::other)?
                    .symlink_target()
                    .ok_or_else(|| io::Error::other("Missing remote link target"))
            })
        } else {
            fs::read_link(path)
        }
    }

    fn unique_name(&self, path: &Path) -> io::Result<PathBuf> {
        if self.remote_file(path).is_none() {
            return Ok(unique_name(path));
        }
        let name = path.file_name().unwrap_or_default().to_string_lossy();
        let (stem, extension) = if self.metadata(path)?.is_dir() {
            (name.into_owned(), String::new())
        } else {
            (
                path.file_stem()
                    .unwrap_or_default()
                    .to_string_lossy()
                    .into_owned(),
                path.extension()
                    .map(|extension| format!(".{}", extension.to_string_lossy()))
                    .unwrap_or_default(),
            )
        };
        for index in 1u64.. {
            let candidate = path.with_file_name(format!("{stem} (copy {index}){extension}"));
            match self.metadata(&candidate) {
                Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(candidate),
                Err(error) => return Err(error),
                Ok(_) => {}
            }
        }
        unreachable!()
    }

    fn children(&self, path: &Path) -> io::Result<Vec<PathBuf>> {
        if let Some(file) = self.remote_file(path) {
            let uri: String = file.uri().into();
            let parent = path.to_path_buf();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                let entries = gio::File::for_uri(&uri)
                    .enumerate_children(
                        "standard::name",
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(&cancel),
                    )
                    .map_err(io::Error::other)?;
                let mut paths = Vec::new();
                while let Some(info) = entries.next_file(Some(&cancel)).map_err(io::Error::other)? {
                    let name = info.name();
                    if name.components().count() != 1
                        || !matches!(
                            name.components().next(),
                            Some(std::path::Component::Normal(_))
                        )
                    {
                        return Err(io::Error::other(
                            "Remote directory returned an invalid filename",
                        ));
                    }
                    paths.push(parent.join(name));
                }
                Ok(paths)
            })
        } else {
            fs::read_dir(path)?
                .map(|entry| entry.map(|entry| entry.path()))
                .collect()
        }
    }

    fn snapshot(&self, path: &Path) -> io::Result<Snapshot> {
        if self.remote_file(path).is_none() {
            return Snapshot::read(path);
        }
        let mut pending = vec![path.to_path_buf()];
        let mut versions = Vec::new();
        while let Some(path) = pending.pop() {
            self.check()?;
            let version = self.metadata(&path)?;
            if version.is_dir() {
                pending.extend(self.children(&path)?);
            }
            versions.push((path, version));
        }
        versions.sort_by(|a, b| a.0.cmp(&b.0));
        Ok(Snapshot {
            root: path.to_path_buf(),
            versions,
        })
    }

    fn prune_sources(&self, mut sources: Vec<PathBuf>) -> Vec<PathBuf> {
        sources.sort();
        sources.dedup();
        let mut result = Vec::new();
        for source in sources {
            if !result.iter().any(|parent: &PathBuf| {
                source.starts_with(parent) && self.metadata(parent).is_ok_and(|m| m.is_dir())
            }) {
                result.push(source);
            }
        }
        result
    }

    fn choose(&mut self, source: &Path, destination: &Path) -> io::Result<Choice> {
        self.check()?;
        let source_metadata = self.metadata(source).ok();
        let destination_metadata = self.metadata(destination).ok();
        let can_merge = self.allow_merge
            && source_metadata.as_ref().is_some_and(Metadata::is_dir)
            && destination_metadata.as_ref().is_some_and(Metadata::is_dir);
        if let Some(choice) = self.policy
            && (!matches!(choice, Choice::Merge) || can_merge)
        {
            return Ok(choice);
        }
        let (answer, receiver) = mpsc::channel();
        let waiting = Instant::now();
        self.emit(Event::Conflict(Box::new(Conflict {
            task: self.id,
            source: source.into(),
            destination: destination.into(),
            can_merge,
            source_metadata,
            destination_metadata,
            answer,
        })));
        loop {
            self.check()?;
            match receiver.recv_timeout(Duration::from_millis(60)) {
                Ok((Choice::Cancel, _)) => {
                    self.cancel.cancel();
                    self.check()?;
                }
                Ok((choice, all)) => {
                    self.waiting += waiting.elapsed();
                    if matches!(choice, Choice::Skip) {
                        self.emit(Event::Totals {
                            id: self.id,
                            bytes: None,
                            entries: None,
                        });
                    }
                    if all {
                        self.policy = Some(choice);
                    }
                    return Ok(choice);
                }
                Err(mpsc::RecvTimeoutError::Timeout) => {}
                Err(_) => {
                    return Err(io::Error::new(
                        io::ErrorKind::Interrupted,
                        "Conflict dialog closed",
                    ));
                }
            }
        }
    }

    fn canonical_parent(&self, path: &Path) -> io::Result<PathBuf> {
        let parent = path
            .parent()
            .ok_or_else(|| io::Error::other("Path has no parent"))?;
        let root = self
            .remote_roots
            .iter()
            .filter(|root| parent.starts_with(&root.path))
            .max_by_key(|root| root.path.components().count())
            .cloned();
        if let Some(root) = root {
            let parent = parent.to_path_buf();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                canonical_remote(&parent, &root, &cancel)
            })
        } else {
            parent.canonicalize()
        }
    }

    fn destination(&mut self, source: &Path, destination: &Path) -> io::Result<Destination> {
        if self.remote_file(source).is_some() || self.remote_file(destination).is_some() {
            let origin = self.canonical_parent(source)?.join(
                source
                    .file_name()
                    .ok_or_else(|| io::Error::other("Source has no filename"))?,
            );
            let target = self.canonical_parent(destination)?.join(
                destination
                    .file_name()
                    .ok_or_else(|| io::Error::other("Destination has no filename"))?,
            );
            if origin == target || (self.metadata(source)?.is_dir() && target.starts_with(origin)) {
                return Err(io::Error::other(
                    "Cannot transfer a file onto itself or a folder into itself",
                ));
            }
        } else {
            ensure_destination(source, destination)?;
        }
        self.check()?;
        match self.metadata(destination) {
            Ok(_) => {}
            Err(error) if error.kind() == io::ErrorKind::NotFound => {
                return Ok(Destination::Publish {
                    path: destination.into(),
                    replace: false,
                });
            }
            Err(error) => return Err(error),
        }
        match self.choose(source, destination)? {
            Choice::Skip => Ok(Destination::Skip),
            Choice::KeepBoth => Ok(Destination::Publish {
                path: self.unique_name(destination)?,
                replace: false,
            }),
            Choice::Replace => {
                self.undo = None;
                Ok(Destination::Publish {
                    path: destination.into(),
                    replace: true,
                })
            }
            Choice::Merge => Ok(Destination::Merge(destination.into())),
            Choice::Cancel => unreachable!(),
        }
    }

    fn transfer(
        &mut self,
        source: &Path,
        destination: &Path,
        moving: bool,
    ) -> io::Result<Option<PathBuf>> {
        self.check()?;
        let parents = self.parent_versions(&[source, destination]);
        let failures = self.failures.len();
        let publications = self.publications.load(Ordering::Relaxed);
        let result = self.transfer_inner(source, destination, moving);
        if let Err(error) = &result
            && self.failures.len() == failures
        {
            let published = self.publications.load(Ordering::Relaxed) != publications;
            self.failures.push(Failure {
                source: source.to_path_buf(),
                destination: Some(destination.to_path_buf()),
                error: if published {
                    format!("{error}. Destination may have changed; inspect both locations before retrying")
                } else { error.to_string() },
            });
            if self.allow_merge && !published && !self.cancel.cancelled() {
                if moving
                    && source.file_name() == destination.file_name()
                    && let Some(parent) = destination.parent()
                {
                    self.retry.push(Operation::Move {
                        sources: vec![source.to_path_buf()],
                        destination: parent.to_path_buf(),
                    });
                } else if moving {
                    self.retry.push(Operation::Rename(vec![(
                        source.to_path_buf(),
                        destination.to_path_buf(),
                    )]));
                } else if source.file_name() == destination.file_name()
                    && let Some(parent) = destination.parent()
                {
                    self.retry.push(Operation::Copy {
                        sources: vec![source.to_path_buf()],
                        destination: parent.to_path_buf(),
                    });
                }
            }
        }
        if result.is_ok() {
            self.rebase_parents(parents);
        }
        result
    }
    fn transfer_inner(
        &mut self,
        source: &Path,
        destination: &Path,
        moving: bool,
    ) -> io::Result<Option<PathBuf>> {
        self.check()?;
        self.progress(source, true);
        let duplicate = if !moving && source == destination {
            self.unique_name(destination)?
        } else {
            destination.to_path_buf()
        };
        let (destination, replace) = match self.destination(source, &duplicate)? {
            Destination::Publish { path, replace } => (path, replace),
            Destination::Skip => return Ok(None),
            Destination::Merge(path) => {
                use std::os::unix::fs::MetadataExt;
                let finalize = if moving && self.remote_file(source).is_none() {
                    fs::symlink_metadata(source)
                        .ok()
                        .filter(|m| m.is_dir())
                        .map(|metadata| Finalization {
                            path: source.to_path_buf(),
                            device: metadata.dev(),
                            inode: metadata.ino(),
                        })
                } else {
                    None
                };
                if moving {
                    self.undo = None;
                }
                let mut failed = None;
                for entry in self.children(source)? {
                    if let Err(error) = self.transfer(
                        &entry,
                        &path.join(entry.file_name().expect("directory entry")),
                        moving,
                    ) {
                        failed.get_or_insert(error);
                        if self.cancel.cancelled() {
                            break;
                        }
                    }
                }
                if let Some(error) = failed {
                    if let Some(finalize) = finalize {
                        self.finalize.push(finalize);
                    } else if moving && self.remote_file(source).is_some() {
                        self.warnings.push(format!("After retrying, inspect and remove empty remote source folders manually: {}", source.display()));
                    }
                    return Err(error);
                }
                if moving && self.children(source)?.is_empty() {
                    self.remove(source)?;
                }
                self.progress(&path, true);
                return Ok(Some(path));
            }
        };
        let before = self.metadata(source)?;
        self.check()?;
        if moving && self.metadata(&destination).is_err() {
            self.check()?;
            match self.rename(source, &destination) {
                Ok(()) => {
                    if let Ok(after) = self.metadata(&destination) {
                        self.rebase(
                            Snapshot::single(source, before),
                            Snapshot::single(&destination, after),
                            None,
                        );
                    }
                    self.record_moved(&destination, source, false);
                    self.entries += 1;
                    self.progress(&destination, true);
                    return Ok(Some(destination));
                }
                Err(error) if error.raw_os_error() == Some(libc::EXDEV) => {}
                Err(error) => return Err(error),
            }
        }
        let staging = self.staging(
            destination
                .parent()
                .ok_or_else(|| io::Error::other("Destination has no parent"))?,
        )?;
        let content = staging.path.join("content");
        let mut versions = Vec::new();
        self.copy_tree(source, &content, &mut versions)?;
        self.check_sources(&versions)?;
        staging.publish(
            &content,
            &destination,
            replace,
            &self.cancel.io,
            &self.publications,
        )?;
        if moving {
            if let Err(error) = self
                .check_sources(&versions)
                .and_then(|_| self.remove(source))
            {
                self.record_created(&destination, replace);
                self.failures.push(Failure {
                    source: source.to_path_buf(),
                    destination: Some(destination.clone()),
                    error: format!("{error}. Destination already contains transferred data; inspect both locations before retrying"),
                });
                return Err(error);
            }
            if let Ok(after) = self.snapshot(&destination) {
                self.rebase(
                    Snapshot {
                        root: source.to_path_buf(),
                        versions,
                    },
                    after,
                    None,
                );
            }
            self.record_moved(&destination, source, replace);
        } else {
            self.record_created(&destination, replace);
        }
        self.progress(&destination, true);
        Ok(Some(destination))
    }

    fn record_created(&mut self, path: &Path, replace: bool) {
        if replace {
            self.undo = None;
            return;
        }
        if self.undo.is_none() {
            return;
        }
        match self.snapshot(path) {
            Ok(snapshot) => self
                .undo
                .as_mut()
                .unwrap()
                .0
                .push(UndoStep::Remove(snapshot)),
            Err(error) => {
                self.undo = None;
                self.warnings.push(format!("Undo unavailable: {error}"));
            }
        }
    }

    fn record_moved(&mut self, path: &Path, original: &Path, replace: bool) {
        self.record_created(path, replace);
        if let Some(undo) = &mut self.undo
            && let Some(UndoStep::Remove(snapshot)) = undo.0.pop()
        {
            undo.0
                .push(UndoStep::Move(snapshot, original.to_path_buf()));
        }
    }

    fn trash_path(&mut self, source: &Path) -> io::Result<()> {
        let parents = self.parent_versions(&[source]);
        let version = self.snapshot(source).ok();
        let before = crate::trash::read().ok();
        self.gio(vec!["trash".into(), "--".into(), source.as_os_str().into()])?;
        let entry = before.and_then(|before| {
            crate::trash::read().ok().and_then(|entries| {
                entries.into_iter().find(|entry| {
                    entry.original == source && !before.iter().any(|old| old.uri == entry.uri)
                })
            })
        });
        if let (Some(entry), Some(version)) = (entry, version) {
            match self.snapshot_uri(&entry.uri, source) {
                Ok(after) => {
                    self.rebase(version, after.clone(), Some(entry.uri.clone()));
                    if let Some(undo) = &mut self.undo {
                        undo.0.push(UndoStep::Restore {
                            uri: entry.uri,
                            original: entry.original,
                            version: after,
                        });
                    }
                }
                Err(error) => {
                    self.undo = None;
                    self.warnings
                        .push(format!("Trash undo unavailable: {error}"));
                }
            }
        } else {
            self.undo = None;
            self.warnings
                .push("Trash undo unavailable: could not identify the new item".into());
        }
        self.rebase_parents(parents);
        Ok(())
    }

    fn snapshot_uri(&self, uri: &str, path: &Path) -> io::Result<Snapshot> {
        let uri = uri.to_string();
        let root = path.to_path_buf();
        let cancel = self.cancel.io.clone();
        inspect_remote(&self.cancel.io, move || {
            let mut pending = vec![(gio::File::for_uri(&uri), root.clone())];
            let mut versions = Vec::new();
            while let Some((file, path)) = pending.pop() {
                let info = file
                    .query_info(
                        "standard::type,standard::size,unix::mode,time::*,etag::value,id::file",
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(&cancel),
                    )
                    .map_err(io::Error::other)?;
                let version = Metadata::remote(&info);
                if version.is_dir() {
                    let entries = file
                        .enumerate_children(
                            "standard::name",
                            gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                            Some(&cancel),
                        )
                        .map_err(io::Error::other)?;
                    while let Some(info) =
                        entries.next_file(Some(&cancel)).map_err(io::Error::other)?
                    {
                        let name = info.name();
                        if name.components().count() != 1
                            || !matches!(
                                name.components().next(),
                                Some(std::path::Component::Normal(_))
                            )
                        {
                            return Err(io::Error::other("Invalid Trash filename"));
                        }
                        pending.push((file.child(&name), path.join(name)));
                    }
                }
                versions.push((path, version));
            }
            versions.sort_by(|a, b| a.0.cmp(&b.0));
            Ok(Snapshot { root, versions })
        })
    }

    fn restore_uri(&mut self, uri: &str, original: &Path) -> io::Result<()> {
        if self.metadata(original).is_ok() {
            return Err(io::Error::other(
                "Original location is occupied; restore was refused",
            ));
        }
        let parents = self.parent_versions(&[original]);
        let before = self.snapshot_uri(uri, original)?;
        self.gio(vec![
            "trash".into(),
            "--restore".into(),
            "--".into(),
            uri.into(),
        ])?;
        let after = self.snapshot(original)?;
        self.rebase(before, after, None);
        self.rebase_parents(parents);
        self.progress(original, true);
        Ok(())
    }

    fn undo_step(&mut self, step: &UndoStep) -> io::Result<()> {
        self.check()?;
        match step {
            UndoStep::Remove(snapshot) => {
                snapshot.check(self.snapshot(&snapshot.root)?)?;
                self.trash_path(&snapshot.root)?;
                self.progress(&snapshot.root, true);
            }
            UndoStep::Move(snapshot, original) => {
                snapshot.check(self.snapshot(&snapshot.root)?)?;
                if self.metadata(original).is_ok() {
                    return Err(io::Error::other(
                        "Original location is occupied; undo was refused",
                    ));
                }
                self.transfer(&snapshot.root, original, true)?;
            }
            UndoStep::Restore { uri, original, .. } => self.restore_uri(uri, original)?,
            UndoStep::Mode {
                path,
                version,
                mode,
            } => {
                if !same_version(version, &self.metadata(path)?) {
                    return Err(io::Error::other("Item changed; undo was refused"));
                }
                self.permission(path, *mode, false, false)?;
            }
        }
        Ok(())
    }

    fn check_sources(&self, versions: &[(PathBuf, Metadata)]) -> io::Result<()> {
        for (path, before) in versions {
            self.check()?;
            if !same_version(before, &self.metadata(path)?) {
                return Err(io::Error::other(format!(
                    "{} changed during the transfer; source was retained",
                    path.display()
                )));
            }
        }
        Ok(())
    }

    fn remote_file(&self, path: &Path) -> Option<gio::File> {
        let root = self
            .remote_roots
            .iter()
            .filter(|root| path.starts_with(&root.path))
            .max_by_key(|root| root.path.components().count())?;
        let relative = path.strip_prefix(&root.path).expect("matched remote root");
        Some(gio::File::for_uri(&root.uri).resolve_relative_path(relative))
    }

    fn copy_tree(
        &mut self,
        source: &Path,
        destination: &Path,
        versions: &mut Vec<(PathBuf, Metadata)>,
    ) -> io::Result<()> {
        use std::os::unix::fs::OpenOptionsExt;
        self.check()?;
        let metadata = self.metadata(source)?;
        if metadata.is_symlink() {
            self.symlink(&self.read_link(source)?, destination)?;
        } else if metadata.is_dir() {
            self.make_directory(destination, false)?;
            for entry in self.children(source)? {
                self.copy_tree(
                    &entry,
                    &destination.join(entry.file_name().expect("directory entry")),
                    versions,
                )?;
            }
        } else if metadata.is_file() {
            let mut input = if let Some(file) = self.remote_file(source) {
                SourceInput::Remote(RemoteStream::open(
                    file.uri().into(),
                    false,
                    self.cancel.io.clone(),
                )?)
            } else {
                SourceInput::Local(
                    OpenOptions::new()
                        .read(true)
                        .custom_flags(libc::O_NOFOLLOW)
                        .open(source)?,
                )
            };
            input.check_metadata(&metadata)?;
            let mut output = if let Some(file) = self.remote_file(destination) {
                CopyOutput::Remote(RemoteStream::open(
                    file.uri().into(),
                    true,
                    self.cancel.io.clone(),
                )?)
            } else {
                CopyOutput::Local(
                    OpenOptions::new()
                        .create_new(true)
                        .write(true)
                        .open(destination)?,
                )
            };
            let mut buffer = [0u8; 128 * 1024];
            let mut received = 0u64;
            loop {
                self.check()?;
                let count = input.read(&mut buffer)?;
                if count == 0 {
                    if received != metadata.len() {
                        return Err(io::Error::new(
                            io::ErrorKind::UnexpectedEof,
                            format!(
                                "Source ended after {received} bytes; expected {}. Destination was not replaced",
                                metadata.len()
                            ),
                        ));
                    }
                    break;
                }
                received += count as u64;
                if received > metadata.len() {
                    return Err(io::Error::other(
                        "Source grew during copying; destination was not replaced",
                    ));
                }
                output.write_chunk(&buffer[..count])?;
                self.bytes += count as u64;
                self.progress(source, false);
            }
            output.finish(destination, &metadata)?;
        } else {
            return Err(io::Error::other("Copying special files is not supported"));
        }
        if let Err(error) = self.preserve_metadata(source, destination, &metadata) {
            self.check()?;
            self.warnings.push(format!(
                "{}: could not preserve metadata/extended attributes/ACLs: {error}",
                source.display()
            ));
        }
        if !same_version(&metadata, &self.metadata(source)?) {
            return Err(io::Error::other(
                "Source changed during copying; destination was not replaced",
            ));
        }
        versions.push((source.to_path_buf(), metadata));
        self.entries += 1;
        Ok(())
    }

    fn permission(
        &mut self,
        path: &Path,
        mode: u32,
        recursive: bool,
        safe: bool,
    ) -> io::Result<()> {
        use std::os::unix::fs::PermissionsExt;
        self.check()?;
        let metadata = self.metadata(path)?;
        if metadata.is_symlink() {
            return Ok(());
        }
        if recursive && metadata.is_dir() {
            for entry in self.children(path)? {
                self.permission(&entry, mode, true, safe)?;
            }
        }
        let previous_mode = metadata.permissions().mode();
        let mode = if safe {
            let execute = if !recursive || metadata.is_dir() || previous_mode & 0o111 != 0 {
                mode & 0o111
            } else {
                0
            };
            previous_mode & 0o7000 | mode & 0o666 | execute
        } else {
            mode
        };
        if let Some(file) = self.remote_file(path) {
            let uri: String = file.uri().into();
            let cancel = self.cancel.io.clone();
            inspect_remote(&self.cancel.io, move || {
                gio::File::for_uri(&uri)
                    .set_attribute_uint32(
                        "unix::mode",
                        mode,
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(&cancel),
                    )
                    .map_err(io::Error::other)
            })?;
        } else {
            fs::set_permissions(path, fs::Permissions::from_mode(mode))?;
        }
        {
            match self.metadata(path) {
                Ok(version) => {
                    self.rebase(
                        Snapshot::single(path, metadata),
                        Snapshot::single(path, version.clone()),
                        None,
                    );
                    if let Some(undo) = &mut self.undo {
                        undo.0.push(UndoStep::Mode {
                            path: path.to_path_buf(),
                            version,
                            mode: previous_mode,
                        });
                    }
                }
                Err(error) => {
                    self.undo = None;
                    self.warnings
                        .push(format!("Permission undo unavailable: {error}"));
                }
            }
        }
        self.entries += 1;
        self.progress(path, true);
        Ok(())
    }

    fn gio(&self, arguments: Vec<OsString>) -> io::Result<()> {
        self.check()?;
        let mut child = Command::new("gio")
            .args(arguments)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::piped())
            .spawn()?;
        let status = loop {
            if self.cancel.cancelled() {
                let _ = child.kill();
                let _ = child.wait();
                return self.check();
            }
            if let Some(status) = child.try_wait()? {
                break status;
            }
            thread::sleep(Duration::from_millis(30));
        };
        let mut error = String::new();
        if let Some(stderr) = child.stderr.take() {
            stderr.take(16384).read_to_string(&mut error)?;
        }
        if status.success() {
            Ok(())
        } else {
            Err(io::Error::other(error.trim().to_owned()))
        }
    }

    fn run(&mut self, operation: Operation) -> Vec<String> {
        self.allow_merge = matches!(
            &operation,
            Operation::Copy { .. } | Operation::Move { .. } | Operation::Rename(_)
        );
        let moving = matches!(&operation, Operation::Move { .. });
        let permanent = matches!(&operation, Operation::Delete(_));
        let mut errors = Vec::new();
        let mut failures = Vec::new();
        let mut attempt = |path: &Path, result: io::Result<()>| {
            if let Err(error) = result {
                failures.push(Failure {
                    source: path.to_path_buf(),
                    destination: None,
                    error: error.to_string(),
                });
                errors.push(format!("{}: {error}", path.display()));
            }
        };
        match operation {
            Operation::Undo(mut undo) => {
                self.undo = None;
                while let Some(step) = undo.0.last() {
                    let result = self.undo_step(step);
                    for change in std::mem::take(&mut self.rebases) {
                        undo.rebase(&change);
                    }
                    if let Err(error) = result {
                        errors.push(error.to_string());
                        break;
                    }
                    undo.0.pop();
                    self.entries += 1;
                }
                self.undo = Some(undo);
            }
            Operation::Copy {
                sources,
                destination,
            }
            | Operation::Move {
                sources,
                destination,
            } => {
                for source in self.prune_sources(sources) {
                    let target = source.file_name().map(|name| destination.join(name));
                    let result = match target {
                        Some(target) => self.transfer(&source, &target, moving).map(|_| ()),
                        None => Err(io::Error::other("Cannot transfer the filesystem root")),
                    };
                    attempt(&source, result);
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::Rename(pairs) => {
                for (source, destination) in pairs {
                    attempt(
                        &source,
                        self.transfer(&source, &destination, true).map(|_| ()),
                    );
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::Properties {
                source,
                destination,
                mode,
                recursive,
            } => {
                let result = (|| {
                    let destination = if source != destination {
                        self.transfer(&source, &destination, true)?.ok_or_else(|| {
                            io::Error::other("Rename was skipped; permissions were not changed")
                        })?
                    } else {
                        destination
                    };
                    self.result = Some(destination.clone());
                    if let Some(mode) = mode {
                        self.permission(&destination, mode, recursive, true)?;
                    }
                    Ok(())
                })();
                attempt(&source, result);
            }
            Operation::Trash(sources) | Operation::Delete(sources) => {
                for source in self.prune_sources(sources) {
                    let result = self.check().and_then(|_| {
                        if permanent {
                            self.remove(&source)
                        } else {
                            self.trash_path(&source)
                        }
                    });
                    attempt(&source, result);
                    self.entries += 1;
                    self.progress(&source, true);
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::DeleteTrash(uris) => {
                for uri in uris {
                    let result = if uri.starts_with("trash:///") && uri != "trash:///" {
                        self.gio(vec!["remove".into(), "--".into(), uri.clone().into()])
                    } else {
                        Err(io::Error::other("Expected an individual trash item"))
                    };
                    attempt(Path::new(&uri), result);
                    self.entries += 1;
                    self.progress(Path::new(&uri), true);
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::Restore(uris) => {
                for uri in uris {
                    let result = (|| {
                        let entry = crate::trash::read()
                            .map_err(io::Error::other)?
                            .into_iter()
                            .find(|entry| entry.uri == uri)
                            .ok_or_else(|| io::Error::other("Trash item no longer exists"))?;
                        if entry.original.as_os_str().is_empty() {
                            return Err(io::Error::other("Trash item has no original location"));
                        }
                        if self.metadata(&entry.original).is_ok() {
                            return Err(io::Error::other(
                                "Original location is occupied; restore was refused",
                            ));
                        }
                        self.restore_uri(&uri, &entry.original)?;
                        self.record_created(&entry.original, false);
                        Ok(())
                    })();
                    attempt(Path::new(&uri), result);
                    self.entries += 1;
                    self.progress(Path::new(&uri), true);
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::Create { path, directory } => {
                let mut created = path.clone();
                while let Some(parent) = created.parent() {
                    match self.metadata(parent) {
                        Ok(_) => break,
                        Err(error) if error.kind() == io::ErrorKind::NotFound => {
                            created = parent.to_path_buf()
                        }
                        Err(_) => break,
                    }
                }
                let parents = self.parent_versions(&[&created]);
                let result = self.check().and_then(|_| {
                    if directory {
                        if self.metadata(&path).is_ok() {
                            return Err(io::Error::new(
                                io::ErrorKind::AlreadyExists,
                                "Already exists",
                            ));
                        }
                        self.make_directory(&path, true)
                    } else {
                        if let Some(parent) = path.parent() {
                            self.make_directory(parent, true)?;
                        }
                        if let Some(file) = self.remote_file(&path) {
                            return RemoteStream::open(
                                file.uri().into(),
                                true,
                                self.cancel.io.clone(),
                            )?
                            .close();
                        }
                        OpenOptions::new()
                            .create_new(true)
                            .write(true)
                            .open(&path)
                            .map(|_| ())
                    }
                });
                if result.is_ok() {
                    self.rebase_parents(parents);
                    self.record_created(&created, false);
                }
                attempt(&path, result);
                self.entries += 1;
                self.progress(&path, true);
            }
            Operation::Link {
                sources,
                destination,
                relative,
                hard,
            } => {
                for source in self.prune_sources(sources) {
                    let result =
                        (|| {
                            let target = destination.join(source.file_name().ok_or_else(|| {
                                io::Error::other("Cannot link the filesystem root")
                            })?);
                            let Destination::Publish {
                                path: target,
                                replace,
                            } = self.destination(&source, &target)?
                            else {
                                return Ok(());
                            };
                            let staging =
                                self.staging(target.parent().ok_or_else(|| {
                                    io::Error::other("Destination has no parent")
                                })?)?;
                            let content = staging.path.join("content");
                            if hard {
                                if self.remote_file(&source).is_some()
                                    || self.remote_file(&content).is_some()
                                {
                                    return Err(io::Error::new(
                                        io::ErrorKind::Unsupported,
                                        "Remote hard links are not supported by GIO",
                                    ));
                                }
                                fs::hard_link(&source, &content)?;
                            } else {
                                let link = if relative {
                                    let parent = self.canonical_parent(&target)?;
                                    let target = self.canonical_parent(&source)?.join(
                                        source.file_name().ok_or_else(|| {
                                            io::Error::other("Link source has no name")
                                        })?,
                                    );
                                    relative_path(&parent, &target)?
                                } else if self.remote_file(&content).is_some() {
                                    let source = self.remote_file(&source).ok_or_else(|| {
                                        io::Error::new(
                                            io::ErrorKind::Unsupported,
                                            "A remote symbolic link cannot target a local file",
                                        )
                                    })?;
                                    let uri =
                                        url::Url::parse(&source.uri()).map_err(io::Error::other)?;
                                    PathBuf::from(
                                        gio::glib::uri_unescape_string(uri.path(), None::<&str>)
                                            .ok_or_else(|| {
                                                io::Error::other("Invalid remote link path")
                                            })?
                                            .as_str(),
                                    )
                                } else {
                                    source.clone()
                                };
                                self.symlink(&link, &content)?;
                            }
                            self.check()?;
                            staging.publish(
                                &content,
                                &target,
                                replace,
                                &self.cancel.io,
                                &self.publications,
                            )?;
                            self.record_created(&target, replace);
                            self.entries += 1;
                            self.progress(&target, true);
                            Ok(())
                        })();
                    attempt(&source, result);
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::Permissions {
                sources,
                mode,
                recursive,
            } => {
                for source in self.prune_sources(sources) {
                    attempt(&source, self.permission(&source, mode, recursive, false));
                    if self.cancel.cancelled() {
                        break;
                    }
                }
            }
            Operation::Archive {
                sources,
                destination,
            } => {
                let result = (|| {
                    let source = sources
                        .first()
                        .ok_or_else(|| io::Error::other("Select at least one item to archive"))?;
                    let Destination::Publish {
                        path: target,
                        replace,
                    } = self.destination(source, &destination)?
                    else {
                        return Ok(());
                    };
                    let staging = self.staging(
                        target
                            .parent()
                            .ok_or_else(|| io::Error::other("Destination has no parent"))?,
                    )?;
                    let content = staging.path.join("content");
                    let sources = self.prune_sources(sources);
                    let scratch = Staging::new(&std::env::temp_dir())?;
                    let mut versions = Vec::new();
                    let mut inputs = Vec::new();
                    for (index, source) in sources.into_iter().enumerate() {
                        if self.remote_file(&source).is_some() {
                            let parent = scratch.path.join(index.to_string());
                            fs::create_dir(&parent)?;
                            let local = parent.join(source.file_name().ok_or_else(|| {
                                io::Error::other("Cannot archive the filesystem root")
                            })?);
                            self.copy_tree(&source, &local, &mut versions)?;
                            inputs.push(local);
                        } else {
                            inputs.push(source);
                        }
                    }
                    let output = if self.remote_file(&content).is_some() {
                        scratch.path.join("archive")
                    } else {
                        content.clone()
                    };
                    crate::archive::create(
                        &inputs,
                        &output,
                        &destination,
                        self.cancel.requested.clone(),
                    )?;
                    self.check_sources(&versions)?;
                    if output != content {
                        self.copy_tree(&output, &content, &mut Vec::new())?;
                    }
                    self.check()?;
                    staging.publish(
                        &content,
                        &target,
                        replace,
                        &self.cancel.io,
                        &self.publications,
                    )?;
                    self.record_created(&target, replace);
                    self.progress(&target, true);
                    Ok(())
                })();
                attempt(&destination, result);
            }
            Operation::Extract {
                source,
                destination,
            } => {
                let result = (|| {
                    let Destination::Publish {
                        path: target,
                        replace,
                    } = self.destination(&source, &destination)?
                    else {
                        return Ok(());
                    };
                    let staging = self.staging(
                        target
                            .parent()
                            .ok_or_else(|| io::Error::other("Destination has no parent"))?,
                    )?;
                    let content = staging.path.join("content");
                    let scratch = Staging::new(&std::env::temp_dir())?;
                    let mut versions = Vec::new();
                    let input = if self.remote_file(&source).is_some() {
                        let input = scratch.path.join(
                            source
                                .file_name()
                                .ok_or_else(|| io::Error::other("Archive has no filename"))?,
                        );
                        self.copy_tree(&source, &input, &mut versions)?;
                        input
                    } else {
                        source.clone()
                    };
                    let output = if self.remote_file(&content).is_some() {
                        scratch.path.join("extracted")
                    } else {
                        content.clone()
                    };
                    fs::create_dir(&output)?;
                    crate::archive::extract(&input, &output, self.cancel.requested.clone())?;
                    self.check_sources(&versions)?;
                    if output != content {
                        self.copy_tree(&output, &content, &mut Vec::new())?;
                    }
                    self.check()?;
                    staging.publish(
                        &content,
                        &target,
                        replace,
                        &self.cancel.io,
                        &self.publications,
                    )?;
                    self.record_created(&target, replace);
                    self.progress(&target, true);
                    Ok(())
                })();
                attempt(&source, result);
            }
        }
        for failure in failures {
            if !self
                .failures
                .iter()
                .any(|known| known.source == failure.source)
                && !self
                    .failures
                    .iter()
                    .any(|known| known.source.starts_with(&failure.source))
            {
                self.failures.push(failure);
            }
        }
        errors
    }
}

fn preserve_times(path: &Path, metadata: &Metadata) -> io::Result<()> {
    filetime::set_symlink_file_times(path, metadata.accessed(), metadata.modified())
}

fn preserve_attributes(source: &Path, destination: &Path) -> io::Result<()> {
    let names = match xattr::list(source) {
        Ok(names) => names,
        Err(error) if error.raw_os_error() == Some(libc::ENOTSUP) => return Ok(()),
        Err(error) => return Err(error),
    };
    for name in names {
        if let Some(value) = xattr::get(source, &name)? {
            xattr::set(destination, &name, &value)?;
        }
    }
    Ok(())
}

fn remove(path: &Path) -> io::Result<()> {
    if path.parent().is_none()
        || (fs::symlink_metadata(path)?.is_dir() && path.canonicalize()?.parent().is_none())
    {
        return Err(io::Error::other("Cannot remove the filesystem root"));
    }
    if fs::symlink_metadata(path)?.is_dir() {
        fs::remove_dir_all(path)
    } else {
        fs::remove_file(path)
    }
}

fn ensure_destination(source: &Path, destination: &Path) -> io::Result<()> {
    let parent = destination
        .parent()
        .ok_or_else(|| io::Error::other("Destination has no parent"))?
        .canonicalize()?;
    let target = parent.join(
        destination
            .file_name()
            .ok_or_else(|| io::Error::other("Destination has no filename"))?,
    );
    let origin = source
        .parent()
        .ok_or_else(|| io::Error::other("Cannot transfer the filesystem root"))?
        .canonicalize()?
        .join(
            source
                .file_name()
                .ok_or_else(|| io::Error::other("Source has no filename"))?,
        );
    if target == origin
        || (fs::symlink_metadata(source)?.is_dir() && target.starts_with(source.canonicalize()?))
    {
        return Err(io::Error::other(
            "Cannot transfer a file onto itself or a folder into itself",
        ));
    }
    Ok(())
}

fn unique_name(path: &Path) -> PathBuf {
    let name = path.file_name().unwrap_or_default().to_string_lossy();
    let (stem, extension) = if fs::symlink_metadata(path).is_ok_and(|m| m.is_dir()) {
        (name.as_ref(), String::new())
    } else {
        (
            path.file_stem().and_then(|s| s.to_str()).unwrap_or(&name),
            path.extension()
                .map(|e| format!(".{}", e.to_string_lossy()))
                .unwrap_or_default(),
        )
    };
    for index in 1.. {
        let candidate = path.with_file_name(format!("{stem} ({index}){extension}"));
        if fs::symlink_metadata(&candidate).is_err() {
            return candidate;
        }
    }
    unreachable!()
}

fn relative_path(base: &Path, target: &Path) -> io::Result<PathBuf> {
    let a: Vec<_> = base.components().collect();
    let b: Vec<_> = target.components().collect();
    let shared = a.iter().zip(&b).take_while(|(a, b)| a == b).count();
    let mut path = PathBuf::new();
    for _ in shared..a.len() {
        path.push("..");
    }
    for part in &b[shared..] {
        path.push(part.as_os_str());
    }
    Ok(path)
}

struct Staging {
    path: PathBuf,
    remote: Option<String>,
    retain: std::cell::Cell<bool>,
}

impl Staging {
    fn new(parent: &Path) -> io::Result<Self> {
        use std::os::unix::fs::DirBuilderExt;
        static NEXT: AtomicU64 = AtomicU64::new(0);
        loop {
            let path = parent.join(format!(
                ".vereda-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            match fs::DirBuilder::new().mode(0o700).create(&path) {
                Ok(()) => {
                    return Ok(Self {
                        path,
                        remote: None,
                        retain: std::cell::Cell::new(false),
                    });
                }
                Err(e) if e.kind() == io::ErrorKind::AlreadyExists => continue,
                Err(e) => return Err(e),
            }
        }
    }

    fn remote(parent: &Path, uri: &str, cancel: &gio::Cancellable) -> io::Result<Self> {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        loop {
            let name = format!(
                ".vereda-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            );
            let file = gio::File::for_uri(uri).child(&name);
            let result = file.make_directory(Some(cancel));
            if result
                .as_ref()
                .is_err_and(|error| error.matches(gio::IOErrorEnum::Exists))
            {
                continue;
            }
            let staging = Self {
                path: parent.join(&name),
                remote: Some(file.uri().into()),
                retain: std::cell::Cell::new(false),
            };
            match result {
                Ok(()) => {
                    file.set_attribute_uint32(
                        "unix::mode",
                        0o700,
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(cancel),
                    )
                    .map_err(io::Error::other)?;
                    return Ok(staging);
                }
                Err(error) => return Err(io::Error::other(error)),
            }
        }
    }

    fn publish(
        &self,
        content: &Path,
        destination: &Path,
        replace: bool,
        cancellation: &gio::Cancellable,
        publications: &Arc<AtomicU64>,
    ) -> io::Result<()> {
        if let Some(uri) = &self.remote {
            let uri = uri.clone();
            let name = destination
                .file_name()
                .ok_or_else(|| io::Error::other("Destination has no filename"))?
                .to_os_string();
            let content = content
                .file_name()
                .ok_or_else(|| io::Error::other("Staging content has no filename"))?
                .to_os_string();
            let cancel = cancellation.clone();
            self.retain.set(true);
            let publications = publications.clone();
            let result = inspect_remote(cancellation, move || {
                let staging = gio::File::for_uri(&uri);
                let destination = staging
                    .parent()
                    .ok_or_else(|| io::Error::other("Staging has no parent"))?
                    .child(name);
                let backup = staging.child("previous");
                let flags = gio::FileCopyFlags::NOFOLLOW_SYMLINKS
                    | gio::FileCopyFlags::NO_FALLBACK_FOR_MOVE;
                let exists = match destination.query_info(
                    "standard::type",
                    gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                    Some(&cancel),
                ) {
                    Ok(_) => true,
                    Err(error) if error.matches(gio::IOErrorEnum::NotFound) => false,
                    Err(error) => return Err(io::Error::other(error)),
                };
                if exists && !replace {
                    return Err(io::Error::new(
                        io::ErrorKind::AlreadyExists,
                        "Destination appeared during the operation; nothing was overwritten",
                    ));
                }
                // A remote failure can race a committed server-side move.
                publications.fetch_add(1, Ordering::Relaxed);
                if exists {
                    destination
                        .move_(&backup, flags, Some(&cancel), None)
                        .map_err(io::Error::other)?;
                }
                if let Err(error) =
                    staging
                        .child(content)
                        .move_(&destination, flags, Some(&cancel), None)
                {
                    if exists
                        && !cancel.is_cancelled()
                        && backup
                            .move_(&destination, flags, Some(&cancel), None)
                            .is_err()
                    {
                        return Err(io::Error::other(format!(
                            "{error}; previous destination retained at {}",
                            backup.uri()
                        )));
                    }
                    return Err(io::Error::other(error));
                }
                if exists {
                    remove_remote(&backup, &cancel)?;
                }
                Ok(())
            });
            if result.is_ok() {
                self.retain.set(false);
            }
            return result.map_err(|error| io::Error::new(error.kind(), format!("{error}; remote staging retained at {}. Inspect the destination before retrying", self.path.display())));
        }

        let backup = self.path.join("previous");
        let exists = fs::symlink_metadata(destination).is_ok();
        if exists && !replace {
            return Err(io::Error::new(
                io::ErrorKind::AlreadyExists,
                "Destination appeared during the operation; nothing was overwritten",
            ));
        }
        if exists {
            fs::rename(destination, &backup)?;
        }
        if let Err(error) = publish_new(content, destination, cancellation, publications) {
            if exists && rename_new(&backup, destination, &AtomicU64::new(0)).is_err() {
                publications.fetch_add(1, Ordering::Relaxed);
                return Err(io::Error::other(format!(
                    "{error}; previous destination retained at {}",
                    backup.display()
                )));
            }
            return Err(error);
        }
        if exists {
            remove(&backup).map_err(|error| {
                io::Error::other(format!(
                    "Destination updated; previous copy retained at {}: {error}",
                    backup.display()
                ))
            })?;
        }
        Ok(())
    }
}

impl Drop for Staging {
    fn drop(&mut self) {
        let path = self.path.clone();
        let cleanup = move || {
            if fs::symlink_metadata(path.join("previous")).is_err() {
                let _ = fs::remove_dir_all(path);
            }
        };
        if let Some(uri) = self.remote.clone() {
            if self.retain.get() {
                return;
            }
            thread::spawn(move || {
                let file = gio::File::for_uri(&uri);
                let cancel = gio::Cancellable::new();
                match file.child("previous").query_info(
                    "standard::type",
                    gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                    Some(&cancel),
                ) {
                    Err(error) if error.matches(gio::IOErrorEnum::NotFound) => {
                        let _ = remove_remote(&file, &cancel);
                    }
                    _ => {}
                }
            });
        } else {
            cleanup();
        }
    }
}

fn remove_remote(root: &gio::File, cancel: &gio::Cancellable) -> io::Result<()> {
    let mut pending = vec![(root.clone(), false)];
    while let Some((file, visited)) = pending.pop() {
        if !visited {
            let info = file
                .query_info(
                    "standard::type",
                    gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                    Some(cancel),
                )
                .map_err(io::Error::other)?;
            if info.file_type() == gio::FileType::Directory {
                let entries = file
                    .enumerate_children(
                        "standard::name",
                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                        Some(cancel),
                    )
                    .map_err(io::Error::other)?;
                pending.push((file.clone(), true));
                while let Some(info) = entries.next_file(Some(cancel)).map_err(io::Error::other)? {
                    pending.push((file.child(info.name()), false));
                }
                continue;
            }
        }
        file.delete(Some(cancel)).map_err(io::Error::other)?;
    }
    Ok(())
}

fn rename_new(source: &Path, destination: &Path, publications: &AtomicU64) -> io::Result<()> {
    match rustix::fs::renameat_with(
        rustix::fs::CWD,
        source,
        rustix::fs::CWD,
        destination,
        rustix::fs::RenameFlags::NOREPLACE,
    ) {
        Ok(()) => {
            publications.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }
        Err(error) if matches!(error.raw_os_error(), libc::EINVAL | libc::EOPNOTSUPP) => {
            if fs::symlink_metadata(source)?.is_dir() {
                return Err(io::Error::from_raw_os_error(libc::EXDEV));
            }
            fs::hard_link(source, destination)?;
            publications.fetch_add(1, Ordering::Relaxed);
            fs::remove_file(source).map_err(|error| {
                io::Error::other(format!("{error}; both hard-linked copies were retained"))
            })
        }
        Err(error) => Err(error.into()),
    }
}

fn publish_new(
    source: &Path,
    destination: &Path,
    cancel: &gio::Cancellable,
    publications: &AtomicU64,
) -> io::Result<()> {
    match rename_new(source, destination, publications) {
        Ok(()) => return Ok(()),
        Err(error) if error.raw_os_error() == Some(libc::EXDEV) => {}
        Err(error) => return Err(error),
    }
    let metadata = fs::symlink_metadata(source)?;
    if !metadata.is_dir() {
        return Err(io::Error::from_raw_os_error(libc::EXDEV));
    }
    use std::os::unix::fs::DirBuilderExt;
    fs::DirBuilder::new().mode(0o700).create(destination)?;
    publications.fetch_add(1, Ordering::Relaxed);
    let result = (|| {
        for entry in fs::read_dir(source)? {
            if cancel.is_cancelled() {
                return Err(io::Error::new(io::ErrorKind::Interrupted, "Cancelled"));
            }
            let entry = entry?;
            publish_new(
                &entry.path(),
                &destination.join(entry.file_name()),
                cancel,
                publications,
            )?;
        }
        fs::set_permissions(destination, metadata.permissions())?;
        preserve_times(destination, &metadata.into())?;
        preserve_attributes(source, destination)?;
        fs::remove_dir(source)
    })();
    result.map_err(|error| {
        io::Error::new(
            error.kind(),
            format!(
                "{error}; partial destination retained at {}. The original source was preserved",
                destination.display()
            ),
        )
    })
}

fn same_version(before: &Metadata, after: &Metadata) -> bool {
    before.same_version(after)
}
