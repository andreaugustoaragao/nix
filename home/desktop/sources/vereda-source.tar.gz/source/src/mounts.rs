use crate::locations::Place;
use gio::{glib, prelude::*};
use rune::{TextEdit, Waker};
use std::{
    path::PathBuf,
    sync::mpsc::{self, Receiver, Sender},
    time::Duration,
};

pub enum Action {
    Connect(String),
    Mount(Place),
    Unmount(Place),
    Eject(Place),
}
pub struct Credentials {
    pub user: String,
    pub password: zeroize::Zeroizing<String>,
    pub domain: String,
    pub anonymous: bool,
}
pub struct Authentication {
    pub message: String,
    pub user: TextEdit,
    pub password: TextEdit,
    pub domain: TextEdit,
    pub flags: gio::AskPasswordFlags,
    pub reply: Sender<Option<Credentials>>,
}
pub struct Question {
    pub message: String,
    pub choices: Vec<String>,
    pub reply: Sender<Option<usize>>,
}
pub enum Event {
    Places(Vec<Place>, Option<u64>),
    Authentication(Box<Authentication>),
    Question(Question),
    Finished(Result<Option<PathBuf>, String>),
}

pub struct Mounts {
    context: glib::MainContext,
    main_loop: Option<glib::MainLoop>,
    worker: Option<std::thread::JoinHandle<()>>,
    events: Sender<Event>,
    output: Receiver<Event>,
    waker: Option<Waker>,
    cancel: Option<gio::Cancellable>,
    refresh_id: u64,
}
impl Default for Mounts {
    fn default() -> Self {
        let (events, output) = mpsc::channel();
        Self {
            context: glib::MainContext::new(),
            main_loop: None,
            worker: None,
            events,
            output,
            waker: None,
            cancel: None,
            refresh_id: 0,
        }
    }
}
impl Mounts {
    pub fn start(&mut self, waker: Waker) {
        self.waker = Some(waker.clone());
        let context = self.context.clone();
        let main_loop = glib::MainLoop::new(Some(&context), false);
        self.main_loop = Some(main_loop.clone());
        let output = self.events.clone();
        self.worker = Some(std::thread::spawn(move || {
            let _ = context.with_thread_default(|| {
                let monitor = gio::VolumeMonitor::get();
                let events = output.clone();
                let wake = waker.clone();
                monitor.connect_mount_added(move |_, _| emit_places(&events, &wake, None));
                let events = output.clone();
                let wake = waker.clone();
                monitor.connect_mount_removed(move |_, _| emit_places(&events, &wake, None));
                let events = output.clone();
                let wake = waker.clone();
                monitor.connect_mount_changed(move |_, _| emit_places(&events, &wake, None));
                let events = output.clone();
                let wake = waker.clone();
                monitor.connect_volume_added(move |_, _| emit_places(&events, &wake, None));
                let events = output.clone();
                let wake = waker.clone();
                monitor.connect_volume_removed(move |_, _| emit_places(&events, &wake, None));
                monitor.connect_volume_changed(move |_, _| emit_places(&output, &waker, None));
                main_loop.run();
                drop(monitor);
            });
        }));
    }
    pub fn push(&mut self, action: Action) -> Result<(), String> {
        if self.cancel.is_some() {
            return Err("A device operation is already running".into());
        }
        let waker = self.waker.clone().ok_or("Device worker is not running")?;
        let cancel = gio::Cancellable::new();
        self.cancel = Some(cancel.clone());
        let mut request = Some((action, cancel, self.events.clone(), waker));
        let source = glib::source::idle_source_new(None, glib::Priority::DEFAULT, move || {
            let (action, cancel, output, waker) = request.take().expect("one device request");
            glib::MainContext::ref_thread_default().spawn_local(async move {
                let result = run(action, cancel, output.clone(), waker.clone()).await;
                let _ = output.send(Event::Finished(result));
                (waker)();
            });
            glib::ControlFlow::Break
        });
        source.attach(Some(&self.context));
        Ok(())
    }
    pub fn refresh_places(&mut self) -> Option<u64> {
        let waker = self.waker.clone()?;
        self.refresh_id = self.refresh_id.wrapping_add(1);
        let id = self.refresh_id;
        let output = self.events.clone();
        glib::source::idle_source_new(None, glib::Priority::DEFAULT, move || {
            emit_places(&output, &waker, Some(id));
            glib::ControlFlow::Break
        })
        .attach(Some(&self.context));
        Some(id)
    }
    pub fn take(&mut self) -> Vec<Event> {
        let events: Vec<_> = self.output.try_iter().collect();
        if events.iter().any(|e| matches!(e, Event::Finished(_))) {
            self.cancel = None;
        }
        events
    }
    pub fn busy(&self) -> bool {
        self.cancel.is_some()
    }
    pub fn cancel(&mut self) {
        if let Some(cancel) = &self.cancel {
            cancel.cancel();
        }
    }
}
impl Drop for Mounts {
    fn drop(&mut self) {
        self.cancel();
        if let Some(main_loop) = &self.main_loop {
            main_loop.quit();
        }
        if let Some(worker) = self.worker.take() {
            let _ = worker.join();
        }
    }
}
fn emit_places(output: &Sender<Event>, waker: &Waker, refresh: Option<u64>) {
    let _ = output.send(Event::Places(crate::locations::places(), refresh));
    (waker)();
}

fn receive<T>(receiver: Receiver<Option<T>>, cancel: &gio::Cancellable) -> Option<T> {
    loop {
        if cancel.is_cancelled() {
            return None;
        }
        match receiver.recv_timeout(Duration::from_millis(60)) {
            Ok(reply) => return reply,
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(_) => return None,
        }
    }
}

fn operation(output: Sender<Event>, waker: Waker, cancel: gio::Cancellable) -> gio::MountOperation {
    let operation = gio::MountOperation::new();
    let events = output.clone();
    let wake = waker.clone();
    let cancellation = cancel.clone();
    operation.connect_ask_password(move |operation, message, user, domain, flags| {
        let (reply, receiver) = mpsc::channel();
        let mut password = TextEdit::new("");
        password.set_secure(true);
        let event = Authentication {
            message: message.into(),
            user: TextEdit::new(user),
            password,
            domain: TextEdit::new(domain),
            flags,
            reply,
        };
        if events.send(Event::Authentication(Box::new(event))).is_err() {
            operation.reply(gio::MountOperationResult::Aborted);
            return;
        }
        (wake)();
        if let Some(credentials) = receive(receiver, &cancellation) {
            operation.set_username(Some(&credentials.user));
            operation.set_domain(Some(&credentials.domain));
            operation.set_password(Some(&credentials.password));
            operation.set_anonymous(credentials.anonymous);
            operation.set_password_save(gio::PasswordSave::Never);
            operation.reply(gio::MountOperationResult::Handled);
        } else {
            operation.reply(gio::MountOperationResult::Aborted);
        }
    });
    let question_operation = operation.downgrade();
    operation.connect_local("ask-question", false, move |values| {
        let question_operation = question_operation.upgrade()?;
        let message = values[1].get::<String>().unwrap_or_default();
        let choices = values[2]
            .get::<glib::StrV>()
            .map(|v| v.iter().map(|s| s.to_string()).collect())
            .unwrap_or_default();
        let (reply, receiver) = mpsc::channel();
        let _ = output.send(Event::Question(Question {
            message,
            choices,
            reply,
        }));
        (waker)();
        if let Some(choice) = receive(receiver, &cancel) {
            question_operation.set_choice(choice as i32);
            question_operation.reply(gio::MountOperationResult::Handled);
        } else {
            question_operation.reply(gio::MountOperationResult::Aborted);
        }
        None
    });
    operation
}

async fn run(
    action: Action,
    cancel: gio::Cancellable,
    output: Sender<Event>,
    waker: Waker,
) -> Result<Option<PathBuf>, String> {
    let operation = operation(output, waker, cancel.clone());
    let monitor = gio::VolumeMonitor::get();
    let (reply, done) = tokio::sync::oneshot::channel();
    let eject = matches!(action, Action::Eject(_));
    match action {
        Action::Connect(uri) => {
            let file = gio::File::for_uri(&uri);
            if let Some(path) = file.path()
                && path.exists()
            {
                return Ok(Some(path));
            }
            file.mount_enclosing_volume(
                gio::MountMountFlags::NONE,
                Some(&operation),
                Some(&cancel),
                move |result| {
                    let _ = reply.send(result);
                },
            );
            match done.await.map_err(|e| e.to_string())? {
                Ok(()) => {}
                Err(error) if error.matches(gio::IOErrorEnum::AlreadyMounted) => {}
                Err(error) => return Err(error.to_string()),
            }
            Ok(Some(crate::locations::local_uri(&uri)?))
        }
        Action::Mount(place) => {
            let volume = monitor
                .volumes()
                .into_iter()
                .find(|v| {
                    Some(
                        v.uuid()
                            .map(|s| s.to_string())
                            .unwrap_or_else(|| v.name().to_string()),
                    ) == place.volume
                })
                .ok_or("Device is no longer connected")?;
            volume.mount(
                gio::MountMountFlags::NONE,
                Some(&operation),
                Some(&cancel),
                move |result| {
                    let _ = reply.send(result);
                },
            );
            done.await
                .map_err(|e| e.to_string())?
                .map_err(|e| e.to_string())?;
            let root = volume
                .get_mount()
                .ok_or("Device did not provide a mounted location")?
                .root();
            Ok(Some(
                root.path().ok_or("GVFS/FUSE is required for this device")?,
            ))
        }
        Action::Unmount(place) | Action::Eject(place) => {
            if eject && !place.mounted {
                let volume = monitor
                    .volumes()
                    .into_iter()
                    .find(|v| {
                        Some(
                            v.uuid()
                                .map(|s| s.to_string())
                                .unwrap_or_else(|| v.name().to_string()),
                        ) == place.volume
                    })
                    .ok_or("Device is no longer connected")?;
                volume.eject_with_operation(
                    gio::MountUnmountFlags::NONE,
                    Some(&operation),
                    Some(&cancel),
                    move |result| {
                        let _ = reply.send(result);
                    },
                );
                done.await
                    .map_err(|e| e.to_string())?
                    .map_err(|e| e.to_string())?;
                return Ok(None);
            }
            let mount = monitor
                .mounts()
                .into_iter()
                .find(|m| m.root().uri().as_str() == place.uri)
                .ok_or("Location is no longer mounted")?;
            if eject {
                mount.eject_with_operation(
                    gio::MountUnmountFlags::NONE,
                    Some(&operation),
                    Some(&cancel),
                    move |result| {
                        let _ = reply.send(result);
                    },
                );
            } else {
                mount.unmount_with_operation(
                    gio::MountUnmountFlags::NONE,
                    Some(&operation),
                    Some(&cancel),
                    move |result| {
                        let _ = reply.send(result);
                    },
                );
            }
            done.await
                .map_err(|e| e.to_string())?
                .map_err(|e| e.to_string())?;
            Ok(None)
        }
    }
}
