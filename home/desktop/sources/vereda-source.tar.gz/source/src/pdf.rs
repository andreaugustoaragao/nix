use std::{
    fs,
    io::{Read, Seek},
    path::PathBuf,
    process::{Command, Stdio},
    sync::Arc,
    time::{Duration, Instant},
};

use gio::prelude::CancellableExt;

#[derive(Clone)]
pub struct Pdf {
    document: Arc<Document>,
    pub page: u32,
    pub content: Page,
}

struct Document {
    path: PathBuf,
    pages: u32,
    _download: Option<tempfile::TempDir>,
}

#[derive(Clone)]
pub enum Page {
    Loading,
    Ready(rune::Image),
    Error(String),
}

impl Pdf {
    pub fn open(
        mut path: PathBuf,
        bytes: Option<Vec<u8>>,
        cancel: &gio::Cancellable,
        cache: &rune::ImageCache,
    ) -> Result<Self, String> {
        let download = if let Some(bytes) = bytes {
            let directory = tempfile::Builder::new()
                .prefix(".vereda-pdf-")
                .tempdir()
                .map_err(|error| error.to_string())?;
            path = directory.path().join("document.pdf");
            fs::write(&path, bytes).map_err(|error| error.to_string())?;
            Some(directory)
        } else {
            if !fs::metadata(&path)
                .map_err(|error| error.to_string())?
                .is_file()
            {
                return Err("No preview for this file type".into());
            }
            None
        };
        let info = run(
            Command::new("pdfinfo")
                .args(["-f", "1", "-l", "1"])
                .arg(&path),
            cancel,
        )?;
        let pages = String::from_utf8_lossy(&info)
            .lines()
            .find_map(|line| {
                line.strip_prefix("Pages:")
                    .and_then(|n| n.trim().parse::<u32>().ok())
            })
            .filter(|&n| n > 0)
            .ok_or("Could not read the PDF page count")?;
        Ok(Self {
            document: Arc::new(Document {
                path,
                pages,
                _download: download,
            }),
            page: 1,
            content: Page::Loading,
        }
        .render(cancel, cache))
    }

    pub fn pages(&self) -> u32 {
        self.document.pages
    }

    pub fn turn(&self, direction: i32) -> Option<Self> {
        let page = self
            .page
            .saturating_add_signed(direction)
            .clamp(1, self.pages());
        (page != self.page).then(|| Self {
            document: self.document.clone(),
            page,
            content: Page::Loading,
        })
    }

    pub fn status(&self) -> &'static str {
        match self.content {
            Page::Loading => "loading",
            Page::Ready(_) => "ready",
            Page::Error(_) => "error",
        }
    }

    pub fn render(mut self, cancel: &gio::Cancellable, cache: &rune::ImageCache) -> Self {
        let page = self.page.to_string();
        let result = run(
            Command::new("pdftoppm")
                .args([
                    "-f",
                    &page,
                    "-l",
                    &page,
                    "-singlefile",
                    "-scale-to",
                    "1600",
                    "-png",
                ])
                .arg(&self.document.path),
            cancel,
        )
        .and_then(|bytes| {
            let image = cache.load(bytes);
            image.wait().map_err(|error| error.to_string())?;
            Ok(image)
        });
        self.content = match result {
            Ok(image) => Page::Ready(image),
            Err(error) => Page::Error(error),
        };
        self
    }
}

fn run(command: &mut Command, cancel: &gio::Cancellable) -> Result<Vec<u8>, String> {
    if cancel.is_cancelled() {
        return Err("PDF preview cancelled".into());
    }
    let mut output = tempfile::tempfile().map_err(|error| error.to_string())?;
    let mut errors = tempfile::tempfile().map_err(|error| error.to_string())?;
    let mut child = command
        .env("LC_ALL", "C")
        .stdin(Stdio::null())
        .stdout(output.try_clone().map_err(|error| error.to_string())?)
        .stderr(errors.try_clone().map_err(|error| error.to_string())?)
        .spawn()
        .map_err(|error| {
            if error.kind() == std::io::ErrorKind::NotFound {
                "PDF preview requires Poppler (pdfinfo and pdftoppm)".into()
            } else {
                format!("Could not start PDF preview: {error}")
            }
        })?;
    let start = Instant::now();
    let result = loop {
        if cancel.is_cancelled() {
            break Err("PDF preview cancelled".into());
        }
        if start.elapsed() > Duration::from_secs(15) {
            break Err("PDF preview timed out · open with o".into());
        }
        match child.try_wait() {
            Ok(Some(status)) => break Ok(status),
            Ok(None) => std::thread::sleep(Duration::from_millis(20)),
            Err(error) => break Err(error.to_string()),
        }
    };
    if result.is_err() {
        let _ = child.kill();
        let _ = child.wait();
    }
    let status = result?;
    if !status.success() {
        errors.rewind().map_err(|error| error.to_string())?;
        let mut detail = String::new();
        errors
            .take(4096)
            .read_to_string(&mut detail)
            .map_err(|error| error.to_string())?;
        if detail.to_ascii_lowercase().contains("password") {
            return Err("Password-protected PDF · open with o".into());
        }
        return Err(format!("Could not preview PDF: {}", detail.trim()));
    }
    output.rewind().map_err(|error| error.to_string())?;
    let mut bytes = Vec::new();
    output
        .take(16 * 1024 * 1024 + 1)
        .read_to_end(&mut bytes)
        .map_err(|error| error.to_string())?;
    if bytes.len() > 16 * 1024 * 1024 {
        return Err("Rendered PDF page exceeds the preview limit".into());
    }
    Ok(bytes)
}
