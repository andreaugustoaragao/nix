use rune::{
    Color, Cx, El, GrowthSpec, ScrollSpec, SurfaceFit, TextStyle, col, el, row, text, text_input,
};

use crate::{
    details,
    file::{self, File, Preview, SortBy},
    finder::{FilterKind, SearchFilters},
    icon,
    operations::{Choice, Status},
    pane::Pane,
    preference::{DetailColumn, ViewMode},
    state::{FolderMenu, State},
};

use crate::theme::Theme;

pub fn input(edit: &rune::TextEdit, style: TextStyle, height: f32, p: Theme) -> El {
    let padding = ((height - style.line_px()) / 2.0).max(0.0);

    text_input(edit, style)
        .single_line()
        .h(height)
        .py(padding)
        .focus_ring(2.0, 0.0, p.accent)
}

fn rule(p: Theme) -> El {
    el().w(1.0).h_full().fill(p.line)
}

fn label(value: impl Into<String>, p: Theme) -> El {
    text(value)
        .font(p.font(13.0, 400.0))
        .color(p.muted)
        .truncate()
        .shrink()
}

pub fn view(s: &State, cx: &mut Cx<State>) -> El {
    let zoom = s.zoom_factor();
    let [width, height] = cx.layout_size("zoom-viewport").unwrap_or([1160.0, 740.0]);
    let content = content(s, cx)
        .absolute(0.0, 0.0)
        .size(width / zoom, height / zoom)
        .origin(0.0, 0.0)
        .scale(zoom);
    el().key("zoom-viewport")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .w_full()
        .h_full()
        .clip_rounded(0.0)
        .motion(rune::Spring::NONE)
        .child(content)
}

fn content(s: &State, cx: &mut Cx<State>) -> El {
    let p = Theme {
        colors: s.appearance.palette(cx.system_dark(), s.dark),
        metrics: s.appearance.metrics(),
    };
    cx.reduced_motion(cx.system_reduced_motion());
    if s.selector.is_some() {
        return selector_view(s, p, cx);
    }
    let tab = s.tab();
    let side = s.active_pane;
    let width = cx.layout_size("app").map_or(1160.0, |size| size[0]);
    let mut path = row()
        .key("toolbar")
        .role("toolbar")
        .label("Folder navigation")
        .h(p.height(48.0))
        .w_full()
        .px(p.space(3))
        .center_y()
        .gap(p.space(1))
        .fill(p.panel)
        .child(
            icon_button(&icon::SIDEBAR, "Show or hide sidebar · F9", p, |s, tx| {
                s.command("sidebar_toggle", tx)
            })
            .key("sidebar-toggle")
            .checked(!s.sidebar_hidden),
        )
        .child(if s.split {
            label("Folders", p).grow(1.0)
        } else {
            let tab_width = cx.layout_size(&format!("tabs-{side}")).map_or(
                width - p.height(32.0) * 7.0 - p.space(3) * 2.0 - p.space(1) * 7.0,
                |v| v[0],
            );
            row()
                .grow(1.0)
                .min_w(0.0)
                .center_y()
                .gap(p.space(1))
                .child(navigation_controls(s, side, p))
                .child(tabs(s, side, p, tab_width))
        })
        .child(
            icon_button(&icon::SEARCH, "Find files · / or Ctrl+F", p, |s, tx| {
                s.show_picker(tx)
            })
            .key("find-files"),
        )
        .child(
            icon_button(&icon::SPLIT, "Toggle split view · F3", p, |s, tx| {
                s.toggle_split(tx)
            })
            .key("split-toggle")
            .checked(s.split)
            .color(if s.split { p.accent } else { p.text }),
        )
        .child(
            icon_button(&icon::SETTINGS, "Appearance · Ctrl+,", p, move |s, tx| {
                s.command(
                    if p.dark {
                        "settings dark"
                    } else {
                        "settings light"
                    },
                    tx,
                )
            })
            .key("settings-open"),
        );
    if s.pane().picker.is_none() && tab.saved_picker.is_some() {
        path = path.child(
            action_button("Back to results", p, |s, tx| s.show_picker(tx)).key("return-results"),
        );
    }
    let sidebar_width = if width < 900.0 { 200.0 } else { 232.0 };
    let divider = p.space(2);
    let available = width
        - if s.sidebar_hidden {
            0.0
        } else {
            sidebar_width + 1.0
        }
        - divider;
    let panes = if s.split && !s.preview_expanded {
        let mut workspace = row().key("split-workspace").grow(1.0).w_full().min_h(0.0);
        if !s.sidebar_hidden {
            workspace = workspace
                .child(sidebar(s, p).w(sidebar_width))
                .child(rule(p));
        }
        workspace
            .child(folder_pane(s, 0, p, cx, available * s.split_width))
            .child(
                el().key("split-divider")
                    .role("separator")
                    .label("Resize folder panes")
                    .w(divider)
                    .h_full()
                    .fill(p.panel)
                    .hover(p.selected)
                    .cursor(rune::Cursor::ResizeColumn)
                    .range_value(s.split_width as f64, 0.25, 0.75)
                    .range_step(0.05)
                    .on_step(|s: &mut State, step, _| {
                        s.split_width = (s.split_width + step as f32 * 0.05).clamp(0.25, 0.75)
                    })
                    .on_drag(move |s: &mut State, drag, tx| {
                        if drag.phase == rune::Phase::Down {
                            drag.data = s.split_width;
                        } else if drag.phase == rune::Phase::Move {
                            s.split_width = (drag.data + drag.dx / (available * s.zoom_factor()))
                                .clamp(0.25, 0.75);
                        }
                        tx.instant();
                    })
                    .on_double_press(|s: &mut State| s.split_width = 0.5),
            )
            .child(folder_pane(s, 1, p, cx, available * (1.0 - s.split_width)))
    } else {
        let preview = col()
            .key("preview-panel")
            .motion(rune::Spring::new(0.22, 0.0))
            .grow(if s.preview_expanded {
                1.0
            } else {
                s.preview_width
            })
            .min_w(0.0)
            .min_h(0.0)
            .child(preview_header(s, p))
            .child(preview(s, p));
        let mut panes = row().key("panes").grow(1.0).min_h(0.0).w_full();
        if !s.preview_expanded {
            if !s.sidebar_hidden {
                panes = panes.child(sidebar(s, p).w(sidebar_width)).child(rule(p));
            }
            let current = if s.pane().picker.is_some() {
                finder_results(s, side, p)
            } else {
                files(s, side, p)
            }
            .grow(1.0 - s.preview_width);
            panes = panes.child(current).child(
                el().key("preview-divider")
                    .role("separator")
                    .label("Resize preview")
                    .w(divider)
                    .h_full()
                    .fill(p.panel)
                    .hover(p.selected)
                    .cursor(rune::Cursor::ResizeColumn)
                    .help("Drag to resize preview; double-click to reset")
                    .range_value(s.preview_width as f64, 0.25, 0.75)
                    .range_step(0.05)
                    .focus_ring(2.0, 0.0, p.accent)
                    .on_step(|s: &mut State, step, _| {
                        s.preview_width = (s.preview_width + step as f32 * 0.05).clamp(0.25, 0.75);
                    })
                    .on_drag(move |s: &mut State, drag, tx| {
                        if drag.phase == rune::Phase::Down {
                            drag.data = s.preview_width;
                        } else if drag.phase == rune::Phase::Move {
                            s.preview_width = (drag.data - drag.dx / (available * s.zoom_factor()))
                                .clamp(0.25, 0.75);
                        }
                        tx.instant();
                    })
                    .on_double_press(|s: &mut State| s.preview_width = 0.5),
            );
        }
        panes.child(preview)
    };
    let info = s
        .pane()
        .file()
        .filter(|f| !f.directory)
        .map(|f| {
            format!(
                "{}{}",
                file::human_size(f.size),
                if f.symlink { "  symlink" } else { "" }
            )
        })
        .unwrap_or_default();
    let (_, count, selected) = s.pane().picker.as_ref().map_or(
        (tab.cursor, tab.visible.len(), tab.selected.len()),
        |picker| (picker.cursor, picker.files.len(), picker.selected.len()),
    );
    let mut details = vec![format!("{count} items")];
    if !info.is_empty() {
        details.push(info);
    }
    if selected > 0 {
        details.push(format!("{selected} selected"));
    }
    if s.tab().preference.show_hidden {
        details.push("Hidden files".into());
    }
    let details = details.join(" · ");
    let message = s.message.as_deref().unwrap_or_default();
    let details = label(&details, p)
        .key("file-details")
        .align(rune::Align::End)
        .min_w(0.0)
        .truncate()
        .help(&details);
    let details = if message.is_empty() {
        details
    } else {
        details.grow(1.0)
    };
    let status = row()
        .key("status")
        .h(p.height(32.0))
        .w_full()
        .px(p.space(3))
        .gap(p.space(3))
        .center_y()
        .fill(p.panel)
        .child(
            text(message)
                .key("message")
                .font(p.font(13.0, 400.0))
                .color(p.folder)
                .grow(1.0)
                .min_w(0.0)
                .truncate()
                .help(message),
        )
        .child(details)
        .child(if let Some(task) = s.queue.active() {
            action_button(
                format!("{} · {}", task.title, file::human_size(task.bytes)),
                p,
                |s, _| s.tasks_open = !s.tasks_open,
            )
            .key("tasks-open")
            .help("Transfer center · W")
            .border(0.0, Color::TRANSPARENT)
            .fill(Color::TRANSPARENT)
        } else {
            el()
        })
        .child(
            icon_button(&icon::HELP, "Keyboard shortcuts · F1", p, |s, tx| {
                s.command("help", tx)
            })
            .key("help-open"),
        );
    let mut root = col()
        .key("app")
        .role("application")
        .label("File manager")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .w_full()
        .h_full()
        .fill(p.background)
        .child(path)
        .child(if s.split && !s.preview_expanded {
            transfers(s, p)
        } else {
            el()
        })
        .child(el().h(1.0).w_full().fill(p.line))
        .child(if s.pane().picker.is_some() {
            finder_controls(s, p)
        } else {
            el()
        })
        .child(panes)
        .child(status);
    if s.tab_menu.is_some() {
        root = root.child(tab_menu(s, p, cx));
    }
    if let Some(prompt) = s.prompt.filter(|prompt| {
        !matches!(
            prompt,
            crate::state::Prompt::Create
                | crate::state::Prompt::CreateFolder
                | crate::state::Prompt::Rename
                | crate::state::Prompt::Archive
        )
    }) {
        root = root.child(
            row()
                .key("prompt-bar")
                .h(p.height(44.0))
                .w_full()
                .px(p.space(4))
                .gap(p.space(3))
                .center_y()
                .fill(p.panel)
                .child(
                    text(prompt.title())
                        .font(p.font(13.0, 400.0))
                        .color(p.accent)
                        .max_w(width * 0.25)
                        .min_w(0.0)
                        .truncate()
                        .help(prompt.title()),
                )
                .child(
                    input(&s.pane().input, p.font(13.0, 400.0), p.height(32.0), p)
                        .key("prompt")
                        .label(prompt.title())
                        .grow(1.0)
                        .min_w(0.0)
                        .color(p.text)
                        .on_edit(|s: &mut State| &mut s.pane_mut().input)
                        .on_submit(|s: &mut State, tx| s.submit_prompt(tx)),
                )
                .child(
                    label("Enter to accept · Esc to close", p)
                        .max_w(width * 0.25)
                        .min_w(0.0)
                        .truncate()
                        .help("Enter to accept · Esc to close"),
                ),
        );
    } else if !s.pending.is_empty() {
        let items: Vec<_> = s
            .bindings
            .iter()
            .filter(|b| b.on.list().starts_with(&s.pending))
            .collect();
        let mut which = col()
            .key("which")
            .w_full()
            .px(p.space(4))
            .py(p.space(2))
            .gap(p.space(1))
            .fill(p.panel);
        for b in items.iter().take(9) {
            which = which.child(
                row()
                    .gap(p.space(3))
                    .child(
                        text(b.on.list().join(" "))
                            .font(p.font(13.0, 400.0))
                            .color(p.accent)
                            .w(88.0),
                    )
                    .child(label(b.desc.clone(), p)),
            );
        }
        root = root.child(which);
    }
    if s.peek.target.is_some() && s.peek_allowed() {
        root = root.child(crate::peek::view(s, p));
    }
    if s.pane().address.editing {
        root = root.child(address_choices(s, s.active_pane, p, cx));
    }
    if s.place_menu.is_some() {
        root = root.child(place_overlay(s, p, width));
    }
    if s.view_options.is_some() {
        root = root.child(folder_view_overlay(
            s,
            p,
            width,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    }
    if let Some(error) = &s.session_error {
        root = root.child(session_error_overlay(error, p, width));
    }
    if s.drop_decision.is_some() {
        root = root.child(drop_overlay(s, p));
    }
    if s.panel == Some(crate::state::Panel::Applications) {
        root = root.child(application_dialog(
            s,
            p,
            width,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    } else if s.panel.is_some() {
        root = root.child(desktop_overlay(
            s,
            p,
            cx.layout_size("app").map_or(360.0, |size| size[1]),
        ));
    }
    if s.authentication.is_some() || s.question.is_some() {
        root = root.child(authentication_overlay(
            s,
            p,
            cx.layout_size("app").map_or(360.0, |size| size[1]),
        ));
    }
    if s.help || s.spot {
        root = root.child(overlay(
            s,
            p,
            width,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    }
    if s.queue.conflict.is_some() || s.confirmation.is_some() || s.tasks_open {
        root = root.child(operation_overlay(
            s,
            p,
            width,
            cx.layout_size("app").map_or(360.0, |size| size[1]),
        ));
    }
    if s.context.is_some() {
        root = root.child(context_menu(s, p, cx));
    }
    if let Some(kind) = s.pane().picker.as_ref().and_then(|picker| picker.menu) {
        root = root.child(finder_menu(
            s,
            p,
            kind,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    }
    if s.prompt.is_some_and(|prompt| {
        matches!(
            prompt,
            crate::state::Prompt::Create
                | crate::state::Prompt::CreateFolder
                | crate::state::Prompt::Rename
                | crate::state::Prompt::Archive
        )
    }) {
        root = root.child(name_dialog(
            s,
            p,
            width,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    }
    if s.appearance.open {
        root = root.child(crate::appearance_view::view(
            s,
            p,
            width,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    }
    root.motion(rune::Spring::NONE)
}

fn tabs(s: &State, side: usize, p: Theme, width: f32) -> El {
    let pane = &s.panes[side];
    let gap = p.space(1);
    let inactive_width = p.height(116.0);
    let active_width = p.height(200.0);
    let add_width = p.height(32.0);
    let count = pane.tabs.len();
    let full = active_width + add_width + (count - 1) as f32 * inactive_width + count as f32 * gap;
    let visible = if full <= width {
        count - 1
    } else {
        ((width - active_width - add_width * 2.0 - gap * 3.0) / (inactive_width + gap))
            .floor()
            .max(0.0) as usize
    };
    let mut shown = 0;
    let mut strip = row()
        .key(format!("tabs-{side}"))
        .role("tablist")
        .label("Folder tabs")
        .grow(1.0)
        .min_w(0.0)
        .center_y()
        .gap(gap);
    for (index, tab) in pane.tabs.iter().enumerate() {
        let active = index == pane.active;
        if !active {
            if shown >= visible {
                continue;
            }
            shown += 1;
        }
        let title = tab.name.clone().unwrap_or_else(|| s.folder_name(&tab.cwd));
        let mut item = button(p, move |s, tx| {
            s.activate_pane(side, tx);
            if s.panes[side].active != index {
                s.command(&format!("tab_switch {index}"), tx);
                tx.blur();
            } else if !s.panes[side].address.editing {
                s.edit_location(side, tx);
            }
        })
        .key(format!("tab-{side}-{index}"))
        .cursor(if active {
            rune::Cursor::Text
        } else {
            rune::Cursor::Pointer
        })
        .role("tab")
        .label(format!("Tab {}: {title}", index + 1))
        .checked(active)
        .h(p.height(36.0))
        .px(p.space(2))
        .gap(gap)
        .min_w(0.0)
        .border(
            if active { 1.0 } else { 0.0 },
            if active {
                p.line.alpha(0.6)
            } else {
                Color::TRANSPARENT
            },
        )
        .hover_group()
        .fill(if active {
            p.background
        } else {
            Color::TRANSPARENT
        });
        if active {
            item = item
                .hover(p.background)
                .grow(1.0)
                .child(location(s, side, p));
        } else {
            item = item.w(inactive_width).child(
                text(&title)
                    .font(p.font(12.0, 500.0))
                    .color(p.text)
                    .grow(1.0)
                    .min_w(0.0)
                    .truncate()
                    .help(s.display_location(&tab.cwd)),
            );
        }
        if !active || !pane.address.editing {
            item = item.child(
                icon_button(&icon::CLOSE, "Close tab", p, move |s, tx| {
                    s.activate_pane(side, tx);
                    s.command(&format!("tab_switch {index}"), tx);
                    s.command("tab_close", tx);
                })
                .key(format!("close-tab-{side}-{index}"))
                .w(p.height(24.0))
                .h(p.height(24.0))
                .label(format!("Close tab {}", index + 1))
                .group_opacity(if active { 1.0 } else { 0.0 }, 1.0),
            );
        }
        strip = strip.child(item);
    }
    if shown + 1 < count {
        strip = strip.child(
            icon_button(&icon::MORE, "More tabs", p, move |s, tx| {
                s.activate_pane(side, tx);
                let open = s.tab_menu == Some(side);
                s.panes[side].address.close();
                s.context = None;
                s.peek.close();
                s.tab_menu = if open { None } else { Some(side) };
                tx.blur();
            })
            .key(format!("tab-overflow-{side}"))
            .checked(s.tab_menu == Some(side)),
        );
    }
    strip.child(
        icon_button(&icon::PLUS, "New tab", p, move |s, tx| {
            s.activate_pane(side, tx);
            s.command("tab_create", tx);
        })
        .key(format!("new-tab-{side}")),
    )
}

fn tab_menu(s: &State, p: Theme, cx: &Cx<State>) -> El {
    let side = s.tab_menu.expect("visible tab menu");
    let anchor = format!("tab-overflow-{side}");
    let size = cx.layout_size("app").unwrap_or([1160.0, 740.0]);
    let margin = 8.0 / s.zoom_factor();
    let gap = p.space(1);
    let room = cx
        .window_layout(&anchor)
        .map_or(size[1] - p.height(48.0) - margin, |rect| {
            (rect[1] - gap - margin).max(size[1] - margin - rect[1] - rect[3] - gap)
        });
    let row_height = p.height(32.0);
    let rows = ((room - p.space(4)) / row_height).floor().max(1.0);
    let mut listing = col()
        .key("tab-menu-list")
        .w_full()
        .min_h(0.0)
        .max_h(rows * row_height)
        .scroll(ScrollSpec {
            stick_bottom: false,
        });
    for (index, tab) in s.panes[side].tabs.iter().enumerate() {
        let title = tab.name.clone().unwrap_or_else(|| s.folder_name(&tab.cwd));
        listing = listing.child(
            action_button(format!("{}  {title}", index + 1), p, move |s, tx| {
                s.activate_pane(side, tx);
                s.command(&format!("tab_switch {index}"), tx);
                tx.blur();
            })
            .key(format!("tab-option-{side}-{index}"))
            .role("menuitem")
            .checked(index == s.panes[side].active)
            .focus_selected(index == s.panes[side].active)
            .focus_highlight(p.selected)
            .help(s.display_location(&tab.cwd))
            .w_full()
            .min_w(0.0)
            .h(row_height)
            .border(0.0, Color::TRANSPARENT)
            .fill(Color::TRANSPARENT),
        );
    }
    col()
        .key("tab-menu")
        .role("menu")
        .label("All folder tabs")
        .w(p.height(300.0).min((size[0] - margin * 2.0).max(100.0)))
        .padding(p.space(2))
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(1))
        .anchored_fit(anchor.clone(), rune::Side::Bottom, rune::Align::End, gap)
        .focus_return(anchor)
        .focus_group()
        .modal(true, |s: &mut State| s.tab_menu = None)
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .child(listing)
}

fn navigation(s: &State, side: usize, p: Theme) -> El {
    row()
        .key(format!("navigation-{side}"))
        .grow(1.0)
        .min_w(0.0)
        .center_y()
        .gap(p.space(1))
        .child(navigation_controls(s, side, p))
        .child(location(s, side, p))
}

fn navigation_controls(s: &State, side: usize, p: Theme) -> El {
    let tab = s.panes[side].tab();
    let mut bar = row().center_y().gap(p.space(1));
    for (glyph, action, help, disabled) in [
        (
            &icon::BACK,
            "back",
            "Back · Alt+Left",
            tab.history_cursor == 0,
        ),
        (
            &icon::FORWARD,
            "forward",
            "Forward · Alt+Right",
            tab.history_cursor + 1 == tab.history.len(),
        ),
        (
            &icon::UP,
            "leave",
            "Up · Alt+Up",
            tab.cwd.parent().is_none(),
        ),
    ] {
        bar = bar.child(
            icon_button(glyph, help, p, move |s, tx| {
                s.activate_pane(side, tx);
                s.command(action, tx);
                tx.blur();
            })
            .key(format!("{action}-{side}"))
            .label(help)
            .help(help)
            .disabled(disabled),
        );
    }
    bar
}

fn location(s: &State, side: usize, p: Theme) -> El {
    let pane = &s.panes[side];
    let tab = pane.tab();
    let bar = row()
        .key(format!("location-{side}"))
        .grow(1.0)
        .min_w(0.0)
        .center_y()
        .gap(p.space(1));
    if pane.address.editing {
        let editor = &pane.address.input;
        return bar
            .child(
                input(editor, p.font(13.0, 400.0), p.height(32.0), p)
                    .key(format!("address-{side}"))
                    .label("Folder path or fuzzy folder query")
                    .grow(1.0)
                    .min_w(0.0)
                    .color(p.text)
                    .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
                    .on_edit(move |s: &mut State| &mut s.panes[side].address.input)
                    .on_submit(move |s: &mut State, _| s.submit_location(side)),
            )
            .child(
                action_button("×", p, move |s, tx| {
                    s.panes[side].address.close();
                    tx.blur();
                })
                .key(format!("close-address-{side}"))
                .label("Cancel path entry")
                .px(p.space(2)),
            );
    }
    let mut crumbs = row()
        .key(format!("breadcrumbs-{side}"))
        .grow(1.0)
        .min_w(0.0)
        .h(p.height(32.0))
        .center_y()
        .gap(p.space(1))
        .scroll_x();
    for (index, (name, path)) in s.breadcrumbs(side).into_iter().enumerate() {
        if index > 0 {
            crumbs = crumbs.child(text("›").color(p.muted).px(p.space(1)));
        }
        let current = path == tab.cwd;
        let home = path == crate::state::home();
        let open = path.clone();
        let drag = path.clone();
        let mut crumb = button(p, move |s, tx| {
            s.activate_pane(side, tx);
            if current {
                s.edit_location(side, tx);
            } else {
                s.cd(side, open.clone(), tx, true);
                tx.blur();
            }
        })
        .key(format!("breadcrumb-{side}-{index}"))
        .cursor(if current {
            rune::Cursor::Text
        } else {
            rune::Cursor::Pointer
        })
        .hover(p.line.alpha(0.16))
        .label(s.display_location(&path))
        .help(s.display_location(&path))
        .px(p.space(1))
        .border(0.0, Color::TRANSPARENT)
        .fill(if s.drop_hover.as_ref() == Some(&path) {
            p.selected
        } else {
            Color::TRANSPARENT
        })
        .on_drag(move |s: &mut State, event, tx| {
            if event.phase == rune::Phase::Down {
                s.activate_pane(side, tx);
            }
            s.drag_file(&drag, true, event);
        })
        .opacity(if current { 1.0 } else { 0.8 });
        crumb = if home {
            crumb.child(rune::icon(&icon::HOME, 18.0).color(p.text))
        } else {
            crumb.child(
                text(name)
                    .font(p.font(12.0, 500.0))
                    .color(p.text)
                    .truncate()
                    .shrink()
                    .min_w(0.0),
            )
        };
        crumbs = crumbs.child(crumb);
    }
    bar.cursor(rune::Cursor::Text)
        .on_press_tx(move |s: &mut State, tx| s.edit_location(side, tx))
        .child(crumbs)
}

fn address_choices(s: &State, side: usize, p: Theme, cx: &Cx<State>) -> El {
    let address = &s.panes[side].address;
    let key = format!("address-{side}");
    let width = cx
        .layout_size(&key)
        .map_or(300.0, |size| size[0])
        .max(220.0);
    let mut menu = col()
        .key("address-choices")
        .role("listbox")
        .label("Folder completions")
        .anchored_fit(key, rune::Side::Bottom, rune::Align::Start, p.space(1))
        .w(width)
        .max_h(328.0)
        .min_h(0.0)
        .padding(p.space(1))
        .gap(0.0)
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(1));
    for (index, choice) in address.choices.iter().enumerate() {
        menu = menu.child(
            button(p, move |s, tx| {
                s.panes[side].address.choose(index);
                tx.instant();
            })
            .key(format!("completion-{index}"))
            .role("option")
            .checked(address.selected == Some(index))
            .w_full()
            .h(p.height(24.0))
            .border(0.0, Color::TRANSPARENT)
            .radius(0.0)
            .fill(if address.selected == Some(index) {
                p.selected
            } else {
                Color::TRANSPARENT
            })
            .label(&choice.name)
            .help(&choice.value)
            .child(
                text(&choice.name)
                    .font(p.font(12.0, 500.0))
                    .color(p.text)
                    .truncate()
                    .min_w(0.0)
                    .grow(1.0),
            ),
        );
    }
    if let Some(error) = &address.error {
        return menu.child(
            text(error)
                .font(p.font(12.0, 400.0))
                .color(p.folder)
                .wrap_anywhere()
                .w_full()
                .px(p.space(1))
                .py(p.space(1)),
        );
    }
    if address.fuzzy {
        menu = menu.child(
            label(
                if address.scanning {
                    "Finding folder paths…"
                } else {
                    "Fuzzy folder paths"
                },
                p,
            )
            .w_full()
            .px(p.space(1))
            .py(p.space(1)),
        );
    }
    menu.child(
        label(
            if address.opening {
                "Opening folder…"
            } else if !address.choices.is_empty() {
                "↑↓ choose · Tab fills · Enter opens · Esc cancels"
            } else {
                "Enter opens · Esc cancels"
            },
            p,
        )
        .w_full()
        .px(p.space(1))
        .py(p.space(1)),
    )
}

fn folder_pane(s: &State, side: usize, p: Theme, cx: &Cx<State>, width: f32) -> El {
    let pane = &s.panes[side];
    let active = side == s.active_pane;
    let content = if pane.picker.is_some() {
        finder_results(s, side, p)
    } else {
        files(s, side, p)
    };
    let name = if side == 0 { "Left" } else { "Right" };
    col()
        .key(format!("pane-{side}"))
        .role("group")
        .label(format!("{name} folder pane"))
        .grow(if side == 0 {
            s.split_width
        } else {
            1.0 - s.split_width
        })
        .min_w(0.0)
        .min_h(0.0)
        .border(
            1.0,
            if active {
                p.accent.alpha(0.45)
            } else {
                p.line.alpha(0.3)
            },
        )
        .on_press_tx(move |s: &mut State, tx| s.activate_pane(side, tx))
        .child(
            row()
                .key(format!("pane-navigation-{side}"))
                .w_full()
                .h(p.height(48.0))
                .px(p.space(2))
                .gap(p.space(1))
                .center_y()
                .fill(p.panel)
                .child(navigation_controls(s, side, p))
                .child(tabs(
                    s,
                    side,
                    p,
                    cx.layout_size(&format!("tabs-{side}")).map_or(
                        width - p.height(32.0) * 3.0 - p.space(2) * 2.0 - p.space(1) * 3.0,
                        |v| v[0],
                    ),
                )),
        )
        .child(content.grow(1.0).min_h(0.0))
}

fn transfers(s: &State, p: Theme) -> El {
    let source = s.pane();
    let destination = s.panes[1 - s.active_pane].tab();
    let name = s.folder_name(&destination.cwd);
    let count = source.selection_count();
    let disabled = count == 0
        || source
            .picker
            .as_ref()
            .map_or(source.tab().loading, |picker| picker.loading)
        || (source.picker.is_none() && source.tab().cwd == destination.cwd);
    row()
        .key("transfer-bar")
        .w_full()
        .h(p.height(40.0))
        .px(p.space(3))
        .gap(p.space(2))
        .center_y()
        .fill(p.panel)
        .child(label(
            if count == 1 {
                "1 item".into()
            } else {
                format!("{count} items")
            },
            p,
        ))
        .child(label(
            if s.active_pane == 0 {
                "Left pane to right pane"
            } else {
                "Right pane to left pane"
            },
            p,
        ))
        .child(el().grow(1.0))
        .child(
            action_button(format!("Copy to {name}"), p, |s, _| s.transfer(false))
                .key("copy-to-other")
                .disabled(disabled)
                .help(format!(
                    "Copy to {} · F5",
                    s.display_location(&destination.cwd)
                )),
        )
        .child(
            action_button(format!("Move to {name}"), p, |s, _| s.transfer(true))
                .key("move-to-other")
                .disabled(disabled)
                .help(format!(
                    "Move to {} · F6",
                    s.display_location(&destination.cwd)
                )),
        )
        .child(
            action_button("Preview", p, |s, tx| s.toggle_preview(tx))
                .key("split-preview")
                .help("Preview the active file · F4"),
        )
}

fn folder_toolbar(s: &State, side: usize, p: Theme) -> El {
    let tab = s.panes[side].tab();
    let uri = s.location_uri(&tab.cwd);
    let pinned = s.favorites().any(|place| place.uri == uri);
    let (name, direction) = match (tab.preference.sort_by, tab.preference.sort_reverse) {
        (SortBy::Modified, true) => ("Modified", "Newest first"),
        (SortBy::Modified, false) => ("Modified", "Oldest first"),
        (SortBy::Size, true) => ("Size", "Largest first"),
        (SortBy::Size, false) => ("Size", "Smallest first"),
        (SortBy::Extension, reverse) => ("Type", if reverse { "Descending" } else { "Ascending" }),
        (SortBy::Owner, reverse) => ("Owner", if reverse { "Descending" } else { "Ascending" }),
        (SortBy::Natural, reverse) => (
            "Natural name",
            if reverse { "Descending" } else { "Ascending" },
        ),
        (_, reverse) => ("Name", if reverse { "Descending" } else { "Ascending" }),
    };
    let controls = row()
        .w_full()
        .grow(1.0)
        .px(p.space(2))
        .gap(p.space(1))
        .center_y()
        .child(el().grow(1.0))
        .child(
            icon_button(
                if pinned {
                    &icon::STAR_FILLED
                } else {
                    &icon::STAR
                },
                if pinned {
                    "Remove current folder from Favorites"
                } else {
                    "Add current folder to Favorites"
                },
                p,
                move |s, tx| s.toggle_favorite(side, tx),
            )
            .key(format!("favorite-toggle-{side}"))
            .checked(pinned)
            .disabled(s.favorites_saving())
            .opacity(if s.favorites_saving() { 0.4 } else { 1.0 }),
        )
        .child(
            icon_button(
                if tab.preference.sort_reverse {
                    &icon::SORT_DESCENDING
                } else {
                    &icon::SORT_ASCENDING
                },
                &format!("{direction} · Reverse sort order"),
                p,
                move |s, tx| {
                    s.activate_pane(side, tx);
                    s.command("sort_reverse", tx);
                    tx.blur();
                },
            )
            .key(format!("sort-direction-{side}"))
            .checked(tab.preference.sort_reverse),
        )
        .child(
            icon_button(
                &icon::SORT_BY,
                &format!("Sort by · {name}"),
                p,
                move |s, tx| {
                    s.activate_pane(side, tx);
                    s.command("folder_view", tx);
                },
            )
            .key(format!("folder-view-{side}"))
            .checked(s.view_options == Some(FolderMenu::Sort) && s.active_pane == side)
            .fill(
                if s.view_options == Some(FolderMenu::Sort) && s.active_pane == side {
                    p.selected
                } else {
                    Color::TRANSPARENT
                },
            ),
        )
        .children(s.selector.is_none().then(|| {
            icon_button(
                view_icon(tab.preference.view_mode),
                &format!("View · {}", tab.preference.view_mode.name()),
                p,
                move |s, tx| {
                    s.activate_pane(side, tx);
                    s.command("view_options", tx);
                },
            )
            .key(format!("view-mode-{side}"))
            .checked(s.view_options == Some(FolderMenu::View) && s.active_pane == side)
            .fill(
                if s.view_options == Some(FolderMenu::View) && s.active_pane == side {
                    p.selected
                } else {
                    Color::TRANSPARENT
                },
            )
        }));

    col()
        .key(format!("folder-toolbar-{side}"))
        .role("toolbar")
        .label("Folder sorting and view")
        .w_full()
        .h(p.height(40.0))
        .fill(p.panel)
        .child(controls)
        .child(el().w_full().h(1.0).fill(p.line.alpha(0.6)))
}

fn files(s: &State, side: usize, p: Theme) -> El {
    let tab = s.panes[side].tab();
    let file_scroll = tab.scroll.clone();
    let peek_scrolled = s.peek_scrolled.clone();
    let columns = s.panes[side].columns();
    let grid = tab.preference.view_mode == ViewMode::Grid;
    let stride = if grid { grid_height(p) } else { p.row() };
    col()
        .key("current-panel")
        .motion(rune::Spring::new(0.22, 0.0))
        .transition(rune::Transition::none())
        .grow(1.0)
        .min_w(0.0)
        .min_h(0.0)
        .child(folder_toolbar(s, side, p))
        .child(if tab.preference.view_mode == ViewMode::Details {
            details::header(s, side, p)
        } else {
            el()
        })
        .child(
            col()
                .key(Pane::list_key(side))
                .on_layout_tx(move |s: &mut State, rect, tx| s.file_columns(side, rect[2], tx))
                .on_secondary_press(move |s: &mut State, point, tx| {
                    s.show_context(side, None, point.into(), tx)
                })
                .instant_changes()
                .grow(1.0)
                .min_h(0.0)
                .w_full()
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .on_scroll_offset(move |pos| {
                    file_scroll.set(pos.offset[1]);
                    if rune::scroll_watch_state().0 {
                        peek_scrolled.set(true);
                    }
                })
                .scroll_margin(stride)
                .child(
                    col()
                        .key("rows")
                        .w_full()
                        .growth(GrowthSpec::default())
                        .virtual_rows(
                            tab.visible.len().div_ceil(columns),
                            stride,
                            move |s: &State, i| {
                                if grid {
                                    format!("grid-row-{i}").into()
                                } else {
                                    s.panes[side].tab().entry(i).key.as_str().into()
                                }
                            },
                            move |s: &State, i| {
                                if !grid {
                                    return file_entry(s, side, i, false, p);
                                }
                                let count = s.panes[side].tab().visible.len();
                                row()
                                    .w_full()
                                    .h(stride)
                                    .px(p.space(2))
                                    .gap(p.space(2))
                                    .equal_columns(columns)
                                    .children((0..columns).map(|column| {
                                        let index = i * columns + column;
                                        if index < count {
                                            file_entry(s, side, index, true, p).min_w(0.0)
                                        } else {
                                            el().min_w(0.0)
                                        }
                                    }))
                            },
                        )
                        .virtual_rows_version((
                            s.panes[side].revision,
                            columns,
                            tab.preference.view_mode,
                        ))
                        .on_visible_rows(move |s: &mut State, range| {
                            let pane = &mut s.panes[side];
                            pane.page_size = (range.len() * columns).max(1);
                            pane.visible_files = range.start * columns
                                ..(range.end * columns).min(pane.tab().visible.len());
                            s.sync_thumbnails();
                            false
                        }),
                ),
        )
}

fn grid_height(p: Theme) -> f32 {
    ((96.0 + p.list().line_px() + p.font(11.0, 400.0).line_px() + p.space(6)) / 4.0).ceil() * 4.0
}

fn file_entry(s: &State, side: usize, index: usize, grid: bool, p: Theme) -> El {
    let tab = s.panes[side].tab();
    let file = tab.entry(index);
    let path = file.path.clone();
    let open_path = path.clone();
    let context_path = path.clone();
    let hovered = index == tab.cursor || s.drop_hover.as_deref() == Some(&file.path);
    let selected = tab.selected(index);
    let entry = if grid {
        file_tile(file, hovered, selected, p, side, s.thumbnail(file))
    } else if tab.preference.view_mode == ViewMode::Details {
        details::file_row(s, side, file, hovered, selected, p, s.thumbnail(file))
    } else {
        file_row(file, hovered, selected, true, p, side, s.thumbnail(file))
    };
    let entry = entry
        .hover_group()
        .on_press_tx(move |s: &mut State, tx| {
            s.activate_pane(side, tx);
            s.hover(&path, tx);
            tx.blur();
        })
        .on_secondary_press(move |s: &mut State, point, tx| {
            s.show_context(side, Some(&context_path), point.into(), tx);
        })
        .on_double_press_tx(move |s: &mut State, tx| {
            s.activate_pane(side, tx);
            s.hover(&open_path, tx);
            s.enter(tx, true);
            tx.blur();
        });
    let entry = draggable_file(entry, file, side);
    if file.directory {
        folder_hover(
            entry,
            file.path.clone(),
            side,
            format!("peek-list-{side}-{}", file.key),
            if grid { grid_height(p) } else { p.row() },
        )
    } else {
        entry
    }
}

fn file_tile(
    file: &File,
    hovered: bool,
    selected: bool,
    p: Theme,
    side: usize,
    thumbnail: Option<&rune::Image>,
) -> El {
    let path = file.path.clone();
    let glyph = icon::for_file(file);
    col()
        .key(&file.key)
        .role("listitem")
        .label(&file.name)
        .w_full()
        .h(grid_height(p))
        .py(p.space(2))
        .gap(p.space(1))
        .child(
            col()
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .padding(p.space(2))
                .radius(p.space(2))
                .fill(if hovered {
                    p.selected
                } else if selected {
                    p.selected.alpha(0.5)
                } else {
                    Color::TRANSPARENT
                })
                .hover(p.selected.alpha(0.45))
                .gap(p.space(1))
                .child(if let Some(image) = thumbnail {
                    el().key("file-image")
                        .w_full()
                        .h(80.0)
                        .pixels_fit(image.pixels(), SurfaceFit::Fit)
                } else {
                    el().key("file-image").w_full().h(80.0).center().child(
                        rune::icon(glyph, 48.0).color(if file.directory {
                            p.folder
                        } else {
                            p.muted
                        }),
                    )
                })
                .child(
                    text(&file.name)
                        .key("filename")
                        .font(p.list())
                        .color(p.text)
                        .align(rune::Align::Center)
                        .truncate()
                        .w_full()
                        .help(&file.name),
                )
                .child(
                    row()
                        .w_full()
                        .center_y()
                        .gap(p.space(1))
                        .child(el().w(20.0).h(20.0))
                        .child(
                            text(if file.directory {
                                "Folder".into()
                            } else {
                                file::human_size(file.size)
                            })
                            .key("file-size")
                            .font(p.font(11.0, 400.0))
                            .color(p.muted)
                            .align(rune::Align::Center)
                            .truncate()
                            .grow(1.0)
                            .min_w(0.0),
                        )
                        .child(
                            el().key("selection")
                                .role("checkbox")
                                .label(format!("Select {}", file.name))
                                .checked(selected)
                                .w(20.0)
                                .h(20.0)
                                .center()
                                .cursor(rune::Cursor::Pointer)
                                .on_press_tx(move |s: &mut State, tx| {
                                    s.activate_pane(side, tx);
                                    s.toggle_selection(&path);
                                })
                                .child(
                                    el().w(16.0)
                                        .h(16.0)
                                        .radius(p.space(1))
                                        .border(1.0, p.accent)
                                        .fill(if selected {
                                            p.accent
                                        } else {
                                            Color::TRANSPARENT
                                        })
                                        .group_opacity(if selected { 1.0 } else { 0.0 }, 1.0)
                                        .child(if selected {
                                            rune::icon(&icon::CHECK, 13.0).color(p.background)
                                        } else {
                                            el()
                                        }),
                                ),
                        ),
                ),
        )
}

fn panel_header(title: &str, p: Theme) -> El {
    text(title)
        .font(p.font(11.0, 500.0))
        .color(p.muted)
        .w_full()
        .h(p.height(24.0))
        .py(p.space(1))
}

fn folder_hover(
    element: El,
    path: std::path::PathBuf,
    side: usize,
    anchor: String,
    height: f32,
) -> El {
    el().w_full().h(height).child(
        el().key(&anchor)
            .w_full()
            .h_full()
            .on_hover_change(move |s: &mut State, inside, _| {
                s.peek_folder(path.clone(), anchor.clone(), side, inside);
            })
            .hover_delays(
                std::time::Duration::from_millis(400),
                std::time::Duration::from_millis(150),
            )
            .child(element),
    )
}

fn draggable_file(element: El, file: &File, side: usize) -> El {
    let path = file.path.clone();
    let directory = file.directory;
    element.on_drag(move |s: &mut State, drag, tx| {
        if drag.phase == rune::Phase::Down {
            s.activate_pane(side, tx);
        }
        s.drag_file(&path, directory, drag);
    })
}

fn file_row(
    file: &File,
    hovered: bool,
    selected: bool,
    metadata: bool,
    p: Theme,
    side: usize,
    thumbnail: Option<&rune::Image>,
) -> El {
    let glyph = icon::for_file(file);
    let mut content = row()
        .key("file-surface")
        .w_full()
        .h_full()
        .px(p.space(3))
        .gap(p.space(2))
        .center_y()
        .radius(p.space(2))
        .motion(rune::Spring::new(0.12, 0.0))
        .fill(if hovered {
            p.selected
        } else if selected {
            p.selected.alpha(0.5)
        } else {
            Color::TRANSPARENT
        })
        .hover(p.selected.alpha(0.45))
        .child(if let Some(image) = thumbnail {
            el().key("thumbnail")
                .w(20.0)
                .h(24.0)
                .pixels_fit(image.pixels(), SurfaceFit::Fit)
        } else {
            el().w(20.0).h(20.0).center().child(
                rune::icon(glyph, 19.0)
                    .label(glyph.name)
                    .color(if file.directory { p.folder } else { p.muted }),
            )
        })
        .child(
            text(&file.name)
                .key("filename")
                .font(p.list())
                .color(p.text)
                .truncate()
                .shrink()
                .min_w(0.0)
                .grow(1.0),
        );
    if file.symlink {
        content = content.child(
            rune::icon(&icon::LINK, 12.0)
                .label("Symbolic link")
                .color(p.muted),
        );
    }
    if metadata && !file.directory {
        content = content.child(
            text(file::human_size(file.size))
                .font(p.font(11.0, 400.0).features("'tnum' 1"))
                .color(p.muted),
        );
    }
    if metadata {
        let path = file.path.clone();
        content = content.child(
            el().key("selection")
                .role("checkbox")
                .label(format!("Select {}", file.name))
                .checked(selected)
                .w(20.0)
                .h(p.height(24.0))
                .center()
                .cursor(rune::Cursor::Pointer)
                .focus_ring(2.0, 0.0, p.accent)
                .on_press_tx(move |s: &mut State, tx| {
                    s.activate_pane(side, tx);
                    s.toggle_selection(&path);
                })
                .child(
                    el().w(16.0)
                        .h(16.0)
                        .radius(p.space(1))
                        .border(1.0, p.accent)
                        .fill(if selected {
                            p.accent
                        } else {
                            Color::TRANSPARENT
                        })
                        .group_opacity(if selected { 1.0 } else { 0.0 }, 1.0)
                        .child(if selected {
                            rune::icon(&icon::CHECK, 13.0).color(p.background)
                        } else {
                            el()
                        }),
                ),
        );
    } else if selected {
        content = content.child(
            rune::icon(&icon::CHECK, 14.0)
                .label("Selected")
                .color(p.accent),
        );
    }
    if file.directory {
        content = content.child(rune::icon(&icon::CHEVRON, 14.0).color(p.folder.alpha(0.7)));
    }
    el().key(file.key.clone())
        .role("listitem")
        .label(file.name.clone())
        .w_full()
        .h(p.row())
        .px(p.space(2))
        .py(p.space(1) / 2.0)
        .child(content)
}

fn preview_header(s: &State, p: Theme) -> El {
    let pane = s.pane();
    let file = pane.file();
    let source = match &pane.preview {
        Preview::Html(html) => matches!(html.view, crate::html::View::Source),
        _ => pane.preview_source,
    };
    let can_source = matches!(pane.preview, Preview::Html(_) | Preview::Markdown { .. });
    let can_wrap =
        matches!(pane.preview, Preview::Text { .. } | Preview::Code(_)) || (source && can_source);
    let info = if let Some(file) = file {
        let mime = pane.preview_mime.as_deref().unwrap_or("…");
        let size = if file.directory {
            String::new()
        } else {
            file::human_size(file.size)
        };
        draggable_file(
            col()
                .key("preview-info")
                .grow(1.0)
                .min_w(0.0)
                .gap(p.space(1))
                .child(
                    text(&file.name)
                        .key("preview-name")
                        .font(p.font(12.0, 500.0))
                        .color(p.text)
                        .truncate()
                        .w_full()
                        .min_w(0.0)
                        .help(&file.name),
                )
                .child(
                    row()
                        .w_full()
                        .min_w(0.0)
                        .center_y()
                        .gap(p.space(1))
                        .children((!file.directory).then(|| {
                            text(size)
                                .key("preview-size")
                                .font(p.font(10.0, 400.0))
                                .color(p.muted)
                        }))
                        .child(
                            text(mime)
                                .key("preview-mime")
                                .font(p.font(10.0, 400.0))
                                .color(p.muted)
                                .w(0.0)
                                .grow(1.0)
                                .min_w(0.0)
                                .truncate()
                                .help(mime),
                        ),
                ),
            file,
            s.active_pane,
        )
    } else {
        label("Preview", p).grow(1.0).min_w(0.0)
    };
    let mut controls = row()
        .w_full()
        .grow(1.0)
        .min_w(0.0)
        .px(p.space(2))
        .gap(p.space(1))
        .center_y()
        .child(info);
    if file.is_some_and(|file| !file.directory) {
        controls = controls.child(
            icon_button(
                &icon::OPEN_DEFAULT,
                "Open in default application",
                p,
                |s, tx| s.open_preview(tx),
            )
            .w(p.height(28.0))
            .h(p.height(28.0))
            .key("preview-open"),
        );
    }
    if file.is_some_and(|file| !file.directory) {
        let reason = if s.print_busy {
            "Printing in progress"
        } else if let Some(mime) = pane.preview_mime.as_deref() {
            crate::printing::unsupported_reason(mime).unwrap_or("Print…")
        } else {
            "Detecting file type…"
        };
        let enabled = !s.print_busy
            && pane
                .preview_mime
                .as_deref()
                .is_some_and(crate::printing::supports);
        controls = controls.child(
            icon_button(&icon::PRINT, reason, p, |s, _| s.print_preview())
                .w(p.height(28.0))
                .h(p.height(28.0))
                .key("preview-print")
                .disabled(!enabled)
                .opacity(if enabled { 1.0 } else { 0.4 }),
        );
    }
    if can_wrap {
        controls = controls.child(
            icon_button(&icon::WRAP, "Toggle word wrap", p, |s, tx| {
                s.pane_mut().preview_wrap = !s.pane().preview_wrap;
                s.pane().preview_scroll.set([0.0; 2]);
                tx.scroll_to_instant("preview", 0.0, 0.0);
            })
            .w(p.height(28.0))
            .h(p.height(28.0))
            .key("preview-wrap")
            .checked(pane.preview_wrap),
        );
    }
    if can_source {
        controls = controls.child(
            icon_button(
                &icon::SOURCE,
                if source {
                    "Render document"
                } else {
                    "Show source"
                },
                p,
                |s, tx| s.toggle_preview_source(tx),
            )
            .w(p.height(28.0))
            .h(p.height(28.0))
            .key("preview-source")
            .checked(source),
        );
    }
    controls = controls.child(
        icon_button(
            if s.preview_expanded {
                &icon::RESTORE
            } else {
                &icon::EXPAND
            },
            "Expand or restore preview · F4",
            p,
            |s, tx| s.toggle_preview(tx),
        )
        .w(p.height(28.0))
        .h(p.height(28.0))
        .key("preview-expand"),
    );
    let needed = p.font(12.0, 500.0).line_px() + p.font(10.0, 400.0).line_px() + p.space(3) + 1.0;
    let header_height = (needed / p.space(1)).ceil() * p.space(1);
    col()
        .key("preview-header")
        .role("toolbar")
        .label("Preview actions")
        .w_full()
        .h(header_height.max(p.height(40.0)))
        .fill(p.panel)
        .child(controls)
        .child(el().w_full().h(1.0).fill(p.line.alpha(0.6)))
}

fn preview(s: &State, p: Theme) -> El {
    let side = s.active_pane;
    let scroll = s.pane().preview_scroll.clone();
    let peek_scrolled = s.peek_scrolled.clone();
    let body = match &s.pane().preview {
        Preview::Empty => col()
            .padding(p.space(4))
            .child(label("No file selected", p)),
        Preview::Loading => col()
            .padding(p.space(4))
            .child(label("Loading preview…", p)),
        Preview::Message(message) => col().padding(p.space(4)).child(
            text(message)
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .w_full(),
        ),
        Preview::Image(image) => el()
            .key("image")
            .w_full()
            .h_full()
            .padding(p.space(4))
            .pixels_fit(image.pixels(), SurfaceFit::Fit),
        Preview::Pdf(pdf) => {
            let image = match &pdf.content {
                crate::pdf::Page::Ready(image) => el()
                    .key("pdf-page")
                    .w_full()
                    .grow(1.0)
                    .min_h(0.0)
                    .padding(p.space(4))
                    .pixels_fit(image.pixels(), SurfaceFit::Fit),
                crate::pdf::Page::Loading => col()
                    .grow(1.0)
                    .padding(p.space(4))
                    .child(label("Rendering page…", p)),
                crate::pdf::Page::Error(error) => col().grow(1.0).padding(p.space(4)).child(
                    text(error)
                        .font(p.font(13.0, 400.0))
                        .color(p.muted)
                        .w_full(),
                ),
            };
            col()
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .child(
                    row()
                        .w_full()
                        .h(p.height(40.0))
                        .px(p.space(3))
                        .gap(p.space(2))
                        .center_y()
                        .child(
                            action_button("Previous", p, |s, _| s.seek_pdf(-1))
                                .key("pdf-previous")
                                .disabled(pdf.page == 1)
                                .opacity(if pdf.page == 1 { 0.4 } else { 1.0 }),
                        )
                        .child(label(format!("{} / {}", pdf.page, pdf.pages()), p).grow(1.0))
                        .child(
                            action_button("Next", p, |s, _| s.seek_pdf(1))
                                .key("pdf-next")
                                .disabled(pdf.page == pdf.pages())
                                .opacity(if pdf.page == pdf.pages() { 0.4 } else { 1.0 }),
                        ),
                )
                .child(image)
                .child(
                    label("J / K · next / previous page", p)
                        .px(p.space(3))
                        .py(p.space(2)),
                )
        }
        Preview::Directory(files) => col()
            .key("preview")
            .w_full()
            .grow(1.0)
            .min_h(0.0)
            .scroll(ScrollSpec {
                stick_bottom: false,
            })
            .on_scroll_offset(move |pos| {
                scroll.set([pos.offset[1], pos.max[1]]);
                if rune::scroll_watch_state().0 {
                    peek_scrolled.set(true);
                }
            })
            .child(
                col()
                    .key("preview-rows")
                    .w_full()
                    .growth(GrowthSpec::default())
                    .virtual_rows(
                        files.len(),
                        p.row(),
                        |s: &State, i| {
                            let Preview::Directory(files) = &s.pane().preview else {
                                unreachable!()
                            };
                            files[i].key.as_str().into()
                        },
                        move |s: &State, i| {
                            let Preview::Directory(files) = &s.pane().preview else {
                                unreachable!()
                            };
                            let file = &files[i];
                            let row = draggable_file(
                                file_row(file, false, false, false, p, side, s.thumbnail(file)),
                                file,
                                side,
                            );
                            if file.directory {
                                folder_hover(
                                    row,
                                    file.path.clone(),
                                    side,
                                    format!("peek-preview-{side}-{}", file.key),
                                    p.row(),
                                )
                            } else {
                                row
                            }
                        },
                    ),
            ),
        Preview::Markdown { truncated, .. } if s.pane().preview_source => {
            text_preview(s, s.pane().preview_source_lines.len(), *truncated, p)
        }
        Preview::Markdown {
            source,
            path,
            truncated,
        } => {
            let path = path.clone();
            let style = document_style(p);
            let markdown = rune_kit::Markdown::new(source)
                .tasks_read_only()
                .selectable(true)
                .scroll_wide(true)
                .on_link_tx(move |s: &mut State, link, tx| s.open_preview_link(&path, link, tx))
                .link_help(|link| Some(link.to_owned()))
                .render(&style)
                .key("markdown")
                .w_full()
                .min_w(0.0);
            let mut body = col().w_full().grow(1.0).min_h(0.0).child(
                col()
                    .key("preview")
                    .w_full()
                    .grow(1.0)
                    .min_h(0.0)
                    .scroll(ScrollSpec {
                        stick_bottom: false,
                    })
                    .on_scroll_offset(move |pos| {
                        scroll.set([pos.offset[1], pos.max[1]]);
                    })
                    .child(
                        row().w_full().center().child(
                            col()
                                .w_full()
                                .max_w(820.0)
                                .min_w(0.0)
                                .padding(p.space(6))
                                .child(markdown),
                        ),
                    ),
            );
            if *truncated {
                body = body.child(
                    label("Preview limited to 256 KiB / 4,000 lines", p)
                        .px(p.space(3))
                        .py(p.space(2)),
                );
            }
            body
        }
        Preview::Zip(zip) => zip_preview(s, zip, p),
        Preview::Core(core) => core_preview(s, core, p),
        Preview::Code(code) => code_preview(s, code, p),
        Preview::Html(html) => html_preview(s, html, p),
        Preview::Text { lines, truncated } => text_preview(s, lines.len(), *truncated, p),
    };
    let body = body
        .grow(1.0)
        .min_h(0.0)
        .min_w(0.0)
        .instant_changes()
        .transition(rune::Transition::none());
    if let Some(file) = s.pane().file() {
        draggable_file(body, file, side)
    } else {
        body
    }
}

fn zip_preview(s: &State, zip: &crate::archive::ZipPreview, p: Theme) -> El {
    let mut header = col()
        .w_full()
        .min_w(0.0)
        .padding(p.space(4))
        .gap(p.space(2))
        .child(text("ZIP archive").font(p.font(20.0, 600.0)).color(p.text))
        .child(
            text(format!(
                "{} on disk · {} files · {}{} folders",
                file::human_size(zip.archive_size),
                zip.files,
                if zip.folders_limited { "≥" } else { "" },
                zip.folders
            ))
            .font(p.font(13.0, 400.0))
            .color(p.text)
            .wrap()
            .w_full(),
        )
        .child(
            text("Directory metadata · contents and CRCs not verified")
                .font(p.font(11.0, 400.0))
                .color(p.muted)
                .wrap()
                .w_full(),
        );
    if zip.encrypted > 0 {
        header = header.child(
            text(format!(
                "{} encrypted entries · no password needed to inspect metadata",
                zip.encrypted
            ))
            .font(p.font(13.0, 400.0))
            .color(p.folder)
            .wrap()
            .w_full(),
        );
    }
    if !zip.issues.is_empty() {
        header = header.child(
            text(format!(
                "{} metadata notices · see Overview",
                zip.issues.len()
            ))
            .font(p.font(13.0, 400.0))
            .color(p.folder)
            .wrap()
            .w_full(),
        );
    }
    let mut tabs = row().role("tablist").w_full().gap(p.space(2));
    for (contents, title) in [(false, "Overview"), (true, "Entries")] {
        let change = move |s: &mut State, tx: &mut rune::Tx| {
            if let Preview::Zip(zip) = &mut s.pane_mut().preview {
                zip.contents = contents;
                s.pane().preview_scroll.set([0.0; 2]);
                tx.scroll_to_y("preview", 0.0);
            }
        };
        tabs = tabs.child(
            action_button(title, p, change)
                .key(if contents {
                    "zip-entries-tab"
                } else {
                    "zip-overview-tab"
                })
                .role("tab")
                .focus_selected(contents == zip.contents)
                .fill(if contents == zip.contents {
                    p.selected
                } else {
                    p.panel
                })
                .on_key(move |s, key, tx| {
                    let activate = crate::keymap::key_name(key)
                        .is_some_and(|key| matches!(key.as_str(), "<Enter>" | " "));
                    if activate {
                        change(s, tx);
                    }
                    activate
                }),
        );
    }
    header = header.child(tabs);
    let scroll = s.pane().preview_scroll.clone();
    let entry_row = {
        let lines = p.font(13.0, 400.0).line_px()
            + p.font(11.0, 400.0).line_px()
            + p.font(11.0, 400.0).line_px()
            + p.space(1) * 2.0;
        (lines / p.space(1)).ceil() * p.space(1)
    };
    let content = if zip.contents {
        col()
            .key("zip-entries")
            .w_full()
            .growth(GrowthSpec::default())
            .virtual_rows(
                zip.entries.len(),
                entry_row,
                |_: &State, i| format!("zip-entry-{i}").into(),
                move |s: &State, i| {
                    let Preview::Zip(zip) = &s.pane().preview else {
                        unreachable!()
                    };
                    let entry = &zip.entries[i];
                    col()
                        .h(entry_row)
                        .w_full()
                        .min_w(0.0)
                        .px(p.space(3))
                        .py(p.space(1))
                        .child(
                            text(format!(
                                "{}{}",
                                entry.path,
                                if entry.directory && !entry.path.ends_with('/') {
                                    "/"
                                } else {
                                    ""
                                }
                            ))
                            .font(p.font(13.0, 400.0))
                            .color(if entry.directory { p.folder } else { p.text })
                            .truncate()
                            .w_full()
                            .help(&entry.path),
                        )
                        .child(
                            text(format!(
                                "{} → {} · {}",
                                file::human_size(entry.packed),
                                file::human_size(entry.unpacked),
                                entry.method
                            ))
                            .font(p.font(11.0, 400.0).features("'tnum' 1"))
                            .color(p.muted)
                            .truncate()
                            .w_full(),
                        )
                        .child(
                            text(format!(
                                "{}{}{}",
                                entry.date,
                                if entry.flags.is_empty() { "" } else { " · " },
                                entry.flags
                            ))
                            .font(p.font(11.0, 400.0).features("'tnum' 1"))
                            .color(if entry.flags.is_empty() {
                                p.muted
                            } else {
                                p.folder
                            })
                            .truncate()
                            .w_full()
                            .help(format!("ZIP timestamp has no timezone. {}", entry.flags)),
                        )
                },
            )
    } else {
        let denominator = zip.unpacked.max(zip.packed).max(1) as f64;
        let bar = |title: &str, bytes: u64, color: Color| {
            let fraction = (bytes as f64 / denominator) as f32;
            col()
                .w_full()
                .gap(p.space(1))
                .child(
                    row()
                        .w_full()
                        .child(label(title, p).grow(1.0))
                        .child(label(file::human_size(bytes), p)),
                )
                .child(
                    row()
                        .w_full()
                        .h(p.space(2))
                        .child(el().h(p.space(2)).grow(fraction).fill(color))
                        .child(el().h(p.space(2)).grow(1.0 - fraction).fill(p.line)),
                )
        };
        let mut body = col()
            .w_full()
            .min_w(0.0)
            .padding(p.space(4))
            .gap(p.space(2))
            .child(bar("Packed entry data", zip.packed, p.accent))
            .child(bar("Unpacked (declared)", zip.unpacked, p.folder));
        if zip.unpacked > 0 {
            let saved = 100.0 * (1.0 - zip.packed as f64 / zip.unpacked as f64);
            let expansion = if zip.packed > 0 {
                format!(
                    " · {:.1}× declared expansion",
                    zip.unpacked as f64 / zip.packed as f64
                )
            } else {
                String::new()
            };
            body = body.child(
                text(format!(
                    "Entry data {:.1}% {}{expansion}",
                    saved.abs(),
                    if saved >= 0.0 { "smaller" } else { "larger" }
                ))
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .wrap()
                .w_full(),
            );
        }
        for issue in &zip.issues {
            body = body.child(
                text(issue)
                    .font(p.font(13.0, 400.0))
                    .color(p.folder)
                    .wrap()
                    .w_full(),
            );
        }
        body = body.child(text("File types").font(p.font(14.0, 600.0)).color(p.text));
        if zip.types.is_empty() {
            body = body.child(label("No file entries", p));
        }
        for kind in zip.types.iter().take(8) {
            body = body.child(
                row()
                    .w_full()
                    .gap(p.space(2))
                    .child(
                        text(&kind.name)
                            .font(p.font(13.0, 400.0))
                            .color(p.accent)
                            .truncate()
                            .grow(1.0),
                    )
                    .child(label(
                        format!("{} · {}", kind.files, file::human_size(kind.bytes)),
                        p,
                    )),
            );
        }
        if zip.types.len() > 8 {
            body = body.child(label(
                format!("Showing 8 of {} file types", zip.types.len()),
                p,
            ));
        }
        body = body.child(
            text("Largest files")
                .font(p.font(14.0, 600.0))
                .color(p.text),
        );
        if zip.largest.is_empty() {
            body = body.child(label("No file entries", p));
        }
        for &index in &zip.largest {
            let entry = &zip.entries[index];
            body = body.child(
                row()
                    .w_full()
                    .gap(p.space(2))
                    .child(
                        text(&entry.path)
                            .font(p.font(13.0, 400.0))
                            .color(p.text)
                            .truncate()
                            .grow(1.0)
                            .help(&entry.path),
                    )
                    .child(label(file::human_size(entry.unpacked), p)),
            );
        }
        body = body.child(
            text("Folder structure")
                .font(p.font(14.0, 600.0))
                .color(p.text),
        );
        if zip.tree.is_empty() {
            body = body.child(label("Empty archive", p));
        }
        for node in &zip.tree {
            let depth = node.path.matches('/').count();
            let name = node.path.rsplit('/').next().unwrap_or(&node.path);
            body = body.child(
                text(format!(
                    "{}{}{}",
                    "  ".repeat(depth.min(12)),
                    name,
                    if node.directory { "/" } else { "" }
                ))
                .font(p.font(13.0, 400.0))
                .color(if node.directory { p.folder } else { p.text })
                .truncate()
                .w_full()
                .help(&node.path),
            );
        }
        if zip.tree_limited {
            body = body.child(label("Structure limited to the first 200 paths; use Entries for the full inspected list", p).wrap().w_full());
        }
        body
    };
    col().w_full().grow(1.0).min_h(0.0).child(header).child(
        col()
            .key("preview")
            .w_full()
            .grow(1.0)
            .min_h(0.0)
            .scroll(ScrollSpec {
                stick_bottom: false,
            })
            .on_scroll_offset(move |pos| {
                scroll.set([pos.offset[1], pos.max[1]]);
            })
            .child(content),
    )
}

fn core_preview(s: &State, core: &crate::core_dump::CoreDump, p: Theme) -> El {
    let mut content = col()
        .w_full()
        .min_w(0.0)
        .padding(p.space(4))
        .gap(p.space(2))
        .child(text("Core dump").font(p.font(20.0, 600.0)).color(p.text))
        .child(
            text(&core.architecture)
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .wrap()
                .w_full(),
        );
    if !core.signal.is_empty() {
        let fault = if core.fault.is_empty() {
            String::new()
        } else {
            format!(" · fault address {}", core.fault)
        };
        content = content.child(
            text(format!("{}{fault} · {} threads", core.signal, core.threads))
                .font(p.font(13.0, 400.0))
                .color(p.folder)
                .wrap()
                .w_full(),
        );
    }
    if !core.symbols.is_empty() {
        content = content.child(
            text(&core.symbols)
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .wrap()
                .w_full(),
        );
    }
    if !core.process.is_empty() {
        content = content.child(
            text(format!("{} · PID {}", core.process, core.pid))
                .font(p.font(13.0, 400.0))
                .color(p.text)
                .wrap_anywhere()
                .w_full(),
        );
    }
    if !core.notice.is_empty() {
        content = content.child(
            text(&core.notice)
                .font(p.font(13.0, 400.0))
                .color(p.folder)
                .wrap()
                .w_full(),
        );
    }
    for (index, section) in core.sections.iter().enumerate() {
        let expanded = section.expanded;
        let toggle = move |s: &mut State, _: &mut rune::Tx| {
            if let Preview::Core(core) = &mut s.pane_mut().preview
                && let Some(section) = core.sections.get_mut(index)
            {
                section.expanded = !section.expanded;
            }
        };
        content = content.child(
            row()
                .key(format!("core-section-{index}"))
                .w_full()
                .px(p.space(2))
                .py(p.space(2))
                .fill(p.panel)
                .hover(p.selected)
                .role("button")
                .label(&section.title)
                .expanded(expanded)
                .focusable(true)
                .on_press_tx(toggle)
                .on_key(move |s, key, tx| {
                    let activate = crate::keymap::key_name(key)
                        .is_some_and(|key| matches!(key.as_str(), "<Enter>" | " "));
                    if activate {
                        toggle(s, tx);
                    }
                    activate
                })
                .child(
                    text(format!(
                        "{} {}",
                        if expanded { "▾" } else { "▸" },
                        section.title
                    ))
                    .font(p.font(13.0, 400.0))
                    .color(p.accent)
                    .wrap()
                    .w_full(),
                ),
        );
        if expanded {
            content = content.child(
                text(&section.body)
                    .font(p.font(13.0, 400.0))
                    .color(p.text)
                    .selectable(true)
                    .wrap_anywhere()
                    .w_full(),
            );
        }
    }
    let scroll = s.pane().preview_scroll.clone();
    col()
        .key("preview")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .on_scroll_offset(move |pos| {
            scroll.set([pos.offset[1], pos.max[1]]);
        })
        .child(content)
}

fn text_preview(s: &State, count: usize, truncated: bool, p: Theme) -> El {
    let scroll = s.pane().preview_scroll.clone();
    let wrap = s.pane().preview_wrap;
    let mut lines = col()
        .key("text-lines")
        .min_w(0.0)
        .growth(GrowthSpec::default());
    if wrap {
        lines = lines.w_full();
    }
    let lines = lines
        .virtual_rows(
            count,
            p.code_height(),
            |_: &State, i| format!("line-{i}").into(),
            move |s: &State, i| {
                let lines = match &s.pane().preview {
                    Preview::Text { lines, .. } => lines,
                    _ => &s.pane().preview_source_lines,
                };
                let content = text(&lines[i])
                    .font(p.code())
                    .color(p.text)
                    .selectable(true);
                let content = if wrap {
                    content.wrap_anywhere().w_full().min_w(0.0).grow(1.0)
                } else {
                    content
                };
                let line = row()
                    .min_h(p.code_height())
                    .gap(p.space(3))
                    .px(p.space(3))
                    .child(
                        text(format!("{:>4}", i + 1))
                            .font(p.code())
                            .color(p.muted)
                            .w((p.code().size * 3.0).ceil()),
                    )
                    .child(content);
                if wrap { line.w_full() } else { line }
            },
        )
        .virtual_rows_version((
            s.panes[s.active_pane].revision,
            wrap,
            s.pane().preview_source,
        ));
    let viewport = col().key("preview").w_full().grow(1.0).min_h(0.0);
    let viewport = if wrap {
        viewport.scroll(ScrollSpec {
            stick_bottom: false,
        })
    } else {
        viewport.scroll_xy()
    };
    let mut body = col().w_full().grow(1.0).min_h(0.0).child(
        viewport
            .on_scroll_offset(move |pos| {
                scroll.set([pos.offset[1], pos.max[1]]);
            })
            .child(lines),
    );
    if truncated {
        body = body.child(
            label("Preview limited to 256 KiB / 4,000 lines", p)
                .px(p.space(3))
                .py(p.space(2)),
        );
    }
    body
}

fn document_style(p: Theme) -> rune_kit::MarkdownStyle {
    rune_kit::MarkdownStyle::neutral(p.dark)
        .text(p.text)
        .muted(p.muted)
        .link(p.accent)
        .body_font(p.font(14.0, 400.0).lh(p.leading(22.0)))
        .heading_font(1, p.font(24.0, 650.0).lh(p.leading(30.0)))
        .heading_font(2, p.font(20.0, 600.0).lh(p.leading(26.0)))
        .heading_font(3, p.font(16.0, 600.0).lh(p.leading(23.0)))
        .code_block_font(p.code())
        .code_block(p.panel, p.line)
        .inline_code_bg(p.panel)
        .quote_rule(p.line)
        .rule(p.line)
        .selection(p.selected)
        .list(22.0, 4.0)
}

fn code_preview(s: &State, code: &crate::code::Code, p: Theme) -> El {
    let scroll = s.pane().preview_scroll.clone();
    let wrap = s.pane().preview_wrap;
    let mut lines = col()
        .key("code-lines")
        .min_w(0.0)
        .growth(GrowthSpec::default());
    if wrap {
        lines = lines.w_full();
    }
    let lines = lines
        .virtual_rows(
            code.lines.len(),
            p.code_height(),
            |_: &State, i| format!("code-line-{i}").into(),
            move |s: &State, i| {
                let code = match &s.pane().preview {
                    Preview::Code(code) => code,
                    Preview::Html(html) => &html.source.code,
                    _ => unreachable!(),
                };
                let line = &code.lines[i];
                let spans: Vec<_> = line
                    .syntax
                    .iter()
                    .map(|(range, token)| {
                        rune::Span::new(range.start, range.end).color(p.token(*token))
                    })
                    .collect();
                let content = text(&line.text)
                    .font(p.code())
                    .color(p.text)
                    .spans(spans)
                    .selectable(true);
                let content = if wrap {
                    content.wrap_anywhere().w_full().min_w(0.0).grow(1.0)
                } else {
                    content
                };
                let line = row()
                    .min_h(p.code_height())
                    .gap(p.space(3))
                    .px(p.space(3))
                    .child(
                        text(format!("{:>4}", i + 1))
                            .font(p.code())
                            .color(p.muted)
                            .w((p.code().size * 3.0).ceil()),
                    )
                    .child(content);
                if wrap { line.w_full() } else { line }
            },
        )
        .virtual_rows_version((s.panes[s.active_pane].revision, wrap));
    let viewport = col().key("preview").w_full().grow(1.0).min_h(0.0);
    let viewport = if wrap {
        viewport.scroll(ScrollSpec {
            stick_bottom: false,
        })
    } else {
        viewport.scroll_xy()
    };
    let mut body = col().w_full().grow(1.0).min_h(0.0).child(
        viewport
            .on_scroll_offset(move |pos| {
                scroll.set([pos.offset[1], pos.max[1]]);
            })
            .child(lines),
    );
    if let Some(note) = &code.note {
        body = body.child(label(note, p).px(p.space(3)).py(p.space(2)));
    }
    if code.truncated {
        body = body.child(
            label("Preview limited to 256 KiB / 4,000 lines", p)
                .px(p.space(3))
                .py(p.space(2)),
        );
    }
    body
}

fn html_preview(s: &State, html: &crate::html::Html, p: Theme) -> El {
    use crate::html::{Part, View};
    let content = match &html.view {
        View::Source => code_preview(s, &html.source.code, p),
        View::Loading => col()
            .w_full()
            .grow(1.0)
            .padding(p.space(4))
            .child(label("Rendering HTML…", p)),
        View::Error(error) => col()
            .w_full()
            .grow(1.0)
            .padding(p.space(4))
            .child(label(error, p)),
        View::Rendered(document) => {
            let style = document_style(p);
            let mut content = col()
                .key("html-content")
                .w_full()
                .min_w(0.0)
                .padding(p.space(4))
                .gap(p.space(3));
            for (i, part) in document.parts.iter().enumerate() {
                let part = match part {
                    Part::Text { source, .. } => {
                        let path = html.source.path.clone();
                        rune_kit::Markdown::new(source)
                            .autolink(false)
                            .tasks_read_only()
                            .selectable(true)
                            .scroll_wide(true)
                            .on_link_tx(move |s: &mut State, link, tx| {
                                s.open_html_link(&path, link, tx)
                            })
                            .link_help(|link| Some(link.to_owned()))
                            .render(&style)
                            .w_full()
                            .min_w(0.0)
                    }
                    Part::Image { image, alt } => {
                        let pixels = image.pixels();
                        let (width, height) = pixels.size();
                        let height =
                            (height as f32 / width.max(1) as f32 * 520.0).clamp(60.0, 420.0);
                        col()
                            .w_full()
                            .min_w(0.0)
                            .child(el().w_full().h(height).pixels_fit(pixels, SurfaceFit::Fit))
                            .child(label(alt, p).py(p.space(1)))
                    }
                };
                content = content.child(part.key(format!("html-part-{i}")));
            }
            if document.parts.is_empty() {
                content = content.child(label("No static content to render", p));
            }
            let scroll = s.pane().preview_scroll.clone();
            let mut body = col().w_full().grow(1.0).min_h(0.0).child(
                col()
                    .key("preview")
                    .w_full()
                    .grow(1.0)
                    .min_h(0.0)
                    .scroll(ScrollSpec {
                        stick_bottom: false,
                    })
                    .on_scroll_offset(move |pos| {
                        scroll.set([pos.offset[1], pos.max[1]]);
                    })
                    .child(content),
            );
            if html.source.truncated || document.limited {
                body = body.child(
                    label("HTML preview limited", p)
                        .px(p.space(3))
                        .py(p.space(2)),
                );
            }
            body
        }
    };
    col().w_full().grow(1.0).min_h(0.0).child(content).child(
        label("Static HTML · document styling · no JavaScript", p)
            .px(p.space(3))
            .py(p.space(2)),
    )
}

fn overlay(s: &State, p: Theme, width: f32, height: f32) -> El {
    if s.spot {
        return crate::properties_view::view(s, p, width, height);
    }
    let mut content = col()
        .key("overlay")
        .w_full()
        .padding(p.space(6))
        .gap(p.space(3))
        .fill(p.panel);
    content = content.child(text("Keyboard navigation").font(p.font(20.0, 600.0)).color(p.text))
            .child(label("Ctrl+L edits the path. Alt+Left, Alt+Right, and Alt+Up navigate history and parents. F3 toggles split view. Tab switches panes when no control has focus. F5 copies and F6 moves to the other pane. F4 previews a file. F9 toggles navigation. Ctrl+F finds files. Ctrl+Shift++ and Ctrl+Shift+- zoom the interface; Ctrl+Shift+0 resets it. Drag files into other applications.", p));
    let mut bindings = col().w_full().gap(p.space(2));
    for binding in &s.bindings {
        bindings = bindings.child(
            row()
                .gap(p.space(4))
                .child(
                    text(binding.on.list().join(" "))
                        .font(p.font(13.0, 400.0))
                        .color(p.accent)
                        .w(170.0),
                )
                .child(
                    text(&binding.desc)
                        .font(p.font(13.0, 400.0))
                        .color(p.text)
                        .grow(1.0)
                        .min_w(0.0)
                        .wrap_anywhere(),
                ),
        );
    }
    content = content.child(bindings);

    el().key("overlay-layer")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .role("dialog")
        .label("Keyboard navigation")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| {
            s.help = false;
        })
        .child(
            col()
                .w((width - 32.0).min(620.0))
                .fill(p.panel)
                .border(1.0, p.line)
                .radius(p.space(2))
                .child(
                    col()
                        .w_full()
                        .max_h((height - 100.0).clamp(120.0, 460.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(
                    row()
                        .w_full()
                        .padding(p.space(3))
                        .gap(p.space(3))
                        .child(el().grow(1.0))
                        .child(
                            action_button("Close", p, |s, _| {
                                s.help = false;
                            })
                            .h(p.height(32.0)),
                        ),
                ),
        )
}

pub fn action_button(
    title: impl Into<String>,
    p: Theme,
    action: impl Fn(&mut State, &mut rune::Tx) + 'static,
) -> El {
    let title = title.into();
    button(p, action).label(&title).child(
        text(title)
            .font(p.font(12.0, 500.0))
            .color(p.text)
            .truncate()
            .shrink()
            .min_w(0.0),
    )
}

fn icon_button(
    glyph: &'static rune::Icon,
    label: &str,
    p: Theme,
    action: impl Fn(&mut State, &mut rune::Tx) + 'static,
) -> El {
    button(p, action)
        .label(label)
        .help(label)
        .w(p.height(32.0))
        .h(p.height(32.0))
        .px(0.0)
        .center()
        .radius(p.space(2))
        .fill(Color::TRANSPARENT)
        .border(0.0, Color::TRANSPARENT)
        .child(rune::icon(glyph, 18.0).color(p.text))
}

fn button(p: Theme, action: impl Fn(&mut State, &mut rune::Tx) + 'static) -> El {
    let action = std::rc::Rc::new(action);
    let enter = action.clone();
    row()
        .role("button")
        .motion(rune::Spring::new(0.12, 0.0))
        .focusable(true)
        .px(p.space(2))
        .h(p.height(28.0))
        .center_y()
        .radius(p.space(1))
        .fill(p.panel)
        .border(1.0, p.line.alpha(0.55))
        .hover(p.selected.alpha(0.6))
        .cursor(rune::Cursor::Pointer)
        .focus_ring(2.0, 0.0, p.accent)
        .on_key(move |s: &mut State, key, tx| {
            if key.key == rune::Key::Enter && key.mods == rune::Mods::default() {
                enter(s, tx);
                true
            } else {
                false
            }
        })
        .on_press_tx(move |s, tx| action(s, tx))
}

fn check_button(
    title: impl Into<String>,
    checked: bool,
    p: Theme,
    action: impl Fn(&mut State) + 'static,
) -> El {
    let title = title.into();
    row()
        .role("checkbox")
        .label(&title)
        .checked(checked)
        .focusable(true)
        .focus_ring(2.0, 0.0, p.accent)
        .w_full()
        .h(p.height(24.0))
        .gap(p.space(2))
        .center_y()
        .cursor(rune::Cursor::Pointer)
        .on_press(action)
        .child(
            el().w(16.0)
                .h(16.0)
                .radius(p.space(1))
                .fill(if checked { p.selected } else { p.background })
                .border(1.0, if checked { p.accent } else { p.line })
                .center()
                .child(
                    text(if checked { "✓" } else { "" })
                        .font(p.font(12.0, 600.0))
                        .color(p.text),
                ),
        )
        .child(
            text(title)
                .font(p.font(12.0, 400.0))
                .color(p.text)
                .grow(1.0)
                .min_w(0.0)
                .truncate(),
        )
}

fn place_row(s: &State, place: &crate::locations::Place, p: Theme) -> El {
    let open = place.clone();
    let menu = place.clone();
    let context = place.clone();
    let uri = place.uri.clone();
    let trigger_key = format!("place-trigger-{}", place.key());
    let trigger_anchor = trigger_key.clone();
    let active = place.path.as_deref() == Some(&s.tab().cwd);
    let glyph = icon::for_place(place);
    let mut leading = el().key("place-icon").w(20.0).h(20.0).center().child(
        rune::icon(glyph, 18.0)
            .label(glyph.name)
            .color(if active { p.accent } else { p.muted }),
    );
    if place.kind == crate::locations::PlaceKind::Favorite {
        let uri = place.uri.clone();
        leading = leading
            .key("reorder-favorite")
            .role("button")
            .label(format!("Reorder {}", place.name))
            .help("Drag this icon to reorder favorite")
            .cursor(rune::Cursor::Grab)
            .on_drag(move |s: &mut State, drag, tx| s.reorder_favorite(&uri, drag, tx));
    }
    let height = p.height(if place.kind == crate::locations::PlaceKind::Favorite {
        28.0
    } else {
        32.0
    });
    let item = row()
        .key(format!(
            "{}-{}",
            if place.kind == crate::locations::PlaceKind::Favorite {
                "favorite"
            } else {
                "sidebar"
            },
            place.key()
        ))
        .role("button")
        .label(&place.name)
        .w_full()
        .min_w(0.0)
        .h(height)
        .px(p.space(3))
        .gap(p.space(2))
        .center_y()
        .radius(p.space(2))
        .hover_group()
        .cursor(rune::Cursor::Pointer)
        .fill(if active {
            p.selected
        } else {
            Color::TRANSPARENT
        })
        .hover(p.selected.alpha(0.5))
        .focusable(true)
        .focus_ring(2.0, 0.0, p.accent)
        .help(&place.uri)
        .on_press_tx(move |s: &mut State, tx| {
            s.open_place(&open, crate::state::PlaceOpen::Current, tx)
        })
        .on_secondary_press(move |s: &mut State, point, tx| {
            s.edit_place(context.clone(), point.into(), tx)
        })
        .on_drag(move |s: &mut State, drag, _| {
            if !uri.is_empty() && !uri.starts_with("trash:") {
                s.drag_place(&uri, drag);
            }
        })
        .child(leading)
        .child(
            text(&place.name)
                .key("place-label")
                .font(p.font(12.0, 500.0))
                .color(p.text)
                .truncate()
                .min_w(0.0)
                .grow(1.0),
        );
    let mut actions = row().gap(p.space(1)).center_y();
    if place.kind == crate::locations::PlaceKind::Device && (place.eject || place.unmount) {
        let device = place.clone();
        actions = actions.child(
            icon_button(
                &icon::EJECT,
                &format!(
                    "{} {}",
                    if place.eject { "Eject" } else { "Unmount" },
                    place.name
                ),
                p,
                move |s, _| {
                    if !s.mounts.busy() {
                        s.mount_action(if device.eject {
                            crate::mounts::Action::Eject(device.clone())
                        } else {
                            crate::mounts::Action::Unmount(device.clone())
                        });
                    }
                },
            )
            .key(format!("eject-{}", place.key()))
            .w(24.0)
            .h(24.0)
            .disabled(s.mounts.busy())
            .opacity(if s.mounts.busy() { 0.4 } else { 1.0 }),
        );
    }
    let item = item.child(
        actions.child(
            icon_button(
                &icon::MORE,
                &format!("Actions for {}", place.name),
                p,
                move |s, tx| {
                    s.edit_place(
                        menu.clone(),
                        rune::PopupAnchor::Key(trigger_anchor.clone()),
                        tx,
                    )
                },
            )
            .key(trigger_key)
            .w(24.0)
            .h(24.0)
            .group_opacity(0.0, 1.0),
        ),
    );
    if let Some(path) = &place.path {
        folder_hover(
            item,
            path.clone(),
            s.active_pane,
            format!("peek-place-{}", place.key()),
            height,
        )
    } else {
        item
    }
}

fn place_overlay(s: &State, p: Theme, width: f32) -> El {
    let place = s.place_menu.as_ref().expect("favorite label dialog");
    let content = col()
        .w((width - 32.0).min(400.0))
        .padding(p.space(6))
        .gap(p.space(3))
        .fill(p.panel)
        .radius(p.space(2))
        .border(1.0, p.line)
        .child(
            text("Rename favorite")
                .font(p.font(18.0, 600.0))
                .color(p.text),
        )
        .child(
            text(&place.name)
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .w_full()
                .truncate(),
        )
        .child(
            input(&s.place_label, p.font(14.0, 400.0), p.height(36.0), p)
                .key("favorite-label")
                .label("Favorite label")
                .w_full()
                .color(p.text)
                .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
                .on_edit(|s: &mut State| &mut s.place_label)
                .on_submit(|s: &mut State, tx| {
                    s.save_place_label();
                    tx.blur();
                }),
        )
        .child(
            text("The folder name stays the same")
                .font(p.font(12.0, 400.0))
                .color(p.muted),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .child(el().grow(1.0))
                .child(
                    action_button("Cancel", p, |s, tx| {
                        s.place_menu = None;
                        s.place_label.focused = false;
                        tx.blur();
                    })
                    .key("close-place-menu"),
                )
                .child(
                    action_button("Save label", p, |s, tx| {
                        s.save_place_label();
                        tx.blur();
                    })
                    .key("save-favorite-label")
                    .disabled(s.place_label.text.trim().is_empty()),
                ),
        );
    el().key("place-menu")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| {
            s.place_menu = None;
            s.place_label.focused = false;
        })
        .child(content)
}

fn context_menu(s: &State, p: Theme, cx: &Cx<State>) -> El {
    let context = s.context.as_ref().expect("visible context menu");
    let size = cx.layout_size("app").unwrap_or([1160.0, 740.0]);
    let width = 274.0;
    let rows: usize = context.groups.iter().map(Vec::len).sum();
    let row_h = p.height(32.0);
    let pad = p.space(2);
    let edge = p.space(4);
    let height = (rows as f32 * row_h
        + context.groups.len().saturating_sub(1) as f32 * (p.space(1) * 2.0 + 1.0)
        + pad * 2.0
        + p.height(28.0))
    .min(size[1] - edge);
    let mut menu = col()
        .key("context-menu")
        .role("menu")
        .label("Actions")
        .focus_group()
        .w(width)
        .max_h(size[1] - edge)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .padding(pad)
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .shadow(5.0, 18.0, Color::BLACK.alpha(0.28))
        .modal(true, |s: &mut State| s.context = None)
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .child(
            text(context.title())
                .font(p.font(12.0, 500.0))
                .color(p.muted)
                .w_full()
                .truncate()
                .h(p.height(28.0))
                .px(p.space(2))
                .py(p.space(1)),
        );
    menu = match &context.anchor {
        rune::PopupAnchor::Point(x, y) => menu.absolute(
            (x / s.zoom_factor()).clamp(p.space(2), (size[0] - width - p.space(2)).max(p.space(2))),
            (y / s.zoom_factor())
                .clamp(p.space(2), (size[1] - height - p.space(2)).max(p.space(2))),
        ),
        rune::PopupAnchor::Key(key) => menu
            .anchored_fit(key, rune::Side::Bottom, rune::Align::Start, p.space(1))
            .focus_return(key),
    };
    for (index, group) in context.groups.iter().enumerate() {
        if index > 0 {
            menu = menu.child(el().w_full().h(1.0).fill(p.line).my(p.space(1)));
        }
        for item in group {
            let key = item.key;
            menu = menu.child(
                row()
                    .key(format!("context-{key}"))
                    .role("menuitem")
                    .label(item.label)
                    .w_full()
                    .h(p.height(32.0))
                    .px(p.space(2))
                    .gap(p.space(4))
                    .center_y()
                    .radius(p.space(1))
                    .focusable(true)
                    .disabled(!item.enabled)
                    .opacity(if item.enabled { 1.0 } else { 0.4 })
                    .focus_highlight(p.selected)
                    .hover(p.selected)
                    .on_press_tx(move |s: &mut State, tx| s.context_action(key, tx))
                    .child(
                        text(item.label)
                            .font(p.font(13.0, 400.0))
                            .color(p.text)
                            .grow(1.0),
                    )
                    .child(text(item.shortcut).font(p.font(11.0, 400.0)).color(p.muted)),
            );
        }
    }
    menu
}

fn name_dialog(s: &State, p: Theme, width: f32, height: f32) -> El {
    use crate::state::Prompt;
    let prompt = s.prompt.expect("name dialog");
    let action = match prompt {
        Prompt::Rename => "Rename",
        Prompt::Archive => "Compress",
        Prompt::Connect => "Connect",
        _ => "Create",
    };
    let title = if prompt == Prompt::Connect {
        "Connect to server"
    } else if prompt == Prompt::Rename && s.rename_preview().len() > 1 {
        "Rename items"
    } else {
        prompt.title()
    };
    let mut content = col()
        .w((width - 32.0).min(460.0))
        .padding(p.space(6))
        .gap(p.space(3))
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .child(text(title).font(p.font(19.0, 600.0)).color(p.text))
        .child(
            text(if prompt == Prompt::Connect {
                "Server location (sftp://, smb://, ftp://, dav://)".to_string()
            } else {
                format!("In {}", s.display_location(&s.tab().cwd))
            })
            .font(p.font(12.0, 400.0))
            .color(p.muted)
            .w_full()
            .truncate(),
        )
        .child(
            input(&s.pane().input, p.font(14.0, 400.0), p.height(40.0), p)
                .key("prompt")
                .label(if prompt == Prompt::Connect {
                    "Server address"
                } else {
                    "Name"
                })
                .w_full()
                .px(p.space(2))
                .fill(p.background)
                .border(1.0, p.line)
                .radius(p.space(1))
                .color(p.text)
                .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
                .on_edit(|s: &mut State| &mut s.pane_mut().input)
                .on_submit(|s: &mut State, tx| s.submit_prompt(tx)),
        );
    if prompt == Prompt::Rename {
        let preview = s.rename_preview();
        let mut listing = col()
            .w_full()
            .max_h((height - 240.0).max(48.0))
            .scroll(ScrollSpec {
                stick_bottom: false,
            })
            .gap(p.space(1));
        if preview.len() > 1 {
            listing = listing.child(
                text("Use {name} for the original name or {n} for a sequence.")
                    .font(p.font(12.0, 400.0))
                    .color(p.muted)
                    .w_full(),
            );
        }
        for (before, after) in preview {
            listing = listing.child(
                text(format!("{before}  →  {after}"))
                    .font(p.font(12.0, 400.0))
                    .color(p.muted)
                    .w_full()
                    .truncate(),
            );
        }
        content = content.child(listing);
    }
    content = content.child(
        text(s.name_error().unwrap_or(""))
            .font(p.font(12.0, 400.0))
            .color(p.muted)
            .w_full()
            .h(p.height(20.0))
            .truncate(),
    );
    content = content.child(
        row()
            .w_full()
            .gap(p.space(2))
            .child(el().grow(1.0))
            .child(action_button("Cancel", p, |s, tx| s.command("escape", tx)).key("cancel-name"))
            .child(
                action_button(action, p, |s, tx| s.submit_prompt(tx))
                    .key("submit-name")
                    .default_button()
                    .fill(p.selected)
                    .opacity(if s.name_error().is_some() { 0.45 } else { 1.0 })
                    .disabled(s.name_error().is_some()),
            ),
    );
    el().key("name-dialog")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| {
            s.prompt = None;
            s.pane_mut().input.focused = false;
        })
        .child(content)
}

fn session_error_overlay(error: &str, p: Theme, width: f32) -> El {
    let content = col()
        .w((width - 32.0).clamp(240.0, 420.0))
        .padding(p.space(6))
        .gap(p.space(3))
        .fill(p.panel)
        .radius(p.space(2))
        .border(1.0, p.line)
        .child(
            text("Session could not be saved")
                .font(p.font(18.0, 600.0))
                .color(p.text),
        )
        .child(label("Your folders and tabs are still open.", p).w_full())
        .child(label(error, p).w_full().truncate())
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .child(action_button("Retry", p, |s, tx| s.close(tx)).key("session-save-retry"))
                .child(
                    action_button("Keep browsing", p, |s, tx| {
                        s.session_error = None;
                        tx.blur();
                    })
                    .key("session-keep-browsing"),
                )
                .child(el().grow(1.0)),
        )
        .child(
            action_button("Close without saving session", p, |s, tx| {
                s.command("quit --no-session", tx)
            })
            .key("session-close-without-saving"),
        );
    el().key("session-save-error")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| s.session_error = None)
        .child(content)
}

fn view_icon(mode: ViewMode) -> &'static rune::Icon {
    match mode {
        ViewMode::List => &icon::LIST,
        ViewMode::Details => &icon::DETAILS,
        ViewMode::Grid => &icon::GRID,
    }
}

fn folder_view_overlay(s: &State, p: Theme, width: f32, height: f32) -> El {
    let preference = s.tab().preference;
    let uri = s.location_uri(&s.tab().cwd);
    let choosing_view = s.view_options == Some(FolderMenu::View);
    let columns =
        !choosing_view && preference.view_mode == ViewMode::Details && s.selector.is_none();
    let anchor = if s.pane().picker.is_some() {
        Pane::finder_key(s.active_pane).to_owned()
    } else if choosing_view {
        format!("view-mode-{}", s.active_pane)
    } else {
        format!("folder-view-{}", s.active_pane)
    };
    let inset = p.space(2);
    let gap = p.space(1);
    let row = p.height(40.0);
    let mut blocks = vec![(p.font(13.0, 400.0).line_px() + inset * 2.0, 0.0)];
    if choosing_view {
        blocks.extend([(row, 0.0); 3]);
    } else {
        blocks.extend([(row, 0.0); 6]);
        blocks.push((1.0, gap));
        blocks.extend([(row, 0.0); 2]);
    }
    if columns {
        blocks.push((1.0, gap));
        blocks.push((p.font(13.0, 400.0).line_px() + inset * 2.0, 0.0));
        blocks.extend([(row, 0.0); 5]);
    }
    if !choosing_view && s.views.error.is_some() {
        blocks.push((p.font(12.0, 400.0).line_px() + inset * 2.0, 0.0));
    }
    if !choosing_view && s.views.customized(&uri) {
        blocks.push((1.0, gap));
        blocks.push((p.height(36.0), 0.0));
    }
    // 8 is the window margin `anchored_fit` keeps. Stay inside that room and on a
    // row edge so the fit pass does not shorten the menu through a row.
    let zoom = s.zoom_factor();
    let room = rune::memo::window_layout_with(&anchor, move |rect| {
        let edge = 8.0 / zoom;
        let before = rect[1] - gap - edge;
        let after = height - edge - (rect[1] + rect[3] + gap);
        before.max(after)
    })
    .unwrap_or(height - 16.0 / zoom);
    let limit = (room - 0.5).floor().max(inset);
    let mut y = inset;
    let mut menu_h = inset;
    for (i, &(block, margin)) in blocks.iter().enumerate() {
        let bottom = y + margin + block + margin;
        let end = bottom + if i + 1 == blocks.len() { inset } else { gap };
        if end > limit {
            if bottom <= limit {
                menu_h = bottom;
            }
            break;
        }
        menu_h = end;
        y = bottom + gap;
    }
    let title = if choosing_view { "View" } else { "Sort by" };
    let mut menu = col()
        .key("folder-view-options")
        .role("menu")
        .label(title)
        .focus_group()
        .w((width - 24.0).clamp(200.0, 260.0))
        .max_h(menu_h)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .padding(inset)
        .gap(gap)
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .shadow(5.0, 18.0, Color::BLACK.alpha(0.25))
        .anchored_fit(&anchor, rune::Side::Bottom, rune::Align::End, gap)
        .focus_return(&anchor)
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(true, |s: &mut State| s.view_options = None)
        .child(label(title, p).w_full().px(p.space(3)).py(inset));
    if choosing_view {
        return menu.children(ViewMode::ALL.into_iter().map(|mode| {
            button(p, move |s, tx| {
                s.command(&format!("view {}", mode.key()), tx)
            })
            .key(format!("view-{}", mode.key()))
            .role("menuitemradio")
            .label(mode.name())
            .checked(preference.view_mode == mode)
            .w_full()
            .h(row)
            .gap(p.space(2))
            .border(0.0, Color::TRANSPARENT)
            .fill(Color::TRANSPARENT)
            .child(rune::icon(view_icon(mode), 18.0).color(p.text))
            .child(text(mode.name()).font(p.font(12.0, 500.0)).color(p.text))
            .child(el().grow(1.0))
            .child(if preference.view_mode == mode {
                rune::icon(&icon::CHECK, 16.0).color(p.accent)
            } else {
                el().w(16.0)
            })
        }));
    }
    for (name, by, value) in [
        ("Name", SortBy::Alphabetical, "alphabetical"),
        ("Natural name", SortBy::Natural, "natural"),
        ("Size", SortBy::Size, "size"),
        ("Modified", SortBy::Modified, "mtime"),
        ("Type", SortBy::Extension, "extension"),
        ("Owner", SortBy::Owner, "owner"),
    ] {
        menu = menu.child(
            action_button(name, p, move |s, tx| {
                if s.tab().preference.sort_by != by {
                    s.command(
                        &format!(
                            "sort {value} --reverse={}",
                            if matches!(by, SortBy::Modified | SortBy::Size) {
                                "yes"
                            } else {
                                "no"
                            }
                        ),
                        tx,
                    );
                }
                s.view_options = None;
                tx.blur();
            })
            .key(format!("view-sort-{value}"))
            .role("menuitemradio")
            .checked(preference.sort_by == by)
            .w_full()
            .h(row)
            .border(0.0, Color::TRANSPARENT)
            .fill(Color::TRANSPARENT)
            .child(el().grow(1.0))
            .child(if preference.sort_by == by {
                rune::icon(&icon::CHECK, 16.0).color(p.accent)
            } else {
                el().w(16.0)
            }),
        );
    }
    menu = menu.child(el().w_full().h(1.0).fill(p.line).my(gap));
    for (name, selected, command, key) in [
        (
            "Folders first",
            preference.sort_dir_first,
            "sort_dir_first",
            "view-folders-first",
        ),
        (
            "Show hidden files",
            preference.show_hidden,
            "hidden",
            "view-hidden",
        ),
    ] {
        menu = menu.child(
            action_button(name, p, move |s, tx| s.command(command, tx))
                .key(key)
                .role("menuitemcheckbox")
                .checked(selected)
                .w_full()
                .h(row)
                .border(0.0, Color::TRANSPARENT)
                .fill(Color::TRANSPARENT)
                .child(el().grow(1.0))
                .child(if selected {
                    rune::icon(&icon::CHECK, 16.0).color(p.accent)
                } else {
                    el().w(16.0)
                }),
        );
    }
    if columns {
        menu = menu
            .child(el().w_full().h(1.0).fill(p.line).my(gap))
            .child(label("Columns", p).w_full().px(p.space(3)).py(inset));
    }
    for column in preference.details.order.into_iter().filter(|_| columns) {
        let selected = column == DetailColumn::Name || preference.details.visible[column.index()];
        let name = column.label();
        let toggle = action_button(name, p, move |s, _| {
            if column == DetailColumn::Name {
                return;
            }
            let mut details = s.tab().preference.details;
            details.visible[column.index()] = !details.visible[column.index()];
            s.set_details(s.active_pane, details);
        })
        .key(format!("details-column-{}", name.to_lowercase()))
        .role("menuitemcheckbox")
        .checked(selected)
        .grow(1.0)
        .h(row)
        .border(0.0, Color::TRANSPARENT)
        .fill(Color::TRANSPARENT)
        .child(if selected {
            rune::icon(&icon::CHECK, 16.0).color(p.accent)
        } else {
            el().w(16.0)
        });
        let mut option = rune::row().w_full().h(row).center_y().child(toggle);
        if column != DetailColumn::Name {
            for (direction, title) in [(-1, "Move left"), (1, "Move right")] {
                option = option.child(
                    action_button(if direction < 0 { "←" } else { "→" }, p, move |s, _| {
                        let mut details = s.tab().preference.details;
                        details.move_by(column, direction);
                        s.set_details(s.active_pane, details);
                    })
                    .key(format!("details-move-{}-{direction}", name.to_lowercase()))
                    .label(format!("{title} {name} column"))
                    .w(p.height(32.0))
                    .h(p.height(32.0))
                    .center()
                    .border(0.0, Color::TRANSPARENT)
                    .fill(Color::TRANSPARENT),
                );
            }
        }
        menu = menu.child(option);
    }
    if let Some(error) = &s.views.error {
        menu = menu.child(
            text(error)
                .font(p.font(12.0, 400.0))
                .color(p.error)
                .w_full()
                .wrap()
                .padding(inset),
        );
    }
    if s.views.customized(&uri) {
        menu = menu.child(el().w_full().h(1.0).fill(p.line).my(gap)).child(
            action_button("Reset to defaults", p, |s, tx| {
                s.command("view_reset", tx);
                s.view_options = None;
                tx.blur();
            })
            .key("view-reset")
            .role("menuitem")
            .w_full()
            .h(p.height(36.0))
            .border(0.0, Color::TRANSPARENT)
            .fill(Color::TRANSPARENT),
        );
    }
    menu
}

fn sidebar_heading(title: &str, p: Theme) -> El {
    row()
        .key(format!("sidebar-heading-{title}"))
        .w_full()
        .h(p.height(32.0))
        .px(p.space(3))
        .center_y()
        .child(
            text(title)
                .font(p.font(11.0, 600.0))
                .color(p.muted)
                .grow(1.0)
                .min_w(0.0)
                .truncate(),
        )
}

fn places(s: &State, p: Theme) -> El {
    let places_scrolled = s.peek_scrolled.clone();
    use crate::locations::PlaceKind;
    let hide_trash = s.selector.is_some();
    let favorites: Vec<_> = s
        .favorites()
        .filter(|place| !hide_trash || !place.uri.starts_with("trash:"))
        .collect();
    let mut favorite_group = col()
        .key("favorites")
        .role("group")
        .label("Favorites")
        .w_full()
        .min_w(0.0)
        .gap(0.0)
        .child(
            sidebar_heading("Favorites", p).child(if s.favorites_saving() {
                label("Saving…", p).font(p.font(11.0, 400.0))
            } else {
                el()
            }),
        );
    if favorites.is_empty() {
        favorite_group = favorite_group.child(
            label("Drop folders here", p)
                .w_full()
                .h(p.height(32.0))
                .px(p.space(3)),
        );
    }
    for (index, favorite) in favorites.iter().enumerate() {
        favorite_group = favorite_group
            .child(
                el().h(p.space(1))
                    .w_full()
                    .fill(if s.favorite_hover == Some(index) {
                        p.accent
                    } else {
                        Color::TRANSPARENT
                    }),
            )
            .child(place_row(s, favorite, p));
    }
    favorite_group = favorite_group.child(el().h(4.0).w_full().fill(
        if s.favorite_hover == Some(favorites.len()) {
            p.accent
        } else {
            Color::TRANSPARENT
        },
    ));
    let mut places = col()
        .key("places-list")
        .grow(1.0)
        .min_h(0.0)
        .w_full()
        .gap(p.space(2))
        .padding(p.space(2))
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .on_scroll_offset(move |_| {
            if rune::scroll_watch_state().0 {
                places_scrolled.set(true);
            }
        })
        .scroll_edge_fade(10.0)
        .child(favorite_group);
    for (kind, name) in [
        (PlaceKind::Location, "Locations"),
        (PlaceKind::Device, "Devices"),
    ] {
        let mut group = col()
            .w_full()
            .min_w(0.0)
            .gap(p.space(1))
            .key(format!("sidebar-section-{name}"))
            .role("group")
            .label(name)
            .child(sidebar_heading(name, p));
        for place in s
            .places
            .iter()
            .filter(|place| place.kind == kind && (!hide_trash || !place.uri.starts_with("trash:")))
        {
            group = group.child(place_row(s, place, p));
        }
        if kind == PlaceKind::Device {
            group = group.child(
                button(p, |s, tx| s.command("connect", tx))
                    .key("connect-server")
                    .label("Connect to server")
                    .w_full()
                    .h(p.height(32.0))
                    .px(p.space(3))
                    .gap(p.space(2))
                    .fill(Color::TRANSPARENT)
                    .border(0.0, Color::TRANSPARENT)
                    .child(rune::icon(&icon::NETWORK, 18.0).w(20.0).color(p.muted))
                    .child(
                        text("Connect to server")
                            .key("place-label")
                            .font(p.font(12.0, 500.0))
                            .color(p.text)
                            .min_w(0.0)
                            .grow(1.0)
                            .truncate(),
                    ),
            );
        }
        places = places
            .child(el().w_full().h(1.0).fill(p.line.alpha(0.65)).my(p.space(2)))
            .child(group);
    }
    places
}

fn sidebar(s: &State, p: Theme) -> El {
    let side = s.active_pane;
    let parent_scrolled = s.peek_scrolled.clone();
    let places = places(s, p);
    let parent = col()
        .key("parent-panel")
        .grow(0.5)
        .max_h(p.row() * 4.0 + p.height(32.0))
        .min_w(0.0)
        .min_h(p.height(32.0) + p.row())
        .child(sidebar_heading("Containing folder", p).px(p.space(5)))
        .child(
            col()
                .key("parent")
                .grow(1.0)
                .min_h(p.row())
                .w_full()
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .on_scroll_offset(move |_| {
                    if rune::scroll_watch_state().0 {
                        parent_scrolled.set(true);
                    }
                })
                .child(
                    col()
                        .key("rows")
                        .w_full()
                        .growth(GrowthSpec::default())
                        .virtual_rows(
                            s.pane().parent.len(),
                            p.row(),
                            |s: &State, i| s.pane().parent[i].key.as_str().into(),
                            move |s: &State, i| {
                                let file = &s.pane().parent[i];
                                let path = file.path.clone();
                                let directory = file.directory;
                                let row = draggable_file(
                                    file_row(
                                        file,
                                        file.path == s.tab().cwd,
                                        false,
                                        false,
                                        p,
                                        side,
                                        s.thumbnail(file),
                                    ),
                                    file,
                                    side,
                                )
                                .on_press_tx(
                                    move |s: &mut State, tx| {
                                        if directory {
                                            s.cd(s.active_pane, path.clone(), tx, true);
                                        }
                                        tx.blur();
                                    },
                                );
                                if file.directory {
                                    folder_hover(
                                        row,
                                        file.path.clone(),
                                        side,
                                        format!("peek-parent-{side}-{}", file.key),
                                        p.row(),
                                    )
                                } else {
                                    row
                                }
                            },
                        )
                        .virtual_rows_version(s.pane().revision),
                ),
        );
    col()
        .key("navigation")
        .role("navigation")
        .label("Places and folders")
        .h_full()
        .min_h(0.0)
        .fill(p.panel)
        .child(places)
        .child(el().h(1.0).w_full().fill(p.line))
        .child(parent)
}

fn finder_controls(s: &State, p: Theme) -> El {
    let picker = s.pane().picker.as_ref().unwrap();
    let input = row()
        .w_full()
        .gap(p.space(2))
        .center_y()
        .child(
            input(&s.pane().input, p.font(13.0, 400.0), p.height(36.0), p)
                .key("finder-input")
                .label(if picker.content {
                    "Text inside files"
                } else {
                    "File name or path"
                })
                .placeholder(
                    if picker.content {
                        "Search file contents"
                    } else {
                        "Search file names"
                    },
                    p.muted,
                )
                .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
                .grow(1.0)
                .min_w(0.0)
                .px(p.space(2))
                .fill(p.background)
                .border(1.0, p.line)
                .radius(p.space(1))
                .focus_ring(2.0, 0.0, p.accent)
                .color(p.text)
                .on_edit(|s: &mut State| &mut s.pane_mut().input)
                .on_submit(|s: &mut State, tx| s.picker_accept(true, tx)),
        )
        .child(
            action_button("Names", p, |s, _| s.picker_mode(false))
                .key("finder-names")
                .checked(!picker.content)
                .fill(if picker.content { p.panel } else { p.selected }),
        )
        .child(
            action_button("Contents", p, |s, _| s.picker_mode(true))
                .key("finder-contents")
                .checked(picker.content)
                .fill(if picker.content { p.selected } else { p.panel })
                .help("Search inside local text files"),
        )
        .child(action_button("Close search", p, |s, tx| {
            s.close_picker(s.active_pane, tx)
        }));
    let mut filters = row().w_full().gap(p.space(2)).center_y();
    for kind in FilterKind::ALL {
        let selected = picker.filters.selected(kind);
        let title = if selected == 0 {
            kind.title().to_owned()
        } else {
            kind.options()[selected].to_owned()
        };
        filters = filters.child(
            action_button(format!("{title} ▾"), p, move |s, _| s.picker_menu(kind))
                .key(format!("finder-filter-{}", kind.key()))
                .role("button")
                .expanded(picker.menu == Some(kind))
                .checked(selected != 0)
                .fill(if selected == 0 { p.panel } else { p.selected })
                .max_w(p.height(150.0))
                .min_w(0.0)
                .help(format!("Filter by {}", kind.title())),
        );
    }
    filters = filters.child(
        action_button("Clear filters", p, |s, _| s.picker_clear_filters())
            .key("finder-clear-filters")
            .disabled(picker.filters == SearchFilters::default()),
    );
    let mut scope = row()
        .w_full()
        .gap(p.space(2))
        .center_y()
        .child(
            label(format!("In {}", s.display_location(&picker.root)), p)
                .grow(1.0)
                .min_w(0.0)
                .max_w(p.height(300.0))
                .help(format!("Search in {}", s.display_location(&picker.root))),
        )
        .child(
            action_button("Include subfolders", p, |s, _| {
                let recursive = s.pane().picker.as_ref().unwrap().recursive;
                s.picker_scope(!recursive);
            })
            .key("finder-recursive")
            .role("checkbox")
            .checked(picker.recursive)
            .fill(if picker.recursive {
                p.selected
            } else {
                p.panel
            }),
        )
        .child(
            action_button(
                if picker.all_files {
                    "Hidden: on"
                } else {
                    "Hidden: off"
                },
                p,
                |s, _| s.picker_all(),
            )
            .key("finder-hidden")
            .help("Include hidden and ignored files · Ctrl+I"),
        );
    if picker.content {
        scope = scope.child(
            action_button(
                if picker.regex {
                    "Regex: on"
                } else {
                    "Regex: off"
                },
                p,
                |s, _| s.picker_regex(),
            )
            .key("finder-regex")
            .checked(picker.regex)
            .help("Use a regular expression instead of literal text"),
        );
    }
    let mut content = col()
        .key("finder-controls")
        .w_full()
        .px(p.space(3))
        .py(p.space(2))
        .gap(p.space(1))
        .fill(p.panel)
        .child(input)
        .child(filters)
        .child(scope);
    if let Some(error) = &picker.error {
        content = content.child(
            text(error)
                .font(p.font(13.0, 400.0))
                .color(p.folder)
                .w_full(),
        );
    }
    content
}

fn finder_menu(s: &State, p: Theme, kind: FilterKind, height: f32) -> El {
    let picker = s.pane().picker.as_ref().unwrap();
    let anchor = format!("finder-filter-{}", kind.key());
    let inset = p.space(1);
    let gap = p.space(1);
    let row_height = p.height(32.0);
    let zoom = s.zoom_factor();
    let room = rune::memo::window_layout_with(&anchor, move |rect| {
        let edge = 8.0 / zoom;
        let before = rect[1] - gap - edge;
        let after = height - edge - (rect[1] + rect[3] + gap);
        before.max(after)
    })
    .unwrap_or(height - 16.0 / zoom);
    let rows = ((room - 2.0 * inset - 2.5) / row_height).floor().max(1.0) as usize;
    let menu_height = 2.0 * inset + row_height * kind.options().len().min(rows) as f32;
    let mut menu = col()
        .key("finder-filter-menu")
        .role("menu")
        .label(format!("{} filter", kind.title()))
        .focus_group()
        .w(p.height(210.0))
        .max_h(menu_height)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .padding(inset)
        .gap(0.0)
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .anchored_fit(&anchor, rune::Side::Bottom, rune::Align::Start, gap)
        .focus_return(&anchor);
    for (option, title) in kind.options().iter().enumerate() {
        let selected = picker.filters.selected(kind) == option;
        menu = menu.child(
            action_button(*title, p, move |s, _| s.picker_filter(kind, option))
                .key(format!("finder-filter-{}-{option}", kind.key()))
                .role("menuitemradio")
                .checked(selected)
                .disabled(picker.content && kind == FilterKind::Type && option == 5)
                .help(
                    if picker.content && kind == FilterKind::Type && option == 5 {
                        "Switch to Names to find folders"
                    } else {
                        *title
                    },
                )
                .w_full()
                .h(row_height)
                .border(0.0, Color::TRANSPARENT)
                .fill(if selected {
                    p.selected
                } else {
                    Color::TRANSPARENT
                })
                .child(el().grow(1.0))
                .child(if selected {
                    rune::icon(&icon::CHECK, 16.0).color(p.accent)
                } else {
                    el().w(16.0)
                }),
        );
    }
    el().absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .modal(false, |s: &mut State| {
            if let Some(picker) = &mut s.pane_mut().picker {
                picker.menu = None;
            }
        })
        .child(menu)
}

fn finder_results(s: &State, side: usize, p: Theme) -> El {
    let picker = s.panes[side].picker.as_ref().unwrap();
    let scroll = picker.scroll.clone();
    let row_height = if picker.content {
        p.row() + p.height(24.0)
    } else {
        p.row()
    };
    let results = col()
        .key(Pane::finder_key(side))
        .instant_changes()
        .role("list")
        .label("Matching files")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .on_scroll_offset(move |pos| {
            scroll.set(pos.offset[1]);
        })
        .scroll_margin(p.row() * 2.0)
        .child(if picker.files.is_empty() {
            text(if picker.content && picker.query.is_empty() {
                "Type text to search inside files"
            } else if picker.loading || picker.scanning {
                "Searching…"
            } else {
                "No matching files"
            })
            .font(p.font(13.0, 400.0))
            .color(p.muted)
            .padding(p.space(4))
        } else {
            col()
                .key("rows")
                .w_full()
                .growth(GrowthSpec::default())
                .virtual_rows(
                    picker.files.len(),
                    row_height,
                    move |s: &State, i| {
                        s.panes[side].picker.as_ref().unwrap().files[i]
                            .key
                            .as_str()
                            .into()
                    },
                    move |s: &State, i| {
                        let picker = s.panes[side].picker.as_ref().unwrap();
                        let file = &picker.files[i];
                        let name = file_row(
                            file,
                            i == picker.cursor,
                            picker.selected.contains(&file.path),
                            s.selector.as_ref().is_none_or(|selector| {
                                selector.request.multiple()
                                    && file.directory == selector.request.folders()
                            }),
                            p,
                            side,
                            s.thumbnail(file),
                        );
                        let row = if picker.content {
                            let snippet = picker
                                .hits
                                .get(&file.path)
                                .map(|hit| format!("{}: {}", hit.line, hit.text.trim()))
                                .unwrap_or_default();
                            col()
                                .key(file.key.clone())
                                .hover_group()
                                .role("listitem")
                                .label(&file.name)
                                .w_full()
                                .h(row_height)
                                .child(name.key("name").role("group"))
                                .child(
                                    text(snippet)
                                        .key("match-line")
                                        .font(p.font(11.0, 400.0).features("'tnum' 1"))
                                        .color(p.muted)
                                        .pl(p.space(12))
                                        .pr(p.space(9))
                                        .h(p.height(20.0))
                                        .w_full()
                                        .truncate(),
                                )
                        } else {
                            name.hover_group()
                        };
                        let context_path = file.path.clone();
                        let row = if s.selector.is_some() {
                            row
                        } else {
                            draggable_file(row, file, side)
                        };
                        row.on_secondary_press(move |s: &mut State, point, tx| {
                            s.show_context(side, Some(&context_path), point.into(), tx)
                        })
                        .disabled(picker.loading)
                        .on_press_tx(move |s: &mut State, tx| s.picker_hover(side, i, tx))
                        .on_double_press_tx(move |s: &mut State, tx| {
                            s.activate_pane(side, tx);
                            s.picker_hover(side, i, tx);
                            s.picker_accept(true, tx);
                        })
                    },
                )
                .virtual_rows_version(s.panes[side].revision)
        });
    let mut list = col()
        .key("current-panel")
        .motion(rune::Spring::new(0.22, 0.0))
        .transition(rune::Transition::none())
        .min_w(0.0)
        .min_h(0.0)
        .child(panel_header(
            &format!(
                "{} {} · {} indexed{}",
                picker.files.len(),
                if picker.files.len() == 1 {
                    "result"
                } else {
                    "results"
                },
                picker.indexed,
                if picker.scanning {
                    " · indexing…"
                } else {
                    ""
                }
            ),
            p,
        ))
        .child(results);
    if picker.content && s.selector.is_none() {
        list = list.child(
            label("First match per file · text files up to 32 MiB", p)
                .font(p.font(11.0, 400.0))
                .px(p.space(2))
                .py(p.space(1)),
        );
    }
    if s.selector.is_some() {
        return list;
    }
    list.child(
        label(
            "↑ ↓ Preview · Ctrl+Space Select · Enter Open · Shift+Enter Reveal",
            p,
        )
        .font(p.font(11.0, 400.0))
        .px(p.space(2))
        .py(p.space(2)),
    )
}

fn transfer_path(s: &State, path: &std::path::Path) -> String {
    let display = s.display_location(path);
    if let Ok(mut uri) = url::Url::parse(&display)
        && uri.has_host()
    {
        let _ = uri.set_password(None);
        let _ = uri.set_username("");
        uri.into()
    } else {
        display
    }
}

fn transfer_location(title: &str, value: String, key: String, p: Theme) -> El {
    row()
        .key(key)
        .w_full()
        .min_w(0.0)
        .gap(p.space(2))
        .center_y()
        .child(label(title, p).font(p.font(12.0, 400.0)).w(p.height(40.0)))
        .child(
            text(&value)
                .font(p.font(12.0, 400.0))
                .color(p.muted)
                .grow(1.0)
                .min_w(0.0)
                .truncate()
                .help(value),
        )
}

fn conflict_item(
    s: &State,
    incoming: bool,
    path: &std::path::Path,
    metadata: Option<&crate::metadata::Metadata>,
    p: Theme,
) -> El {
    let (title, key) = if incoming {
        ("Incoming item", "conflict-source")
    } else {
        ("Already in destination", "conflict-destination")
    };
    static FILE: rune::Icon = rune::Icon {
        name: "conflict-file",
        view: 16.0,
        body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4" stroke="currentColor" stroke-linejoin="round"/>"#,
    };
    let (glyph, kind) = if metadata.is_some_and(|m| m.is_symlink()) {
        (&icon::LINK, "Symbolic link")
    } else if metadata.is_some_and(|m| m.is_dir()) {
        (&icon::FOLDER, "Folder")
    } else {
        (&FILE, "File")
    };
    let facts = metadata.map_or_else(
        || "Metadata unavailable".into(),
        |metadata| {
            let size = if metadata.is_dir() {
                "Folder".into()
            } else {
                format!("{kind} · {}", file::human_size(metadata.len()))
            };
            let modified = gio::glib::DateTime::from_unix_local(metadata.modified().unix_seconds())
                .ok()
                .and_then(|date| date.format("%d %b %Y, %H:%M").ok())
                .map(|date| date.to_string())
                .unwrap_or_else(|| "Unknown".into());
            format!("{size}\nModified {modified}")
        },
    );
    col()
        .key(key)
        .w_full()
        .min_w(0.0)
        .padding(p.space(4))
        .gap(p.space(2))
        .fill(p.background)
        .border(1.0, p.line)
        .radius(p.space(2))
        .child(label(title, p).font(p.font(12.0, 600.0)))
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(el().size(48.0, 48.0).center().child(
                    if let Some(image) = s.conflict_thumbnail(incoming) {
                        el().size(48.0, 48.0)
                            .pixels_fit(image.pixels(), SurfaceFit::Fit)
                    } else {
                        rune::icon(glyph, 32.0).color(p.folder)
                    },
                ))
                .child(
                    text(
                        path.file_name()
                            .unwrap_or(path.as_os_str())
                            .to_string_lossy(),
                    )
                    .font(p.font(14.0, 600.0))
                    .color(p.text)
                    .grow(1.0)
                    .min_w(0.0)
                    .wrap_anywhere(),
                ),
        )
        .child(
            text(transfer_path(s, path))
                .key(format!("{key}-path"))
                .font(p.font(11.0, 400.0))
                .color(p.muted)
                .w_full()
                .wrap_anywhere(),
        )
        .child(
            text(facts)
                .key(format!("{key}-metadata"))
                .font(p.font(12.0, 400.0))
                .color(p.text)
                .w_full()
                .wrap(),
        )
}

fn transfer_card(s: &State, task: &crate::operations::Task, p: Theme) -> El {
    let id = task.id;
    let active = matches!(
        task.status,
        Status::Queued | Status::Running | Status::Waiting
    );
    let status = match task.status {
        Status::Queued => "Queued",
        Status::Running => "In progress",
        Status::Waiting => "Needs a decision",
        Status::Completed => "Completed",
        Status::Failed => "Needs attention",
        Status::Cancelled => "Cancelled",
    };
    let mut card = col()
        .key(format!("transfer-{id}"))
        .w_full()
        .min_w(0.0)
        .padding(p.space(4))
        .gap(p.space(2))
        .fill(p.background)
        .border(1.0, p.line)
        .radius(p.space(2))
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(
                    text(&task.title)
                        .font(p.font(14.0, 600.0))
                        .color(p.text)
                        .grow(1.0)
                        .min_w(0.0)
                        .wrap(),
                )
                .child(
                    text(status)
                        .key(format!("transfer-status-{id}"))
                        .font(p.font(12.0, 500.0))
                        .color(if task.status == Status::Failed {
                            p.folder
                        } else {
                            p.muted
                        }),
                ),
        );
    if let Some(source) = task.sources.first() {
        let source = if task.sources.len() == 1 {
            transfer_path(s, source)
        } else {
            format!(
                "{} (+{} more)",
                transfer_path(s, source),
                task.sources.len() - 1
            )
        };
        card = card.child(transfer_location(
            "From",
            source,
            format!("transfer-source-{id}"),
            p,
        ));
    }
    if let Some(destination) = &task.destination {
        card = card.child(transfer_location(
            "To",
            transfer_path(s, destination),
            format!("transfer-destination-{id}"),
            p,
        ));
    }
    let mut progress = match task.total_bytes {
        Some(total) => format!(
            "{} of {}",
            file::human_size(task.bytes),
            file::human_size(total)
        ),
        None => file::human_size(task.bytes),
    };
    let entries = match task.total_entries {
        Some(total) => format!("{} of {total} items", task.entries),
        None => format!("{} items processed", task.entries),
    };
    progress.push_str(&format!(" · {entries}"));
    if task.status == Status::Running {
        if let Some(rate) = task.rate_bps.filter(|rate| rate.is_finite() && *rate > 0.0) {
            progress.push_str(&format!(" · {}/s", file::human_size(rate as u64)));
        }
        if let Some(seconds) = task.eta_seconds {
            let remaining = if seconds < 60 {
                "less than a minute".into()
            } else if seconds < 3600 {
                format!("{} min", seconds.div_ceil(60))
            } else {
                format!("{} hr {} min", seconds / 3600, seconds % 3600 / 60)
            };
            progress.push_str(&format!(" · About {remaining} remaining"));
        }
    }
    if let Some(total) = task.total_bytes.filter(|total| *total > 0) {
        let fraction = (task.bytes as f64 / total as f64).clamp(0.0, 1.0) as f32;
        card = card.child(
            row()
                .key(format!("transfer-progress-{id}"))
                .role("progressbar")
                .label(format!("{:.0}% transferred", fraction * 100.0))
                .w_full()
                .h(p.space(1))
                .radius(p.space(1))
                .fill(p.line)
                .child(el().h_full().grow(fraction).fill(p.accent))
                .child(el().h_full().grow(1.0 - fraction)),
        );
    }
    card = card.child(
        text(progress)
            .key(format!("transfer-summary-{id}"))
            .font(p.font(12.0, 400.0))
            .color(p.text)
            .w_full()
            .wrap(),
    );
    if !task.current.as_os_str().is_empty() {
        card = card.child(
            text(transfer_path(s, &task.current))
                .key(format!("transfer-current-{id}"))
                .font(p.font(11.0, 400.0))
                .color(p.muted)
                .w_full()
                .truncate()
                .help(transfer_path(s, &task.current)),
        );
    }
    if task.failures.is_empty() {
        for error in &task.errors {
            card = card.child(
                text(error)
                    .font(p.font(12.0, 400.0))
                    .color(p.folder)
                    .w_full()
                    .wrap_anywhere(),
            );
        }
    } else {
        for (index, failure) in task.failures.iter().enumerate() {
            let mut detail = format!("{}\n{}", transfer_path(s, &failure.source), failure.error);
            if let Some(destination) = &failure.destination {
                detail.push_str(&format!("\nTo {}", transfer_path(s, destination)));
            }
            card = card.child(
                text(detail)
                    .key(format!("transfer-failure-{id}-{index}"))
                    .font(p.font(12.0, 400.0))
                    .color(p.folder)
                    .w_full()
                    .wrap_anywhere(),
            );
        }
    }
    for warning in &task.warnings {
        card = card.child(
            text(warning)
                .font(p.font(12.0, 400.0))
                .color(p.muted)
                .w_full()
                .wrap_anywhere(),
        );
    }
    if active {
        card = card.child(
            row().w_full().child(el().grow(1.0)).child(
                action_button("Cancel task", p, move |s, _| s.queue.cancel(id))
                    .key(format!("task-cancel-{id}"))
                    .h(p.height(32.0)),
            ),
        );
    } else if task.can_retry {
        card = card.child(
            row().w_full().child(el().grow(1.0)).child(
                action_button("Retry failed items", p, move |s, tx| {
                    s.command(&format!("task_retry {id}"), tx)
                })
                .key(format!("task-retry-{id}"))
                .h(p.height(32.0)),
            ),
        );
    }
    card
}

fn operation_overlay(s: &State, p: Theme, width: f32, height: f32) -> El {
    let dialog_width = (width - p.space(8))
        .max(160.0)
        .min(if s.confirmation.is_some() {
            530.0
        } else {
            760.0
        });
    let inner_width = dialog_width - p.space(8);
    let mut content =
        col()
            .w_full()
            .gap(p.space(3))
            .role("dialog")
            .label(if s.queue.conflict.is_some() {
                "File conflict"
            } else {
                "Transfer center"
            });
    if let Some(conflict) = &s.queue.conflict {
        let incoming = conflict_item(
            s,
            true,
            &conflict.source,
            conflict.source_metadata.as_ref(),
            p,
        );
        let existing = conflict_item(
            s,
            false,
            &conflict.destination,
            conflict.destination_metadata.as_ref(),
            p,
        );
        let comparison = if inner_width >= p.height(560.0) {
            row()
                .w_full()
                .gap(p.space(3))
                .equal_columns(2)
                .child(incoming.min_w(0.0))
                .child(existing.min_w(0.0))
        } else {
            col()
                .w_full()
                .gap(p.space(2))
                .child(incoming)
                .child(existing)
        };
        content = content
            .child(text("An item with this name already exists").font(p.font(20.0, 600.0)).color(p.text).w_full().wrap())
            .child(comparison)
            .child(text("Keep both saves the incoming item under a new name. Replace overwrites the item already in the destination.").font(p.font(12.0, 400.0)).color(p.muted).w_full().wrap())
            .child(check_button("Apply to remaining conflicts in this task", s.conflict_all, p, |s| s.conflict_all = !s.conflict_all).key("conflict-apply-all"));
        let mut choices = if inner_width >= p.height(560.0) {
            row()
                .w_full()
                .gap(p.space(2))
                .equal_columns(3 + conflict.can_merge as usize)
        } else {
            col().w_full().gap(p.space(2))
        };
        if conflict.can_merge {
            choices = choices.child(
                action_button("Merge folders", p, |s, _| {
                    s.answer_conflict(Choice::Merge, false)
                })
                .key("conflict-merge")
                .h(p.height(32.0)),
            );
        }
        for (name, key, choice) in [
            ("Skip", "conflict-skip", Choice::Skip),
            ("Replace", "conflict-replace", Choice::Replace),
            ("Keep both", "conflict-keep-both", Choice::KeepBoth),
        ] {
            choices = choices.child(
                action_button(name, p, move |s, _| s.answer_conflict(choice, false))
                    .key(key)
                    .h(p.height(32.0))
                    .fill(if matches!(choice, Choice::KeepBoth) {
                        p.selected
                    } else {
                        p.panel
                    }),
            );
        }
        content = content.child(choices).child(
            action_button("Cancel", p, |s, _| s.answer_conflict(Choice::Cancel, false))
                .key("conflict-cancel")
                .h(p.height(32.0)),
        );
    } else if let Some(operation) = &s.confirmation {
        content = content
            .child(
                text(match operation {
                    crate::operations::Operation::Trash(paths)
                    | crate::operations::Operation::Delete(paths) => {
                        let target = if paths.len() == 1 {
                            paths[0]
                                .file_name()
                                .unwrap_or_default()
                                .to_string_lossy()
                                .into_owned()
                        } else {
                            format!("{} items", paths.len())
                        };
                        if matches!(operation, crate::operations::Operation::Trash(_)) {
                            format!("Move {target} to trash?")
                        } else {
                            format!("Permanently delete {target}?")
                        }
                    }
                    _ => format!("{} selected items?", operation.title()),
                })
                .font(p.font(20.0, 600.0))
                .color(p.text),
            )
            .child(
                text(
                    if matches!(
                        operation,
                        crate::operations::Operation::Delete(_)
                            | crate::operations::Operation::DeleteTrash(_)
                    ) {
                        "Permanent deletion cannot be undone."
                    } else {
                        "You can restore these items from the trash."
                    },
                )
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .w_full(),
            )
            .child(
                row()
                    .gap(p.space(2))
                    .w_full()
                    .child(el().grow(1.0))
                    .child(
                        action_button("Cancel", p, |s, _| s.confirmation = None).h(p.height(32.0)),
                    )
                    .child(
                        action_button(
                            if matches!(operation, crate::operations::Operation::Trash(_)) {
                                "Move to Trash"
                            } else {
                                "Delete Permanently"
                            },
                            p,
                            |s, _| {
                                if let Some(operation) = s.confirmation.take() {
                                    s.enqueue(operation, false);
                                }
                            },
                        )
                        .key("confirm-operation")
                        .default_button()
                        .h(p.height(32.0))
                        .fill(p.selected),
                    ),
            );
    } else {
        let active = s
            .queue
            .tasks
            .iter()
            .filter(|task| {
                matches!(
                    task.status,
                    Status::Queued | Status::Running | Status::Waiting
                )
            })
            .count();
        let compact = inner_width < p.height(560.0);
        let title = text("Transfer center")
            .font(p.font(if compact { 16.0 } else { 20.0 }, 600.0))
            .color(p.text)
            .min_w(0.0)
            .wrap();
        let status = label(
            if active == 0 {
                "No active transfers".into()
            } else {
                format!("{active} active")
            },
            p,
        );
        let heading = if compact {
            col()
                .w_full()
                .gap(p.space(1))
                .child(title.w_full())
                .child(status.w_full())
        } else {
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(title.grow(1.0))
                .child(status)
        };
        content = content.child(heading).child(
            text(if compact {
                "Close to continue browsing."
            } else {
                "Transfers continue in the background when you close this window."
            })
            .font(p.font(12.0, 400.0))
            .color(p.muted)
            .w_full()
            .wrap(),
        );
        if !compact && s.queue.undo_available() {
            content = content.child(
                action_button("Undo last operation", p, |s, tx| s.command("undo", tx))
                    .h(p.height(32.0)),
            );
        }
        let mut tasks = col().w_full().gap(p.space(3));
        for task in s.queue.tasks.iter().rev() {
            tasks = tasks.child(transfer_card(s, task, p));
        }
        if s.queue.tasks.is_empty() {
            tasks = tasks.child(label("No file tasks yet", p));
        }
        content = content.child(tasks);
        if compact && s.queue.undo_available() {
            content = content.child(
                action_button("Undo last operation", p, |s, tx| s.command("undo", tx))
                    .h(p.height(32.0)),
            );
        }
    }
    el().key("operation-layer")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .modal(false, |s: &mut State| {
            if s.queue.conflict.is_some() {
                s.answer_conflict(Choice::Cancel, false);
            }
            s.confirmation = None;
            s.context = None;
            s.tasks_open = false;
        })
        .center()
        .child(
            col()
                .key("operation-dialog")
                .w(dialog_width)
                .padding(p.space(4))
                .gap(p.space(3))
                .fill(p.panel)
                .radius(p.space(2))
                .child(
                    col()
                        .key("operation-scroll")
                        .w_full()
                        .max_h((height - p.space(16) - p.height(32.0)).max(p.height(64.0)))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(if s.confirmation.is_some() || s.queue.conflict.is_some() {
                    el()
                } else {
                    row().w_full().child(el().grow(1.0)).child(
                        action_button(
                            if s.queue.conflict.is_some() {
                                "Cancel"
                            } else {
                                "Close"
                            },
                            p,
                            |s, _| {
                                s.answer_conflict(Choice::Cancel, false);
                                s.confirmation = None;
                                s.context = None;
                                s.tasks_open = false;
                            },
                        )
                        .key("transfers-close")
                        .h(p.height(32.0)),
                    )
                }),
        )
}

fn application_dialog(s: &State, p: Theme, width: f32, height: f32) -> El {
    let chooser = &s.chooser;
    let available = s.applications.as_ref();
    let visible = available
        .map(|apps| chooser.visible(apps))
        .unwrap_or_default();
    let can_open = !chooser.busy
        && available
            .is_some_and(|apps| chooser.custom.is_some() || chooser.selection(apps).is_some());
    let mut listing = col().w_full().gap(p.space(1));
    if let Some(path) = &chooser.custom {
        listing = listing.child(
            col()
                .w_full()
                .padding(p.space(3))
                .gap(p.space(1))
                .fill(p.selected)
                .radius(p.space(1))
                .child(
                    text(path.file_name().unwrap_or_default().to_string_lossy())
                        .font(p.font(14.0, 500.0))
                        .color(p.text),
                )
                .child(
                    text(path.display().to_string())
                        .font(p.font(12.0, 400.0))
                        .color(p.muted)
                        .w_full()
                        .truncate(),
                ),
        );
    }
    for app in &visible {
        let id = app.id.clone();
        let open_id = id.clone();
        let selected = chooser.custom.is_none() && chooser.selected.as_ref() == Some(&id);
        let image = if let Some(image) = app.icon.as_ref().filter(|image| image.size().is_some()) {
            el().w(28.0)
                .h(p.height(28.0))
                .pixels_fit(image.pixels(), SurfaceFit::Fit)
        } else {
            el().w(28.0)
                .h(p.height(28.0))
                .center()
                .child(text("▣").font(p.font(24.0, 400.0)).color(p.muted))
        };
        let mut item = row()
            .key(format!("application-{id}"))
            .role("option")
            .label(&app.name)
            .checked(selected)
            .focus_selected(selected)
            .focusable(true)
            .focus_ring(2.0, 0.0, p.accent)
            .w_full()
            .min_w(0.0)
            .h(p.height(48.0))
            .px(p.space(2))
            .gap(p.space(3))
            .center_y()
            .radius(p.space(1))
            .fill(if selected { p.selected } else { p.background })
            .hover(p.selected.alpha(0.6))
            .cursor(rune::Cursor::Pointer)
            .disabled(chooser.busy)
            .on_key(|s: &mut State, key, tx| {
                if key.key == rune::Key::Enter {
                    s.open_application();
                    true
                } else {
                    s.key(key, tx)
                }
            })
            .on_press(move |s: &mut State| s.chooser.select(id.clone()))
            .on_double_press(move |s: &mut State| {
                s.chooser.select(open_id.clone());
                s.open_application();
            })
            .child(image)
            .child(
                text(&app.name)
                    .font(p.font(14.0, 500.0))
                    .color(p.text)
                    .grow(1.0)
                    .min_w(0.0)
                    .truncate(),
            );
        if app.default {
            item = item.child(text("Default").font(p.font(11.0, 400.0)).color(p.muted));
        }
        listing = listing.child(item);
    }
    if visible.is_empty() && chooser.custom.is_none() {
        listing = listing.child(
            text(if available.is_none() {
                if chooser.error.is_some() {
                    "Applications could not be loaded."
                } else {
                    "Finding applications…"
                }
            } else if !chooser.query.text.trim().is_empty() {
                "No matching applications. Try another name or browse."
            } else {
                "No recommended applications. Show all apps or browse."
            })
            .font(p.font(13.0, 400.0))
            .color(p.muted)
            .w_full()
            .wrap()
            .padding(p.space(3)),
        );
    }
    let context = available
        .map(|apps| {
            if apps.paths.len() == 1 {
                apps.paths[0]
                    .file_name()
                    .unwrap_or_default()
                    .to_string_lossy()
                    .into_owned()
            } else {
                format!("{} selected files", apps.paths.len())
            }
        })
        .unwrap_or_default();
    let mut content = col()
        .w((width - 32.0).min(500.0))
        .padding(p.space(6))
        .gap(p.space(2))
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .child(
            col()
                .w_full()
                .gap(p.space(1))
                .child(text("Open with").font(p.font(20.0, 600.0)).color(p.text))
                .child(
                    text(context)
                        .font(p.font(13.0, 400.0))
                        .color(p.muted)
                        .w_full()
                        .truncate(),
                ),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(
                    input(&chooser.query, p.font(14.0, 400.0), p.height(36.0), p)
                        .key("application-search")
                        .label("Search applications")
                        .placeholder("Search applications", p.muted)
                        .grow(1.0)
                        .min_w(0.0)
                        .px(p.space(2))
                        .fill(p.background)
                        .border(1.0, p.line)
                        .radius(p.space(1))
                        .color(p.text)
                        .disabled(chooser.busy)
                        .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
                        .on_edit(|s: &mut State| &mut s.chooser.query)
                        .on_submit(|s: &mut State, _| s.open_application()),
                )
                .child(
                    action_button(
                        if chooser.all {
                            "Recommended"
                        } else {
                            "All apps"
                        },
                        p,
                        |s, _| {
                            s.chooser.all = !s.chooser.all;
                            s.chooser.query = rune::TextEdit::new("");
                        },
                    )
                    .key("application-show-all")
                    .disabled(chooser.busy),
                ),
        )
        .child(
            col()
                .key("application-list")
                .role("listbox")
                .label("Applications")
                .focus_group()
                .w_full()
                .h(
                    (height - 284.0 - if chooser.error.is_some() { 50.0 } else { 0.0 })
                        .clamp(24.0, 280.0),
                )
                .padding(p.space(1))
                .fill(p.background)
                .border(1.0, p.line)
                .radius(p.space(1))
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .child(listing),
        );
    if let Some(apps) = available
        && apps.paths.len() == 1
        && chooser.custom.is_none()
    {
        content = content.child(
            check_button(
                format!("Always use for {}", apps.description),
                chooser.always,
                p,
                |s| s.chooser.always = !s.chooser.always,
            )
            .key("application-always")
            .disabled(chooser.busy),
        );
    }
    if let Some(error) = &chooser.error {
        content = content.child(
            text(error)
                .key("application-error")
                .font(p.font(12.0, 400.0))
                .color(p.folder)
                .w_full()
                .wrap()
                .max_h(42.0),
        );
    }
    content = content.child(
        row()
            .w_full()
            .gap(p.space(2))
            .center_y()
            .child(
                action_button("Browse…", p, |s, tx| s.browse_application(tx))
                    .key("application-browse")
                    .h(p.height(32.0))
                    .disabled(available.is_none() || chooser.busy),
            )
            .child(el().grow(1.0))
            .child(
                action_button("Cancel", p, |s, _| s.panel = None)
                    .key("application-cancel")
                    .h(p.height(32.0))
                    .disabled(chooser.busy),
            )
            .child(
                action_button(
                    if chooser.busy {
                        "Please wait…"
                    } else {
                        "Open"
                    },
                    p,
                    |s, _| s.open_application(),
                )
                .key("application-open")
                .h(p.height(32.0))
                .default_button()
                .fill(p.selected)
                .disabled(!can_open)
                .opacity(if can_open { 1.0 } else { 0.45 }),
            ),
    );
    el().key("application-dialog")
        .role("dialog")
        .label("Open with")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| {
            if !s.chooser.busy {
                s.panel = None;
            }
        })
        .child(content)
}

fn desktop_overlay(s: &State, p: Theme, height: f32) -> El {
    use crate::state::Panel;
    let mut content = col().w_full().gap(p.space(3));
    let mut items = col().w_full().gap(p.space(2));
    if s.panel == Some(Panel::Places) {
        content = content.child(
            text("Places and devices")
                .font(p.font(20.0, 600.0))
                .color(p.text),
        );
        for place in &s.places {
            let place = place.clone();
            let name = format!(
                "{}{}",
                place.name,
                if place.mounted { "" } else { " (not mounted)" }
            );
            let unmount = place.clone();
            let eject = place.clone();
            let mut item = row()
                .gap(p.space(2))
                .child(action_button(name, p, move |s, tx| {
                    s.open_place(&place, crate::state::PlaceOpen::Current, tx)
                }));
            if unmount.unmount {
                item = item.child(action_button("Unmount", p, move |s, _| {
                    s.mount_action(crate::mounts::Action::Unmount(unmount.clone()))
                }));
            }
            if eject.eject {
                item = item.child(action_button("Eject", p, move |s, _| {
                    s.mount_action(crate::mounts::Action::Eject(eject.clone()))
                }));
            }
            items = items.child(item);
        }
        content = content.child(action_button("Connect to server", p, |s, tx| {
            s.panel = None;
            s.command("connect", tx);
        }));
        if s.mounts.busy() {
            content = content.child(action_button("Cancel device operation", p, |s, _| {
                s.cancel_mount()
            }));
        }
        content = content.child(
            row()
                .gap(p.space(2))
                .child(action_button("Pin current folder", p, |s, tx| {
                    s.command("bookmark", tx)
                }))
                .child(action_button("Refresh devices", p, |s, tx| {
                    s.command("refresh_places", tx)
                }))
                .child(action_button("Trash", p, |s, tx| {
                    s.panel = None;
                    s.command("trash", tx);
                })),
        );
    } else if s.panel == Some(Panel::Trash) {
        content = content
            .child(text("Trash").font(p.font(20.0, 600.0)).color(p.text))
            .child(
                text("All mounted volumes · ↑/↓ navigate · Space select · r restore · d delete")
                    .font(p.font(13.0, 400.0))
                    .color(p.muted)
                    .wrap()
                    .w_full(),
            )
            .child(
                row()
                    .gap(p.space(2))
                    .child(action_button("Restore selected", p, |s, tx| {
                        s.command("restore", tx)
                    }))
                    .child(action_button("Delete selected", p, |s, tx| {
                        s.command("trash_delete", tx)
                    })),
            )
            .child(
                row()
                    .gap(p.space(2))
                    .child(action_button("Empty trash…", p, |s, tx| {
                        s.command("trash_empty", tx)
                    }))
                    .child(action_button("Refresh", p, |s, tx| {
                        s.command("refresh_trash", tx)
                    })),
            );
        if let Some(entries) = &s.trash {
            if entries.is_empty() {
                items = items.child(label("Trash is empty", p));
            }
            for (index, entry) in entries.iter().enumerate() {
                let uri = entry.uri.clone();
                let selected = s.trash_selected.contains(&entry.uri);
                items = items.child(
                    col()
                        .key(format!("trash-entry-{index}"))
                        .w_full()
                        .gap(p.space(1))
                        .child(action_button(
                            format!(
                                "{} {} {}",
                                if index == s.trash_cursor { "›" } else { " " },
                                if selected { "✓" } else { "○" },
                                entry.name
                            ),
                            p,
                            move |s, _| {
                                s.trash_cursor = index;
                                if !s.trash_selected.remove(&uri) {
                                    s.trash_selected.insert(uri.clone());
                                }
                            },
                        ))
                        .child(
                            text(format!("From {}", entry.original.display()))
                                .wrap_anywhere()
                                .font(p.font(13.0, 400.0))
                                .color(p.muted)
                                .w_full(),
                        )
                        .child(label(
                            format!("{} · {}", entry.deleted, file::human_size(entry.size)),
                            p,
                        )),
                );
            }
        } else {
            items = items.child(label("Reading trash…", p));
        }
    }
    if let Some(message) = &s.message {
        content = content.child(
            text(message)
                .font(p.font(13.0, 400.0))
                .color(p.folder)
                .w_full(),
        );
    }
    content = content.child(items);
    el().key("desktop-layer")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.85))
        .modal(false, |s: &mut State| s.panel = None)
        .center()
        .child(
            col()
                .w(560.0)
                .padding(p.space(6))
                .gap(p.space(3))
                .fill(p.panel)
                .radius(p.space(2))
                .child(
                    col()
                        .key("desktop-content")
                        .w_full()
                        .max_h((height - 120.0).clamp(120.0, 432.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(
                    row()
                        .w_full()
                        .child(el().grow(1.0))
                        .child(action_button("Close", p, |s, _| s.panel = None).h(p.height(32.0))),
                ),
        )
}

fn authentication_overlay(s: &State, p: Theme, height: f32) -> El {
    let mut content = col().w_full().gap(p.space(3)).child(
        text(if s.authentication.is_some() {
            "Connect to server"
        } else {
            "Server request"
        })
        .font(p.font(20.0, 600.0))
        .color(p.text),
    );
    if let Some(auth) = &s.authentication {
        content = content.child(
            text(&auth.message)
                .font(p.font(13.0, 400.0))
                .color(p.text)
                .w_full(),
        );
        if auth.flags.contains(gio::AskPasswordFlags::NEED_USERNAME) {
            content = content
                .child(text("Username").font(p.font(12.0, 500.0)).color(p.muted))
                .child(
                    input(&auth.user, p.font(14.0, 400.0), p.height(36.0), p)
                        .key("auth-user")
                        .label("Username")
                        .w_full()
                        .px(p.space(2))
                        .fill(p.background)
                        .border(1.0, p.line)
                        .radius(p.space(1))
                        .color(p.text)
                        .on_edit(|s: &mut State| &mut s.authentication.as_mut().unwrap().user),
                );
        }
        if auth.flags.contains(gio::AskPasswordFlags::NEED_DOMAIN) {
            content = content
                .child(text("Domain").font(p.font(12.0, 500.0)).color(p.muted))
                .child(
                    input(&auth.domain, p.font(14.0, 400.0), p.height(36.0), p)
                        .key("auth-domain")
                        .label("Domain")
                        .w_full()
                        .px(p.space(2))
                        .fill(p.background)
                        .border(1.0, p.line)
                        .radius(p.space(1))
                        .color(p.text)
                        .on_edit(|s: &mut State| &mut s.authentication.as_mut().unwrap().domain),
                );
        }
        if auth.flags.contains(gio::AskPasswordFlags::NEED_PASSWORD) {
            content = content
                .child(text("Password").font(p.font(12.0, 500.0)).color(p.muted))
                .child(
                    input(&auth.password, p.font(14.0, 400.0), p.height(36.0), p)
                        .key("auth-password")
                        .label("Password")
                        .w_full()
                        .px(p.space(2))
                        .fill(p.background)
                        .border(1.0, p.line)
                        .radius(p.space(1))
                        .color(p.text)
                        .on_edit(|s: &mut State| &mut s.authentication.as_mut().unwrap().password)
                        .on_submit(|s: &mut State, _| s.authenticate(false)),
                );
        }
        if auth
            .flags
            .contains(gio::AskPasswordFlags::ANONYMOUS_SUPPORTED)
        {
            content = content.child(action_button("Connect anonymously", p, |s, _| {
                s.authenticate(true)
            }));
        }
    }
    if let Some(question) = &s.question {
        content = content.child(
            text(&question.message)
                .font(p.font(13.0, 400.0))
                .color(p.text)
                .w_full(),
        );
        for (index, choice) in question.choices.iter().enumerate() {
            content = content.child(action_button(choice, p, move |s, _| {
                if let Some(question) = s.question.take() {
                    let _ = question.reply.send(Some(index));
                }
            }));
        }
    }
    el().key("authentication-layer")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .modal(false, |s: &mut State| s.cancel_mount())
        .center()
        .child(
            col()
                .w(540.0)
                .padding(p.space(6))
                .gap(p.space(3))
                .fill(p.panel)
                .radius(p.space(2))
                .child(
                    col()
                        .w_full()
                        .max_h((height - 120.0).clamp(120.0, 432.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(
                    row()
                        .w_full()
                        .gap(p.space(2))
                        .child(el().grow(1.0))
                        .child(
                            action_button("Cancel", p, |s, _| s.cancel_mount()).h(p.height(32.0)),
                        )
                        .child(if s.authentication.is_some() {
                            action_button("Connect", p, |s, _| s.authenticate(false))
                                .h(p.height(32.0))
                                .fill(p.selected)
                                .default_button()
                        } else {
                            el()
                        }),
                ),
        )
}

fn drop_overlay(s: &State, p: Theme) -> El {
    let drop = s.drop_decision.as_ref().expect("drop decision");
    el().absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.85))
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| {
            if let Some(drop) = s.drop_decision.take() {
                s.cancel_drop(drop.token);
            }
        })
        .center()
        .child(
            col()
                .w(520.0)
                .padding(p.space(6))
                .gap(p.space(3))
                .fill(p.panel)
                .radius(p.space(2))
                .child(
                    text(format!("Drop {} item(s)", drop.paths.len()))
                        .font(p.font(20.0, 600.0))
                        .color(p.text),
                )
                .child(
                    text(drop.destination.display().to_string())
                        .font(p.font(13.0, 400.0))
                        .color(p.muted)
                        .wrap_anywhere()
                        .w_full(),
                )
                .child(
                    row()
                        .gap(p.space(2))
                        .child(action_button("Copy", p, |s, _| {
                            if let Some(drop) = s.drop_decision.take() {
                                s.accept_drop(drop, 1);
                            }
                        }))
                        .child(action_button("Move", p, |s, _| {
                            if let Some(drop) = s.drop_decision.take() {
                                s.accept_drop(drop, 2);
                            }
                        }))
                        .child(action_button("Create Link", p, |s, _| {
                            if let Some(drop) = s.drop_decision.take() {
                                s.accept_drop(drop, 8);
                            }
                        })),
                )
                .child(action_button("Cancel", p, |s, _| {
                    if let Some(drop) = s.drop_decision.take() {
                        s.cancel_drop(drop.token);
                    }
                })),
        )
}

fn selector_view(s: &State, p: Theme, cx: &mut Cx<State>) -> El {
    use crate::selector::{Menu, Mode};
    let selector = s.selector.as_ref().expect("file picker");
    let width = cx.layout_size("app").map_or(1160.0, |size| size[0]);
    let height = cx.layout_size("app").map_or(740.0, |size| size[1]);
    let scroll = s.tab().scroll.clone();
    let listing = col()
        .key(Pane::list_key(0))
        .grow(1.0)
        .min_h(0.0)
        .w_full()
        .role("listbox")
        .label("Files")
        .focus_group()
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .on_scroll_offset(move |position| {
            scroll.set(position.offset[1]);
        })
        .child(if s.tab().visible.is_empty() {
            text(if s.tab().loading {
                "Reading folder…"
            } else {
                "No matching items"
            })
            .font(p.font(14.0, 400.0))
            .color(p.muted)
            .padding(p.space(6))
        } else {
            col()
                .w_full()
                .growth(GrowthSpec::default())
                .virtual_rows(
                    s.tab().visible.len(),
                    p.row(),
                    |s: &State, index| s.tab().entry(index).key.as_str().into(),
                    move |s: &State, index| {
                        let file = s.tab().entry(index);
                        let path = file.path.clone();
                        let open = path.clone();
                        let selector = s.selector.as_ref().unwrap();
                        file_row(
                            file,
                            s.tab().cursor == index,
                            s.tab().selected(index),
                            selector.request.multiple()
                                && file.directory == selector.request.folders(),
                            p,
                            0,
                            s.thumbnail(file),
                        )
                        .focusable(true)
                        .focus_selected(s.tab().cursor == index)
                        .hover_group()
                        .on_press_tx(move |s: &mut State, tx| {
                            s.selector_hover(&path, tx);
                            tx.blur();
                        })
                        .on_double_press_tx(move |s: &mut State, tx| {
                            s.selector_hover(&open, tx);
                            s.enter(tx, true);
                            tx.blur();
                        })
                    },
                )
                .virtual_rows_version(s.pane().revision)
        });
    let listing = if s.pane().picker.is_some() {
        finder_results(s, 0, p).grow(1.0)
    } else {
        listing
    };
    let sidebar_width = if width < 900.0 { 200.0 } else { 232.0 };
    let mut body = row()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .child(
            col()
                .w(sidebar_width)
                .h_full()
                .min_h(0.0)
                .min_w(0.0)
                .fill(p.panel)
                .child(places(s, p)),
        )
        .child(rule(p))
        .child(
            col()
                .grow(1.0)
                .min_w(0.0)
                .min_h(0.0)
                .child(if s.pane().picker.is_none() {
                    folder_toolbar(s, 0, p)
                } else {
                    el()
                })
                .child(listing),
        );
    if width >= 880.0 {
        body = body.child(rule(p)).child(
            col()
                .w((width * 0.34).min(440.0))
                .h_full()
                .child(preview(s, p)),
        );
    }
    let mut options = col().w_full().gap(p.space(2));
    if matches!(selector.request.mode, Mode::Save) {
        options = options.child(
            row()
                .w_full()
                .gap(p.space(3))
                .center_y()
                .child(text("Name").font(p.font(13.0, 500.0)).color(p.text).w(70.0))
                .child(
                    input(&selector.name, p.font(14.0, 400.0), p.height(36.0), p)
                        .key("selector-name")
                        .label("File name")
                        .grow(1.0)
                        .min_w(0.0)
                        .px(p.space(2))
                        .fill(p.background)
                        .border(1.0, p.line)
                        .radius(p.space(1))
                        .color(p.text)
                        .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
                        .on_edit(|s: &mut State| &mut s.selector.as_mut().unwrap().name)
                        .on_submit(|s: &mut State, tx| s.selector_accept(false, tx)),
                ),
        );
    } else if let Mode::SaveFiles { files } = &selector.request.mode {
        options = options.child(
            text(format!("Save {} files in the selected folder", files.len()))
                .font(p.font(13.0, 400.0))
                .color(p.text),
        );
    }
    if !selector.request.filters.is_empty() {
        let label = &selector.request.filters[selector.filter].0;
        options = options.child(
            row()
                .w_full()
                .gap(p.space(3))
                .center_y()
                .child(
                    text("File type")
                        .font(p.font(13.0, 500.0))
                        .color(p.text)
                        .w(70.0),
                )
                .child(
                    action_button(format!("{label}  ▾"), p, |s, _| {
                        s.selector.as_mut().unwrap().menu = Some(Menu::Filter)
                    })
                    .key("selector-filter")
                    .role("combobox")
                    .label(label)
                    .expanded(selector.menu == Some(Menu::Filter))
                    .h(p.height(32.0)),
                ),
        );
    }
    for (index, (_, label, values, _)) in selector.request.choices.iter().enumerate() {
        if values.is_empty() {
            options = options.child(
                check_button(label, selector.choices[index] == "true", p, move |s| {
                    let value = &mut s.selector.as_mut().unwrap().choices[index];
                    *value = if value == "true" { "false" } else { "true" }.into();
                })
                .key(format!("selector-choice-{index}")),
            );
        } else {
            let value = values
                .iter()
                .find(|(id, _)| id == &selector.choices[index])
                .map(|(_, label)| label.as_str())
                .unwrap_or("");
            options = options.child(
                row()
                    .w_full()
                    .gap(p.space(3))
                    .center_y()
                    .child(text(label).font(p.font(13.0, 500.0)).color(p.text))
                    .child(
                        action_button(format!("{value}  ▾"), p, move |s, _| {
                            s.selector.as_mut().unwrap().menu = Some(Menu::Choice(index))
                        })
                        .key(format!("selector-choice-{index}"))
                        .role("combobox")
                        .label(label)
                        .h(p.height(32.0)),
                    ),
            );
        }
    }
    let error = selector
        .error
        .as_ref()
        .or(s.message.as_ref())
        .map(String::as_str)
        .unwrap_or("");
    let selected = s
        .pane()
        .picker
        .as_ref()
        .map_or(s.tab().selected.len(), |picker| picker.selected.len());
    let mut root = col()
        .key("app")
        .w_full()
        .h_full()
        .fill(p.background)
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .child(
            row()
                .w_full()
                .h(p.height(56.0))
                .px(p.space(4))
                .gap(p.space(3))
                .center_y()
                .child(
                    text(&selector.request.title)
                        .font(p.font(20.0, 600.0))
                        .color(p.text)
                        .grow(1.0)
                        .min_w(0.0)
                        .truncate(),
                )
                .child(
                    icon_button(&icon::SETTINGS, "Appearance · Ctrl+,", p, move |s, tx| {
                        s.command(
                            if p.dark {
                                "settings dark"
                            } else {
                                "settings light"
                            },
                            tx,
                        )
                    })
                    .key("settings-open")
                    .help("Appearance · Ctrl+,"),
                )
                .child(
                    action_button("Find files…", p, |s, tx| s.show_picker(tx))
                        .key("selector-search")
                        .help("Search names or contents · / or Ctrl+F"),
                ),
        )
        .child(
            row()
                .w_full()
                .h(p.height(40.0))
                .px(p.space(2))
                .gap(p.space(2))
                .center_y()
                .child(navigation(s, 0, p))
                .child(
                    action_button("New folder…", p, |s, tx| s.command("create --dir", tx))
                        .key("selector-new-folder"),
                )
                .child(
                    action_button(
                        if s.tab().preference.show_hidden {
                            "Hide hidden"
                        } else {
                            "Show hidden"
                        },
                        p,
                        |s, tx| s.command("hidden", tx),
                    )
                    .key("selector-hidden")
                    .role("checkbox")
                    .checked(s.tab().preference.show_hidden),
                ),
        )
        .child(el().w_full().h(1.0).fill(p.line))
        .child(if s.pane().picker.is_some() {
            finder_controls(s, p)
        } else {
            el()
        })
        .child(body)
        .child(
            col()
                .w_full()
                .px(p.space(4))
                .py(p.space(2))
                .max_h((height * 0.3).max(60.0))
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .child(options),
        )
        .child(
            row()
                .w_full()
                .h(p.height(60.0))
                .px(p.space(4))
                .gap(p.space(2))
                .center_y()
                .fill(p.panel)
                .child(
                    text(if error.is_empty() {
                        if selected > 1 {
                            format!("{selected} items selected")
                        } else {
                            String::new()
                        }
                    } else {
                        error.into()
                    })
                    .key("selector-error")
                    .font(p.font(12.0, 400.0))
                    .color(if error.is_empty() { p.muted } else { p.folder })
                    .grow(1.0)
                    .min_w(0.0)
                    .truncate()
                    .help(error),
                )
                .child(
                    action_button("Cancel", p, |s, tx| s.close(tx))
                        .key("selector-cancel")
                        .h(p.height(36.0))
                        .disabled(selector.busy),
                )
                .child(
                    action_button(
                        if selector.busy {
                            "Please wait…"
                        } else {
                            &selector.request.accept_label
                        },
                        p,
                        |s, tx| s.selector_accept(false, tx),
                    )
                    .key("selector-accept")
                    .h(p.height(36.0))
                    .fill(p.selected)
                    .default_button()
                    .disabled(selector.busy || s.tab().loading),
                ),
        );
    if s.pane().address.editing {
        root = root.child(address_choices(s, 0, p, cx));
    }
    if s.view_options.is_some() {
        root = root.child(folder_view_overlay(s, p, width, height));
    }
    if s.context.is_some() {
        root = root.child(context_menu(s, p, cx));
    }
    if let Some(kind) = s.pane().picker.as_ref().and_then(|picker| picker.menu) {
        root = root.child(finder_menu(s, p, kind, height));
    }
    if s.place_menu.is_some() {
        root = root.child(place_overlay(s, p, width));
    }
    if s.prompt.is_some() {
        root = root.child(name_dialog(s, p, width, height));
    }
    if s.authentication.is_some() || s.question.is_some() {
        root = root.child(authentication_overlay(s, p, height));
    }
    if let Some(menu) = selector.menu {
        root = root.child(selector_menu(s, p, menu, height));
    }
    if let Some(paths) = &selector.replace {
        let target = if paths.len() == 1 {
            paths[0]
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .into_owned()
        } else {
            format!("{} existing files", paths.len())
        };
        root = root.child(
            el().key("selector-replace-dialog")
                .role("dialog")
                .label("Replace existing files")
                .absolute(0.0, 0.0)
                .w_full()
                .h_full()
                .fill(p.background.alpha(0.65))
                .center()
                .modal(false, |s: &mut State| {
                    s.selector.as_mut().unwrap().replace = None
                })
                .child(
                    col()
                        .w((width - 40.0).min(460.0))
                        .padding(p.space(6))
                        .gap(p.space(4))
                        .fill(p.panel)
                        .border(1.0, p.line)
                        .radius(p.space(2))
                        .child(
                            text(format!("Replace {target}?"))
                                .font(p.font(19.0, 600.0))
                                .color(p.text)
                                .w_full()
                                .wrap(),
                        )
                        .child(
                            text("Saving here will replace the existing contents.")
                                .font(p.font(13.0, 400.0))
                                .color(p.muted)
                                .w_full()
                                .wrap(),
                        )
                        .child(
                            row()
                                .w_full()
                                .gap(p.space(2))
                                .child(el().grow(1.0))
                                .child(
                                    action_button("Cancel", p, |s, _| {
                                        s.selector.as_mut().unwrap().replace = None
                                    })
                                    .key("selector-replace-cancel")
                                    .h(p.height(32.0)),
                                )
                                .child(
                                    action_button("Replace", p, |s, tx| {
                                        s.selector_accept(true, tx)
                                    })
                                    .key("selector-replace-confirm")
                                    .h(p.height(32.0))
                                    .fill(p.selected)
                                    .default_button(),
                                ),
                        ),
                ),
        );
    }
    if s.appearance.open {
        root = root.child(crate::appearance_view::view(
            s,
            p,
            width,
            cx.layout_size("app").map_or(740.0, |size| size[1]),
        ));
    }
    root.motion(rune::Spring::NONE)
}

fn selector_menu(s: &State, p: Theme, target: crate::selector::Menu, height: f32) -> El {
    use crate::selector::Menu;
    let selector = s.selector.as_ref().unwrap();
    let (anchor, entries): (_, Vec<_>) = match target {
        Menu::Filter => (
            "selector-filter".into(),
            selector
                .request
                .filters
                .iter()
                .enumerate()
                .map(|(index, (label, _))| (index.to_string(), label.clone()))
                .collect(),
        ),
        Menu::Choice(index) => (
            format!("selector-choice-{index}"),
            selector.request.choices[index].2.clone(),
        ),
    };
    let mut menu = col()
        .key("selector-menu")
        .role("menu")
        .label("Options")
        .focus_group()
        .w(280.0)
        .max_h((height - 32.0).min(300.0))
        .padding(p.space(2))
        .gap(p.space(1))
        .fill(p.panel)
        .border(1.0, p.line)
        .radius(p.space(2))
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .anchored_fit(&anchor, rune::Side::Top, rune::Align::Start, p.space(1))
        .focus_return(&anchor);
    for (index, (id, label)) in entries.into_iter().enumerate() {
        menu = menu.child(
            action_button(label, p, move |s, _| match target {
                Menu::Filter => s.selector_filter(index),
                Menu::Choice(choice) => {
                    let selector = s.selector.as_mut().unwrap();
                    selector.choices[choice] = id.clone();
                    selector.menu = None;
                }
            })
            .key(format!("selector-option-{index}"))
            .role("menuitem")
            .w_full()
            .h(p.height(32.0)),
        );
    }
    el().absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .modal(false, |s: &mut State| {
            s.selector.as_mut().unwrap().menu = None
        })
        .child(menu)
}
