use std::{collections::HashMap, path::PathBuf, process::Stdio, sync::Arc};

use tokio::sync::{RwLock, oneshot, watch};
use zbus::{
    Connection, OwnedObjectPath, fdo,
    message::Header,
    zvariant::{OwnedVariant, Variant},
};

use crate::selector::{self, Mode, Reply};

const NAME: &str = "org.freedesktop.impl.portal.desktop.vereda";
const PATH: &str = "/org/freedesktop/portal/desktop";
type Results = HashMap<String, OwnedVariant>;

struct Request {
    owner: String,
    cancel: Option<oneshot::Sender<()>>,
}

#[zbus::interface(name = "org.freedesktop.impl.portal.Request")]
impl Request {
    fn close(&mut self, #[zbus(header)] header: Header<'_>) -> fdo::Result<()> {
        if header.sender().map(|sender| sender.as_str()) != Some(&self.owner) {
            return Err(fdo::Error::AccessDenied(
                "Only the portal may close this request".into(),
            ));
        }
        if let Some(cancel) = self.cancel.take() {
            let _ = cancel.send(());
        }
        Ok(())
    }
}

struct Backend {
    shutdown: watch::Sender<bool>,
    active: Arc<RwLock<()>>,
}

impl Backend {
    async fn choose(
        &self,
        connection: &Connection,
        header: Header<'_>,
        handle: OwnedObjectPath,
        request: selector::Request,
    ) -> fdo::Result<(u32, Results)> {
        let _active = self.active.read().await;
        let mut shutdown = self.shutdown.subscribe();
        if *shutdown.borrow() {
            return Ok((1, Results::new()));
        }
        let owner = zbus::fdo::DBusProxy::new(connection)
            .await?
            .get_name_owner(
                "org.freedesktop.portal.Desktop"
                    .try_into()
                    .expect("portal bus name"),
            )
            .await?;
        if header.sender().map(|sender| sender.as_str()) != Some(owner.as_str()) {
            return Err(fdo::Error::AccessDenied(
                "Only xdg-desktop-portal may request file dialogs".into(),
            ));
        }
        let (cancel, cancelled) = oneshot::channel();
        connection
            .object_server()
            .at(
                handle.clone(),
                Request {
                    owner: owner.to_string(),
                    cancel: Some(cancel),
                },
            )
            .await?;
        let result = Self::run(request, cancelled, &mut shutdown).await;
        let _ = connection
            .object_server()
            .remove::<Request, _>(handle)
            .await;
        result.map_err(fdo::Error::Failed)
    }

    async fn run(
        request: selector::Request,
        cancelled: oneshot::Receiver<()>,
        shutdown: &mut watch::Receiver<bool>,
    ) -> Result<(u32, Results), String> {
        let temp = tempfile::Builder::new()
            .prefix("vereda-picker-")
            .tempdir()
            .map_err(|error| error.to_string())?;
        let input = temp.path().join("request.json");
        let output = temp.path().join("reply.json");
        tokio::fs::write(
            &input,
            serde_json::to_vec(&request).map_err(|error| error.to_string())?,
        )
        .await
        .map_err(|error| error.to_string())?;
        let executable = std::env::current_exe().map_err(|error| error.to_string())?;
        let mut command = tokio::process::Command::new(executable);
        command
            .args(["--file-picker"])
            .arg(input)
            .arg("--picker-result")
            .arg(&output)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::inherit())
            .kill_on_drop(true);
        let mut child = command.spawn().map_err(|error| error.to_string())?;
        let status = tokio::select! {
            status = child.wait() => Some(status.map_err(|error| error.to_string())?),
            _ = cancelled => None,
            _ = shutdown.changed() => None,
        };
        let Some(status) = status else {
            let _ = child.kill().await;
            let _ = child.wait().await;
            return Ok((1, Results::new()));
        };
        if !status.success() {
            return Ok((2, Results::new()));
        }
        let data = match tokio::fs::read(&output).await {
            Ok(data) => data,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                return Ok((1, Results::new()));
            }
            Err(error) => return Err(error.to_string()),
        };
        let reply: Reply = serde_json::from_slice(&data).map_err(|error| error.to_string())?;
        let mut results = Results::from([
            ("uris".into(), owned(reply.uris)?),
            ("choices".into(), owned(reply.choices)?),
            ("writable".into(), OwnedVariant::from(reply.writable)),
        ]);
        if let Some(filter) = reply.current_filter {
            results.insert("current_filter".into(), owned(filter)?);
        }
        Ok((0, results))
    }
}

fn owned<'a, T: Into<Variant<'a>>>(value: T) -> Result<OwnedVariant, String> {
    OwnedVariant::try_from(value.into()).map_err(|error| error.to_string())
}

#[zbus::interface(name = "org.freedesktop.impl.portal.FileChooser")]
impl Backend {
    #[zbus(property)]
    fn version(&self) -> u32 {
        4
    }

    #[allow(clippy::too_many_arguments)]
    async fn open_file(
        &self,
        handle: OwnedObjectPath,
        app_id: String,
        parent_window: String,
        title: String,
        options: Results,
        #[zbus(connection)] connection: &Connection,
        #[zbus(header)] header: Header<'_>,
    ) -> fdo::Result<(u32, Results)> {
        let mode = Mode::Open {
            multiple: selector::option::<bool>(&options, "multiple")
                .map_err(fdo::Error::InvalidArgs)?
                .unwrap_or(false),
            directory: selector::option::<bool>(&options, "directory")
                .map_err(fdo::Error::InvalidArgs)?
                .unwrap_or(false),
        };
        let request = selector::Request::from_options(mode, title, app_id, parent_window, options)
            .map_err(fdo::Error::InvalidArgs)?;
        self.choose(connection, header, handle, request).await
    }

    #[allow(clippy::too_many_arguments)]
    async fn save_file(
        &self,
        handle: OwnedObjectPath,
        app_id: String,
        parent_window: String,
        title: String,
        options: Results,
        #[zbus(connection)] connection: &Connection,
        #[zbus(header)] header: Header<'_>,
    ) -> fdo::Result<(u32, Results)> {
        let request =
            selector::Request::from_options(Mode::Save, title, app_id, parent_window, options)
                .map_err(fdo::Error::InvalidArgs)?;
        self.choose(connection, header, handle, request).await
    }

    #[allow(clippy::too_many_arguments)]
    async fn save_files(
        &self,
        handle: OwnedObjectPath,
        app_id: String,
        parent_window: String,
        title: String,
        options: Results,
        #[zbus(connection)] connection: &Connection,
        #[zbus(header)] header: Header<'_>,
    ) -> fdo::Result<(u32, Results)> {
        let files = selector::option::<Vec<Vec<u8>>>(&options, "files")
            .map_err(fdo::Error::InvalidArgs)?
            .ok_or_else(|| fdo::Error::InvalidArgs("Missing file names".into()))?;
        if files.is_empty() {
            return Err(fdo::Error::InvalidArgs("No files to save".into()));
        }
        for file in &files {
            selector::filename(selector::byte_path(file.clone()).as_os_str())
                .map_err(fdo::Error::InvalidArgs)?;
        }
        let request = selector::Request::from_options(
            Mode::SaveFiles { files },
            title,
            app_id,
            parent_window,
            options,
        )
        .map_err(fdo::Error::InvalidArgs)?;
        self.choose(connection, header, handle, request).await
    }
}

pub fn serve() -> Result<(), String> {
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|error| error.to_string())?;
    runtime.block_on(async {
        let (shutdown, _) = watch::channel(false);
        let active = Arc::new(RwLock::new(()));
        let connection = zbus::connection::Builder::session()
            .name(NAME)
            .serve_at(
                PATH,
                Backend {
                    shutdown: shutdown.clone(),
                    active: active.clone(),
                },
            )
            .build()
            .await
            .map_err(|error| error.to_string())?;
        let mut terminate =
            tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
                .map_err(|error| error.to_string())?;
        tokio::select! { _ = tokio::signal::ctrl_c() => {}, _ = terminate.recv() => {} }
        let _ = shutdown.send(true);
        let _finished = active.write().await;
        connection.close().await.map_err(|error| error.to_string())
    })
}

pub fn read(path: PathBuf, result: PathBuf) -> Result<selector::Selector, String> {
    let request = serde_json::from_slice(&std::fs::read(path).map_err(|error| error.to_string())?)
        .map_err(|error| error.to_string())?;
    selector::Selector::new(request, result)
}
