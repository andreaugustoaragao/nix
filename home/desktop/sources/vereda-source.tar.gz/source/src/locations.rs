use gio::prelude::*;
use serde::Serialize;
use std::{fs, path::PathBuf};

#[derive(Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum PlaceKind {
    Favorite,
    Location,
    Device,
}

#[derive(Clone, Serialize)]
pub struct Place {
    pub kind: PlaceKind,
    pub name: String,
    pub uri: String,
    pub path: Option<PathBuf>,
    pub volume: Option<String>,
    pub icon_name: Option<String>,
    pub mounted: bool,
    pub eject: bool,
    pub unmount: bool,
}

impl Place {
    pub fn key(&self) -> String {
        let (kind, id) = self
            .volume
            .as_deref()
            .map_or(("uri", self.uri.as_str()), |volume| ("volume", volume));
        format!(
            "place:{kind}:{}",
            url::form_urlencoded::byte_serialize(id.as_bytes()).collect::<String>()
        )
    }
}

fn device_icon(icon: gio::Icon) -> Option<String> {
    icon.downcast_ref::<gio::ThemedIcon>()?
        .names()
        .first()
        .map(ToString::to_string)
}

pub fn places() -> Vec<Place> {
    let home = crate::state::home();
    let mut places = Vec::new();
    for (name, path) in [
        ("Home", home.clone()),
        ("Downloads", home.join("Downloads")),
        ("Desktop", home.join("Desktop")),
        ("Documents", home.join("Documents")),
        ("Pictures", home.join("Pictures")),
        ("Filesystem", PathBuf::from("/")),
    ] {
        if path.is_dir() {
            places.push(Place {
                kind: PlaceKind::Location,
                name: name.into(),
                uri: gio::File::for_path(&path).uri().to_string(),
                path: Some(path),
                volume: None,
                icon_name: None,
                mounted: true,
                eject: false,
                unmount: false,
            });
        }
    }
    for line in fs::read_to_string(bookmark_path())
        .unwrap_or_default()
        .lines()
    {
        let (uri, name) = line.split_once(' ').unwrap_or((line, ""));
        if url::Url::parse(uri).is_err()
            || places
                .iter()
                .any(|p| p.kind == PlaceKind::Favorite && p.uri == uri)
        {
            continue;
        }
        let name = if name.is_empty() {
            gio::File::for_uri(uri)
                .basename()
                .map(|p| p.to_string_lossy().into_owned())
                .unwrap_or_else(|| uri.into())
        } else {
            name.into()
        };
        places.push(Place {
            kind: PlaceKind::Favorite,
            name,
            uri: uri.into(),
            path: gio::File::for_uri(uri).path(),
            volume: None,
            icon_name: None,
            mounted: uri.starts_with("file:"),
            eject: false,
            unmount: false,
        });
    }
    places.push(Place {
        kind: PlaceKind::Location,
        name: "Trash".into(),
        uri: "trash:///".into(),
        path: None,
        volume: None,
        icon_name: None,
        mounted: true,
        eject: false,
        unmount: false,
    });
    let monitor = gio::VolumeMonitor::get();
    for volume in monitor.volumes() {
        let id = volume
            .uuid()
            .map(|s| s.to_string())
            .unwrap_or_else(|| volume.name().to_string());
        let mount = volume.get_mount();
        let uri = mount
            .as_ref()
            .map(|m| m.root().uri().to_string())
            .or_else(|| volume.activation_root().map(|f| f.uri().to_string()))
            .unwrap_or_default();
        places.push(Place {
            kind: PlaceKind::Device,
            name: volume.name().to_string(),
            uri,
            path: mount.as_ref().and_then(|mount| mount.root().path()),
            volume: Some(id),
            icon_name: device_icon(volume.icon()),
            mounted: mount.is_some(),
            eject: volume.can_eject(),
            unmount: mount.as_ref().is_some_and(|m| m.can_unmount()),
        });
    }
    for mount in monitor.mounts() {
        let uri = mount.root().uri().to_string();
        for favorite in places
            .iter_mut()
            .filter(|p| p.kind == PlaceKind::Favorite && p.uri == uri)
        {
            favorite.path = mount.root().path();
            favorite.mounted = true;
        }
        if let Some(place) = places
            .iter_mut()
            .find(|p| p.kind == PlaceKind::Device && p.uri == uri)
        {
            place.icon_name = device_icon(mount.icon());
            place.path = mount.root().path();
            place.mounted = true;
            place.eject = mount.can_eject();
            place.unmount = mount.can_unmount();
            if place.name == uri {
                place.name = mount.name().to_string();
            }
        } else {
            places.push(Place {
                kind: PlaceKind::Device,
                name: mount.name().to_string(),
                uri,
                path: mount.root().path(),
                volume: None,
                icon_name: device_icon(mount.icon()),
                mounted: true,
                eject: mount.can_eject(),
                unmount: mount.can_unmount(),
            });
        }
    }
    places
}

fn bookmark_path() -> PathBuf {
    crate::state::xdg_config_home().join("gtk-3.0/bookmarks")
}

pub enum Bookmark {
    Pin(Vec<String>),
    Remove(String),
    Rename {
        uri: String,
        label: String,
    },
    Reorder {
        uris: Vec<String>,
        before: Option<String>,
    },
}

fn bookmark_flags(file: &gio::File) -> gio::FileCreateFlags {
    let private = gio::FileCreateFlags::PRIVATE;
    let symlink = file
        .query_info(
            "standard::is-symlink",
            gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
            gio::Cancellable::NONE,
        )
        .is_ok_and(|info| info.is_symlink());
    if !symlink {
        return private;
    }
    let writable = file
        .query_info(
            "access::can-write",
            gio::FileQueryInfoFlags::NONE,
            gio::Cancellable::NONE,
        )
        .is_ok_and(|info| info.boolean("access::can-write"));
    if writable {
        private
    } else {
        // Replace this alias. Following a read-only target fails with ELOOP
        // and would write through into a managed store file.
        private | gio::FileCreateFlags::REPLACE_DESTINATION
    }
}

fn bookmark_unchanged(
    file: &gio::File,
    contents: &str,
    etag: Option<&str>,
) -> Result<bool, String> {
    match file.load_contents(gio::Cancellable::NONE) {
        Ok((current, current_etag)) => {
            Ok(current.as_ref() == contents.as_bytes() && current_etag.as_deref() == etag)
        }
        Err(error) => Err(error.to_string()),
    }
}

pub fn edit_bookmarks(edit: Bookmark) -> Result<String, String> {
    let path = bookmark_path();
    fs::create_dir_all(path.parent().expect("bookmark parent")).map_err(|e| e.to_string())?;
    let file = gio::File::for_path(path);
    let uri_of = |line: &str| line.split_once(' ').map_or(line, |(uri, _)| uri).to_owned();
    if let Bookmark::Pin(uris) = &edit {
        if uris.is_empty() {
            return Err("Choose a folder to add to Favorites".into());
        }
        for uri in uris {
            url::Url::parse(uri).map_err(|e| e.to_string())?;
            if uri.chars().any(char::is_whitespace) || uri.contains('\0') {
                return Err("Enter a valid folder URI".into());
            }
            if uri.starts_with("file:")
                && gio::File::for_uri(uri)
                    .query_file_type(gio::FileQueryInfoFlags::NONE, gio::Cancellable::NONE)
                    != gio::FileType::Directory
            {
                return Err("Only folders can be added to Favorites".into());
            }
        }
    }
    if let Bookmark::Rename { label, .. } = &edit
        && (label.trim().is_empty() || label.contains(['\r', '\n', '\0']))
    {
        return Err("Enter a favorite label on one line".into());
    }
    for _ in 0..3 {
        let (contents, etag) = match file.load_contents(gio::Cancellable::NONE) {
            Ok((contents, etag)) => (
                String::from_utf8(contents.to_vec())
                    .map_err(|_| "Favorites file is not valid UTF-8")?,
                etag,
            ),
            Err(error) if error.matches(gio::IOErrorEnum::NotFound) => {
                match file.create(gio::FileCreateFlags::PRIVATE, gio::Cancellable::NONE) {
                    Ok(stream) => {
                        stream
                            .close(gio::Cancellable::NONE)
                            .map_err(|error| error.to_string())?;
                    }
                    Err(error) if error.matches(gio::IOErrorEnum::Exists) => {}
                    Err(error) => return Err(error.to_string()),
                }
                continue;
            }
            Err(error) => return Err(error.to_string()),
        };
        let mut lines: Vec<_> = contents.lines().map(str::to_owned).collect();
        let message = match &edit {
            Bookmark::Pin(uris) => {
                for uri in uris {
                    if !lines.iter().any(|line| uri_of(line) == *uri) {
                        lines.push(uri.clone());
                    }
                }
                "Added to Favorites"
            }
            Bookmark::Remove(uri) => {
                lines.retain(|line| uri_of(line) != *uri);
                "Removed from Favorites"
            }
            Bookmark::Rename { uri, label } => {
                let line = lines
                    .iter_mut()
                    .find(|line| uri_of(line) == *uri)
                    .ok_or("This favorite was removed")?;
                *line = format!("{uri} {}", label.trim());
                "Favorite label saved"
            }
            Bookmark::Reorder { uris, before } => {
                if before.as_ref().is_some_and(|before| uris.contains(before)) {
                    return Ok("Favorite order unchanged".into());
                }
                for uri in uris {
                    url::Url::parse(uri).map_err(|error| error.to_string())?;
                    if uri.chars().any(char::is_whitespace) || uri.contains('\0') {
                        return Err("Enter a valid folder URI".into());
                    }
                    if !lines.iter().any(|line| uri_of(line) == *uri)
                        && gio::File::for_uri(uri)
                            .query_file_type(gio::FileQueryInfoFlags::NONE, gio::Cancellable::NONE)
                            != gio::FileType::Directory
                    {
                        return Err("Only folders can be added to Favorites".into());
                    }
                }
                let mut moved = Vec::new();
                for uri in uris {
                    if moved.iter().any(|line: &String| uri_of(line) == *uri) {
                        continue;
                    }
                    moved.push(
                        lines
                            .iter()
                            .find(|line| uri_of(line) == *uri)
                            .cloned()
                            .unwrap_or_else(|| uri.clone()),
                    );
                }
                lines.retain(|line| !uris.contains(&uri_of(line)));
                let index = before
                    .as_ref()
                    .and_then(|uri| lines.iter().position(|line| uri_of(line) == *uri))
                    .unwrap_or(lines.len());
                lines.splice(index..index, moved);
                "Favorites updated"
            }
        };
        let data = if lines.is_empty() {
            String::new()
        } else {
            format!("{}\n", lines.join("\n"))
        };
        if data == contents {
            return Ok(message.into());
        }
        let flags = bookmark_flags(&file);
        if flags.contains(gio::FileCreateFlags::REPLACE_DESTINATION)
            && !bookmark_unchanged(&file, &contents, etag.as_deref())?
        {
            continue;
        }
        match file.replace_contents(
            data.as_bytes(),
            etag.as_deref(),
            false,
            flags,
            gio::Cancellable::NONE,
        ) {
            Ok(_) => return Ok(message.into()),
            Err(error) if error.matches(gio::IOErrorEnum::WrongEtag) => continue,
            Err(error)
                if error.matches(gio::IOErrorEnum::TooManyLinks)
                    && !flags.contains(gio::FileCreateFlags::REPLACE_DESTINATION) =>
            {
                if !bookmark_unchanged(&file, &contents, etag.as_deref())? {
                    continue;
                }
                match file.replace_contents(
                    data.as_bytes(),
                    etag.as_deref(),
                    false,
                    flags | gio::FileCreateFlags::REPLACE_DESTINATION,
                    gio::Cancellable::NONE,
                ) {
                    Ok(_) => return Ok(message.into()),
                    Err(error) if error.matches(gio::IOErrorEnum::WrongEtag) => continue,
                    Err(error) => return Err(error.to_string()),
                }
            }
            Err(error) => return Err(error.to_string()),
        }
    }
    Err("Favorites changed in another application; try again".into())
}

#[derive(Clone, Serialize)]
pub struct Properties {
    pub path: PathBuf,
    pub name: String,
    pub kind: String,
    pub mime: String,
    pub size: String,
    pub owner: String,
    pub group: String,
    pub modified: String,
    pub created: String,
    pub link_target: Option<String>,
    pub mode: Option<u32>,
    pub directory: bool,
    pub remote: bool,
    pub can_change_mode: bool,
}

pub fn properties(
    path: PathBuf,
    uri: Option<String>,
    cancel: gio::Cancellable,
) -> Result<Properties, String> {
    let remote = uri.is_some();
    let file = uri.map_or_else(
        || gio::File::for_path(&path),
        |uri| gio::File::for_uri(&uri),
    );
    let info = file
        .query_info(
            "standard::*,time::*,unix::*,owner::*,access::*",
            gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
            Some(&cancel),
        )
        .map_err(|e| e.to_string())?;
    let mime = info.content_type().map(|value| value.to_string());
    let kind: String = match info.file_type() {
        gio::FileType::Directory => "Folder".into(),
        gio::FileType::SymbolicLink => "Symbolic link".into(),
        gio::FileType::Regular => mime
            .as_deref()
            .map(gio::content_type_get_description)
            .map(|value| value.to_string())
            .unwrap_or_else(|| "File".into()),
        _ => "Other".into(),
    };
    let date = |key| {
        if info.has_attribute(key) {
            gio::glib::DateTime::from_unix_local(info.attribute_uint64(key) as i64)
                .and_then(|time| time.format("%Y-%m-%d %H:%M:%S"))
                .map(|value| value.to_string())
                .unwrap_or_else(|_| "Unavailable".into())
        } else {
            "Unavailable".into()
        }
    };
    let mode = info
        .has_attribute("unix::mode")
        .then(|| info.attribute_uint32("unix::mode") & 0o7777);
    let can_change_mode = !remote
        && info.file_type() != gio::FileType::SymbolicLink
        && mode.is_some()
        && info.has_attribute("unix::uid")
        && info.attribute_uint32("unix::uid") == unsafe { libc::geteuid() };
    let name = path
        .file_name()
        .map(|name| name.to_string_lossy().into_owned())
        .unwrap_or_default();
    Ok(Properties {
        path,
        name,
        kind,
        mime: mime.unwrap_or_else(|| "Unavailable".into()),
        size: if info.file_type() == gio::FileType::Directory {
            "Folder size is not calculated".into()
        } else {
            format!(
                "{} ({} bytes)",
                crate::file::human_size(info.size().max(0) as u64),
                info.size().max(0)
            )
        },
        owner: info
            .attribute_as_string("owner::user")
            .map(|s| s.to_string())
            .unwrap_or_else(|| "Unavailable".into()),
        group: info
            .attribute_as_string("owner::group")
            .map(|s| s.to_string())
            .unwrap_or_else(|| "Unavailable".into()),
        modified: date("time::modified"),
        created: date("time::created"),
        link_target: if info.has_attribute("standard::symlink-target") {
            info.symlink_target()
                .map(|target| target.display().to_string())
        } else {
            None
        },
        mode,
        directory: info.file_type() == gio::FileType::Directory,
        remote,
        can_change_mode,
    })
}

#[derive(Clone, Serialize)]
pub struct Application {
    pub id: String,
    pub name: String,
    pub recommended: bool,
    pub default: bool,
    #[serde(skip)]
    pub icon: Option<rune::Image>,
}
#[derive(Clone, Serialize)]
pub struct Applications {
    pub paths: Vec<PathBuf>,
    pub mime: String,
    pub description: String,
    pub apps: Vec<Application>,
}

pub fn applications(paths: Vec<PathBuf>, uri: Option<String>) -> Result<Applications, String> {
    let path = paths.first().ok_or("Select a file first")?;
    let info = uri
        .map_or_else(|| gio::File::for_path(path), |uri| gio::File::for_uri(&uri))
        .query_info(
            "standard::content-type",
            gio::FileQueryInfoFlags::NONE,
            gio::Cancellable::NONE,
        )
        .map_err(|e| e.to_string())?;
    let mime = info
        .content_type()
        .map(|s| s.to_string())
        .unwrap_or_default();
    let compatible = gio::AppInfo::all_for_type(&mime);
    let default = gio::AppInfo::default_for_type(&mime, false).and_then(|app| app.id());
    let mut apps: Vec<_> = gio::AppInfo::all()
        .into_iter()
        .filter(|app| app.should_show() && (app.supports_files() || app.supports_uris()))
        .filter_map(|app| {
            app.id().map(|id| Application {
                default: default.as_deref() == Some(&id),
                recommended: compatible.iter().any(|candidate| candidate.equal(&app)),
                id: id.to_string(),
                name: app.display_name().to_string(),
                icon: None,
            })
        })
        .collect();
    apps.sort_by_cached_key(|app| {
        (
            !app.default,
            !app.recommended,
            app.name.to_lowercase(),
            app.id.clone(),
        )
    });
    let description = gio::content_type_get_description(&mime).to_string();
    Ok(Applications {
        paths,
        mime,
        description,
        apps,
    })
}

impl Applications {
    pub fn load_icons(&mut self, cache: &rune::ImageCache) {
        for app in &mut self.apps {
            app.icon = gio::DesktopAppInfo::new(&app.id)
                .and_then(|info| info.filename())
                .map(|path| cache.app_icon(path, 28.0));
        }
    }
}

#[derive(Clone)]
pub enum Launch {
    Default(String),
    Application {
        paths: Vec<PathBuf>,
        uri: Option<String>,
        id: String,
        default: bool,
    },
}

impl Launch {
    pub fn run(self) -> Result<String, String> {
        match self {
            Self::Default(uri) => {
                gio::AppInfo::launch_default_for_uri(&uri, None::<&gio::AppLaunchContext>)
                    .map_err(|error| format!("Could not open file: {error}"))?;

                Ok("Opened in default application".into())
            }
            Self::Application {
                paths,
                uri,
                id,
                default,
            } => applications(paths, uri).and_then(|apps| launch(apps, id, default)),
        }
    }
}

pub fn launch(applications: Applications, id: String, default: bool) -> Result<String, String> {
    let app = gio::AppInfo::all()
        .into_iter()
        .find(|app| app.id().as_deref() == Some(&id))
        .ok_or("Application is no longer installed")?;
    let files: Vec<_> = applications.paths.iter().map(gio::File::for_path).collect();
    app.launch(&files, None::<&gio::AppLaunchContext>)
        .map_err(|e| e.to_string())?;
    if default && applications.paths.len() == 1 {
        app.set_as_default_for_type(&applications.mime)
            .map_err(|e| e.to_string())?;
    }
    Ok(format!("Opened with {}", app.display_name()))
}

pub fn local_uri(uri: &str) -> Result<PathBuf, String> {
    gio::File::for_uri(uri)
        .path()
        .ok_or_else(|| "Mount this location first; GVFS/FUSE is required for remote files".into())
}

pub fn launch_custom(paths: Vec<PathBuf>, program: PathBuf) -> Result<String, String> {
    use std::os::unix::fs::PermissionsExt;

    let metadata = std::fs::metadata(&program).map_err(|error| error.to_string())?;
    if !metadata.is_file() || metadata.permissions().mode() & 0o111 == 0 {
        return Err("Choose an executable application".into());
    }
    let command = gio::glib::shell_quote(program.as_os_str())
        .to_string_lossy()
        .into_owned();
    let app = gio::AppInfo::create_from_commandline(&command, None, gio::AppInfoCreateFlags::NONE)
        .map_err(|e| e.to_string())?;
    let files: Vec<_> = paths.iter().map(gio::File::for_path).collect();
    app.launch(&files, None::<&gio::AppLaunchContext>)
        .map_err(|e| e.to_string())?;
    Ok("Opened with custom program".into())
}

#[derive(Clone)]
pub enum Location {
    Path(PathBuf),
    Uri(String),
}
impl Location {
    pub fn parse(value: &str, cwd: &std::path::Path) -> Result<Self, String> {
        if !value.contains("://") && !value.starts_with("file:") {
            return Ok(Self::Path(crate::state::expand_path(value, cwd)));
        }
        let mut uri = url::Url::parse(value).map_err(|e| e.to_string())?;
        if uri.scheme() == "file" {
            return uri
                .to_file_path()
                .map(Self::Path)
                .map_err(|_| "A file URI must refer to this computer".into());
        }
        // Credentials are requested through the secure authentication dialog.
        let _ = uri.set_password(None);
        Ok(Self::Uri(uri.to_string()))
    }
    pub fn argument(&self) -> &std::ffi::OsStr {
        match self {
            Self::Path(path) => path.as_os_str(),
            Self::Uri(uri) => std::ffi::OsStr::new(uri),
        }
    }
    pub fn folder(&self) -> bool {
        match self {
            Self::Path(path) => path.is_dir(),
            Self::Uri(_) => true,
        }
    }
}
