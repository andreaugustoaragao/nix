use rune::{Color, El, SurfaceFit, col, el, row, text};

use crate::{
    file::{self, File, SortBy},
    icon,
    preference::DetailColumn,
    state::State,
    theme::Theme,
};

fn columns(s: &State, side: usize) -> Vec<(DetailColumn, f32)> {
    let pane = &s.panes[side];
    pane.tab().preference.details.columns(pane.list_width)
}

fn sort_by(column: DetailColumn) -> SortBy {
    match column {
        DetailColumn::Name => SortBy::Alphabetical,
        DetailColumn::Size => SortBy::Size,
        DetailColumn::Modified => SortBy::Modified,
        DetailColumn::Type => SortBy::Extension,
        DetailColumn::Owner => SortBy::Owner,
    }
}

fn sort_column(s: &mut State, side: usize, sort: SortBy, tx: &mut rune::Tx) {
    s.activate_pane(side, tx);
    let mut preference = s.tab().preference;
    if preference.sort_by == sort {
        preference.sort_reverse = !preference.sort_reverse;
    } else {
        preference.sort_by = sort;
        preference.sort_reverse = matches!(sort, SortBy::Size | SortBy::Modified);
    }
    s.set_folder_view(Some(preference), tx);
}

pub fn header(s: &State, side: usize, p: Theme) -> El {
    let preference = s.panes[side].tab().preference;
    let mut heading = row()
        .key(format!("details-header-{side}"))
        .role("row")
        .w_full()
        .h(p.height(32.0))
        .fill(p.panel)
        .children(columns(s, side).into_iter().map(|(column, width)| {
            let sort = sort_by(column);
            let active = preference.sort_by == sort;
            let label = column.label();
            let title = text(label)
                .font(p.font(11.0, 600.0))
                .color(if active { p.text } else { p.muted })
                .truncate()
                .align(if column == DetailColumn::Size {
                    rune::Align::End
                } else {
                    rune::Align::Start
                })
                .grow(1.0)
                .min_w(0.0);
            let arrow = if active {
                rune::icon(
                    if preference.sort_reverse {
                        &icon::SORT_DESCENDING
                    } else {
                        &icon::SORT_ASCENDING
                    },
                    12.0,
                )
                .color(p.muted)
            } else {
                el().w(12.0)
            };
            let control = row()
                .key(format!("details-sort-{side}-{}", label.to_lowercase()))
                .role("button")
                .label(format!("Sort by {label}"))
                .focusable(true)
                .grow(1.0)
                .min_w(0.0)
                .h_full()
                .px(p.space(2))
                .pl(if column == DetailColumn::Name {
                    20.0 + p.space(4)
                } else {
                    p.space(2)
                })
                .pr(if column == DetailColumn::Size {
                    2.0
                } else {
                    p.space(2)
                })
                .center_y()
                .gap(p.space(1))
                .cursor(rune::Cursor::Pointer)
                .focus_ring(2.0, 0.0, p.accent)
                .on_press_tx(move |s: &mut State, tx| sort_column(s, side, sort, tx))
                .on_key(move |s: &mut State, key, tx| {
                    if matches!(key.key, rune::Key::Enter)
                        || matches!(key.key, rune::Key::Text(ref value) if value == " ")
                    {
                        sort_column(s, side, sort, tx);
                        true
                    } else {
                        false
                    }
                });
            let control = if column == DetailColumn::Size {
                control.child(arrow).child(title)
            } else {
                control.child(title).child(arrow)
            };
            let mut cell = row()
                .role("columnheader")
                .label(label)
                .w(width)
                .h_full()
                .center_y()
                .child(control);
            let resize = el()
                .key(format!("details-resize-{side}-{}", label.to_lowercase()))
                .role("separator")
                .label(format!("Resize {label} column"))
                .focusable(true)
                .w(6.0)
                .h_full()
                .cursor(rune::Cursor::ResizeColumn)
                .hover(p.accent.alpha(0.5))
                .focus_ring(2.0, 0.0, p.accent)
                .range_value(width as f64, column.minimum() as f64, 600.0)
                .range_step(8.0)
                .on_step(move |s: &mut State, step, _| {
                    s.resize_detail_column(side, column, width + step as f32 * 8.0);
                })
                .on_key(move |s: &mut State, key, _| {
                    let step = match key.key {
                        rune::Key::Left => -8.0,
                        rune::Key::Right => 8.0,
                        _ => return false,
                    };
                    s.resize_detail_column(side, column, width + step);
                    true
                })
                .on_drag(move |s: &mut State, drag, tx| {
                    if drag.phase == rune::Phase::Down {
                        drag.data = width;
                    }
                    if drag.phase == rune::Phase::Move {
                        s.resize_detail_column(side, column, drag.data + drag.dx / s.zoom_factor());
                        tx.instant();
                    }
                });
            cell = cell.child(resize);
            cell
        }));
    heading = heading.child(el().grow(1.0));
    col()
        .w_full()
        .child(heading)
        .child(el().w_full().h(1.0).fill(p.line.alpha(0.6)))
}

pub fn file_row(
    s: &State,
    side: usize,
    file: &File,
    hovered: bool,
    selected: bool,
    p: Theme,
    thumbnail: Option<&rune::Image>,
) -> El {
    let mut content = row()
        .key("file-surface")
        .w_full()
        .h_full()
        .center_y()
        .radius(p.space(2))
        .fill(if hovered {
            p.selected
        } else if selected {
            p.selected.alpha(0.5)
        } else {
            Color::TRANSPARENT
        })
        .hover(p.selected.alpha(0.45));
    for (column, width) in columns(s, side) {
        content = content.child(match column {
            DetailColumn::Name => name_cell(file, selected, side, thumbnail, width, p),
            _ => {
                let value = match column {
                    DetailColumn::Size => {
                        if file.directory {
                            "—".into()
                        } else {
                            file::human_size(file.size)
                        }
                    }
                    DetailColumn::Modified => modified(file),
                    DetailColumn::Type => kind(file),
                    DetailColumn::Owner => file.owner.clone(),
                    DetailColumn::Name => unreachable!(),
                };
                text(value)
                    .font(p.font(11.0, 400.0).features("'tnum' 1"))
                    .color(p.muted)
                    .truncate()
                    .align(if column == DetailColumn::Size {
                        rune::Align::End
                    } else {
                        rune::Align::Start
                    })
                    .w(width)
                    .px(p.space(2))
            }
        });
    }
    el().key(file.key.clone())
        .role("listitem")
        .label(file.name.clone())
        .w_full()
        .h(p.row())
        .child(content)
}

fn name_cell(
    file: &File,
    selected: bool,
    side: usize,
    thumbnail: Option<&rune::Image>,
    width: f32,
    p: Theme,
) -> El {
    let glyph = icon::for_file(file);
    let path = file.path.clone();
    row()
        .w(width)
        .h_full()
        .px(p.space(2))
        .gap(p.space(2))
        .center_y()
        .child(if let Some(image) = thumbnail {
            el().w(20.0)
                .h(24.0)
                .pixels_fit(image.pixels(), SurfaceFit::Fit)
        } else {
            el().w(20.0)
                .h(20.0)
                .center()
                .child(rune::icon(glyph, 19.0).color(if file.directory {
                    p.folder
                } else {
                    p.muted
                }))
        })
        .child(
            text(&file.name)
                .key("filename")
                .font(p.list())
                .color(p.text)
                .truncate()
                .grow(1.0)
                .min_w(0.0),
        )
        .child(if file.symlink {
            rune::icon(&icon::LINK, 12.0).color(p.muted)
        } else {
            el()
        })
        .child(
            el().key("selection")
                .role("checkbox")
                .label(format!("Select {}", file.name))
                .checked(selected)
                .w(20.0)
                .h(p.height(24.0))
                .center()
                .cursor(rune::Cursor::Pointer)
                .focus_ring(2.0, 0.0, p.accent)
                .on_press_tx(move |s: &mut State, tx| {
                    s.activate_pane(side, tx);
                    s.toggle_selection(&path);
                })
                .child(
                    el().w(16.0)
                        .h(16.0)
                        .radius(p.space(1))
                        .border(1.0, p.accent)
                        .fill(if selected {
                            p.accent
                        } else {
                            Color::TRANSPARENT
                        })
                        .group_opacity(if selected { 1.0 } else { 0.0 }, 1.0)
                        .child(if selected {
                            rune::icon(&icon::CHECK, 13.0).color(p.background)
                        } else {
                            el()
                        }),
                ),
        )
}

fn modified(file: &File) -> String {
    file.modified
        .and_then(|time| time.duration_since(std::time::SystemTime::UNIX_EPOCH).ok())
        .and_then(|duration| gio::glib::DateTime::from_unix_local(duration.as_secs() as i64).ok())
        .and_then(|date| date.format("%d %b %Y, %H:%M").ok())
        .map(|value| value.to_string())
        .unwrap_or_else(|| "—".into())
}

fn kind(file: &File) -> String {
    if file.directory {
        return "Folder".into();
    }
    let extension = file
        .path
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    match extension.as_str() {
        "rs" => "Rust source".into(),
        "md" | "markdown" => "Markdown document".into(),
        "txt" => "Text document".into(),
        "png" | "jpg" | "jpeg" | "gif" | "webp" => "Image".into(),
        "pdf" => "PDF document".into(),
        "zip" | "tar" | "gz" => "Archive".into(),
        "" => "File".into(),
        value => format!("{} file", value.to_ascii_uppercase()),
    }
}
