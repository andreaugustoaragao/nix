use std::{
    collections::BTreeMap,
    fs,
    io::{self, Read, Write},
    path::{Path, PathBuf},
};

use serde::{Deserialize, Serialize};

use crate::{
    file::SortBy,
    keymap::{Binding, Strings},
    preference::{Details, Preference, ViewMode},
    scheme::{self, Scheme},
    session::Session,
    state,
    step::Step,
};

const MAX_LEGACY_BYTES: u64 = 4 * 1024 * 1024;
const MARKER_FILE: &str = "migration.json";
const LOCK_FILE: &str = "migration.lock";

#[derive(Serialize)]
struct MigrationRecord {
    version: u32,
    imported: Vec<String>,
    warnings: Vec<String>,
}

#[derive(Default, Serialize)]
struct ImportedBrowser {
    #[serde(skip_serializing_if = "Option::is_none")]
    view_mode: Option<ViewMode>,
    #[serde(skip_serializing_if = "Option::is_none")]
    show_hidden: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    sort_sensitive: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    sort_dir_first: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    sort_reverse: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    sort_by: Option<SortBy>,
    #[serde(skip_serializing_if = "Option::is_none")]
    details: Option<Details>,
}

impl ImportedBrowser {
    fn has_any(&self) -> bool {
        self.view_mode.is_some()
            || self.show_hidden.is_some()
            || self.sort_sensitive.is_some()
            || self.sort_dir_first.is_some()
            || self.sort_reverse.is_some()
            || self.sort_by.is_some()
            || self.details.is_some()
    }
}

#[derive(Serialize)]
struct BrowserConfig {
    browser: ImportedBrowser,
}

#[derive(Default, Deserialize)]
struct VerifyConfig {
    #[serde(default)]
    #[allow(dead_code)]
    browser: Preference,
}

#[derive(Default, Deserialize)]
struct LegacyKeymapSection {
    #[serde(default)]
    keymap: Vec<Binding>,
    #[serde(default)]
    prepend_keymap: Vec<Binding>,
    #[serde(default)]
    append_keymap: Vec<Binding>,
}

#[derive(Default, Deserialize)]
struct LegacyKeymapFile {
    mgr: Option<LegacyKeymapSection>,
    manager: Option<LegacyKeymapSection>,
}

#[derive(Serialize)]
#[serde(untagged)]
enum OutStrings<'a> {
    One(&'a str),
    Many(&'a [String]),
}

#[derive(Serialize)]
struct OutBinding<'a> {
    on: OutStrings<'a>,
    run: OutStrings<'a>,
    #[serde(skip_serializing_if = "str::is_empty")]
    desc: &'a str,
}

#[derive(Serialize)]
struct OutKeymapSection<'a> {
    #[serde(skip_serializing_if = "Vec::is_empty")]
    keymap: Vec<OutBinding<'a>>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    prepend_keymap: Vec<OutBinding<'a>>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    append_keymap: Vec<OutBinding<'a>>,
}

#[derive(Serialize)]
struct OutKeymapConfig<'a> {
    browser: OutKeymapSection<'a>,
}

pub fn migrate_once() {
    let vereda_state = state::default_state_dir();
    let marker = vereda_state.join(MARKER_FILE);
    if fs::symlink_metadata(&marker).is_ok() {
        return;
    }
    if let Err(error) = fs::create_dir_all(&vereda_state) {
        eprintln!(
            "Vereda settings import skipped ({}): {error}",
            vereda_state.display()
        );
        return;
    }
    let lock = match fs::OpenOptions::new()
        .create(true)
        .truncate(false)
        .read(true)
        .write(true)
        .open(vereda_state.join(LOCK_FILE))
    {
        Ok(lock) => lock,
        Err(error) => {
            eprintln!("Vereda settings import lock failed: {error}");
            return;
        }
    };
    if let Err(error) = lock.lock() {
        eprintln!("Vereda settings import lock failed: {error}");
        return;
    }
    if fs::symlink_metadata(&marker).is_ok() {
        return;
    }

    let xdg_config = state::xdg_config_home();
    let xdg_state = state::xdg_state_home();
    let vereda_config = state::default_config_dir();
    let legacy_files_config = xdg_config.join("files");
    let legacy_files_state = xdg_state.join("files");
    let legacy_yazi_config = std::env::var_os("YAZI_CONFIG_HOME")
        .filter(|path| !path.is_empty())
        .map(PathBuf::from)
        .unwrap_or_else(|| xdg_config.join("yazi"));
    let legacy_yazi = (legacy_yazi_config != vereda_config).then_some(legacy_yazi_config.as_path());

    let mut imported = Vec::new();
    let mut warnings = Vec::new();
    let mut write_failed = false;

    migrate_schemes(
        &legacy_files_config.join("schemes"),
        &vereda_config.join("schemes"),
        &mut imported,
        &mut warnings,
        &mut write_failed,
    );
    migrate_config(
        &legacy_files_config.join("config.toml"),
        legacy_yazi.map(|dir| dir.join("yazi.toml")).as_deref(),
        &vereda_config.join("config.toml"),
        &mut imported,
        &mut warnings,
        &mut write_failed,
    );
    if let Some(yazi_dir) = legacy_yazi {
        migrate_keymap(
            &yazi_dir.join("keymap.toml"),
            &vereda_config.join("keymap.toml"),
            &mut imported,
            &mut warnings,
            &mut write_failed,
        );
    }
    migrate_folder_views(
        &legacy_files_config.join("folder-views.json"),
        &vereda_config.join("folder-views.json"),
        &mut imported,
        &mut warnings,
        &mut write_failed,
    );
    migrate_session(
        &legacy_files_state.join("session.json"),
        &vereda_state.join("session.json"),
        &mut imported,
        &mut warnings,
        &mut write_failed,
    );

    for warning in &warnings {
        eprintln!("Vereda settings import: {warning}");
    }
    if write_failed {
        return;
    }

    let record = MigrationRecord {
        version: 1,
        imported,
        warnings,
    };
    if let Ok(bytes) = serde_json::to_vec_pretty(&record)
        && let Err(error) = write_noclobber(&marker, &bytes)
    {
        eprintln!(
            "Vereda settings import could not record {}: {error}",
            marker.display()
        );
    }
}

fn destination_absent(path: &Path, warnings: &mut Vec<String>) -> bool {
    match fs::symlink_metadata(path) {
        Ok(_) => false,
        Err(error) if error.kind() == io::ErrorKind::NotFound => true,
        Err(error) => {
            warnings.push(format!("{}: {error}", path.display()));
            false
        }
    }
}

fn read_bounded(path: &Path) -> Result<Option<Vec<u8>>, String> {
    let metadata = match fs::metadata(path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(format!("{}: {error}", path.display())),
    };
    if !metadata.is_file() {
        return Ok(None);
    }
    if metadata.len() > MAX_LEGACY_BYTES {
        return Err(format!(
            "{}: exceeds {} MiB import limit",
            path.display(),
            MAX_LEGACY_BYTES / (1024 * 1024)
        ));
    }
    let file = fs::File::open(path).map_err(|error| format!("{}: {error}", path.display()))?;
    let mut bytes = Vec::new();
    file.take(MAX_LEGACY_BYTES + 1)
        .read_to_end(&mut bytes)
        .map_err(|error| format!("{}: {error}", path.display()))?;
    if bytes.len() as u64 > MAX_LEGACY_BYTES {
        return Err(format!(
            "{}: exceeds {} MiB import limit",
            path.display(),
            MAX_LEGACY_BYTES / (1024 * 1024)
        ));
    }
    Ok(Some(bytes))
}

fn read_utf8_bounded(path: &Path) -> Result<Option<String>, String> {
    let Some(bytes) = read_bounded(path)? else {
        return Ok(None);
    };
    String::from_utf8(bytes)
        .map(Some)
        .map_err(|error| format!("{}: {error}", path.display()))
}

fn write_noclobber(path: &Path, bytes: &[u8]) -> Result<bool, String> {
    let parent = path
        .parent()
        .ok_or_else(|| format!("{}: missing parent directory", path.display()))?;
    fs::create_dir_all(parent).map_err(|error| format!("{}: {error}", parent.display()))?;
    let mut temporary = tempfile::Builder::new()
        .prefix(".vereda-migrate-")
        .tempfile_in(parent)
        .map_err(|error| format!("{}: {error}", parent.display()))?;
    temporary
        .write_all(bytes)
        .map_err(|error| format!("{}: {error}", path.display()))?;
    temporary
        .as_file()
        .sync_all()
        .map_err(|error| format!("{}: {error}", path.display()))?;
    match temporary.persist_noclobber(path) {
        Ok(_) => Ok(true),
        Err(error) if error.error.kind() == io::ErrorKind::AlreadyExists => Ok(false),
        Err(error) => Err(format!("{}: {}", path.display(), error.error)),
    }
}

fn replace_string_field(table: &mut toml_edit::Item, key: &str, from: &str, to: &str) {
    let current = table
        .get(key)
        .and_then(toml_edit::Item::as_value)
        .and_then(toml_edit::Value::as_str);
    if current == Some(from) {
        let mut next = toml_edit::Value::from(to);
        if let Some(old) = table.get(key).and_then(toml_edit::Item::as_value) {
            *next.decor_mut() = old.decor().clone();
        }
        table[key] = toml_edit::Item::Value(next);
    }
}

fn migrate_schemes(
    source_dir: &Path,
    dest_dir: &Path,
    imported: &mut Vec<String>,
    warnings: &mut Vec<String>,
    write_failed: &mut bool,
) {
    let entries = match fs::read_dir(source_dir) {
        Ok(entries) => entries,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_dir.display()));
            return;
        }
    };
    let mut paths = Vec::new();
    for entry in entries {
        match entry {
            Ok(entry) => paths.push(entry.path()),
            Err(error) => warnings.push(format!("{}: {error}", source_dir.display())),
        }
    }
    paths.sort();
    let builtins = scheme::builtins();

    for path in paths {
        if path.extension().and_then(|ext| ext.to_str()) != Some("toml") {
            continue;
        }
        let Some(file_name) = path.file_name() else {
            continue;
        };
        let Some(id) = path.file_stem().and_then(|stem| stem.to_str()) else {
            warnings.push(format!("{}: scheme filename must be UTF-8", path.display()));
            continue;
        };
        if id.is_empty() || id == "system" || builtins.iter().any(|scheme| scheme.id == id) {
            continue;
        }
        let dest = dest_dir.join(file_name);
        if !destination_absent(&dest, warnings) {
            continue;
        }
        let source = match read_utf8_bounded(&path) {
            Ok(Some(source)) => source,
            Ok(None) => continue,
            Err(error) => {
                warnings.push(error);
                continue;
            }
        };
        let mut doc: toml_edit::DocumentMut = match source.parse() {
            Ok(doc) => doc,
            Err(error) => {
                warnings.push(format!("{}: {error}", path.display()));
                continue;
            }
        };
        replace_string_field(doc.as_item_mut(), "extends", "files-dark", "vereda-dark");
        replace_string_field(doc.as_item_mut(), "extends", "files-light", "vereda-light");
        let rendered = doc.to_string();
        if let Err(error) = Scheme::parse(id, &rendered, &builtins) {
            warnings.push(format!("{}: {error}", path.display()));
            continue;
        }
        match write_noclobber(&dest, rendered.as_bytes()) {
            Ok(true) => imported.push(format!("schemes/{}", file_name.to_string_lossy())),
            Ok(false) => {}
            Err(error) => {
                *write_failed = true;
                warnings.push(error);
            }
        }
    }
}

fn extract_browser_section(path: &Path, warnings: &mut Vec<String>) -> Option<String> {
    let source = match read_utf8_bounded(path) {
        Ok(Some(source)) => source,
        Ok(None) => return None,
        Err(error) => {
            warnings.push(error);
            return None;
        }
    };
    let table: toml::Table = match toml::from_str(&source) {
        Ok(table) => table,
        Err(error) => {
            warnings.push(format!("{}: {error}", path.display()));
            return None;
        }
    };
    let mgr = table
        .get("mgr")
        .or_else(|| table.get("manager"))
        .and_then(toml::Value::as_table)?;
    let browser = ImportedBrowser {
        view_mode: mgr
            .get("view_mode")
            .and_then(|value| value.clone().try_into::<ViewMode>().ok()),
        show_hidden: mgr.get("show_hidden").and_then(toml::Value::as_bool),
        sort_sensitive: mgr.get("sort_sensitive").and_then(toml::Value::as_bool),
        sort_dir_first: mgr.get("sort_dir_first").and_then(toml::Value::as_bool),
        sort_reverse: mgr.get("sort_reverse").and_then(toml::Value::as_bool),
        sort_by: mgr
            .get("sort_by")
            .and_then(|value| value.clone().try_into::<SortBy>().ok()),
        details: mgr
            .get("details")
            .and_then(|value| value.clone().try_into::<Details>().ok()),
    };
    if !browser.has_any() {
        return None;
    }
    match toml::to_string_pretty(&BrowserConfig { browser }) {
        Ok(rendered) => Some(rendered),
        Err(error) => {
            warnings.push(format!("{}: {error}", path.display()));
            None
        }
    }
}

fn extract_appearance_section(path: &Path, warnings: &mut Vec<String>) -> Option<String> {
    let source = match read_utf8_bounded(path) {
        Ok(Some(source)) => source,
        Ok(None) => return None,
        Err(error) => {
            warnings.push(error);
            return None;
        }
    };
    let table: toml::Table = match toml::from_str(&source) {
        Ok(table) => table,
        Err(error) => {
            warnings.push(format!("{}: {error}", path.display()));
            return None;
        }
    };
    if !table.contains_key("appearance") {
        return None;
    }
    if let Err(error) = crate::appearance::options(&source) {
        warnings.push(format!("{}: {error}", path.display()));
        return None;
    }
    let mut doc: toml_edit::DocumentMut = match source.parse() {
        Ok(doc) => doc,
        Err(error) => {
            warnings.push(format!("{}: {error}", path.display()));
            return None;
        }
    };
    let mut appearance = doc.remove("appearance")?;
    replace_string_field(
        &mut appearance,
        "light_scheme",
        "files-light",
        "vereda-light",
    );
    replace_string_field(&mut appearance, "dark_scheme", "files-dark", "vereda-dark");
    let mut out = toml_edit::DocumentMut::new();
    out["appearance"] = appearance;
    let rendered = out.to_string();
    if let Err(error) = crate::appearance::options(&rendered) {
        warnings.push(format!("{}: {error}", path.display()));
        return None;
    }
    Some(rendered)
}

fn migrate_config(
    legacy_appearance: &Path,
    legacy_yazi: Option<&Path>,
    dest: &Path,
    imported: &mut Vec<String>,
    warnings: &mut Vec<String>,
    write_failed: &mut bool,
) {
    if !destination_absent(dest, warnings) {
        return;
    }
    let mut sections = Vec::new();
    if let Some(yazi_toml) = legacy_yazi
        && let Some(browser) = extract_browser_section(yazi_toml, warnings)
    {
        let trimmed = browser.trim();
        if !trimmed.is_empty() {
            sections.push(trimmed.to_owned());
        }
    }
    if let Some(appearance) = extract_appearance_section(legacy_appearance, warnings) {
        let trimmed = appearance.trim();
        if !trimmed.is_empty() {
            sections.push(trimmed.to_owned());
        }
    }
    if sections.is_empty() {
        return;
    }
    let mut combined = sections.join("\n\n");
    combined.push('\n');
    if let Err(error) = crate::appearance::options(&combined) {
        warnings.push(format!("{}: {error}", dest.display()));
        return;
    }
    if let Err(error) = toml::from_str::<VerifyConfig>(&combined) {
        warnings.push(format!("{}: {error}", dest.display()));
        return;
    }
    match write_noclobber(dest, combined.as_bytes()) {
        Ok(true) => imported.push("config.toml".into()),
        Ok(false) => {}
        Err(error) => {
            *write_failed = true;
            warnings.push(error);
        }
    }
}

fn is_supported_command(command: &str) -> bool {
    let mut words = command.split_whitespace();
    let Some(action) = words.next() else {
        return false;
    };
    let arg = words.next().unwrap_or_default();
    match action {
        "escape" => !command
            .split_whitespace()
            .skip(1)
            .any(|flag| matches!(flag, "--search" | "--find")),
        "arrow" => arg.parse::<Step>().is_ok(),
        "cd" => command.contains("--interactive") || !arg.is_empty(),
        "sort" => matches!(
            arg,
            "alphabetical" | "natural" | "extension" | "owner" | "size" | "mtime"
        ),
        "copy" => matches!(arg, "filename" | "name_without_ext" | "dirpath" | "path"),
        "view" => matches!(arg, "list" | "details" | "grid"),
        "settings"
        | "picker_accept"
        | "picker_replace"
        | "picker_cancel"
        | "picker_filter"
        | "split"
        | "pane_switch"
        | "copy_to_other"
        | "move_to_other"
        | "sidebar_toggle"
        | "preview_expand"
        | "yank"
        | "unyank"
        | "paste"
        | "link"
        | "hardlink"
        | "remove"
        | "create"
        | "rename"
        | "permissions"
        | "archive"
        | "extract"
        | "undo"
        | "tasks:show"
        | "task_retry"
        | "task_cancel"
        | "restore"
        | "trash_select"
        | "trash_delete"
        | "trash_empty"
        | "trash"
        | "refresh_trash"
        | "quit"
        | "close"
        | "tab_close"
        | "leave"
        | "enter"
        | "open"
        | "open_with"
        | "finder_refresh"
        | "find_files"
        | "browse_application"
        | "connect"
        | "mount_cancel"
        | "places"
        | "bookmark"
        | "favorite_pin_selection"
        | "refresh_places"
        | "back"
        | "forward"
        | "toggle"
        | "toggle_all"
        | "visual_mode"
        | "folder_view"
        | "view_options"
        | "view_reset"
        | "hidden"
        | "sort_reverse"
        | "sort_dir_first"
        | "filter"
        | "new_window"
        | "tab_create"
        | "tab_switch"
        | "tab_swap"
        | "tab_rename"
        | "preview_render"
        | "seek"
        | "help"
        | "spot" => true,
        _ => false,
    }
}

fn supported_binding(binding: &Binding) -> bool {
    let keys = binding.on.list();
    let commands = binding.run.list();
    !keys.is_empty()
        && keys.iter().all(|key| !key.trim().is_empty())
        && !commands.is_empty()
        && commands.iter().all(|cmd| is_supported_command(cmd))
}

fn out_strings(strings: &Strings) -> OutStrings<'_> {
    match strings {
        Strings::One(single) => OutStrings::One(single.as_str()),
        Strings::Many(many) => OutStrings::Many(many.as_slice()),
    }
}

fn out_bindings(bindings: &[Binding]) -> Vec<OutBinding<'_>> {
    bindings
        .iter()
        .map(|binding| OutBinding {
            on: out_strings(&binding.on),
            run: out_strings(&binding.run),
            desc: binding.desc.as_str(),
        })
        .collect()
}

fn migrate_keymap(
    source_path: &Path,
    dest: &Path,
    imported: &mut Vec<String>,
    warnings: &mut Vec<String>,
    write_failed: &mut bool,
) {
    if !destination_absent(dest, warnings) {
        return;
    }
    let source = match read_utf8_bounded(source_path) {
        Ok(Some(source)) => source,
        Ok(None) => return,
        Err(error) => {
            warnings.push(error);
            return;
        }
    };
    let parsed: LegacyKeymapFile = match toml::from_str(&source) {
        Ok(parsed) => parsed,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_path.display()));
            return;
        }
    };
    let Some(mut section) = parsed.mgr.or(parsed.manager) else {
        return;
    };
    let before = section.keymap.len() + section.prepend_keymap.len() + section.append_keymap.len();
    section.keymap.retain(supported_binding);
    section.prepend_keymap.retain(supported_binding);
    section.append_keymap.retain(supported_binding);
    let after = section.keymap.len() + section.prepend_keymap.len() + section.append_keymap.len();
    if before != after {
        warnings.push(format!(
            "{}: skipped {} unsupported keyboard bindings",
            source_path.display(),
            before - after
        ));
    }
    if section.keymap.is_empty()
        && section.prepend_keymap.is_empty()
        && section.append_keymap.is_empty()
    {
        return;
    }
    let out = OutKeymapConfig {
        browser: OutKeymapSection {
            keymap: out_bindings(&section.keymap),
            prepend_keymap: out_bindings(&section.prepend_keymap),
            append_keymap: out_bindings(&section.append_keymap),
        },
    };
    let rendered = match toml::to_string_pretty(&out) {
        Ok(rendered) => rendered,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_path.display()));
            return;
        }
    };
    match write_noclobber(dest, rendered.as_bytes()) {
        Ok(true) => imported.push("keymap.toml".into()),
        Ok(false) => {}
        Err(error) => {
            *write_failed = true;
            warnings.push(error);
        }
    }
}

fn migrate_folder_views(
    source_path: &Path,
    dest: &Path,
    imported: &mut Vec<String>,
    warnings: &mut Vec<String>,
    write_failed: &mut bool,
) {
    if !destination_absent(dest, warnings) {
        return;
    }
    let bytes = match read_bounded(source_path) {
        Ok(Some(bytes)) => bytes,
        Ok(None) => return,
        Err(error) => {
            warnings.push(error);
            return;
        }
    };
    let folders: BTreeMap<String, Preference> = match serde_json::from_slice(&bytes) {
        Ok(folders) => folders,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_path.display()));
            return;
        }
    };
    let rendered = match serde_json::to_vec_pretty(&folders) {
        Ok(rendered) => rendered,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_path.display()));
            return;
        }
    };
    match write_noclobber(dest, &rendered) {
        Ok(true) => imported.push("folder-views.json".into()),
        Ok(false) => {}
        Err(error) => {
            *write_failed = true;
            warnings.push(error);
        }
    }
}

fn migrate_session(
    source_path: &Path,
    dest: &Path,
    imported: &mut Vec<String>,
    warnings: &mut Vec<String>,
    write_failed: &mut bool,
) {
    if !destination_absent(dest, warnings) {
        return;
    }
    let bytes = match read_bounded(source_path) {
        Ok(Some(bytes)) => bytes,
        Ok(None) => return,
        Err(error) => {
            warnings.push(error);
            return;
        }
    };
    let session = match Session::parse(&bytes) {
        Ok(session) => session,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_path.display()));
            return;
        }
    };
    let rendered = match serde_json::to_vec_pretty(&session) {
        Ok(rendered) => rendered,
        Err(error) => {
            warnings.push(format!("{}: {error}", source_path.display()));
            return;
        }
    };
    match write_noclobber(dest, &rendered) {
        Ok(true) => imported.push("session.json".into()),
        Ok(false) => {}
        Err(error) => {
            *write_failed = true;
            warnings.push(error);
        }
    }
}
