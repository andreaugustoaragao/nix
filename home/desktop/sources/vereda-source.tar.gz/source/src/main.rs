mod appearance;
mod appearance_view;
mod archive;
mod chooser;
mod clipboard;
mod code;
mod context;
mod core_dump;
mod desktop;
mod details;
mod dnd;
mod file;
mod finder;
mod font;
mod html;
mod icon;
mod keymap;
mod locations;
mod metadata;
mod migration;
mod mounts;
mod navigation;
mod operations;
mod pane;
mod pdf;
mod peek;
mod portal;
mod preference;
mod printing;
mod properties;
mod properties_view;
mod scheme;
mod search;
mod selector;
mod session;
mod state;
mod step;
mod system_appearance;
mod theme;
mod thumbnail;
mod trash;
mod ui;
mod watcher;

use std::{cell::RefCell, path::PathBuf, rc::Rc};

use rune::{App, AppSpec, WindowOptions};
use state::State;

fn main() {
    if std::env::args_os().nth(1).as_deref() == Some(std::ffi::OsStr::new("--portal")) {
        if let Err(error) = portal::serve() {
            eprintln!("Vereda portal: {error}");
            std::process::exit(1);
        }
        return;
    }
    if std::env::args_os().nth(1).as_deref() == Some(std::ffi::OsStr::new("--zip-metadata")) {
        archive::zip_metadata_main();
        return;
    }
    let mut directory = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
    let mut config_dir = None;
    let mut cwd_file = None;
    let mut state_out = None;
    let mut rune_args = Vec::new();
    let mut reveal = None;
    let mut properties = false;
    let mut remote = None;
    let mut service = false;
    let mut explicit_location = false;
    let mut fresh = false;
    let mut extra = Vec::new();
    let mut picker_request = None;
    let mut picker_result = None;
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--file-picker" => picker_request = args.next().map(PathBuf::from),
            "--picker-result" => picker_result = args.next().map(PathBuf::from),
            "--fresh" => fresh = true,
            "--service" => {
                service = true;
                directory = state::home();
            }
            "--directory" | "--select" | "--properties" | "--config-dir" | "--cwd-file"
            | "--state-out" => {
                let Some(value) = args.next() else {
                    eprintln!("{arg} requires a path");
                    std::process::exit(2)
                };
                match arg.as_str() {
                    "--directory" | "--select" | "--properties" => {
                        explicit_location = true;
                        let location = locations::Location::parse(&value, &directory)
                            .unwrap_or_else(|error| {
                                eprintln!("{error}");
                                std::process::exit(2)
                            });
                        let folders = arg == "--directory";
                        properties = arg == "--properties";
                        match location {
                            locations::Location::Path(path) => {
                                remote = None;
                                if folders {
                                    directory = path;
                                    reveal = None;
                                } else {
                                    directory = path
                                        .parent()
                                        .unwrap_or(std::path::Path::new("/"))
                                        .to_path_buf();
                                    reveal = Some(path);
                                }
                            }
                            locations::Location::Uri(uri) => {
                                remote = Some((uri, folders, properties))
                            }
                        }
                    }
                    "--config-dir" => config_dir = Some(PathBuf::from(value)),
                    "--cwd-file" => cwd_file = Some(PathBuf::from(value)),
                    _ => state_out = Some(PathBuf::from(value)),
                }
            }

            "--help" => {
                println!(
                    "Vereda\n\nUsage: vereda [PATH|URI ...] [Rune options]\n\nApp options:\n  --service             Start hidden for FileManager1 activation\n  --fresh               Start without restoring the last session\n  --directory PATH|URI   Open a folder\n  --select PATH|URI      Reveal an item\n  --properties PATH|URI  Show item properties\n  --config-dir PATH   Read config.toml and keymap.toml here\n  --cwd-file PATH     Save the final directory when quitting with q\n  --state-out PATH    Write final state for headless verification\n\nRune options: --snap PNG, --tree JSON, --script JSON, --theme dark|light, --size WIDTHxHEIGHT"
                );
                return;
            }
            "--snap" | "--tree" | "--trace" | "--script" | "--theme" | "--size" | "--scale"
            | "--at" | "--scene" | "--frames" | "--fps" | "--duration" | "--out" | "--video"
            | "--strip" | "--crop" | "--cols" => {
                rune_args.push(arg);
                if let Some(value) = args.next() {
                    rune_args.push(value);
                }
            }
            _ if !arg.starts_with('-') => {
                let location =
                    locations::Location::parse(&arg, &directory).unwrap_or_else(|error| {
                        eprintln!("{error}");
                        std::process::exit(2)
                    });
                extra.push(location);
            }

            _ => rune_args.push(arg),
        }
    }
    state::set_isolated_config_dir(config_dir.clone());
    if let Some(location) = extra.first() {
        explicit_location = true;
        match location {
            locations::Location::Path(path) => {
                remote = None;
                if path.is_dir() {
                    directory = path.clone();
                    reveal = None;
                } else {
                    directory = path
                        .parent()
                        .unwrap_or(std::path::Path::new("/"))
                        .to_path_buf();
                    reveal = Some(path.clone());
                }
            }
            locations::Location::Uri(uri) => remote = Some((uri.clone(), true, false)),
        }
    }
    let selector = picker_request.map(|request| {
        let result = picker_result.unwrap_or_else(|| request.with_file_name("reply.json"));
        portal::read(request, result).unwrap_or_else(|error| {
            eprintln!("File picker: {error}");
            std::process::exit(2);
        })
    });
    let picking = selector.is_some();
    rune::set_app_id(if picking {
        "io.github.andrearagao.vereda.Picker"
    } else {
        "io.github.andrearagao.vereda"
    });
    if let Some(selector) = &selector {
        directory = selector.request.folder();
        explicit_location = true;
    }
    let native = !rune::tooling::Args::parse_from(rune_args.clone()).headless();
    if native {
        for path in extra.into_iter().skip(1) {
            let folder = path.folder();
            if let Err(error) =
                desktop::spawn_window(path.argument(), folder, false, config_dir.as_deref())
            {
                eprintln!("Could not open window: {error}");
            }
        }
    }
    let spec = AppSpec {
        min_size: Some((680.0, 360.0)),
        families: ("sans-serif", "ui-monospace"),
        setup: Some(|s: &mut State, w| s.setup(w)),
        poll: Some(|s: &mut State, _, tx| s.poll(tx)),
        on_key: Some(|s: &mut State, key, tx| s.key(key, tx)),
        scenes: &[
            ("light", |s| s.dark = Some(false)),
            ("dark", |s| s.dark = Some(true)),
        ],
        ..AppSpec::new(
            "Vereda",
            (1160.0, 740.0),
            || State::new(PathBuf::from("/"), state::isolated_config_dir(), None),
            ui::view,
        )
    };
    let last = Rc::new(RefCell::new(serde_json::Value::Null));
    let capture = last.clone();
    let exporting = state_out.is_some();
    let app = App::new(spec)
        .window_options(WindowOptions {
            visible: !service,
            ..WindowOptions::default()
        })
        .tab_visits_controls(true)
        .keep_running()
        .on_close(|s: &mut State, tx| s.close(tx))
        .on_focus(|s: &mut State, focused, _| {
            s.window_focused = focused;
            if !focused {
                s.peek.close();
            }
        })
        .args(rune_args)
        .init(move || {
            let mut state = State::new(directory, config_dir, cwd_file);
            state.selector = selector;
            if let Some(selector) = &mut state.selector
                && matches!(selector.request.mode, selector::Mode::Save)
            {
                selector.name.focused = true;
                let stem = std::path::Path::new(&selector.name.text)
                    .file_stem()
                    .map_or(selector.name.text.len(), |stem| stem.len());
                selector.name.set_selection(0, stem);
            }
            if picking {
                state.session_path = None;
            }
            if service {
                state.session_path = None;
            } else if !explicit_location && !fresh {
                state.restore_session();
            }
            if let Some(path) = reveal {
                let cwd = state.tab().cwd.clone();
                if path
                    .file_name()
                    .is_some_and(|name| name.as_encoded_bytes().starts_with(b"."))
                {
                    state.tab_mut().preference.show_hidden = true;
                }
                state.tab_mut().hovered.insert(cwd, path);
                state.spot = properties;
            }
            if let Some((uri, folders, properties)) = remote {
                state.startup_uri = Some(uri);
                state.mount_intent = Some((state.active_pane, folders, properties));
            }
            if exporting {
                state.export = Some(capture);
            }
            state
        });
    let handle = app.handle();
    let app = app
        .on_window(move |window| {
            let window = window.clone();
            handle.update(move |state, _| {
                state.dnd = None;
                if state.selector.is_some() {
                    return;
                }
                match dnd::Dnd::attach(window) {
                    Ok(dnd) => state.dnd = dnd,
                    Err(error) => state.message = Some(format!("Drag and drop: {error}")),
                }
            });
        })
        .on_frame_drawn(|runtime| {
            let state = &runtime.state;
            let mut targets = Vec::new();
            let breadcrumbs = [state.breadcrumbs(0), state.breadcrumbs(1)];
            let favorites: Vec<_> = state.favorites().collect();
            let favorite_keys: Vec<_> = favorites
                .iter()
                .map(|place| format!("favorite-{}", place.key()))
                .collect();
            let place_keys: Vec<_> = state
                .places
                .iter()
                .map(|place| format!("sidebar-{}", place.key()))
                .collect();
            for element in runtime.elements() {
                let Some(key) = &element.key else { continue };
                if element.inert
                    || element.exiting
                    || element.visible[2] <= 0.0
                    || element.visible[3] <= 0.0
                {
                    continue;
                }
                if let Some(side) = ["pane-0", "pane-1"]
                    .iter()
                    .position(|candidate| *candidate == key)
                {
                    targets.push(dnd::Target {
                        rect: element.visible,
                        destination: dnd::Destination::Folder(state.panes[side].tab().cwd.clone()),
                    });
                }
                if let Some((side, index)) = key
                    .strip_prefix("breadcrumb-")
                    .and_then(|key| key.split_once('-'))
                    .and_then(|(side, index)| {
                        Some((side.parse::<usize>().ok()?, index.parse::<usize>().ok()?))
                    })
                    && let Some((_, path)) =
                        breadcrumbs.get(side).and_then(|crumbs| crumbs.get(index))
                {
                    targets.push(dnd::Target {
                        rect: element.visible,
                        destination: dnd::Destination::Folder(path.clone()),
                    });
                }
                if key == "favorites" {
                    targets.push(dnd::Target {
                        rect: element.visible,
                        destination: dnd::Destination::Favorites(None),
                    });
                }
                if let Some(index) = favorite_keys.iter().position(|candidate| candidate == key)
                    && let Some(place) = favorites.get(index)
                {
                    let [x, y, width, height] = element.visible;
                    targets.push(dnd::Target {
                        rect: [x, y, width, height / 2.0],
                        destination: dnd::Destination::Favorites(Some(place.uri.clone())),
                    });
                    targets.push(dnd::Target {
                        rect: [x, y + height / 2.0, width, height / 2.0],
                        destination: dnd::Destination::Favorites(
                            favorites.get(index + 1).map(|place| place.uri.clone()),
                        ),
                    });
                }
                if let Some(index) = place_keys.iter().position(|candidate| candidate == key)
                    && let Some(place) = state.places.get(index)
                    && let Some(path) = &place.path
                    && place.kind != locations::PlaceKind::Favorite
                {
                    targets.push(dnd::Target {
                        rect: element.visible,
                        destination: dnd::Destination::Folder(path.clone()),
                    });
                }
                if element.role != "listitem" {
                    continue;
                }
                if let Some(file) = state
                    .panes
                    .iter()
                    .flat_map(|pane| {
                        pane.tab()
                            .files
                            .iter()
                            .chain(&pane.parent)
                            .chain(match &pane.preview {
                                file::Preview::Directory(files) => files.as_slice(),
                                _ => &[],
                            })
                    })
                    .find(|file| file.directory && &file.key == key)
                {
                    targets.push(dnd::Target {
                        rect: element.visible,
                        destination: dnd::Destination::Folder(file.path.clone()),
                    });
                }
            }
            state.drop_targets.replace(targets);
        });
    let _desktop = native.then(|| desktop::Desktop::start(app.handle(), !picking));
    app.run();
    if let Some(path) = state_out
        && let Err(error) = std::fs::write(
            &path,
            serde_json::to_vec_pretty(&*last.borrow()).expect("state JSON"),
        )
    {
        eprintln!("Could not save {}: {error}", path.display());
        std::process::exit(1);
    }
}
