use std::path::Path;

use rune::TextEdit;

use crate::locations::Properties;

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Tab {
    General,
    Permissions,
}

pub struct Dialog {
    pub tab: Tab,
    pub name: TextEdit,
    pub mode: u32,
    pub recursive: bool,
    pub advanced: bool,
}

impl Default for Dialog {
    fn default() -> Self {
        Self {
            tab: Tab::General,
            name: TextEdit::new(""),
            mode: 0,
            recursive: false,
            advanced: false,
        }
    }
}

impl Dialog {
    pub fn new(properties: &Properties) -> Self {
        let mut name = TextEdit::new(properties.name.clone());
        let stem = if properties.directory {
            name.text.len()
        } else {
            Path::new(&name.text)
                .file_stem()
                .map_or(name.text.len(), |stem| stem.as_encoded_bytes().len())
        };
        name.set_selection(0, stem);
        name.focused = true;
        Self {
            tab: Tab::General,
            name,
            mode: properties.mode.unwrap_or_default(),
            recursive: false,
            advanced: false,
        }
    }

    pub fn name_error(&self) -> Option<&'static str> {
        let name = &self.name.text;
        if name.trim().is_empty() {
            Some("Enter a name")
        } else if matches!(name.as_str(), "." | "..") || name.contains(['/', '\0']) {
            Some("Use a name without folder separators")
        } else {
            None
        }
    }

    pub fn dirty(&self, properties: &Properties) -> bool {
        self.name.text != properties.name
            || properties.can_change_mode
                && (self.mode != properties.mode.unwrap_or_default() || self.recursive)
    }

    pub fn can_apply(&self, properties: &Properties) -> bool {
        self.name_error().is_none() && self.dirty(properties)
    }

    pub fn toggle(&mut self, bit: u32) {
        self.mode ^= bit;
    }
}
