use std::{collections::BTreeMap, fs, path::PathBuf};

use rune::{Latest, Waker};
use serde::{Deserialize, Serialize};

use crate::file::SortBy;

#[derive(Clone, Copy, Default, PartialEq, Eq, Hash, Deserialize, Serialize)]
pub enum ViewMode {
    #[default]
    #[serde(alias = "list")]
    List,
    #[serde(alias = "details")]
    Details,
    #[serde(alias = "grid")]
    Grid,
}

impl ViewMode {
    pub const ALL: [Self; 3] = [Self::List, Self::Details, Self::Grid];

    pub fn name(self) -> &'static str {
        match self {
            Self::List => "List",
            Self::Details => "Details",
            Self::Grid => "Grid",
        }
    }

    pub fn key(self) -> &'static str {
        match self {
            Self::List => "list",
            Self::Details => "details",
            Self::Grid => "grid",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum DetailColumn {
    Name,
    Size,
    Modified,
    Type,
    Owner,
}

impl DetailColumn {
    pub const ALL: [Self; 5] = [
        Self::Name,
        Self::Size,
        Self::Modified,
        Self::Type,
        Self::Owner,
    ];

    pub fn label(self) -> &'static str {
        match self {
            Self::Name => "Name",
            Self::Size => "Size",
            Self::Modified => "Modified",
            Self::Type => "Type",
            Self::Owner => "Owner",
        }
    }

    pub fn index(self) -> usize {
        Self::ALL.iter().position(|&column| column == self).unwrap()
    }

    pub fn minimum(self) -> f32 {
        match self {
            Self::Name => 160.0,
            Self::Size => 64.0,
            Self::Modified => 100.0,
            Self::Type => 88.0,
            Self::Owner => 65.0,
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Deserialize, Serialize)]
#[serde(default)]
pub struct Details {
    pub order: [DetailColumn; 5],
    pub widths: [u16; 5],
    pub visible: [bool; 5],
    pub name_fixed: bool,
}

impl Default for Details {
    fn default() -> Self {
        Self {
            order: DetailColumn::ALL,
            widths: [190, 86, 142, 134, 82],
            visible: [true, true, true, true, false],
            name_fixed: false,
        }
    }
}

impl Details {
    pub fn columns(self, available: f32) -> Vec<(DetailColumn, f32)> {
        let mut columns: Vec<_> = self
            .order
            .into_iter()
            .filter(|&column| column == DetailColumn::Name || self.visible[column.index()])
            .collect();
        for column in [
            DetailColumn::Type,
            DetailColumn::Modified,
            DetailColumn::Size,
            DetailColumn::Owner,
        ] {
            let total = DetailColumn::Name.minimum()
                + columns
                    .iter()
                    .filter(|&&c| c != DetailColumn::Name)
                    .map(|&c| self.widths[c.index()].max(c.minimum() as u16) as f32)
                    .sum::<f32>();
            if total <= available || columns.len() == 1 {
                break;
            }
            columns.retain(|&c| c != column);
        }
        let other: f32 = columns
            .iter()
            .filter(|&&c| c != DetailColumn::Name)
            .map(|&c| self.widths[c.index()].max(c.minimum() as u16) as f32)
            .sum();
        let name_width = (available - other).max(0.0);
        columns
            .into_iter()
            .map(|column| {
                (
                    column,
                    if column == DetailColumn::Name {
                        if self.name_fixed {
                            (self.widths[0].max(160) as f32).min(name_width)
                        } else {
                            name_width
                        }
                    } else {
                        self.widths[column.index()].max(column.minimum() as u16) as f32
                    },
                )
            })
            .collect()
    }

    pub fn resize(&mut self, column: DetailColumn, width: f32) {
        self.widths[column.index()] = width.clamp(column.minimum(), 600.0) as u16;
        if column == DetailColumn::Name {
            self.name_fixed = true;
        }
    }

    pub fn move_by(&mut self, column: DetailColumn, step: isize) {
        if column == DetailColumn::Name {
            return;
        }
        let Some(index) = self.order.iter().position(|&c| c == column) else {
            return;
        };
        let target = index
            .saturating_add_signed(step)
            .clamp(1, self.order.len() - 1);
        self.order.swap(index, target);
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Deserialize, Serialize)]
#[serde(default)]
pub struct Preference {
    pub view_mode: ViewMode,
    pub show_hidden: bool,
    pub sort_sensitive: bool,
    pub sort_dir_first: bool,
    pub sort_reverse: bool,
    pub sort_by: SortBy,
    pub details: Details,
}

impl Default for Preference {
    fn default() -> Self {
        Self {
            view_mode: ViewMode::List,
            show_hidden: false,
            sort_sensitive: false,
            sort_dir_first: true,
            sort_reverse: true,
            sort_by: SortBy::Modified,
            details: Details::default(),
        }
    }
}

type Changes = BTreeMap<String, Option<Preference>>;

pub struct Preferences {
    defaults: Preference,
    folders: BTreeMap<String, Preference>,
    pending: Changes,
    worker: Latest<(Changes, Result<(), String>)>,
    running: bool,
    pub error: Option<String>,
    path: PathBuf,
}

impl Preferences {
    pub fn new(path: PathBuf, defaults: Preference) -> Self {
        let result = match fs::read(&path) {
            Ok(data) => serde_json::from_slice(&data).map_err(|error| error.to_string()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(BTreeMap::new()),
            Err(error) => Err(error.to_string()),
        };
        let (folders, error) = match result {
            Ok(folders) => (folders, None),
            Err(error) => (BTreeMap::new(), Some(error)),
        };
        Self {
            defaults,
            folders,
            pending: BTreeMap::new(),
            worker: Latest::default(),
            running: false,
            error,
            path,
        }
    }

    pub fn get(&self, uri: &str) -> Preference {
        self.folders.get(uri).copied().unwrap_or(self.defaults)
    }

    pub fn customized(&self, uri: &str) -> bool {
        self.folders.contains_key(uri)
    }

    pub fn set(&mut self, uri: String, preference: Option<Preference>) {
        if let Some(preference) = preference {
            self.folders.insert(uri.clone(), preference);
        } else {
            self.folders.remove(&uri);
        }
        self.pending.insert(uri, preference);
        self.error = None;
    }

    pub fn set_waker(&mut self, waker: Waker) {
        self.worker.set_waker(waker);
    }

    pub fn saving(&self) -> bool {
        self.running || (self.error.is_none() && !self.pending.is_empty())
    }

    pub fn poll(&mut self) -> Option<Result<(), String>> {
        let result = self.worker.take().map(|(changes, result)| {
            self.running = false;
            if let Err(error) = &result {
                for (uri, preference) in changes {
                    self.pending.entry(uri).or_insert(preference);
                }
                self.error = Some(error.clone());
            }
            result
        });
        if !self.running && self.error.is_none() && !self.pending.is_empty() {
            self.running = true;
            self.worker.request(
                (self.path.clone(), std::mem::take(&mut self.pending)),
                |(path, changes)| {
                    let result = save(path, &changes);
                    (changes, result)
                },
            );
        }
        result
    }
}

fn save(path: PathBuf, changes: &Changes) -> Result<(), String> {
    let parent = path
        .parent()
        .ok_or("Folder views need a configuration directory")?;
    fs::create_dir_all(parent).map_err(|error| error.to_string())?;
    let lock = fs::OpenOptions::new()
        .create(true)
        .truncate(false)
        .read(true)
        .write(true)
        .open(path.with_extension("lock"))
        .map_err(|error| error.to_string())?;
    lock.lock().map_err(|error| error.to_string())?;

    let mut folders: BTreeMap<String, Preference> = match fs::read(&path) {
        Ok(data) => serde_json::from_slice(&data).map_err(|error| error.to_string())?,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => BTreeMap::new(),
        Err(error) => return Err(error.to_string()),
    };
    for (uri, preference) in changes {
        if let Some(preference) = preference {
            folders.insert(uri.clone(), *preference);
        } else {
            folders.remove(uri);
        }
    }
    let mut temporary =
        tempfile::NamedTempFile::new_in(parent).map_err(|error| error.to_string())?;
    serde_json::to_writer_pretty(&mut temporary, &folders).map_err(|error| error.to_string())?;
    temporary.persist(path).map_err(|error| error.to_string())?;
    Ok(())
}
