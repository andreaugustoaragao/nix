use rune::{El, Key, ScrollSpec, TextStyle, col, el, row, text};

use crate::{
    appearance::Mode, font::Role, icon, scheme::Palette, state::State, theme::Theme,
    ui::action_button,
};

pub fn view(s: &State, p: Theme, width: f32, height: f32) -> El {
    let appearance = &s.appearance;
    let dialog_width = (width - 40.0).min(780.0);
    let dark = appearance.page_dark;
    let selected = if dark {
        &appearance.options.dark_scheme
    } else {
        &appearance.options.light_scheme
    };
    let mut modes = row()
        .w_full()
        .gap(p.space(2))
        .role("radiogroup")
        .label("Appearance mode");
    for (mode, title) in [
        (Mode::System, "System"),
        (Mode::Light, "Light"),
        (Mode::Dark, "Dark"),
    ] {
        modes = modes.child(
            action_button(title, p, move |s, _| s.appearance.set_mode(mode))
                .key(format!("appearance-mode-{}", mode.name()))
                .role("radio")
                .checked(appearance.options.mode == mode)
                .h(p.height(32.0))
                .fill(if appearance.options.mode == mode {
                    p.selected
                } else {
                    p.background
                }),
        );
    }
    let mut content = col()
        .w_full()
        .gap(p.space(4))
        .padding(p.space(6))
        .child(
            col()
                .w_full()
                .gap(p.space(2))
                .child(
                    text("Appearance mode")
                        .font(p.font(13.0, 600.0))
                        .color(p.text),
                )
                .child(modes)
                .child(
                    text("System follows your desktop’s light or dark preference.")
                        .font(p.font(12.0, 400.0))
                        .color(p.muted)
                        .w_full()
                        .wrap(),
                ),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .role("tablist")
                .label("Color schemes")
                .child(
                    action_button("Light colors", p, |s, _| s.appearance.page_dark = false)
                        .key("appearance-light-tab")
                        .role("tab")
                        .checked(!dark)
                        .h(p.height(32.0))
                        .fill(if dark { p.background } else { p.selected }),
                )
                .child(
                    action_button("Dark colors", p, |s, _| s.appearance.page_dark = true)
                        .key("appearance-dark-tab")
                        .role("tab")
                        .checked(dark)
                        .h(p.height(32.0))
                        .fill(if dark { p.selected } else { p.background }),
                ),
        );
    let columns = if dialog_width >= 560.0 { 2 } else { 1 };
    let column_gap = p.space(3);
    let card_width =
        (dialog_width - p.space(6) * 2.0 - (columns - 1) as f32 * column_gap) / columns as f32;
    let mut cards = vec![card(
        "system",
        "System colors",
        appearance.system_source(dark),
        appearance.scheme_palette("system", dark),
        selected == "system",
        card_width,
        p,
    )];
    for scheme in appearance
        .schemes
        .iter()
        .filter(|scheme| scheme.palette.dark == dark)
    {
        cards.push(card(
            &scheme.id,
            &scheme.name,
            if scheme.palette.dark {
                "Dark scheme"
            } else {
                "Light scheme"
            },
            scheme.palette,
            selected == &scheme.id,
            card_width,
            p,
        ));
    }
    let mut grid = col()
        .w_full()
        .gap(column_gap)
        .role("radiogroup")
        .label(if dark {
            "Dark color scheme"
        } else {
            "Light color scheme"
        });
    let mut line = row().w_full().gap(column_gap);
    let count = cards.len();
    for (index, card) in cards.into_iter().enumerate() {
        line = line.child(card);
        if (index + 1) % columns == 0 || index + 1 == count {
            grid = grid.child(line);
            line = row().w_full().gap(column_gap);
        }
    }
    content = content.child(grid).child(
        text("Changes apply to Vereda and file pickers. Custom schemes appear here automatically.")
            .font(p.font(12.0, 400.0))
            .color(p.muted)
            .w_full()
            .wrap(),
    );
    if appearance.fonts_open {
        content = fonts(s, p);
    }
    if let Some(error) = &appearance.error {
        content = content.child(
            col()
                .w_full()
                .gap(p.space(2))
                .child(
                    text(error)
                        .key("appearance-error")
                        .font(p.font(12.0, 400.0))
                        .color(p.error)
                        .w_full()
                        .wrap_anywhere(),
                )
                .child(
                    action_button("Retry", p, |s, _| s.appearance.retry()).key("appearance-retry"),
                ),
        );
    }
    el().key("appearance-dialog")
        .role("dialog")
        .label("Appearance")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.65))
        .center()
        .modal(false, |s: &mut State| s.appearance.open = false)
        .child(
            col()
                .w(dialog_width)
                .h((height - 32.0).min(680.0))
                .fill(p.panel)
                .border(1.0, p.line)
                .radius(p.space(3))
                .child(
                    col()
                        .w_full()
                        .px(p.space(6))
                        .py(p.space(4))
                        .gap(p.space(1))
                        .child(text("Appearance").font(p.font(23.0, 600.0)).color(p.text))
                        .child(
                            text("Choose how Vereda looks on your desktop.")
                                .font(p.font(13.0, 400.0))
                                .color(p.muted)
                                .w_full()
                                .wrap(),
                        ),
                )
                .child(el().w_full().h(1.0).fill(p.line))
                .child(
                    row()
                        .w_full()
                        .px(p.space(6))
                        .py(p.space(2))
                        .gap(p.space(2))
                        .role("tablist")
                        .label("Appearance settings")
                        .child(
                            action_button("Colors", p, |s, _| s.appearance.fonts_open = false)
                                .key("appearance-colors-tab")
                                .role("tab")
                                .checked(!appearance.fonts_open)
                                .h(p.height(32.0))
                                .fill(if appearance.fonts_open {
                                    p.background
                                } else {
                                    p.selected
                                }),
                        )
                        .child(
                            action_button("Fonts", p, |s, _| s.appearance.fonts_open = true)
                                .key("appearance-fonts-tab")
                                .role("tab")
                                .checked(appearance.fonts_open)
                                .h(p.height(32.0))
                                .fill(if appearance.fonts_open {
                                    p.selected
                                } else {
                                    p.background
                                }),
                        ),
                )
                .child(
                    col()
                        .key("appearance-scroll")
                        .w_full()
                        .grow(1.0)
                        .min_h(0.0)
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(el().w_full().h(1.0).fill(p.line))
                .child(
                    row()
                        .w_full()
                        .h(p.height(56.0))
                        .px(p.space(6))
                        .gap(p.space(2))
                        .center_y()
                        .child(
                            text(if appearance.saving() {
                                "Saving…"
                            } else if appearance.error.is_some() {
                                "Changes could not be saved or loaded"
                            } else {
                                "Changes are saved automatically"
                            })
                            .key("appearance-save-status")
                            .font(p.font(12.0, 400.0))
                            .color(p.muted)
                            .grow(1.0)
                            .min_w(0.0)
                            .truncate(),
                        )
                        .child(
                            action_button("Done", p, |s, tx| {
                                s.appearance.open = false;
                                tx.blur();
                            })
                            .key("appearance-done")
                            .h(p.height(32.0))
                            .default_button(),
                        ),
                ),
        )
}

fn card(
    id: &str,
    name: &str,
    subtitle: &str,
    preview: Palette,
    selected: bool,
    width: f32,
    p: Theme,
) -> El {
    let click = id.to_owned();
    let keyboard = click.clone();
    col()
        .key(format!("appearance-scheme-{id}"))
        .role("radio")
        .label(name)
        .checked(selected)
        .w(width)
        .gap(p.space(2))
        .padding(p.space(3))
        .fill(p.background)
        .radius(p.space(2))
        .border(
            2.0,
            if selected {
                p.accent
            } else {
                p.line.alpha(0.65)
            },
        )
        .hover(p.panel)
        .cursor(rune::Cursor::Pointer)
        .focusable(true)
        .focus_ring(2.0, 2.0, p.accent)
        .on_press_tx(move |s: &mut State, _| s.appearance.select(&click, s.appearance.page_dark))
        .on_key(move |s: &mut State, event, _| {
            if matches!(event.key, Key::Enter) && event.mods == rune::Mods::default() {
                s.appearance.select(&keyboard, s.appearance.page_dark);
                true
            } else {
                false
            }
        })
        .child(
            row()
                .w_full()
                .h(72.0)
                .fill(preview.background)
                .border(1.0, preview.line)
                .radius(p.space(1))
                .child(
                    col()
                        .w(p.space(2) * 2.0 + 16.0)
                        .h_full()
                        .px(p.space(2))
                        .py(p.space(3))
                        .gap(p.space(2))
                        .fill(preview.panel)
                        .child(el().w(16.0).h(4.0).fill(preview.accent).radius(p.space(1)))
                        .child(el().w(12.0).h(4.0).fill(preview.muted).radius(p.space(1)))
                        .child(
                            el().w(16.0)
                                .h(4.0)
                                .fill(preview.muted.alpha(0.5))
                                .radius(p.space(1)),
                        ),
                )
                .child(
                    col()
                        .grow(1.0)
                        .min_w(0.0)
                        .py(p.space(2))
                        .gap(p.space(1))
                        .child(
                            row()
                                .w_full()
                                .h(23.0)
                                .px(p.space(2))
                                .gap(p.space(2))
                                .center_y()
                                .child(rune::icon(&icon::FOLDER, 12.0).color(preview.folder))
                                .child(
                                    text("Documents")
                                        .font(TextStyle::new(11.0, 500.0))
                                        .color(preview.text),
                                ),
                        )
                        .child(
                            row()
                                .w_full()
                                .h(23.0)
                                .px(p.space(2))
                                .gap(p.space(2))
                                .center_y()
                                .fill(preview.selected)
                                .child(el().w(4.0).h(4.0).fill(preview.accent).radius(p.space(1)))
                                .child(
                                    text("notes.md")
                                        .font(TextStyle::new(11.0, 400.0))
                                        .color(preview.text),
                                ),
                        ),
                ),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(
                    text(name)
                        .font(p.font(13.0, 550.0))
                        .color(p.text)
                        .grow(1.0)
                        .min_w(0.0)
                        .truncate(),
                )
                .child(if selected {
                    rune::icon(&icon::CHECK, 14.0).color(p.accent)
                } else {
                    el().w(14.0).h(14.0)
                }),
        )
        .child(
            text(subtitle)
                .font(p.font(11.0, 400.0))
                .color(p.muted)
                .w_full()
                .truncate()
                .help(subtitle),
        )
}

fn fonts(s: &State, p: Theme) -> El {
    let mut roles = row()
        .w_full()
        .gap(p.space(2))
        .role("tablist")
        .label("Font category");
    for (role, title) in [
        (Role::Interface, "Interface"),
        (Role::Files, "File list"),
        (Role::Preview, "Preview"),
    ] {
        roles = roles.child(
            action_button(title, p, move |s, _| s.appearance.font_role = role)
                .key(format!("appearance-font-role-{}", role.prefix()))
                .role("tab")
                .checked(s.appearance.font_role == role)
                .fill(if s.appearance.font_role == role {
                    p.selected
                } else {
                    p.background
                }),
        );
    }
    col()
        .w_full()
        .padding(p.space(6))
        .gap(p.space(4))
        .child(roles)
        .child(
            text("Choose installed font families. Sizes are in points.")
                .font(p.font(13.0, 400.0))
                .color(p.muted)
                .w_full()
                .wrap(),
        )
        .child(font_controls(s, p, s.appearance.font_role))
        .child(
            text("File lists, interface controls, and code previews can each use their own font.")
                .font(p.font(12.0, 400.0))
                .color(p.muted)
                .w_full()
                .wrap(),
        )
}

fn font_controls(s: &State, p: Theme, role: Role) -> El {
    let appearance = &s.appearance;
    let font = appearance.font(role);
    let (choice, size) = appearance.font_options(role);
    let editor = appearance.editor(role);
    let prefix = role.prefix();
    let title = role.title();
    let apply = move |s: &mut State, _: &mut rune::Tx| {
        let name = s.appearance.editor(role).text.clone();
        s.appearance.set_font(role, &name);
    };
    col()
        .w_full()
        .gap(p.space(2))
        .child(text(title).font(p.font(15.0, 600.0)).color(p.text))
        .child(
            text(format!(
                "{}{} · {:.1} pt",
                if choice == "system" { "System: " } else { "" },
                font.family,
                font.points
            ))
            .key(format!("appearance-{prefix}-resolved"))
            .font(p.font(12.0, 400.0))
            .color(p.muted)
            .w_full()
            .wrap(),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(
                    crate::ui::input(editor, p.font(13.0, 400.0), p.height(36.0), p)
                        .key(format!("appearance-{prefix}-font"))
                        .label(format!("{title} family"))
                        .grow(1.0)
                        .min_w(0.0)
                        .px(p.space(2))
                        .fill(p.background)
                        .border(1.0, p.line)
                        .radius(p.space(1))
                        .color(p.text)
                        .on_edit(move |s: &mut State| s.appearance.editor_mut(role))
                        .on_submit(apply),
                )
                .child(
                    action_button("Apply", p, apply)
                        .key(format!("appearance-{prefix}-apply"))
                        .h(p.height(32.0)),
                ),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .child(if role == Role::Files {
                    action_button("Monospace", p, |s, _| {
                        s.appearance.set_font(Role::Files, "monospace")
                    })
                    .key("appearance-list-monospace")
                    .checked(choice == "monospace")
                    .fill(if choice == "monospace" {
                        p.selected
                    } else {
                        p.background
                    })
                } else {
                    el()
                })
                .child(
                    action_button(
                        if role == Role::Files {
                            "Use interface font"
                        } else {
                            "Use system font"
                        },
                        p,
                        move |s, _| s.appearance.set_font(role, "system"),
                    )
                    .key(format!("appearance-{prefix}-system"))
                    .checked(choice == "system")
                    .fill(if choice == "system" {
                        p.selected
                    } else {
                        p.background
                    })
                    .h(p.height(32.0)),
                ),
        )
        .child(
            row()
                .w_full()
                .gap(p.space(2))
                .center_y()
                .child(text("Size").font(p.font(13.0, 400.0)).color(p.text))
                .child(
                    action_button("−", p, move |s, _| {
                        s.appearance.adjust_font_size(role, Some(-0.5))
                    })
                    .key(format!("appearance-{prefix}-smaller"))
                    .label(format!("Smaller {title}"))
                    .h(p.height(32.0)),
                )
                .child(
                    text(format!("{:.1} pt", font.points))
                        .key(format!("appearance-{prefix}-size"))
                        .font(p.font(13.0, 500.0))
                        .color(p.text),
                )
                .child(
                    action_button("+", p, move |s, _| {
                        s.appearance.adjust_font_size(role, Some(0.5))
                    })
                    .key(format!("appearance-{prefix}-larger"))
                    .label(format!("Larger {title}"))
                    .h(p.height(32.0)),
                )
                .child(
                    action_button(
                        if role == Role::Files {
                            "Interface size"
                        } else {
                            "System size"
                        },
                        p,
                        move |s, _| s.appearance.adjust_font_size(role, None),
                    )
                    .key(format!("appearance-{prefix}-system-size"))
                    .checked(size.is_none())
                    .fill(if size.is_none() {
                        p.selected
                    } else {
                        p.background
                    })
                    .h(p.height(32.0)),
                ),
        )
        .child(
            text(if role == Role::Preview {
                "fn main() { println!(\"Hello\"); }"
            } else {
                "Documents   Pictures   Downloads"
            })
            .key(format!("appearance-{prefix}-sample"))
            .font(match role {
                Role::Preview => p.code(),
                Role::Files => p.list(),
                Role::Interface => p.font(13.0, 400.0),
            })
            .color(p.text)
            .w_full()
            .wrap()
            .padding(p.space(3))
            .fill(p.background)
            .radius(p.space(1)),
        )
}
