use std::{
    collections::BTreeSet,
    path::{Path, PathBuf},
    sync::mpsc::{self, Receiver, RecvTimeoutError, Sender},
    thread,
    time::{Duration, Instant},
};

use notify::{Event, RecursiveMode, Watcher};
use rune::Waker;

enum Update {
    Paths(Vec<PathBuf>),
    Invalidated(Vec<PathBuf>),
}

#[derive(Default)]
pub struct Watch {
    updates: Option<Sender<Update>>,
    changes: Option<Receiver<Vec<PathBuf>>>,
    errors: Option<Receiver<String>>,
}

impl Watch {
    pub fn start(&mut self, waker: Waker) -> notify::Result<()> {
        let (input, events) = mpsc::sync_channel::<Event>(256);
        let (output, changes) = mpsc::channel();
        let mut watcher = notify::recommended_watcher(move |result: notify::Result<Event>| {
            let event = result.unwrap_or_else(|_| Event::new(notify::EventKind::Any));
            if !event.kind.is_access()
                && (event.paths.is_empty() || !event.paths.iter().all(|path| private_path(path)))
            {
                let _ = input.try_send(event);
            }
        })?;
        thread::spawn(move || {
            while let Ok(first) = events.recv() {
                let mut paths: BTreeSet<_> = first.paths.into_iter().collect();
                paths.insert(PathBuf::new());
                let start = Instant::now();
                loop {
                    match events.recv_timeout(Duration::from_millis(80)) {
                        Ok(event) => paths.extend(event.paths),
                        Err(RecvTimeoutError::Timeout) => break,
                        Err(RecvTimeoutError::Disconnected) => return,
                    }
                    if start.elapsed() >= Duration::from_millis(240) {
                        break;
                    }
                }
                if output.send(paths.into_iter().collect()).is_err() {
                    return;
                }
                (waker)();
            }
        });
        let (updates, requested) = mpsc::channel();
        let (errors, failures) = mpsc::channel();
        thread::spawn(move || {
            let mut paths = BTreeSet::new();
            for update in requested {
                match update {
                    Update::Paths(wanted) => {
                        let wanted: BTreeSet<_> =
                            wanted.into_iter().filter(|p| p.is_dir()).collect();
                        for path in paths.difference(&wanted) {
                            let _ = watcher.unwatch(path);
                        }
                        paths.retain(|p| wanted.contains(p));
                        for path in wanted.difference(&paths).cloned().collect::<Vec<_>>() {
                            match watcher.watch(&path, RecursiveMode::NonRecursive) {
                                Ok(()) => {
                                    paths.insert(path);
                                }
                                Err(error) => {
                                    let _ = errors.send(error.to_string());
                                }
                            }
                        }
                    }
                    Update::Invalidated(changed) => {
                        for path in changed {
                            if paths.remove(&path) {
                                let _ = watcher.unwatch(&path);
                            }
                        }
                    }
                }
            }
        });
        self.updates = Some(updates);
        self.errors = Some(failures);
        self.changes = Some(changes);
        Ok(())
    }

    pub fn update(&mut self, paths: impl IntoIterator<Item = PathBuf>) -> notify::Result<()> {
        if let Some(updates) = &self.updates {
            updates
                .send(Update::Paths(paths.into_iter().collect()))
                .map_err(|_| notify::Error::generic("Watcher worker stopped"))?;
        }
        Ok(())
    }

    pub fn error(&self) -> Option<String> {
        self.errors
            .as_ref()
            .and_then(|errors| errors.try_iter().last())
    }

    pub fn take(&mut self) -> Vec<PathBuf> {
        let changes: Vec<_> = self
            .changes
            .as_ref()
            .map(|r| r.try_iter().flatten().collect())
            .unwrap_or_default();
        if let Some(updates) = &self.updates {
            let _ = updates.send(Update::Invalidated(changes.clone()));
        }
        changes
    }
}

fn private_path(path: &Path) -> bool {
    path.components()
        .any(|c| c.as_os_str().to_string_lossy().starts_with(".vereda-"))
}
