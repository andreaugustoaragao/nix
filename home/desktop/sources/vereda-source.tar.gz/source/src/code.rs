use std::{
    path::Path,
    sync::LazyLock,
    time::{Duration, Instant},
};

use crate::scheme::Token;
use syntect::{easy::HighlightLines, highlighting::ThemeSet, parsing::SyntaxSet};

static SYNTAXES: LazyLock<SyntaxSet> = LazyLock::new(two_face::syntax::extra_no_newlines);
static THEMES: LazyLock<ThemeSet> = LazyLock::new(ThemeSet::load_defaults);
const BYTE_LIMIT: usize = 256 * 1024;
const LINE_LIMIT: usize = 4000;

pub struct Code {
    pub lines: Vec<Line>,
    pub note: Option<String>,
    pub truncated: bool,
}

pub struct Line {
    pub text: String,
    pub syntax: Vec<(std::ops::Range<usize>, Token)>,
}

impl Code {
    pub fn new(
        path: &Path,
        source: &str,
        truncated: bool,
        cancel: &gio::Cancellable,
    ) -> Option<Self> {
        use gio::prelude::CancellableExt;

        let syntax = SYNTAXES
            .find_syntax_by_path(&path.to_string_lossy())
            .or_else(|| {
                SYNTAXES.find_syntax_by_extension(
                    &path.extension()?.to_string_lossy().to_ascii_lowercase(),
                )
            })
            .or_else(|| {
                SYNTAXES.find_syntax_by_first_line(source.lines().next().unwrap_or_default())
            })?;
        if syntax.name == "Plain Text" {
            return None;
        }
        let mut note = None;
        let formatted = if syntax.name == "JSON" {
            if truncated {
                note = Some("Incomplete JSON · showing source".into());
                None
            } else if serde_json::from_str::<&serde_json::value::RawValue>(source).is_err() {
                note = Some("Invalid JSON · showing source".into());
                None
            } else {
                match pretty_json(source) {
                    Some(value) => {
                        note = Some("Formatted JSON · original file unchanged".into());
                        Some(value)
                    }
                    None => {
                        note = Some("Formatted JSON exceeds preview limit · showing source".into());
                        None
                    }
                }
            }
        } else {
            None
        };
        let source = formatted.as_deref().unwrap_or(source);
        let mut highlighter = HighlightLines::new(syntax, &THEMES.themes["base16-ocean.dark"]);
        let deadline = Instant::now() + Duration::from_millis(750);
        let mut coloring = true;
        let mut lines = Vec::new();
        for line in source.lines().take(LINE_LIMIT) {
            if cancel.is_cancelled() {
                return None;
            }
            if coloring && (line.len() > 8192 || Instant::now() > deadline) {
                coloring = false;
                let limit = "Syntax coloring limited · remaining source shown as text";
                note =
                    Some(note.map_or_else(|| limit.to_owned(), |note| format!("{note} · {limit}")));
            }
            let text: String = line
                .chars()
                .map(|c| {
                    if c.is_control() && c != '\t' {
                        '�'
                    } else {
                        c
                    }
                })
                .collect();
            let syntax = if coloring {
                spans(&mut highlighter, &text)
            } else {
                Vec::new()
            };
            lines.push(Line { text, syntax });
        }
        Some(Self {
            lines,
            note,
            truncated: truncated || source.lines().count() > LINE_LIMIT,
        })
    }
}

fn spans(highlighter: &mut HighlightLines<'_>, text: &str) -> Vec<(std::ops::Range<usize>, Token)> {
    let Ok(parts) = highlighter.highlight_line(text, &SYNTAXES) else {
        return Vec::new();
    };
    let mut offset = 0;
    parts
        .into_iter()
        .filter_map(|(style, part)| {
            let start = offset;
            offset += part.len();
            let color = style.foreground;
            let token = match (color.r, color.g, color.b) {
                (101, 115, 126) => Token::Comment,
                (163, 190, 140) => Token::String,
                (180, 142, 173) => Token::Keyword,
                (208, 135, 112) => Token::Number,
                (235, 203, 139) => Token::Type,
                (143, 161, 179) => Token::Function,
                (150, 181, 180) => Token::Constant,
                (191, 97, 106) => Token::Error,
                _ => Token::Text,
            };
            (!part.is_empty()).then_some((start..offset, token))
        })
        .collect()
}

fn pretty_json(source: &str) -> Option<String> {
    let mut output = String::with_capacity(source.len());
    let mut chars = source
        .chars()
        .filter(|c| !c.is_control() || c.is_whitespace())
        .peekable();
    let (mut quoted, mut escaped, mut depth, mut lines) = (false, false, 0usize, 1usize);
    let mut previous = None;
    while let Some(c) = chars.next() {
        if quoted {
            output.push(c);
            if escaped {
                escaped = false;
            } else if c == '\\' {
                escaped = true;
            } else if c == '"' {
                quoted = false;
            }
        } else {
            if c.is_whitespace() {
                continue;
            }
            match c {
                '"' => {
                    quoted = true;
                    output.push(c);
                }
                '{' | '[' => {
                    output.push(c);
                    depth += 1;
                    while chars.peek().is_some_and(|c| c.is_whitespace()) {
                        chars.next();
                    }
                    if !chars.peek().is_some_and(|c| matches!(c, '}' | ']')) {
                        output.push('\n');
                        lines += 1;
                        output.extend(std::iter::repeat_n(' ', depth * 2));
                    }
                }
                '}' | ']' => {
                    depth -= 1;
                    if !matches!(previous, Some('{' | '[')) {
                        output.push('\n');
                        lines += 1;
                        output.extend(std::iter::repeat_n(' ', depth * 2));
                    }
                    output.push(c);
                }
                ',' => {
                    output.push_str(",\n");
                    lines += 1;
                    output.extend(std::iter::repeat_n(' ', depth * 2));
                }
                ':' => output.push_str(": "),
                _ => output.push(c),
            }
        }
        previous = Some(c);
        if output.len() > BYTE_LIMIT || lines > LINE_LIMIT {
            return None;
        }
    }
    Some(output)
}
