use std::{num::ParseIntError, str::FromStr};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Step {
    Top,
    Bot,
    Prev,
    Next,
    Fixed(isize),
    Percent(isize),
}

impl Default for Step {
    fn default() -> Self {
        Self::Fixed(0)
    }
}

impl Step {
    pub fn add(self, current: usize, len: usize, page_size: usize) -> usize {
        if len == 0 {
            return 0;
        }
        let last = len - 1;
        let current = current.min(last);
        let delta = match self {
            Self::Top => return 0,
            Self::Bot => return last,
            Self::Prev => return if current == 0 { last } else { current - 1 },
            Self::Next => return if current >= last { 0 } else { current + 1 },
            Self::Fixed(steps) => steps,
            Self::Percent(0) => 0,
            Self::Percent(percent) => {
                let scaled = percent.saturating_mul(page_size.max(1) as isize) / 100;
                if scaled == 0 {
                    percent.signum()
                } else {
                    scaled
                }
            }
        };
        current.saturating_add_signed(delta).min(last)
    }
}

impl FromStr for Step {
    type Err = ParseIntError;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        Ok(match value {
            "top" => Self::Top,
            "bot" => Self::Bot,
            "prev" => Self::Prev,
            "next" => Self::Next,
            _ if value.ends_with('%') => Self::Percent(value[..value.len() - 1].parse()?),
            _ => Self::Fixed(value.parse()?),
        })
    }
}
