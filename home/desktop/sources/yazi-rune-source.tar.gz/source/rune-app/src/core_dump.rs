use std::{
    io::{Read, Seek},
    path::Path,
    process::{Command, Stdio},
    time::{Duration, Instant},
};

use gio::prelude::CancellableExt;
use serde::{Deserialize, Serialize};

#[derive(Default, Deserialize, Serialize)]
#[serde(default)]
pub struct CoreDump {
    pub architecture: String,
    pub process: String,
    pub pid: u32,
    pub signal: String,
    pub fault: String,
    pub symbols: String,
    pub threads: usize,
    pub sections: Vec<Section>,
    pub notice: String,
}

#[derive(Deserialize, Serialize)]
pub struct Section {
    pub title: String,
    pub body: String,
    pub expanded: bool,
}

impl CoreDump {
    pub fn detect(bytes: &[u8]) -> Option<String> {
        if bytes.len() < 20 || &bytes[..4] != b"\x7fELF" {
            return None;
        }
        let little = match bytes[5] {
            1 => true,
            2 => false,
            _ => return None,
        };
        let word = |i| {
            let pair = [bytes[i], bytes[i + 1]];
            if little {
                u16::from_le_bytes(pair)
            } else {
                u16::from_be_bytes(pair)
            }
        };
        if word(16) != 4 {
            return None;
        }
        let bits = match bytes[4] {
            1 => 32,
            2 => 64,
            _ => return None,
        };
        let machine = match word(18) {
            3 => "x86".into(),
            40 => "ARM".into(),
            62 => "x86-64".into(),
            183 => "AArch64".into(),
            243 => "RISC-V".into(),
            other => format!("machine {other}"),
        };
        Some(format!(
            "{machine} · {bits}-bit · {} endian",
            if little { "little" } else { "big" }
        ))
    }

    pub fn open(path: &Path, architecture: String, cancel: &gio::Cancellable) -> Self {
        let mut core = Self {
            architecture,
            ..Self::default()
        };
        if cancel.is_cancelled() {
            core.notice = "Core preview cancelled".into();
            return core;
        }
        match analyze(path, cancel) {
            Ok((mut report, notice)) => {
                report.architecture = core.architecture;
                report.notice = notice;
                report
            }
            Err(error) => {
                core.notice = error;
                core
            }
        }
    }
}

fn analyze(path: &Path, cancel: &gio::Cancellable) -> Result<(CoreDump, String), String> {
    let mut output = tempfile::tempfile().map_err(|error| error.to_string())?;
    let mut child = Command::new("gdb")
        .args(["--nx", "--nh", "--quiet", "--batch"])
        .args([
            "-iex",
            "set auto-load off",
            "-iex",
            "set debuginfod enabled off",
        ])
        .args([
            "-iex",
            "set pagination off",
            "-iex",
            "set print elements 32",
        ])
        .arg("--core")
        .arg(path)
        .arg("-ex")
        .arg(format!(
            "python exec({})",
            serde_json::to_string(SCRIPT).unwrap()
        ))
        .env("LC_ALL", "C")
        .env("DEBUGINFOD_URLS", "")
        .stdin(Stdio::null())
        .stdout(output.try_clone().map_err(|error| error.to_string())?)
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| {
            if error.kind() == std::io::ErrorKind::NotFound {
                "Install GDB with Python support to show crash details".into()
            } else {
                format!("Could not start core analysis: {error}")
            }
        })?;
    let start = Instant::now();
    let notice = loop {
        if cancel.is_cancelled() {
            break "Core preview cancelled".to_owned();
        }
        if start.elapsed() > Duration::from_secs(8) {
            break "Analysis limited to 8 seconds; showing available details".to_owned();
        }
        if output
            .metadata()
            .map_or(true, |m| m.len() > 2 * 1024 * 1024)
        {
            break "Analysis reached the 2 MiB output limit".to_owned();
        }
        match child.try_wait() {
            Ok(Some(_)) => break String::new(),
            Ok(None) => std::thread::sleep(Duration::from_millis(20)),
            Err(error) => break error.to_string(),
        }
    };
    if !notice.is_empty() {
        let _ = child.kill();
        let _ = child.wait();
    }
    output.rewind().map_err(|error| error.to_string())?;
    let mut bytes = Vec::new();
    output
        .take(2 * 1024 * 1024)
        .read_to_end(&mut bytes)
        .map_err(|error| error.to_string())?;
    let text = String::from_utf8_lossy(&bytes);
    let core = text
        .lines()
        .rev()
        .filter_map(|line| line.strip_prefix("YAZI_CORE_JSON:"))
        .find_map(|json| serde_json::from_str(json).ok());
    core.map(|core| (core, notice.clone())).ok_or_else(|| if notice.is_empty() {
        "GDB could not read crash details. The dump may be incomplete or use an unsupported architecture.".into()
    } else { notice })
}

const SCRIPT: &str = r#"
import gdb, json, os, re, signal

def command(cmd, limit=16000):
    try:
        return gdb.execute(cmd, to_string=True)[:limit].strip()
    except gdb.error as error:
        return 'Unavailable: ' + str(error)[:500]

def value(expr):
    try:
        return int(gdb.parse_and_eval(expr))
    except (gdb.error, ValueError):
        return None

report = {'process': command('info proc', 2000), 'signal': '', 'fault': '', 'threads': 0, 'sections': []}
def emit():
    print('YAZI_CORE_JSON:' + json.dumps(report), flush=True)

def section(title, body, expanded=False):
    report['sections'].append({'title': title, 'body': body, 'expanded': expanded})
    emit()

inferior = gdb.selected_inferior()
threads = list(inferior.threads())
if not threads:
    raise gdb.GdbError('No thread registers recorded in this core')
exe = command('info proc exe', 2000)
match = re.fullmatch(r"exe = '(.*)'", exe, re.S)
if match:
    report['process'] = match.group(1)
if match and os.path.isfile(match.group(1)):
    command('file ' + json.dumps(match.group(1), ensure_ascii=False))
report['threads'] = len(threads)
report['pid'] = inferior.pid
faulting = gdb.selected_thread()
number = value('$_siginfo.si_signo')
try:
    report['signal'] = signal.Signals(number).name if number else 'Signal unavailable'
except ValueError:
    report['signal'] = 'Signal ' + str(number)
code = value('$_siginfo.si_code')
address = value('$_siginfo._sifields._sigfault.si_addr') if number in (4, 5, 7, 8, 11) and code is not None and code > 0 else None
report['fault'] = hex(address) if address is not None else ''
pc, sp = value('$pc'), value('$sp')
try:
    has_source = gdb.selected_frame().find_sal().symtab is not None
except gdb.error:
    has_source = False
report['symbols'] = 'Source symbols available at crash' if has_source else 'Source symbols unavailable at crash'
emit()

if faulting:
    section(('Faulting thread ' if number else 'Selected thread ') + str(faulting.num), command('bt 24'), True)
    filename = gdb.current_progspace().filename
    section('Symbols', ('Executable: ' + filename if filename else 'Matching executable unavailable') + '\n' + command('info sharedlibrary', 6000) + '\nSource lines and local variables require matching debug symbols.')
    section('Source context', command('list *$pc', 4000))
    section('Registers', command('info registers'))
    section('Disassembly', command('x/12i $pc'))
    section('Arguments and locals', command('info args', 4000) + '\n' + command('info locals', 4000))
    section('Memory near fault' if address is not None else 'Memory at stack pointer', command('x/64bx ' + hex(address if address is not None else (sp or 0))))

groups = {}
for thread in sorted(threads, key=lambda thread: thread.num)[:64]:
    if thread == faulting:
        continue
    try:
        thread.switch()
        stack = command('bt 12', 4000)
        groups.setdefault(stack, []).append(str(thread.num))
    except gdb.error:
        pass
if faulting:
    faulting.switch()
body = '\n\n'.join('Threads ' + ', '.join(numbers) + '\n' + stack for stack, numbers in groups.items())
if len(threads) > 64:
    body += '\nThread analysis limited to 64 threads.'
section('Other threads', body or 'No other threads recorded')

def annotate(body):
    annotated = []
    for line in body.splitlines():
        match = re.match(r'\s*(0x[0-9a-f]+)\s+(?:-\s+)?(0x[0-9a-f]+)', line)
        if match:
            start, end = (int(item, 16) for item in match.groups())
            marks = [name for name, ptr in [('PC', pc), ('SP', sp), ('FAULT', address)] if ptr is not None and start <= ptr < end]
            if marks:
                line += '  <' + ', '.join(marks) + '>'
        annotated.append(line)
    return '\n'.join(annotated)

legend = '\nPC = instruction pointer; SP = stack pointer.'
section('Memory mappings', annotate(command('info proc mappings', 32000)) + legend + '\nMappings do not guarantee captured pages.', True)
section('Captured memory regions', annotate(command('info files', 32000)) + legend)

"#;
