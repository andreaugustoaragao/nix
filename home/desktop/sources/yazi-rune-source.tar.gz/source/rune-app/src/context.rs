use std::path::PathBuf;

use rune::PopupAnchor;

use crate::{
    file::File,
    locations::{Place, PlaceKind},
    state::PlaceOpen,
};

#[derive(Clone, Copy)]
pub enum Action {
    Command(&'static str),
    Open(PlaceOpen),
    OpenWindow,
    Paste,
    CopyPaths,
    Properties,
    Pin,
    FavoriteMove(bool),
    FavoriteRename,
    FavoriteRemove,
    Unmount,
    Eject,
}

pub struct Item {
    pub key: &'static str,
    pub label: &'static str,
    pub shortcut: &'static str,
    pub action: Action,
    pub enabled: bool,
}

impl Item {
    fn new(key: &'static str, label: &'static str, shortcut: &'static str, action: Action) -> Self {
        Self {
            key,
            label,
            shortcut,
            action,
            enabled: true,
        }
    }
}

pub enum Target {
    Files { file: File, paths: Vec<PathBuf> },
    Background,
    Place(Place),
}

pub struct Context {
    pub side: usize,
    pub anchor: PopupAnchor,
    pub directory: PathBuf,
    pub target: Target,
    pub groups: Vec<Vec<Item>>,
}

impl Context {
    pub fn files(
        side: usize,
        anchor: PopupAnchor,
        directory: PathBuf,
        file: File,
        paths: Vec<PathBuf>,
        all_folders: bool,
    ) -> Self {
        use Action::*;
        let single = paths.len() == 1;
        let mut groups = Vec::new();
        if single {
            let mut open = vec![Item::new(
                "open",
                if file.directory {
                    "Open folder"
                } else {
                    "Open"
                },
                "Enter",
                Open(PlaceOpen::Current),
            )];
            if file.directory {
                open.push(Item::new(
                    "open-tab",
                    "Open in new tab",
                    "",
                    Open(PlaceOpen::Tab),
                ));
                open.push(Item::new(
                    "open-other",
                    "Open in opposite pane",
                    "",
                    Open(PlaceOpen::Other),
                ));
                open.push(Item::new(
                    "open-window",
                    "Open in new window",
                    "",
                    OpenWindow,
                ));
            } else {
                open.push(Item::new(
                    "open-with",
                    "Open with…",
                    "",
                    Command("open_with"),
                ));
            }
            groups.push(open);
        }
        let mut edit = vec![
            Item::new("cut", "Cut", "Ctrl+X", Command("yank --cut")),
            Item::new("copy", "Copy", "Ctrl+C", Command("yank")),
        ];
        if single && file.directory {
            edit.push(Item::new("paste", "Paste into folder", "", Paste));
        }
        edit.push(Item::new(
            "rename",
            if single {
                "Rename…"
            } else {
                "Rename items…"
            },
            "F2",
            Command("rename"),
        ));
        edit.push(Item::new(
            "copy-path",
            if single {
                "Copy location"
            } else {
                "Copy locations"
            },
            "",
            CopyPaths,
        ));
        groups.push(edit);
        let mut organize = Vec::new();
        if all_folders {
            organize.push(Item::new("pin", "Pin to Favorites", "", Pin));
        }
        organize.push(Item::new("archive", "Compress…", "", Command("archive")));
        if single && crate::archive::supported(&file.path) {
            organize.push(Item::new("extract", "Extract here", "", Command("extract")));
        }
        groups.push(organize);
        groups.push(vec![Item::new(
            "trash",
            "Move to trash",
            "Delete",
            Command("remove"),
        )]);
        if single {
            groups.push(vec![Item::new("properties", "Properties", "", Properties)]);
        }
        Self {
            side,
            anchor,
            directory,
            target: Target::Files { file, paths },
            groups,
        }
    }

    pub fn background(side: usize, anchor: PopupAnchor, directory: PathBuf, undo: bool) -> Self {
        use Action::*;
        let mut groups = vec![
            vec![
                Item::new(
                    "new-folder",
                    "New folder…",
                    "Ctrl+Shift+N",
                    Command("create --dir"),
                ),
                Item::new("new-file", "New file…", "", Command("create")),
            ],
            vec![Item::new("paste", "Paste", "Ctrl+V", Paste)],
        ];
        if undo {
            groups[1].push(Item::new(
                "undo",
                "Undo last operation",
                "Ctrl+Z",
                Command("undo"),
            ));
        }
        groups.push(vec![
            Item::new("view", "Folder view…", "", Command("folder_view")),
            Item::new("copy-path", "Copy folder location", "", CopyPaths),
            Item::new("properties", "Folder properties", "", Properties),
        ]);
        Self {
            side,
            anchor,
            directory,
            target: Target::Background,
            groups,
        }
    }

    pub fn place(side: usize, anchor: PopupAnchor, directory: PathBuf, place: Place) -> Self {
        use Action::*;
        let mut open = vec![Item::new(
            "place-open",
            "Open",
            "",
            Open(PlaceOpen::Current),
        )];
        if !place.uri.starts_with("trash:") {
            open.push(Item::new(
                "place-open-tab",
                "Open in new tab",
                "",
                Open(PlaceOpen::Tab),
            ));
            open.push(Item::new(
                "place-open-other",
                "Open in opposite pane",
                "",
                Open(PlaceOpen::Other),
            ));
        }
        let mut groups = vec![open];
        if place.kind == PlaceKind::Favorite {
            groups.push(vec![
                Item::new("rename-favorite", "Rename favorite…", "", FavoriteRename),
                Item::new("favorite-up", "Move up", "", FavoriteMove(false)),
                Item::new("favorite-down", "Move down", "", FavoriteMove(true)),
                Item::new(
                    "remove-favorite",
                    "Remove from Favorites",
                    "",
                    FavoriteRemove,
                ),
            ]);
        } else if !place.uri.is_empty() && !place.uri.starts_with("trash:") {
            groups.push(vec![Item::new("pin-place", "Pin to Favorites", "", Pin)]);
        }
        let mut device = Vec::new();
        if place.unmount {
            device.push(Item::new("unmount", "Unmount", "", Unmount));
        }
        if place.eject {
            device.push(Item::new("eject", "Eject", "", Eject));
        }
        if !device.is_empty() {
            groups.push(device);
        }
        Self {
            side,
            anchor,
            directory,
            target: Target::Place(place),
            groups,
        }
    }

    pub fn title(&self) -> String {
        match &self.target {
            Target::Files { file, paths } if paths.len() == 1 => file.name.clone(),
            Target::Files { paths, .. } => format!("{} items selected", paths.len()),
            Target::Background => self
                .directory
                .file_name()
                .map_or_else(|| "/".into(), |name| name.to_string_lossy().into_owned()),
            Target::Place(place) => place.name.clone(),
        }
    }
}
