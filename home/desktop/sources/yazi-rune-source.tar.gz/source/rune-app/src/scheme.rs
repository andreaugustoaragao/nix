use std::collections::BTreeMap;

use rune::Color;
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Variant {
    Light,
    Dark,
}

impl Variant {
    pub fn dark(self) -> bool {
        self == Self::Dark
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Token {
    Text,
    Comment,
    String,
    Keyword,
    Number,
    Type,
    Function,
    Constant,
    Error,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Palette {
    pub dark: bool,
    pub background: Color,
    pub panel: Color,
    pub text: Color,
    pub muted: Color,
    pub line: Color,
    pub accent: Color,
    pub folder: Color,
    pub selected: Color,
    pub error: Color,
    pub warning: Color,
    pub success: Color,
    pub comment: Color,
    pub string: Color,
    pub keyword: Color,
    pub number: Color,
    pub kind: Color,
    pub function: Color,
    pub constant: Color,
}

impl Palette {
    pub fn token(self, token: Token) -> Color {
        match token {
            Token::Text => self.text,
            Token::Comment => self.comment,
            Token::String => self.string,
            Token::Keyword => self.keyword,
            Token::Number => self.number,
            Token::Type => self.kind,
            Token::Function => self.function,
            Token::Constant => self.constant,
            Token::Error => self.error,
        }
    }

    pub fn with_accent(mut self, accent: Color) -> Self {
        self.accent = accent;
        self.selected = mix(self.background, accent, if self.dark { 0.24 } else { 0.16 });
        self
    }
}

pub fn mix(a: Color, b: Color, amount: f32) -> Color {
    Color {
        r: a.r + (b.r - a.r) * amount,
        g: a.g + (b.g - a.g) * amount,
        b: a.b + (b.b - a.b) * amount,
        a: 1.0,
    }
}

#[derive(Clone)]
pub struct Scheme {
    pub id: String,
    pub name: String,
    pub palette: Palette,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Definition {
    id: Option<String>,
    name: String,
    variant: Variant,
    extends: Option<String>,
    #[serde(default)]
    colors: BTreeMap<String, String>,
    #[serde(default)]
    syntax: BTreeMap<String, String>,
}

impl Scheme {
    pub fn parse(id: &str, source: &str, builtins: &[Scheme]) -> Result<Self, String> {
        let definition: Definition = toml::from_str(source).map_err(|error| error.to_string())?;
        if definition.id.as_deref().is_some_and(|value| value != id) {
            return Err("The scheme id must match its filename".into());
        }
        if id == "system" || definition.name.trim().is_empty() {
            return Err("Choose a scheme name and an id other than 'system'".into());
        }
        let dark = definition.variant.dark();
        let mut palette = if let Some(base) = &definition.extends {
            let base = builtins
                .iter()
                .find(|scheme| &scheme.id == base)
                .ok_or_else(|| format!("Unknown built-in base scheme: {base}"))?;
            if base.palette.dark != dark {
                return Err("The base scheme must use the same light/dark variant".into());
            }
            base.palette
        } else {
            let clear = Color::TRANSPARENT;
            Palette {
                dark,
                background: clear,
                panel: clear,
                text: clear,
                muted: clear,
                line: clear,
                accent: clear,
                folder: clear,
                selected: clear,
                error: clear,
                warning: clear,
                success: clear,
                comment: clear,
                string: clear,
                keyword: clear,
                number: clear,
                kind: clear,
                function: clear,
                constant: clear,
            }
        };
        let mut missing = Vec::new();
        for (name, slot) in [
            ("background", &mut palette.background),
            ("panel", &mut palette.panel),
            ("text", &mut palette.text),
            ("muted", &mut palette.muted),
            ("border", &mut palette.line),
            ("accent", &mut palette.accent),
            ("folder", &mut palette.folder),
            ("selection", &mut palette.selected),
            ("error", &mut palette.error),
            ("warning", &mut palette.warning),
            ("success", &mut palette.success),
        ] {
            if let Some(value) = definition.colors.get(name) {
                *slot = color(value).map_err(|error| format!("{name}: {error}"))?;
            } else if definition.extends.is_none() {
                missing.push(name);
            }
        }
        for name in definition.colors.keys() {
            if ![
                "background",
                "panel",
                "text",
                "muted",
                "border",
                "accent",
                "folder",
                "selection",
                "error",
                "warning",
                "success",
            ]
            .contains(&name.as_str())
            {
                return Err(format!("Unknown color role: {name}"));
            }
        }
        for (name, slot) in [
            ("comment", &mut palette.comment),
            ("string", &mut palette.string),
            ("keyword", &mut palette.keyword),
            ("number", &mut palette.number),
            ("type", &mut palette.kind),
            ("function", &mut palette.function),
            ("constant", &mut palette.constant),
        ] {
            if let Some(value) = definition.syntax.get(name) {
                *slot = color(value).map_err(|error| format!("syntax.{name}: {error}"))?;
            } else if definition.extends.is_none() {
                missing.push(name);
            }
        }
        for name in definition.syntax.keys() {
            if ![
                "comment", "string", "keyword", "number", "type", "function", "constant",
            ]
            .contains(&name.as_str())
            {
                return Err(format!("Unknown syntax role: {name}"));
            }
        }
        if !missing.is_empty() {
            return Err(format!(
                "Missing colors: {}. Set extends to a built-in scheme to inherit defaults.",
                missing.join(", ")
            ));
        }
        Ok(Self {
            id: id.into(),
            name: definition.name,
            palette,
        })
    }
}

pub fn color(value: &str) -> Result<Color, String> {
    if !value.starts_with('#') || !matches!(value.len(), 7 | 9) {
        return Err("Use a hexadecimal color such as #91baf8".into());
    }
    rune::color::hex(value).ok_or_else(|| format!("Invalid color: {value}"))
}

pub fn builtins() -> Vec<Scheme> {
    [
        (
            "files-dark",
            include_str!("../share/color-schemes/files-dark.toml"),
        ),
        (
            "files-light",
            include_str!("../share/color-schemes/files-light.toml"),
        ),
        (
            "catppuccin-mocha",
            include_str!("../share/color-schemes/catppuccin-mocha.toml"),
        ),
        (
            "catppuccin-latte",
            include_str!("../share/color-schemes/catppuccin-latte.toml"),
        ),
        ("nord", include_str!("../share/color-schemes/nord.toml")),
        (
            "gruvbox-dark",
            include_str!("../share/color-schemes/gruvbox-dark.toml"),
        ),
    ]
    .into_iter()
    .map(|(id, source)| Scheme::parse(id, source, &[]).expect("built-in color scheme"))
    .collect()
}
