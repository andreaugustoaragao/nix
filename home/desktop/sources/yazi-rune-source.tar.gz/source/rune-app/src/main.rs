mod archive;
mod clipboard;
mod code;
mod core_dump;
mod desktop;
mod dnd;
mod file;
mod finder;
mod html;
mod icon;
mod keymap;
mod locations;
mod metadata;
mod mounts;
mod operations;
mod pdf;
mod search;
mod state;
#[path = "../../yazi-widgets/src/step.rs"]
mod step;
mod trash;
mod ui;
mod watcher;

use std::{cell::RefCell, path::PathBuf, rc::Rc};

use rune::{App, AppSpec, WindowOptions};
use state::State;

fn main() {
    if std::env::args_os().nth(1).as_deref() == Some(std::ffi::OsStr::new("--zip-metadata")) {
        archive::zip_metadata_main();
        return;
    }
    rune::set_app_id("io.github.yazi_rune");
    let mut directory = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/"));
    let mut config_dir = None;
    let mut cwd_file = None;
    let mut state_out = None;
    let mut rune_args = Vec::new();
    let mut reveal = None;
    let mut properties = false;
    let mut remote = None;
    let mut service = false;
    let mut extra = Vec::new();
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--service" => {
                service = true;
                directory = state::home();
            }
            "--directory" | "--select" | "--properties" | "--config-dir" | "--cwd-file"
            | "--state-out" => {
                let Some(value) = args.next() else {
                    eprintln!("{arg} requires a path");
                    std::process::exit(2)
                };
                match arg.as_str() {
                    "--directory" | "--select" | "--properties" => {
                        let location = locations::Location::parse(&value, &directory)
                            .unwrap_or_else(|error| {
                                eprintln!("{error}");
                                std::process::exit(2)
                            });
                        let folders = arg == "--directory";
                        properties = arg == "--properties";
                        match location {
                            locations::Location::Path(path) => {
                                remote = None;
                                if folders {
                                    directory = path;
                                    reveal = None;
                                } else {
                                    directory = path
                                        .parent()
                                        .unwrap_or(std::path::Path::new("/"))
                                        .to_path_buf();
                                    reveal = Some(path);
                                }
                            }
                            locations::Location::Uri(uri) => {
                                remote = Some((uri, folders, properties))
                            }
                        }
                    }
                    "--config-dir" => config_dir = Some(PathBuf::from(value)),
                    "--cwd-file" => cwd_file = Some(PathBuf::from(value)),
                    _ => state_out = Some(PathBuf::from(value)),
                }
            }

            "--help" => {
                println!(
                    "Yazi Rune\n\nUsage: yazi-rune [PATH|URI ...] [Rune options]\n\nApp options:\n  --service             Start hidden for FileManager1 activation\n  --directory PATH|URI   Open a folder\n  --select PATH|URI      Reveal an item\n  --properties PATH|URI  Show item properties\n  --config-dir PATH   Read yazi.toml and keymap.toml here\n  --cwd-file PATH     Save the final directory when quitting with q\n  --state-out PATH    Write final state for headless verification\n\nRune options: --snap PNG, --tree JSON, --script JSON, --theme dark|light, --size WIDTHxHEIGHT"
                );
                return;
            }
            "--snap" | "--tree" | "--script" | "--theme" | "--size" | "--scale" | "--at"
            | "--scene" | "--frames" | "--fps" | "--duration" | "--out" | "--video" | "--strip"
            | "--crop" | "--cols" => {
                rune_args.push(arg);
                if let Some(value) = args.next() {
                    rune_args.push(value);
                }
            }
            _ if !arg.starts_with('-') => {
                let location =
                    locations::Location::parse(&arg, &directory).unwrap_or_else(|error| {
                        eprintln!("{error}");
                        std::process::exit(2)
                    });
                extra.push(location);
            }

            _ => rune_args.push(arg),
        }
    }
    if let Some(location) = extra.first() {
        match location {
            locations::Location::Path(path) => {
                remote = None;
                if path.is_dir() {
                    directory = path.clone();
                    reveal = None;
                } else {
                    directory = path
                        .parent()
                        .unwrap_or(std::path::Path::new("/"))
                        .to_path_buf();
                    reveal = Some(path.clone());
                }
            }
            locations::Location::Uri(uri) => remote = Some((uri.clone(), true, false)),
        }
    }
    let native = !rune_args.iter().any(|arg| {
        matches!(
            arg.as_str(),
            "--snap" | "--tree" | "--script" | "--out" | "--video" | "--strip"
        )
    });
    if native {
        for path in extra.into_iter().skip(1) {
            let folder = path.folder();
            if let Err(error) =
                desktop::spawn_window(path.argument(), folder, false, config_dir.as_deref())
            {
                eprintln!("Could not open window: {error}");
            }
        }
    }
    let spec = AppSpec {
        min_size: Some((680.0, 360.0)),
        families: ("Inter", "ui-monospace"),
        setup: Some(|s: &mut State, w| s.setup(w)),
        poll: Some(|s: &mut State, _, tx| s.poll(tx)),
        on_key: Some(|s: &mut State, key, tx| s.key(key, tx)),
        scenes: &[
            ("light", |s| s.dark = Some(false)),
            ("dark", |s| s.dark = Some(true)),
        ],
        ..AppSpec::new(
            "Yazi Rune",
            (1160.0, 740.0),
            || State::new(PathBuf::from("/"), None, None),
            ui::view,
        )
    };
    let last = Rc::new(RefCell::new(serde_json::Value::Null));
    let capture = last.clone();
    let exporting = state_out.is_some();
    let app = App::new(spec)
        .window_options(WindowOptions {
            visible: !service,
            ..WindowOptions::default()
        })
        .tab_visits_controls(true)
        .keep_running()
        .on_close(|s: &mut State, tx| s.close(tx))
        .args(rune_args)
        .init(move || {
            let mut state = State::new(directory, config_dir, cwd_file);
            if let Some(path) = reveal {
                let cwd = state.tab().cwd.clone();
                if path
                    .file_name()
                    .is_some_and(|name| name.as_encoded_bytes().starts_with(b"."))
                {
                    state.preference.show_hidden = true;
                }
                state.tab_mut().hovered.insert(cwd, path);
                state.spot = properties;
            }
            if let Some((uri, folders, properties)) = remote {
                state.startup_uri = Some(uri);
                state.mount_intent = Some((folders, properties));
            }
            if exporting {
                state.export = Some(capture);
            }
            state
        });
    let handle = app.handle();
    let app = app
        .on_window(move |window| {
            let window = window.clone();
            handle.update(move |state, _| {
                state.dnd = None;
                match dnd::Dnd::attach(window) {
                    Ok(dnd) => state.dnd = dnd,
                    Err(error) => state.message = Some(format!("Drag and drop: {error}")),
                }
            });
        })
        .on_frame_drawn(|runtime| {
            let state = &runtime.state;
            let mut targets = Vec::new();
            for element in runtime.elements() {
                if element.role != "listitem" {
                    continue;
                }
                let Some(key) = &element.key else {
                    continue;
                };
                if let Some(file) = state
                    .tab()
                    .files
                    .iter()
                    .chain(&state.parent)
                    .find(|file| file.directory && &file.key == key)
                {
                    targets.push(dnd::Target {
                        rect: element.rect,
                        path: file.path.clone(),
                    });
                }
            }
            state.drop_targets.replace(targets);
        });
    let _desktop = native.then(|| desktop::Desktop::start(app.handle()));
    app.run();
    if let Some(path) = state_out
        && let Err(error) = std::fs::write(
            &path,
            serde_json::to_vec_pretty(&*last.borrow()).expect("state JSON"),
        )
    {
        eprintln!("Could not save {}: {error}", path.display());
        std::process::exit(1);
    }
}
