use gio::prelude::*;
use serde::Serialize;
use std::{os::unix::ffi::OsStringExt, path::PathBuf};

#[derive(Clone, Serialize)]
pub struct Entry {
    pub uri: String,
    pub name: String,
    pub original: PathBuf,
    pub deleted: String,
    pub directory: bool,
    pub size: u64,
}

pub fn read() -> Result<Vec<Entry>, String> {
    let root = gio::File::for_uri("trash:///");
    let children = root
        .enumerate_children(
            "standard::*,trash::*",
            gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
            gio::Cancellable::NONE,
        )
        .map_err(|e| e.to_string())?;
    let mut entries = Vec::new();
    while let Some(info) = children
        .next_file(gio::Cancellable::NONE)
        .map_err(|e| e.to_string())?
    {
        let original = info
            .attribute_byte_string("trash::orig-path")
            .map(|s| PathBuf::from(std::ffi::OsString::from_vec(s.as_bytes().to_vec())))
            .unwrap_or_default();
        entries.push(Entry {
            uri: children.child(&info).uri().to_string(),
            name: info.display_name().to_string(),
            original,
            deleted: info
                .attribute_string("trash::deletion-date")
                .map(|s| s.to_string())
                .unwrap_or_default(),
            directory: info.file_type() == gio::FileType::Directory,
            size: info.size().max(0) as u64,
        });
    }
    entries.sort_by(|a, b| b.deleted.cmp(&a.deleted).then_with(|| a.uri.cmp(&b.uri)));
    Ok(entries)
}
