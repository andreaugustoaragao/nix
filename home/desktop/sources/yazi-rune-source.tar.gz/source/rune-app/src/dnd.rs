use raw_window_handle::RawWindowHandle;
use rune::WindowHandle;
use std::{
    ffi::c_void,
    path::{Path, PathBuf},
    ptr::NonNull,
    sync::mpsc::{self, Receiver, Sender},
};

#[derive(Clone)]
pub struct Target {
    pub rect: [f32; 4],
    pub path: PathBuf,
}
impl Target {
    pub fn contains(&self, point: [f32; 2]) -> bool {
        point[0] >= self.rect[0]
            && point[0] < self.rect[0] + self.rect[2]
            && point[1] >= self.rect[1]
            && point[1] < self.rect[1] + self.rect[3]
    }
}
#[derive(Clone)]
pub struct Drop {
    pub action: u32,
    pub token: u32,
    pub paths: Vec<PathBuf>,
    pub destination: PathBuf,
}

pub enum Event {
    Hover {
        token: u32,
        point: [f32; 2],
    },
    Preview {
        token: u32,
        point: [f32; 2],
        paths: Vec<PathBuf>,
        local: bool,
    },
    Drop {
        token: u32,
        point: [f32; 2],
        paths: Vec<PathBuf>,
        action: u32,
        choose: bool,
    },
    Error(String),
    End,
}
struct RawEvent {
    kind: u32,
    token: u32,
    point: [f32; 2],
    action: u32,
    bytes: Vec<u8>,
}
struct Pending {
    task: u64,
    token: u32,
    action: u32,
}

pub struct Dnd {
    native: NonNull<c_void>,
    window: WindowHandle,
    events: Receiver<RawEvent>,
    _sender: Box<Sender<RawEvent>>,
    pending: Vec<Pending>,
}
unsafe extern "C" {
    fn yr_dnd_create(
        surface: *mut c_void,
        callback: unsafe extern "C" fn(*mut c_void, u32, u32, f64, f64, u32, *const u8, usize),
        context: *mut c_void,
    ) -> *mut c_void;
    fn yr_dnd_destroy(native: *mut c_void);
    fn yr_dnd_start(
        native: *mut c_void,
        surface: *mut c_void,
        data: *const u8,
        length: usize,
    ) -> i32;
    fn yr_dnd_poll(native: *mut c_void);
    fn yr_dnd_prefer(native: *mut c_void, token: u32, action: u32);
    fn yr_dnd_finish(native: *mut c_void, token: u32, success: i32, action: u32);
}
unsafe extern "C" fn event(
    context: *mut c_void,
    kind: u32,
    token: u32,
    x: f64,
    y: f64,
    action: u32,
    bytes: *const u8,
    length: usize,
) {
    // The bridge owns this callback's buffers only for the synchronous call.
    let data = if length == 0 {
        Vec::new()
    } else {
        unsafe { std::slice::from_raw_parts(bytes, length) }.to_vec()
    };
    let sender = unsafe { &*(context as *const Sender<RawEvent>) };
    let _ = sender.send(RawEvent {
        kind,
        token,
        point: [x as f32, y as f32],
        action,
        bytes: data,
    });
}
impl Dnd {
    pub fn attach(window: WindowHandle) -> Result<Option<Self>, String> {
        let (sender, events) = mpsc::channel();
        let sender = Box::new(sender);
        let context = (&*sender as *const Sender<RawEvent>).cast_mut().cast();
        let native = window.with_raw_handle(|handle| match handle.as_raw() {
            RawWindowHandle::Wayland(handle) => unsafe {
                yr_dnd_create(handle.surface.as_ptr(), event, context)
            },
            _ => std::ptr::null_mut(),
        })?;
        Ok(NonNull::new(native).map(|native| Self {
            native,
            window,
            events,
            _sender: sender,
            pending: Vec::new(),
        }))
    }
    pub fn start(&mut self, uris: Vec<String>) -> Result<bool, String> {
        let bytes = format!("{}\r\n", uris.join("\r\n")).into_bytes();
        self.poll_native();
        self.window.with_raw_handle(|handle| match handle.as_raw() {
            RawWindowHandle::Wayland(surface) => unsafe {
                yr_dnd_start(
                    self.native.as_ptr(),
                    surface.surface.as_ptr(),
                    bytes.as_ptr(),
                    bytes.len(),
                ) != 0
            },
            _ => false,
        })
    }
    fn poll_native(&mut self) {
        unsafe { yr_dnd_poll(self.native.as_ptr()) };
    }
    pub fn poll(&mut self) -> Vec<Event> {
        self.poll_native();
        let mut events = Vec::new();
        for event in self.events.try_iter() {
            match event.kind {
                1 => events.push(Event::Hover {
                    token: event.token,
                    point: event.point,
                }),
                2 | 5 => match paths(&event.bytes) {
                    Ok(paths) if !paths.is_empty() => {
                        if event.kind == 2 {
                            events.push(Event::Drop {
                                token: event.token,
                                point: event.point,
                                paths,
                                action: event.action & 15,
                                choose: event.action & 16 != 0,
                            });
                        } else {
                            events.push(Event::Preview {
                                token: event.token,
                                point: event.point,
                                paths,
                                local: event.action != 0,
                            });
                        }
                    }
                    result => {
                        unsafe { yr_dnd_finish(self.native.as_ptr(), event.token, 0, 1) };
                        events.push(Event::Error(
                            result.err().unwrap_or("The drag contains no files".into()),
                        ));
                    }
                },
                3 => events.push(Event::End),
                4 => events.push(Event::Error(
                    String::from_utf8_lossy(&event.bytes).into_owned(),
                )),
                _ => {}
            }
        }
        events
    }
    pub fn prefer(&mut self, token: u32, action: u32) {
        unsafe { yr_dnd_prefer(self.native.as_ptr(), token, action) };
    }
    pub fn track(&mut self, task: u64, token: u32, action: u32) {
        self.pending.push(Pending {
            task,
            token,
            action,
        });
    }
    pub fn cancel(&mut self, token: u32) {
        unsafe { yr_dnd_finish(self.native.as_ptr(), token, 0, 1) };
    }
    pub fn finish_tasks(&mut self, tasks: &[crate::operations::Task]) {
        self.pending.retain(|pending| {
            let Some(task) = tasks.iter().find(|task| task.id == pending.task) else {
                return true;
            };
            use crate::operations::Status;
            if matches!(
                task.status,
                Status::Queued | Status::Running | Status::Waiting
            ) {
                return true;
            }
            unsafe {
                yr_dnd_finish(
                    self.native.as_ptr(),
                    pending.token,
                    i32::from(
                        task.status == Status::Completed
                            && task.warnings.is_empty()
                            && pending.action != 0,
                    ),
                    pending.action,
                )
            };
            false
        });
    }
}
impl std::ops::Drop for Dnd {
    fn drop(&mut self) {
        unsafe { yr_dnd_destroy(self.native.as_ptr()) };
    }
}
fn paths(data: &[u8]) -> Result<Vec<PathBuf>, String> {
    let text = std::str::from_utf8(data).map_err(|e| e.to_string())?;
    text.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(crate::locations::local_uri)
        .collect()
}
pub fn preferred(paths: &[PathBuf], destination: &Path) -> u32 {
    use std::os::unix::fs::MetadataExt;
    let Ok(target) = std::fs::metadata(destination) else {
        return 1;
    };
    if !paths.is_empty()
        && paths
            .iter()
            .all(|path| std::fs::symlink_metadata(path).is_ok_and(|m| m.dev() == target.dev()))
    {
        2
    } else {
        1
    }
}
