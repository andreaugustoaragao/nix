use crate::{finder::Engine, locations::Location};
use gio::prelude::*;
use rune::{Latest, TextEdit};
use std::{
    path::{Path, PathBuf},
    sync::Arc,
    time::{Duration, Instant},
};

pub struct Completion {
    pub name: String,
    pub value: String,
}

#[derive(Clone)]
struct DirectoryIndex {
    root: PathBuf,
    engine: Arc<Engine>,
    paths: Arc<Vec<String>>,
}

struct Completions {
    choices: Vec<Completion>,
    index: Option<DirectoryIndex>,
    scanning: bool,
}

enum Reply {
    Complete(Completions),
    Open(Location),
}

pub struct Address {
    pub input: TextEdit,
    pub editing: bool,
    pub choices: Vec<Completion>,
    pub selected: Option<usize>,
    pub error: Option<String>,
    pub opening: bool,
    pub scanning: bool,
    pub fuzzy: bool,
    index: Option<DirectoryIndex>,
    refreshed: Instant,
    query: Option<String>,
    worker: Latest<Result<Reply, String>>,
    cancel: gio::Cancellable,
}

impl Default for Address {
    fn default() -> Self {
        Self {
            input: TextEdit::new(""),
            editing: false,
            choices: Vec::new(),
            selected: None,
            error: None,
            opening: false,
            scanning: false,
            fuzzy: false,
            index: None,
            refreshed: Instant::now(),
            query: None,
            worker: Latest::default().debounce(Duration::from_millis(65)),
            cancel: gio::Cancellable::new(),
        }
    }
}

impl Address {
    pub fn set_waker(&self, waker: rune::Waker) {
        self.worker.set_waker(waker);
    }

    pub fn edit(&mut self, value: String) {
        self.close();
        let mut editor = TextEdit::new(value);
        editor.set_selection(0, editor.text.len());
        editor.focused = true;
        self.input = editor;
        self.editing = true;
    }

    pub fn close(&mut self) {
        self.cancel.cancel();
        self.worker.cancel();
        self.editing = false;
        self.input.focused = false;
        self.query = None;
        self.choices.clear();
        self.selected = None;
        self.error = None;
        self.opening = false;
        self.scanning = false;
        self.fuzzy = false;
        self.index = None;
    }

    fn cancel_work(&mut self) {
        self.scanning = false;
        self.cancel.cancel();
        self.worker.cancel();
        self.cancel = gio::Cancellable::new();
        self.error = None;
    }

    pub fn choose(&mut self, index: usize) {
        if self.query.as_deref() != Some(self.input.text.as_str()) {
            return;
        }
        let Some(choice) = self.choices.get(index) else {
            return;
        };
        let mut editor = TextEdit::new(&choice.value);
        editor.set_selection(editor.text.len(), editor.text.len());
        editor.focused = true;
        self.input = editor;
        self.editing = true;
        self.selected = None;
        self.query = None;
    }

    pub fn step(&mut self, forward: bool) {
        if self.choices.is_empty() {
            return;
        }
        let count = self.choices.len();
        self.selected = Some(match self.selected {
            Some(i) if forward => (i + 1) % count,
            Some(i) => (i + count - 1) % count,
            None if forward => 0,
            None => count - 1,
        });
    }

    pub fn submit(&mut self, cwd: &Path) {
        if let Some(index) = self.selected {
            self.choose(index);
        }
        if !self.editing {
            return;
        }
        let value = self.input.text.clone();
        if value.is_empty() {
            self.error = Some("Enter a folder path or location URI".into());
            return;
        }
        let location = match Location::parse(&value, cwd) {
            Ok(location) => location,
            Err(error) => {
                self.error = Some(error);
                return;
            }
        };
        self.cancel_work();
        self.query = Some(value.clone());
        self.opening = true;
        self.choices.clear();
        let cancel = self.cancel.clone();
        let cwd = cwd.to_path_buf();
        let index = self.index.clone();
        self.worker.request(
            (location, cancel, value, cwd, index),
            |(location, cancel, value, cwd, index)| {
                let location = match location {
                    Location::Path(path) => {
                        let file = gio::File::for_path(path);
                        let kind =
                            file.query_file_type(gio::FileQueryInfoFlags::NONE, Some(&cancel));
                        if kind == gio::FileType::Unknown {
                            return complete(&value, &cwd, &cancel, index).map(Reply::Complete);
                        }
                        if kind != gio::FileType::Directory {
                            return Err(
                                "Folder unavailable. Check the path and access permissions.".into(),
                            );
                        }
                        Location::Path(file.path().ok_or("This location has no local path")?)
                    }
                    location => location,
                };
                Ok(Reply::Open(location))
            },
        );
    }

    pub fn poll(&mut self, cwd: &Path) -> (bool, Option<Location>) {
        if !self.editing {
            return (false, None);
        }
        let value = self.input.text.clone();
        let mut changed = false;
        if self.query.as_ref() != Some(&value) {
            self.cancel_work();
            self.query = Some(value.clone());
            self.opening = false;
            self.choices.clear();
            self.selected = None;
            self.search(value, cwd);
            changed = true;
        }
        if let Some(reply) = self.worker.take() {
            match reply {
                Ok(Reply::Complete(result)) => {
                    let previous = self
                        .selected
                        .and_then(|i| self.choices.get(i))
                        .map(|choice| choice.value.clone());
                    self.choices = result.choices;
                    self.fuzzy = result.index.is_some();
                    self.scanning = result.scanning;
                    self.index = result.index;
                    self.selected = previous
                        .and_then(|value| {
                            self.choices.iter().position(|choice| choice.value == value)
                        })
                        .or_else(|| (self.fuzzy && !self.choices.is_empty()).then_some(0));
                    if self.opening
                        && !self.scanning
                        && self
                            .choices
                            .first()
                            .is_some_and(|choice| choice.value != self.input.text)
                    {
                        self.choose(0);
                        self.submit(cwd);
                    } else if self.opening && !self.scanning {
                        self.opening = false;
                        self.error = Some(
                            "Folder unavailable. Check the path and access permissions.".into(),
                        );
                    }
                }
                Ok(Reply::Open(location)) => return (true, Some(location)),
                Err(error) => {
                    self.opening = false;
                    self.scanning = false;
                    self.error = Some(error);
                }
            }
            changed = true;
        }
        if self.scanning
            && !self.worker.is_pending()
            && self.refreshed.elapsed() >= Duration::from_millis(120)
        {
            self.search(self.input.text.clone(), cwd);
        }
        (changed, None)
    }

    fn search(&mut self, value: String, cwd: &Path) {
        let cwd = cwd.to_path_buf();
        let cancel = self.cancel.clone();
        let index = self.index.clone();
        self.worker.request(
            (value, cwd, cancel, index),
            |(value, cwd, cancel, index)| {
                complete(&value, &cwd, &cancel, index).map(Reply::Complete)
            },
        );
        self.refreshed = Instant::now();
    }
}

fn complete(
    value: &str,
    cwd: &Path,
    cancel: &gio::Cancellable,
    cached: Option<DirectoryIndex>,
) -> Result<Completions, String> {
    if !value.contains("://") && !value.starts_with("file:") {
        let mut prefix = value.rfind('/').map_or("", |i| &value[..i + 1]);
        loop {
            let location = Location::parse(if prefix.is_empty() { "." } else { prefix }, cwd)?;
            let Location::Path(root) = location else {
                unreachable!()
            };
            let folder = gio::File::for_path(&root);
            if folder.query_file_type(gio::FileQueryInfoFlags::NONE, Some(cancel))
                == gio::FileType::Directory
            {
                let query = &value[prefix.len()..];
                let exact = gio::File::for_path(crate::state::expand_path(value, cwd));
                if root.parent().is_some()
                    && query.chars().filter(|c| !c.is_whitespace()).count() >= 2
                    && !query.starts_with('.')
                    && exact.query_file_type(gio::FileQueryInfoFlags::NONE, Some(cancel))
                        == gio::FileType::Unknown
                {
                    let root = folder.path().ok_or("This location has no local path")?;
                    let mut index = match cached {
                        Some(index) if index.root == root => index,
                        _ => DirectoryIndex {
                            engine: Arc::new(Engine::navigation(root.clone())?),
                            root,
                            paths: Arc::default(),
                        },
                    };
                    if cancel.is_cancelled() {
                        return Err("Cancelled".into());
                    }
                    let guard = index
                        .engine
                        .index
                        .read()
                        .map_err(|error| error.to_string())?;
                    let picker = guard.as_ref().ok_or("Folder index is unavailable")?;
                    let dirs = picker.get_dirs();
                    if index.paths.len() != dirs.len() {
                        index.paths =
                            Arc::new(dirs.iter().map(|dir| dir.relative_path(picker)).collect());
                    }
                    let scanning = picker.get_scan_progress().is_scanning;
                    drop(guard);
                    let config = neo_frizbee::Config {
                        max_typos: Some(0),
                        ..Default::default()
                    };
                    let mut matcher = neo_frizbee::Matcher::from_query(query, &config);
                    let choices = matcher
                        .match_list_parallel(index.paths.as_slice(), 2)
                        .into_iter()
                        .filter_map(|matched| {
                            let name = &index.paths[matched.index as usize];
                            (!name.is_empty()).then(|| Completion {
                                value: format!("{prefix}{}/", name.trim_end_matches('/')),
                                name: name.clone(),
                            })
                        })
                        .take(8)
                        .collect();
                    return Ok(Completions {
                        choices,
                        index: Some(index),
                        scanning,
                    });
                }
                break;
            }
            if cancel.is_cancelled() {
                return Err("Cancelled".into());
            }
            let shorter = prefix.trim_end_matches('/');
            let next = shorter.rfind('/').map_or("", |i| &shorter[..i + 1]);
            if prefix.is_empty() || next == prefix {
                break;
            }
            prefix = next;
        }
    }
    complete_prefix(value, cwd, cancel).map(|choices| Completions {
        choices,
        index: None,
        scanning: false,
    })
}

fn complete_prefix(
    value: &str,
    cwd: &Path,
    cancel: &gio::Cancellable,
) -> Result<Vec<Completion>, String> {
    let (prefix, name) = value
        .rsplit_once('/')
        .map_or(("", value), |(parent, name)| {
            (&value[..parent.len() + 1], name)
        });
    let location = Location::parse(if prefix.is_empty() { "." } else { prefix }, cwd)?;
    let decoded = if value.contains("://") || value.starts_with("file:") {
        gio::File::for_uri(value).basename()
    } else {
        None
    };
    let name = if name.is_empty() {
        name
    } else {
        decoded.as_deref().and_then(Path::to_str).unwrap_or(name)
    };
    let remote = matches!(location, Location::Uri(_));
    let folder = match location {
        Location::Path(path) => gio::File::for_path(path),
        Location::Uri(uri) => gio::File::for_uri(&uri),
    };
    let entries = folder
        .enumerate_children(
            "standard::name,standard::display-name,standard::type",
            gio::FileQueryInfoFlags::NONE,
            Some(cancel),
        )
        .map_err(|error| error.to_string())?;
    let mut choices = Vec::new();
    while let Some(info) = entries
        .next_file(Some(cancel))
        .map_err(|error| error.to_string())?
    {
        if cancel.is_cancelled() {
            break;
        }
        let path = info.name();
        let Some(entry) = path.to_str() else { continue };
        if info.file_type() != gio::FileType::Directory
            || !entry.starts_with(name)
            || (entry.starts_with('.') && !name.starts_with('.'))
        {
            continue;
        }
        let value = if remote || prefix.starts_with("file:") {
            format!("{}/", folder.child(&path).uri().trim_end_matches('/'))
        } else {
            format!("{prefix}{entry}/")
        };
        choices.push(Completion {
            name: info.display_name().into(),
            value,
        });
        if choices.len() == 8 {
            break;
        }
    }
    choices.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(choices)
}
