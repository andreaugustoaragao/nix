use gio::prelude::*;
use serde::Serialize;
use std::{fs, path::PathBuf};

#[derive(Clone, Serialize)]
pub struct Place {
    pub name: String,
    pub uri: String,
    pub path: Option<PathBuf>,
    pub volume: Option<String>,
    pub mounted: bool,
    pub eject: bool,
    pub unmount: bool,
}

pub fn places() -> Vec<Place> {
    let home = crate::state::home();
    let mut places = Vec::new();
    for (name, path) in [
        ("Home", home.clone()),
        ("Downloads", home.join("Downloads")),
        ("Desktop", home.join("Desktop")),
        ("Documents", home.join("Documents")),
        ("Pictures", home.join("Pictures")),
        ("Filesystem", PathBuf::from("/")),
    ] {
        if path.is_dir() {
            places.push(Place {
                name: name.into(),
                uri: gio::File::for_path(&path).uri().to_string(),
                path: Some(path),
                volume: None,
                mounted: true,
                eject: false,
                unmount: false,
            });
        }
    }
    for line in fs::read_to_string(bookmark_path())
        .unwrap_or_default()
        .lines()
    {
        let (uri, name) = line.split_once(' ').unwrap_or((line, ""));
        if url::Url::parse(uri).is_err() || places.iter().any(|p| p.uri == uri) {
            continue;
        }
        let name = if name.is_empty() {
            gio::File::for_uri(uri)
                .basename()
                .map(|p| p.to_string_lossy().into_owned())
                .unwrap_or_else(|| uri.into())
        } else {
            name.into()
        };
        places.push(Place {
            name,
            uri: uri.into(),
            path: gio::File::for_uri(uri).path(),
            volume: None,
            mounted: true,
            eject: false,
            unmount: false,
        });
    }
    places.push(Place {
        name: "Trash".into(),
        uri: "trash:///".into(),
        path: None,
        volume: None,
        mounted: true,
        eject: false,
        unmount: false,
    });
    let monitor = gio::VolumeMonitor::get();
    for volume in monitor.volumes() {
        let id = volume
            .uuid()
            .map(|s| s.to_string())
            .unwrap_or_else(|| volume.name().to_string());
        let mount = volume.get_mount();
        let uri = mount
            .as_ref()
            .map(|m| m.root().uri().to_string())
            .or_else(|| volume.activation_root().map(|f| f.uri().to_string()))
            .unwrap_or_default();
        places.push(Place {
            name: volume.name().to_string(),
            uri,
            path: mount.as_ref().and_then(|mount| mount.root().path()),
            volume: Some(id),
            mounted: mount.is_some(),
            eject: volume.can_eject(),
            unmount: mount.as_ref().is_some_and(|m| m.can_unmount()),
        });
    }
    for mount in monitor.mounts() {
        let uri = mount.root().uri().to_string();
        if let Some(place) = places.iter_mut().find(|p| p.uri == uri) {
            place.path = mount.root().path();
            place.mounted = true;
            place.eject = mount.can_eject();
            place.unmount = mount.can_unmount();
            if place.name == uri {
                place.name = mount.name().to_string();
            }
        } else {
            places.push(Place {
                name: mount.name().to_string(),
                uri,
                path: mount.root().path(),
                volume: None,
                mounted: true,
                eject: mount.can_eject(),
                unmount: mount.can_unmount(),
            });
        }
    }
    places
}

fn bookmark_path() -> PathBuf {
    std::env::var_os("XDG_CONFIG_HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| crate::state::home().join(".config"))
        .join("gtk-3.0/bookmarks")
}

pub fn bookmark(uri: String) -> Result<String, String> {
    let path = bookmark_path();
    fs::create_dir_all(path.parent().expect("bookmark parent")).map_err(|e| e.to_string())?;
    let file = gio::File::for_path(path);
    for _ in 0..3 {
        let (contents, etag) = match file.load_contents(gio::Cancellable::NONE) {
            Ok((contents, etag)) => (String::from_utf8_lossy(&contents).into_owned(), etag),
            Err(error) if error.matches(gio::IOErrorEnum::NotFound) => (String::new(), None),
            Err(error) => return Err(error.to_string()),
        };
        let mut lines: Vec<_> = contents.lines().map(str::to_owned).collect();
        let existed = lines
            .iter()
            .any(|line| line.split(' ').next() == Some(&uri));
        lines.retain(|line| line.split(' ').next() != Some(&uri));
        if !existed {
            lines.push(uri.clone());
        }
        let data = format!("{}\n", lines.join("\n"));
        match file.replace_contents(
            data.as_bytes(),
            etag.as_deref(),
            false,
            gio::FileCreateFlags::PRIVATE,
            gio::Cancellable::NONE,
        ) {
            Ok(_) => {
                return Ok(if existed {
                    "Bookmark removed"
                } else {
                    "Folder bookmarked"
                }
                .into());
            }
            Err(error) if error.matches(gio::IOErrorEnum::WrongEtag) => continue,
            Err(error) => return Err(error.to_string()),
        }
    }
    Err("Bookmarks changed concurrently; try again".into())
}

#[derive(Clone, Serialize)]
pub struct Properties {
    pub path: PathBuf,
    pub mime: String,
    pub rows: Vec<(String, String)>,
}

pub fn properties(path: PathBuf, uri: Option<String>) -> Result<Properties, String> {
    let file = uri.map_or_else(
        || gio::File::for_path(&path),
        |uri| gio::File::for_uri(&uri),
    );
    let info = file
        .query_info(
            "standard::*,time::*,unix::*,owner::*,access::*",
            gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
            gio::Cancellable::NONE,
        )
        .map_err(|e| e.to_string())?;
    let mime = info
        .content_type()
        .map(|s| s.to_string())
        .unwrap_or_default();
    let mut rows = vec![
        ("Location".into(), path.display().to_string()),
        ("Type".into(), mime.clone()),
        (
            "Size".into(),
            crate::file::human_size(info.size().max(0) as u64),
        ),
    ];
    for (label, key) in [
        ("Owner", "owner::user"),
        ("Group", "owner::group"),
        ("Modified", "time::modified"),
        ("Created", "time::created"),
        ("Readable", "access::can-read"),
        ("Writable", "access::can-write"),
        ("Executable", "access::can-execute"),
    ] {
        if info.has_attribute(key) {
            let value = if key.starts_with("time::") {
                gio::glib::DateTime::from_unix_local(info.attribute_uint64(key) as i64)
                    .and_then(|time| time.format("%Y-%m-%d %H:%M:%S"))
                    .map(|s| s.to_string())
                    .unwrap_or_default()
            } else {
                info.attribute_as_string(key)
                    .map(|s| s.to_string())
                    .unwrap_or_default()
            };
            rows.push((label.into(), value));
        }
    }
    rows.push((
        "Permissions".into(),
        format!("{:04o}", info.attribute_uint32("unix::mode") & 0o7777),
    ));
    if let Some(target) = info.symlink_target() {
        rows.push(("Link target".into(), target.display().to_string()));
    }
    if info.file_type() == gio::FileType::Directory {
        let mut count = 0u64;
        let mut bytes = 0u64;
        let mut partial = false;
        let mut pending = vec![file];
        while let Some(directory) = pending.pop() {
            let entries = match directory.enumerate_children(
                "standard::name,standard::type,standard::size",
                gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                gio::Cancellable::NONE,
            ) {
                Ok(entries) => entries,
                Err(_) => {
                    partial = true;
                    continue;
                }
            };
            loop {
                let info = match entries.next_file(gio::Cancellable::NONE) {
                    Ok(Some(info)) => info,
                    Ok(None) => break,
                    Err(_) => {
                        partial = true;
                        break;
                    }
                };
                if count == 100_000 {
                    partial = true;
                    break;
                }
                count += 1;
                match info.file_type() {
                    gio::FileType::Directory => pending.push(directory.child(info.name())),
                    gio::FileType::Regular => bytes += info.size().max(0) as u64,
                    _ => {}
                }
            }
            if count == 100_000 {
                break;
            }
        }
        rows.push((
            "Contents".into(),
            format!(
                "{count} items · {}{}",
                crate::file::human_size(bytes),
                if partial { " (partial)" } else { "" }
            ),
        ));
    }
    Ok(Properties { path, mime, rows })
}

#[derive(Clone, Serialize)]
pub struct Application {
    pub id: String,
    pub name: String,
}
#[derive(Clone, Serialize)]
pub struct Applications {
    pub paths: Vec<PathBuf>,
    pub mime: String,
    pub apps: Vec<Application>,
}

pub fn applications(paths: Vec<PathBuf>, uri: Option<String>) -> Result<Applications, String> {
    let path = paths.first().ok_or("Select a file first")?;
    let info = uri
        .map_or_else(|| gio::File::for_path(path), |uri| gio::File::for_uri(&uri))
        .query_info(
            "standard::content-type",
            gio::FileQueryInfoFlags::NONE,
            gio::Cancellable::NONE,
        )
        .map_err(|e| e.to_string())?;
    let mime = info
        .content_type()
        .map(|s| s.to_string())
        .unwrap_or_default();
    let apps = gio::AppInfo::all()
        .into_iter()
        .filter(|app| app.should_show())
        .filter_map(|app| {
            app.id().map(|id| Application {
                id: id.to_string(),
                name: app.display_name().to_string(),
            })
        })
        .collect();
    Ok(Applications { paths, mime, apps })
}

pub fn launch(applications: Applications, id: String, default: bool) -> Result<String, String> {
    let app = gio::AppInfo::all()
        .into_iter()
        .find(|app| app.id().as_deref() == Some(&id))
        .ok_or("Application is no longer installed")?;
    let files: Vec<_> = applications.paths.iter().map(gio::File::for_path).collect();
    app.launch(&files, None::<&gio::AppLaunchContext>)
        .map_err(|e| e.to_string())?;
    if default {
        app.set_as_default_for_type(&applications.mime)
            .map_err(|e| e.to_string())?;
    }
    Ok(format!("Opened with {}", app.display_name()))
}

pub fn local_uri(uri: &str) -> Result<PathBuf, String> {
    gio::File::for_uri(uri)
        .path()
        .ok_or_else(|| "Mount this location first; GVFS/FUSE is required for remote files".into())
}

pub fn launch_custom(paths: Vec<PathBuf>, command: String) -> Result<String, String> {
    let app = gio::AppInfo::create_from_commandline(&command, None, gio::AppInfoCreateFlags::NONE)
        .map_err(|e| e.to_string())?;
    let files: Vec<_> = paths.iter().map(gio::File::for_path).collect();
    app.launch(&files, None::<&gio::AppLaunchContext>)
        .map_err(|e| e.to_string())?;
    Ok("Opened with custom program".into())
}

#[derive(Clone)]
pub enum Location {
    Path(PathBuf),
    Uri(String),
}
impl Location {
    pub fn parse(value: &str, cwd: &std::path::Path) -> Result<Self, String> {
        if !value.contains("://") && !value.starts_with("file:") {
            return Ok(Self::Path(crate::state::expand_path(value, cwd)));
        }
        let mut uri = url::Url::parse(value).map_err(|e| e.to_string())?;
        if uri.scheme() == "file" {
            return uri
                .to_file_path()
                .map(Self::Path)
                .map_err(|_| "A file URI must refer to this computer".into());
        }
        // Credentials are requested through the secure authentication dialog.
        let _ = uri.set_password(None);
        Ok(Self::Uri(uri.to_string()))
    }
    pub fn argument(&self) -> &std::ffi::OsStr {
        match self {
            Self::Path(path) => path.as_os_str(),
            Self::Uri(uri) => std::ffi::OsStr::new(uri),
        }
    }
    pub fn folder(&self) -> bool {
        match self {
            Self::Path(path) => path.is_dir(),
            Self::Uri(_) => true,
        }
    }
}
