//! Visible-image thumbnails from the shared freedesktop cache.
//!
//! The UI thread only records the visible list. A worker reads small cached PNGs
//! and talks to `org.freedesktop.thumbnails.Thumbnailer1`.

use std::{
    collections::{HashMap, HashSet, VecDeque},
    path::{Path, PathBuf},
    sync::Arc,
    time::SystemTime,
};

use futures_util::StreamExt;
use gio::prelude::*;
use tokio::sync::{mpsc, oneshot, watch};

use crate::file::File;

const LIMIT: usize = 256;
const MAX_PNG: usize = 2 * 1024 * 1024;
const FLAVOR: &str = "large";
/// Longest side of a freedesktop `large` thumbnail, in pixels.
const FLAVOR_PX: u32 = 256;
const SCHEDULER: &str = "foreground";
const DEST: &str = "org.freedesktop.thumbnails.Thumbnailer1";
const OBJECT: &str = "/org/freedesktop/thumbnails/Thumbnailer1";
const INTERFACE: &str = "org.freedesktop.thumbnails.Thumbnailer1";
const PNG: &[u8] = b"\x89PNG\r\n\x1a\n";

/// Counts from the latest `set_visible` and the worker.
///
/// `service` stays `None` until a thumbnailer connection is attempted.
/// `skipped` counts image files whose URI is not a local `file:` URI.
/// `deferred` counts image files past the 256-file cap.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[allow(dead_code)]
pub struct Counters {
    pub visible: usize,
    pub ready: usize,
    pub failed: usize,
    pub queued: usize,
    pub skipped: usize,
    pub deferred: usize,
    pub service: Option<bool>,
}

#[derive(Clone, PartialEq, Eq)]
struct Item {
    path: PathBuf,
    size: u64,
    modified: Option<SystemTime>,
    uri: String,
    mime: &'static str,
}

impl Item {
    fn key(&self) -> Key {
        Key {
            path: self.path.clone(),
            size: self.size,
            modified: self.modified,
        }
    }
}

#[derive(Clone, Default)]
struct Desired {
    generation: u64,
    items: Vec<Item>,
}

#[derive(Clone, PartialEq, Eq, Hash)]
struct Key {
    path: PathBuf,
    size: u64,
    modified: Option<SystemTime>,
}

struct Slot {
    size: u64,
    modified: Option<SystemTime>,
    image: Option<rune::Image>,
}

enum Update {
    Service(bool),
    Queued {
        generation: u64,
        count: usize,
    },
    Ready {
        generation: u64,
        path: PathBuf,
        size: u64,
        modified: Option<SystemTime>,
        image: rune::Image,
    },
    Failed {
        generation: u64,
        path: PathBuf,
        size: u64,
        modified: Option<SystemTime>,
    },
}

enum Control {
    Restart,
    Stop,
}

enum Accept {
    Current,
    AnyUri,
}

enum Fresh {
    Current,
    Uri,
    Reject,
}

#[derive(Default)]
struct Located {
    large: Option<PathBuf>,
    other: Option<PathBuf>,
    blocked: bool,
}

#[derive(Default)]
struct Memo {
    order: VecDeque<Key>,
    keys: HashSet<Key>,
}

impl Memo {
    fn contains(&self, key: &Key) -> bool {
        self.keys.contains(key)
    }

    fn insert(&mut self, key: Key) {
        if !self.keys.insert(key.clone()) {
            return;
        }
        self.order.push_back(key);
        while self.keys.len() > LIMIT {
            if let Some(old) = self.order.pop_front() {
                self.keys.remove(&old);
            }
        }
    }

    fn remove(&mut self, key: &Key) {
        if self.keys.remove(key) {
            self.order.retain(|item| item != key);
        }
    }
}

type Bus = (zbus::Proxy<'static>, zbus::proxy::SignalStream<'static>);

/// Bounded thumbnail broker.
///
/// `image` is empty until a small cached PNG is loaded, and after a failure,
/// so the generic icon stays up. A returned image can still be decoding;
/// `ImageCache` wakes the UI when its pixels are ready.
#[allow(dead_code)]
pub struct Thumbnails {
    desired: watch::Sender<Desired>,
    results: mpsc::Receiver<Update>,
    stop: Option<oneshot::Sender<()>>,
    cancel: gio::Cancellable,
    thread: Option<std::thread::JoinHandle<()>>,
    generation: u64,
    items: Vec<Item>,
    slots: HashMap<PathBuf, Slot>,
    counters: Counters,
}

#[allow(dead_code)]
impl Thumbnails {
    pub fn new(cache: Arc<rune::ImageCache>, waker: rune::Waker) -> Self {
        let (desired_tx, desired_rx) = watch::channel(Desired::default());
        let (tx, results) = mpsc::channel(LIMIT);
        let (stop_tx, stop_rx) = oneshot::channel();
        let cancel = gio::Cancellable::new();
        let lookup = cancel.clone();
        let thread = std::thread::Builder::new()
            .name("rune-thumbnails".into())
            .spawn(move || {
                let Ok(runtime) = tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                else {
                    return;
                };
                runtime.block_on(serve(desired_rx, tx, cache, waker, stop_rx, lookup));
            })
            .ok();
        Self {
            desired: desired_tx,
            results,
            stop: Some(stop_tx),
            cancel,
            thread,
            generation: 0,
            items: Vec::new(),
            slots: HashMap::new(),
            counters: Counters::default(),
        }
    }

    /// Replaces the visible set. Files that are no longer visible drop their images.
    ///
    /// This does not read the disk or talk to the bus. Only absolute local `file:`
    /// URIs are queued. Remote URIs stay on the generic icon.
    pub fn set_visible(&mut self, files: Vec<(File, String)>) {
        let mut items = Vec::new();
        let mut skipped = 0;
        let mut deferred = 0;
        let mut seen = HashSet::new();
        for (file, uri) in files {
            let Some(mime) = image_mime(&file) else {
                continue;
            };
            if !file.path.is_absolute() || !local_file_uri(&uri) {
                skipped += 1;
                continue;
            }
            if !seen.insert(file.path.clone()) {
                continue;
            }
            if items.len() == LIMIT {
                deferred += 1;
                continue;
            }
            items.push(Item {
                path: file.path,
                size: file.size,
                modified: file.modified,
                uri,
                mime,
            });
        }
        self.counters.skipped = skipped;
        self.counters.deferred = deferred;
        if self.items == items {
            return;
        }

        self.generation = self.generation.wrapping_add(1);
        self.slots.retain(|path, slot| {
            items.iter().any(|item| {
                item.path == *path && item.size == slot.size && item.modified == slot.modified
            })
        });
        self.items = items.clone();
        self.counters.visible = self.items.len();
        self.counters.queued = 0;
        self.recount();
        let _ = self.desired.send(Desired {
            generation: self.generation,
            items,
        });
    }

    /// Moves worker results into the visible map. `true` when that map or the
    /// service flag changed.
    pub fn poll(&mut self) -> bool {
        let before = self.counters;
        let mut changed = false;
        while let Ok(update) = self.results.try_recv() {
            changed |= self.apply(update);
        }
        self.recount();
        changed || self.counters != before
    }

    /// The thumbnail for this path, size, and modification time.
    pub fn image(&self, file: &File) -> Option<&rune::Image> {
        let slot = self.slots.get(&file.path)?;
        if slot.size == file.size && slot.modified == file.modified {
            slot.image.as_ref().filter(|image| image.size().is_some())
        } else {
            None
        }
    }

    /// Drops the visible set and asks the worker to dequeue its own handle.
    pub fn cancel(&mut self) {
        self.items.clear();
        self.slots.clear();
        self.generation = self.generation.wrapping_add(1);
        let service = self.counters.service;
        self.counters = Counters {
            service,
            ..Counters::default()
        };
        let _ = self.desired.send(Desired {
            generation: self.generation,
            items: Vec::new(),
        });
    }

    pub fn counters(&self) -> Counters {
        self.counters
    }

    fn recount(&mut self) {
        self.counters.ready = self
            .slots
            .values()
            .filter(|slot| {
                slot.image
                    .as_ref()
                    .is_some_and(|image| image.size().is_some())
            })
            .count();
        self.counters.failed = self
            .slots
            .values()
            .filter(|slot| {
                slot.image
                    .as_ref()
                    .is_none_or(|image| image.error().is_some())
            })
            .count();
    }

    fn apply(&mut self, update: Update) -> bool {
        match update {
            Update::Service(up) => {
                let changed = self.counters.service != Some(up);
                self.counters.service = Some(up);
                changed
            }
            Update::Queued { generation, count } => {
                if generation != self.generation {
                    return false;
                }
                let changed = self.counters.queued != count;
                self.counters.queued = count;
                changed
            }
            Update::Ready {
                generation,
                path,
                size,
                modified,
                image,
            } => self.store(generation, path, size, modified, Some(image)),
            Update::Failed {
                generation,
                path,
                size,
                modified,
            } => {
                let kept = self.slots.get(&path).is_some_and(|slot| {
                    slot.image.is_some() && slot.size == size && slot.modified == modified
                });
                if kept {
                    return false;
                }
                self.store(generation, path, size, modified, None)
            }
        }
    }

    fn store(
        &mut self,
        generation: u64,
        path: PathBuf,
        size: u64,
        modified: Option<SystemTime>,
        image: Option<rune::Image>,
    ) -> bool {
        if generation != self.generation {
            return false;
        }
        if !self
            .items
            .iter()
            .any(|item| item.path == path && item.size == size && item.modified == modified)
        {
            return false;
        }
        self.slots.insert(
            path,
            Slot {
                size,
                modified,
                image,
            },
        );
        self.recount();
        true
    }
}

impl Drop for Thumbnails {
    fn drop(&mut self) {
        self.cancel.cancel();
        if let Some(stop) = self.stop.take() {
            let _ = stop.send(());
        }
        // Detach. Joining here would wait out a mount lookup on the UI thread.
        // The worker still dequeues its own thumbnailer handle after `stop`.
        drop(self.thread.take());
    }
}

/// Extension check for the formats this broker asks the thumbnailer to build.
#[allow(dead_code)]
pub fn is_image(file: &File) -> bool {
    image_mime(file).is_some()
}

fn image_mime(file: &File) -> Option<&'static str> {
    if file.directory {
        return None;
    }
    let extension = file.path.extension()?.to_str()?.to_ascii_lowercase();
    Some(match extension.as_str() {
        "jpg" | "jpeg" | "jpe" => "image/jpeg",
        "png" => "image/png",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "svg" => "image/svg+xml",
        "svgz" => "image/svg+xml-compressed",
        "heic" | "heif" => "image/heif",
        "dng" => "image/x-adobe-dng",
        "cr2" => "image/x-canon-cr2",
        "crw" => "image/x-canon-crw",
        "raf" => "image/x-fuji-raf",
        "mrw" => "image/x-minolta-mrw",
        "nef" => "image/x-nikon-nef",
        "nrw" => "image/x-nikon-nrw",
        "orf" => "image/x-olympus-orf",
        "raw" => "image/x-panasonic-raw",
        "rw2" => "image/x-panasonic-rw2",
        "pef" => "image/x-pentax-pef",
        "arw" => "image/x-sony-arw",
        _ => return None,
    })
}

fn local_file_uri(uri: &str) -> bool {
    let Some(rest) = uri.strip_prefix("file:") else {
        return false;
    };
    let Some(rest) = rest.strip_prefix("//") else {
        return rest.starts_with('/');
    };
    if rest.starts_with('/') {
        return true;
    }
    let Some((host, path)) = rest.split_once('/') else {
        return false;
    };
    (host.is_empty() || host.eq_ignore_ascii_case("localhost")) && !path.is_empty()
}

fn names_path(uri: &str, path: &Path) -> bool {
    gio::File::for_uri(uri)
        .path()
        .is_some_and(|got| got == path)
}

fn stopped(stop: &mut oneshot::Receiver<()>) -> bool {
    match stop.try_recv() {
        Ok(()) | Err(oneshot::error::TryRecvError::Closed) => true,
        Err(oneshot::error::TryRecvError::Empty) => false,
    }
}

async fn serve(
    mut desired: watch::Receiver<Desired>,
    tx: mpsc::Sender<Update>,
    cache: Arc<rune::ImageCache>,
    waker: rune::Waker,
    mut stop: oneshot::Receiver<()>,
    cancel: gio::Cancellable,
) {
    let mut ctx = Ctx {
        desired: &mut desired,
        stop: &mut stop,
        tx: &tx,
        cache: &cache,
        waker: &waker,
        failed: Memo::default(),
        shown: Memo::default(),
        bus: None,
        handle: None,
        service: None,
        cancel: &cancel,
    };
    loop {
        let snapshot = ctx.desired.borrow_and_update().clone();
        match ctx.drive(snapshot).await {
            Ok(()) => {}
            Err(Control::Restart) => continue,
            Err(Control::Stop) => break,
        }
        match ctx.idle().await {
            Control::Restart => continue,
            Control::Stop => break,
        }
    }
    ctx.release().await;
}

struct Ctx<'a> {
    desired: &'a mut watch::Receiver<Desired>,
    stop: &'a mut oneshot::Receiver<()>,
    tx: &'a mpsc::Sender<Update>,
    cache: &'a rune::ImageCache,
    waker: &'a rune::Waker,
    failed: Memo,
    shown: Memo,
    bus: Option<Bus>,
    handle: Option<u32>,
    service: Option<bool>,
    cancel: &'a gio::Cancellable,
}

impl Ctx<'_> {
    async fn drive(&mut self, desired: Desired) -> Result<(), Control> {
        let generation = desired.generation;
        self.release().await;
        self.check().await?;
        if desired.items.is_empty() {
            return Ok(());
        }

        let mut queue = Vec::new();
        for mut item in desired.items {
            self.check().await?;
            let canonical = gio::File::for_path(&item.path).uri().to_string();
            if !names_path(&item.uri, &item.path) {
                let key = item.key();
                self.failed.insert(key);
                self.fail(generation, &item).await?;
                continue;
            }
            item.uri = canonical;
            if matches!(item.mime, "image/svg+xml" | "image/svg+xml-compressed") {
                if let Some(bytes) = read_svg(&item.path).await {
                    self.send(Update::Ready {
                        generation,
                        path: item.path.clone(),
                        size: item.size,
                        modified: item.modified,
                        image: self.cache.svg(bytes, FLAVOR_PX as f32, 1.0),
                    })
                    .await?;
                } else {
                    self.fail(generation, &item).await?;
                }
                continue;
            }
            let located = locate(item.path.clone(), self.cancel.clone()).await;
            let key = item.key();
            let showed_large = match located.large.as_deref() {
                Some(path) => self.show(generation, &item, path, Accept::Current).await?,
                None => false,
            };
            if showed_large {
                self.shown.insert(key.clone());
                self.failed.remove(&key);
                continue;
            }
            let showed_other = match located.other.as_deref() {
                Some(path) => self.show(generation, &item, path, Accept::Current).await?,
                None => false,
            };
            if self.failed.contains(&key) {
                if !showed_other {
                    self.fail(generation, &item).await?;
                }
                continue;
            }
            if self.shown.contains(&key) {
                if !showed_other {
                    let recovered = self.recover(generation, &item, &located).await?;
                    if !recovered {
                        self.fail(generation, &item).await?;
                    }
                }
                continue;
            }
            if located.blocked {
                self.failed.insert(key);
                if !showed_other {
                    self.fail(generation, &item).await?;
                }
                continue;
            }
            queue.push(item);
        }

        if queue.is_empty() {
            return Ok(());
        }
        if !self.ensure_bus().await? {
            return Ok(());
        }
        if self.enqueue(&queue).await.is_err() {
            self.bus = None;
            self.note_service(false).await?;
            return Ok(());
        }
        self.send(Update::Queued {
            generation,
            count: queue.len(),
        })
        .await?;
        self.collect(generation, queue).await
    }

    async fn recover(
        &mut self,
        generation: u64,
        item: &Item,
        located: &Located,
    ) -> Result<bool, Control> {
        if let Some(path) = located.large.as_deref()
            && self.show(generation, item, path, Accept::AnyUri).await?
        {
            return Ok(true);
        }
        if let Some(path) = located.other.as_deref()
            && self.show(generation, item, path, Accept::AnyUri).await?
        {
            return Ok(true);
        }
        Ok(false)
    }

    async fn collect(&mut self, generation: u64, mut pending: Vec<Item>) -> Result<(), Control> {
        let handle = self.handle.unwrap_or(0);
        loop {
            let wake = {
                let Some((_, signals)) = self.bus.as_mut() else {
                    return Ok(());
                };
                tokio::select! {
                    biased;
                    _ = &mut *self.stop => Wake::Stop,
                    result = self.desired.changed() => {
                        if result.is_err() { Wake::Stop } else { Wake::Restart }
                    }
                    message = signals.next() => Wake::Signal(message),
                }
            };
            match wake {
                Wake::Stop => {
                    self.release().await;
                    return Err(Control::Stop);
                }
                Wake::Restart => {
                    self.release().await;
                    return Err(Control::Restart);
                }
                Wake::Signal(None) => {
                    self.release().await;
                    self.bus = None;
                    self.note_service(false).await?;
                    return Ok(());
                }
                Wake::Signal(Some(message)) => {
                    self.note_signal(generation, handle, &mut pending, message)
                        .await?;
                    if self.handle.is_none() {
                        return Ok(());
                    }
                }
            }
        }
    }

    async fn note_signal(
        &mut self,
        generation: u64,
        handle: u32,
        pending: &mut Vec<Item>,
        message: zbus::Message,
    ) -> Result<(), Control> {
        let Some(signal) = decode(&message) else {
            return Ok(());
        };
        match signal {
            Signal::Ready(got, uris) if got == handle => {
                let mut rest = Vec::new();
                for item in pending.drain(..) {
                    let listed = uris.iter().any(|uri| uri == &item.uri);
                    if listed && self.finish_one(generation, &item).await? {
                        continue;
                    }
                    rest.push(item);
                }
                *pending = rest;
            }
            Signal::Error(got, uris) if got == handle => {
                let fail_all = uris.is_empty();
                let mut rest = Vec::new();
                for item in pending.drain(..) {
                    if fail_all || uris.iter().any(|uri| uri == &item.uri) {
                        self.failed.insert(item.key());
                        self.fail(generation, &item).await?;
                    } else {
                        rest.push(item);
                    }
                }
                *pending = rest;
            }
            Signal::Finished(got) if got == handle => {
                for item in pending.drain(..) {
                    if !self.finish_one(generation, &item).await? {
                        self.failed.insert(item.key());
                        self.fail(generation, &item).await?;
                    }
                }
                self.handle = None;
            }
            _ => {}
        }
        Ok(())
    }

    async fn finish_one(&mut self, generation: u64, item: &Item) -> Result<bool, Control> {
        let located = locate(item.path.clone(), self.cancel.clone()).await;
        let recovered = self.recover(generation, item, &located).await?;
        if recovered {
            let key = item.key();
            self.shown.insert(key.clone());
            self.failed.remove(&key);
        }
        Ok(recovered)
    }

    async fn show(
        &mut self,
        generation: u64,
        item: &Item,
        thumb: &Path,
        accept: Accept,
    ) -> Result<bool, Control> {
        let Some(image) = read_png(
            self.cache,
            thumb,
            &item.path,
            &item.uri,
            item.size,
            item.modified,
            accept,
        )
        .await
        else {
            return Ok(false);
        };
        self.send(Update::Ready {
            generation,
            path: item.path.clone(),
            size: item.size,
            modified: item.modified,
            image,
        })
        .await?;
        Ok(true)
    }

    async fn fail(&mut self, generation: u64, item: &Item) -> Result<(), Control> {
        self.send(Update::Failed {
            generation,
            path: item.path.clone(),
            size: item.size,
            modified: item.modified,
        })
        .await
    }

    async fn ensure_bus(&mut self) -> Result<bool, Control> {
        if self.bus.is_some() {
            return Ok(true);
        }
        match connect().await {
            Some(bus) => {
                self.bus = Some(bus);
                self.note_service(true).await?;
                Ok(true)
            }
            None => {
                self.note_service(false).await?;
                Ok(false)
            }
        }
    }

    async fn note_service(&mut self, up: bool) -> Result<(), Control> {
        if self.service == Some(up) {
            return Ok(());
        }
        self.service = Some(up);
        self.send(Update::Service(up)).await
    }

    async fn enqueue(&mut self, items: &[Item]) -> Result<(), ()> {
        let previous = self.handle.take().unwrap_or(0);
        let Some((proxy, _)) = self.bus.as_ref() else {
            return Err(());
        };
        let uris: Vec<&str> = items.iter().map(|item| item.uri.as_str()).collect();
        let mimes: Vec<&str> = items.iter().map(|item| item.mime).collect();
        let queued = tokio::time::timeout(std::time::Duration::from_secs(3), async {
            proxy
                .call::<_, _, u32>("Queue", &(uris, mimes, FLAVOR, SCHEDULER, previous))
                .await
        })
        .await
        .ok()
        .and_then(Result::ok);
        let Some(handle) = queued else {
            if previous != 0 {
                let _ = tokio::time::timeout(std::time::Duration::from_secs(1), async {
                    proxy.call::<_, _, ()>("Dequeue", &(previous,)).await
                })
                .await;
            }
            return Err(());
        };
        self.handle = Some(handle);
        Ok(())
    }

    async fn release(&mut self) {
        let Some(handle) = self.handle.take() else {
            return;
        };
        let Some((proxy, _)) = self.bus.as_ref() else {
            return;
        };
        let _ = tokio::time::timeout(std::time::Duration::from_secs(1), async {
            proxy.call::<_, _, ()>("Dequeue", &(handle,)).await
        })
        .await;
    }

    async fn idle(&mut self) -> Control {
        match self.desired.has_changed() {
            Ok(true) => return Control::Restart,
            Err(_) => return Control::Stop,
            Ok(false) => {}
        }
        tokio::select! {
            biased;
            _ = &mut *self.stop => Control::Stop,
            result = self.desired.changed() => {
                if result.is_err() { Control::Stop } else { Control::Restart }
            }
        }
    }

    async fn check(&mut self) -> Result<(), Control> {
        if stopped(self.stop) {
            self.release().await;
            return Err(Control::Stop);
        }
        match self.desired.has_changed() {
            Ok(true) => {
                self.release().await;
                Err(Control::Restart)
            }
            Ok(false) => Ok(()),
            Err(_) => {
                self.release().await;
                Err(Control::Stop)
            }
        }
    }

    async fn send(&mut self, update: Update) -> Result<(), Control> {
        tokio::select! {
            biased;
            _ = &mut *self.stop => Err(Control::Stop),
            result = self.desired.changed() => {
                if result.is_err() { Err(Control::Stop) } else { Err(Control::Restart) }
            }
            sent = self.tx.send(update) => {
                if sent.is_ok() {
                    (self.waker)();
                    Ok(())
                } else {
                    Err(Control::Stop)
                }
            }
        }
    }
}

enum Wake {
    Stop,
    Restart,
    Signal(Option<zbus::Message>),
}

enum Signal {
    Ready(u32, Vec<String>),
    Error(u32, Vec<String>),
    Finished(u32),
}

fn decode(message: &zbus::Message) -> Option<Signal> {
    let member = message.header().member()?.to_string();
    match member.as_str() {
        "Ready" => {
            let (handle, uris) = message.body().deserialize().ok()?;
            Some(Signal::Ready(handle, uris))
        }
        "Error" => {
            let (handle, uris, _code, _message): (u32, Vec<String>, i32, String) =
                message.body().deserialize().ok()?;
            Some(Signal::Error(handle, uris))
        }
        "Finished" => {
            let (handle,) = message.body().deserialize().ok()?;
            Some(Signal::Finished(handle))
        }
        _ => None,
    }
}

async fn connect() -> Option<Bus> {
    let connection = tokio::time::timeout(
        std::time::Duration::from_secs(2),
        zbus::Connection::session(),
    )
    .await
    .ok()?
    .ok()?;
    let proxy = tokio::time::timeout(
        std::time::Duration::from_secs(2),
        zbus::Proxy::new(&connection, DEST, OBJECT, INTERFACE),
    )
    .await
    .ok()?
    .ok()?;
    let flavors: Vec<String> = tokio::time::timeout(
        std::time::Duration::from_secs(2),
        proxy.call("GetFlavors", &()),
    )
    .await
    .ok()?
    .ok()?;
    if !flavors.iter().any(|flavor| flavor == FLAVOR) {
        return None;
    }
    let signals = proxy.receive_all_signals().await.ok()?;
    Some((proxy, signals))
}

async fn locate(path: PathBuf, cancel: gio::Cancellable) -> Located {
    tokio::task::spawn_blocking(move || locate_sync(&path, &cancel))
        .await
        .unwrap_or_default()
}

fn locate_sync(path: &Path, cancel: &gio::Cancellable) -> Located {
    let file = gio::File::for_path(path);
    let Ok(info) = file.query_info(
        "thumbnail::path-large,thumbnail::is-valid-large,thumbnail::failed-large,thumbnail::path",
        gio::FileQueryInfoFlags::NONE,
        Some(cancel),
    ) else {
        return Located::default();
    };
    let large = byte_path(&info, "thumbnail::path-large");
    let other = byte_path(&info, "thumbnail::path").filter(|other| Some(other) != large.as_ref());
    let blocked = info.has_attribute("thumbnail::failed-large")
        && info.boolean("thumbnail::failed-large")
        && info.has_attribute("thumbnail::is-valid-large")
        && info.boolean("thumbnail::is-valid-large");
    Located {
        large,
        other,
        blocked,
    }
}

fn byte_path(info: &gio::FileInfo, attribute: &str) -> Option<PathBuf> {
    let value = info.attribute_byte_string(attribute)?;
    let path = PathBuf::from(value.as_str());
    if path.as_os_str().is_empty() {
        None
    } else {
        Some(path)
    }
}

async fn read_png(
    cache: &rune::ImageCache,
    thumb: &Path,
    source: &Path,
    uri: &str,
    size: u64,
    modified: Option<SystemTime>,
    accept: Accept,
) -> Option<rune::Image> {
    if thumb == source {
        return None;
    }
    let bytes = read_capped(thumb).await?;
    png_extent(&bytes)?;
    let fresh = freshness(&bytes, uri, size, modified);
    let ok = match accept {
        Accept::Current => matches!(fresh, Fresh::Current),
        Accept::AnyUri => matches!(fresh, Fresh::Current | Fresh::Uri),
    };
    if !ok {
        return None;
    }
    Some(cache.load(bytes))
}

async fn read_svg(path: &Path) -> Option<Vec<u8>> {
    let path = path.to_path_buf();
    tokio::task::spawn_blocking(move || {
        use std::io::Read;
        let bytes = read_capped_sync(&path)?;
        if !bytes.starts_with(&[0x1f, 0x8b]) {
            return Some(bytes);
        }
        let mut source = Vec::new();
        flate2::read::GzDecoder::new(bytes.as_slice())
            .take(MAX_PNG as u64 + 1)
            .read_to_end(&mut source)
            .ok()?;
        if source.len() > MAX_PNG || source.starts_with(&[0x1f, 0x8b]) {
            None
        } else {
            Some(source)
        }
    })
    .await
    .ok()
    .flatten()
}

async fn read_capped(path: &Path) -> Option<Vec<u8>> {
    let path = path.to_path_buf();
    tokio::task::spawn_blocking(move || read_capped_sync(&path))
        .await
        .ok()
        .flatten()
}

fn read_capped_sync(path: &Path) -> Option<Vec<u8>> {
    use std::io::Read;
    let meta = std::fs::metadata(path).ok()?;
    let len = meta.len();
    if !meta.is_file() || len == 0 || len > MAX_PNG as u64 {
        return None;
    }
    let mut file = std::fs::File::open(path).ok()?;
    let mut bytes = Vec::new();
    file.by_ref().take(len).read_to_end(&mut bytes).ok()?;
    if bytes.len() as u64 != len || bytes.len() > MAX_PNG {
        return None;
    }
    Some(bytes)
}

/// Width and height of a PNG that fits the `large` thumbnail budget.
fn png_extent(bytes: &[u8]) -> Option<(u32, u32)> {
    if bytes.len() < 24 || &bytes[..8] != PNG || &bytes[12..16] != b"IHDR" {
        return None;
    }
    let width = u32::from_be_bytes(bytes[16..20].try_into().ok()?);
    let height = u32::from_be_bytes(bytes[20..24].try_into().ok()?);
    if width == 0 || height == 0 || width > FLAVOR_PX || height > FLAVOR_PX {
        return None;
    }
    Some((width, height))
}

struct Meta {
    uri: Option<Vec<u8>>,
    mtime: Option<u64>,
    size: Option<u64>,
}

/// Tumbler stores `Thumb::MTime` with a fractional suffix. GLib's verifier
/// requires a pure integer, so `thumbnail::is-valid` stays false for a thumbnail
/// that was just written. Compare the integer seconds here.
fn freshness(bytes: &[u8], uri: &str, size: u64, modified: Option<SystemTime>) -> Fresh {
    let Some(meta) = text_meta(bytes) else {
        return Fresh::Reject;
    };
    if meta.uri.as_deref() != Some(uri.as_bytes()) {
        return Fresh::Reject;
    }
    if meta.size.is_some_and(|got| got != size) {
        return Fresh::Reject;
    }
    match (meta.mtime, modified_seconds(modified)) {
        (Some(got), Some(expected)) if got == expected => Fresh::Current,
        _ => Fresh::Uri,
    }
}

fn text_meta(bytes: &[u8]) -> Option<Meta> {
    if bytes.len() < PNG.len() || &bytes[..PNG.len()] != PNG {
        return None;
    }
    let mut meta = Meta {
        uri: None,
        mtime: None,
        size: None,
    };
    let mut offset = PNG.len();
    while offset + 12 <= bytes.len() {
        let length = u32::from_be_bytes(bytes[offset..offset + 4].try_into().ok()?) as usize;
        let kind = &bytes[offset + 4..offset + 8];
        let data_at = offset + 8;
        let next = data_at.checked_add(length)?.checked_add(4)?;
        if next > bytes.len() {
            break;
        }
        if kind == b"tEXt"
            && let Some(split) = bytes[data_at..data_at + length]
                .iter()
                .position(|byte| *byte == 0)
        {
            let key = &bytes[data_at..data_at + split];
            let value = &bytes[data_at + split + 1..data_at + length];
            match key {
                b"Thumb::URI" if meta.uri.is_none() => meta.uri = Some(value.to_vec()),
                b"Thumb::MTime" if meta.mtime.is_none() => meta.mtime = mtime_seconds(value),
                b"Thumb::Size" if meta.size.is_none() => meta.size = parse_u64(value),
                _ => {}
            }
        }
        if kind == b"IEND" {
            break;
        }
        offset = next;
    }
    Some(meta)
}

fn mtime_seconds(value: &[u8]) -> Option<u64> {
    let digits = value
        .iter()
        .take_while(|byte| byte.is_ascii_digit())
        .count();
    if digits == 0 {
        return None;
    }
    if digits != value.len() && value.get(digits) != Some(&b'.') {
        return None;
    }
    parse_u64(&value[..digits])
}

fn parse_u64(value: &[u8]) -> Option<u64> {
    if value.is_empty() {
        return None;
    }
    let mut number = 0u64;
    for &byte in value {
        let digit = byte.checked_sub(b'0')?;
        if digit > 9 {
            return None;
        }
        number = number.checked_mul(10)?.checked_add(u64::from(digit))?;
    }
    Some(number)
}

fn modified_seconds(modified: Option<SystemTime>) -> Option<u64> {
    modified?
        .duration_since(SystemTime::UNIX_EPOCH)
        .ok()
        .map(|duration| duration.as_secs())
}
