#include <cairo-pdf.h>
#include <cairo.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include <pango/pangocairo.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    double width;
    double height;
    double left;
    double top;
    double right;
    double bottom;
} YrPrintPage;

typedef int (*YrCancelled)(void *);

typedef struct {
    int y0;
    int y1;
} YrLine;

static void set_error(char *error, size_t error_len, const char *text) {
    if (error == NULL || error_len == 0) return;
    snprintf(error, error_len, "%s", text);
}

static int content_box(const YrPrintPage *page, double *width, double *height) {
    *width = page->width - page->left - page->right;
    *height = page->height - page->top - page->bottom;
    return *width >= 36.0 && *height >= 36.0;
}

int yr_print_text_pdf(
    const char *text,
    size_t text_len,
    const YrPrintPage *page,
    const char *path,
    YrCancelled cancelled,
    void *cancel_data,
    char *error,
    size_t error_len
) {
    double content_w = 0.0;
    double content_h = 0.0;
    cairo_surface_t *surface = NULL;
    cairo_t *cr = NULL;
    PangoLayout *layout = NULL;
    PangoFontDescription *font = NULL;
    cairo_status_t status;
    int code = -1;
    if (text == NULL || page == NULL || path == NULL) {
        set_error(error, error_len, "Could not prepare the document for printing");
        return -1;
    }
    if (!content_box(page, &content_w, &content_h)) {
        set_error(error, error_len, "Page margins leave no room to print");
        return -1;
    }
    if (text_len > (size_t)INT_MAX) {
        set_error(error, error_len, "This text file is too large to print");
        return -1;
    }
    surface = cairo_pdf_surface_create(path, page->width, page->height);
    status = cairo_surface_status(surface);
    if (status != CAIRO_STATUS_SUCCESS) {
        set_error(error, error_len, cairo_status_to_string(status));
        cairo_surface_destroy(surface);
        return -1;
    }
    cr = cairo_create(surface);
    layout = pango_cairo_create_layout(cr);
    font = pango_font_description_from_string("Monospace 10");
    pango_layout_set_font_description(layout, font);
    pango_layout_set_width(layout, (int)(content_w * PANGO_SCALE));
    pango_layout_set_wrap(layout, PANGO_WRAP_WORD_CHAR);
    pango_layout_set_text(layout, text, (int)text_len);
    pango_cairo_update_layout(cr, layout);

    int line_count = pango_layout_get_line_count(layout);
    if (line_count <= 0) {
        cairo_show_page(cr);
        code = 0;
    } else {
        /* Line extents are baseline-relative. Iterator y ranges are layout
           coordinates, meet at line boundaries, and include the spacing. */
        YrLine *lines = calloc((size_t)line_count, sizeof *lines);
        PangoLayoutIter *iter = NULL;
        int count = 0;
        int start = 0;
        int guard = 0;
        code = 0;
        if (lines == NULL) {
            set_error(error, error_len, "This text file is too long to print");
            code = -1;
        } else {
            iter = pango_layout_get_iter(layout);
        }
        if (code == 0 && iter == NULL) {
            set_error(error, error_len, "Could not prepare the document for printing");
            code = -1;
        }
        if (code == 0) {
            do {
                if (count >= line_count) break;
                pango_layout_iter_get_line_yrange(iter, &lines[count].y0, &lines[count].y1);
                count++;
            } while (pango_layout_iter_next_line(iter));
        }
        if (iter != NULL) pango_layout_iter_free(iter);
        while (code == 0 && start < count && guard < 100000) {
            int origin = lines[start].y0;
            int end = start;
            double shown;
            if (cancelled != NULL && cancelled(cancel_data)) {
                code = 1;
                break;
            }
            while (end < count) {
                double span = ((double)lines[end].y1 - (double)origin) / PANGO_SCALE;
                if (end > start && span > content_h) break;
                end++;
                if (span > content_h) break;
            }
            if (end == start) end = start + 1;
            shown = ((double)lines[end - 1].y1 - (double)origin) / PANGO_SCALE;
            if (shown > content_h) shown = content_h;
            if (shown < 0.0) shown = 0.0;
            cairo_save(cr);
            cairo_rectangle(cr, page->left, page->top, content_w, shown);
            cairo_clip(cr);
            cairo_set_source_rgb(cr, 0, 0, 0);
            cairo_move_to(cr, page->left, page->top - (double)origin / PANGO_SCALE);
            pango_cairo_show_layout(cr, layout);
            cairo_restore(cr);
            cairo_show_page(cr);
            start = end;
            guard++;
        }
        free(lines);
        if (guard >= 100000 && code == 0) {
            set_error(error, error_len, "This text file is too long to print");
            code = -1;
        }
    }

    if (font != NULL) pango_font_description_free(font);
    if (layout != NULL) g_object_unref(layout);
    if (cr != NULL) cairo_destroy(cr);
    cairo_surface_finish(surface);
    status = cairo_surface_status(surface);
    cairo_surface_destroy(surface);
    if (code == 0 && status != CAIRO_STATUS_SUCCESS) {
        set_error(error, error_len, cairo_status_to_string(status));
        return -1;
    }
    return code;
}

int yr_print_image_supported(const char *mime) {
    static const char *names[] = {"png", "jpeg", "gif", "bmp", "tiff", "webp", NULL};
    GSList *formats;
    GSList *item;
    int supported = 0;
    if (mime == NULL || mime[0] == '\0') return 0;
    formats = gdk_pixbuf_get_formats();
    for (item = formats; item != NULL && !supported; item = item->next) {
        GdkPixbufFormat *format = item->data;
        g_autofree gchar *name = gdk_pixbuf_format_get_name(format);
        gchar **mimes;
        int allowed = 0;
        int i;
        if (name == NULL || gdk_pixbuf_format_is_disabled(format)) continue;
        for (i = 0; names[i] != NULL; i++) {
            if (g_ascii_strcasecmp(name, names[i]) == 0) {
                allowed = 1;
                break;
            }
        }
        if (!allowed) continue;
        mimes = gdk_pixbuf_format_get_mime_types(format);
        if (mimes == NULL) continue;
        for (i = 0; mimes[i] != NULL; i++) {
            if (g_ascii_strcasecmp(mimes[i], mime) == 0) {
                supported = 1;
                break;
            }
        }
        g_strfreev(mimes);
    }
    g_slist_free(formats);
    return supported;
}

int yr_print_image_pdf(
    const char *image_path,
    const YrPrintPage *page,
    const char *pdf_path,
    char *error,
    size_t error_len
) {
    GError *gerror = NULL;
    GdkPixbuf *pixbuf = NULL;
    cairo_surface_t *surface = NULL;
    cairo_surface_t *image = NULL;
    cairo_t *cr = NULL;
    unsigned char *pixels = NULL;
    int width;
    int height;
    int channels;
    int src_stride;
    int dest_stride;
    int code = -1;
    double content_w = 0.0;
    double content_h = 0.0;
    double scale;
    double fitted;
    cairo_status_t status;
    const unsigned char *source;
    if (image_path == NULL || page == NULL || pdf_path == NULL) {
        set_error(error, error_len, "Could not prepare the image for printing");
        return -1;
    }
    if (!content_box(page, &content_w, &content_h)) {
        set_error(error, error_len, "Page margins leave no room to print");
        return -1;
    }
    pixbuf = gdk_pixbuf_new_from_file(image_path, &gerror);
    if (pixbuf == NULL) {
        set_error(error, error_len, gerror != NULL ? gerror->message : "Could not read the image");
        if (gerror != NULL) g_error_free(gerror);
        return -1;
    }
    width = gdk_pixbuf_get_width(pixbuf);
    height = gdk_pixbuf_get_height(pixbuf);
    channels = gdk_pixbuf_get_n_channels(pixbuf);
    src_stride = gdk_pixbuf_get_rowstride(pixbuf);
    if (width <= 0 || height <= 0 || (channels != 3 && channels != 4)) {
        set_error(error, error_len, "Image has no printable size");
        goto done;
    }
    dest_stride = cairo_format_stride_for_width(CAIRO_FORMAT_ARGB32, width);
    if (dest_stride <= 0 || (size_t)height > SIZE_MAX / (size_t)dest_stride) {
        set_error(error, error_len, "Image is too large to print");
        goto done;
    }
    pixels = calloc((size_t)height, (size_t)dest_stride);
    if (pixels == NULL) {
        set_error(error, error_len, "Image is too large to print");
        goto done;
    }
    source = gdk_pixbuf_get_pixels(pixbuf);
    for (int y = 0; y < height; y++) {
        const unsigned char *row = source + (size_t)y * (size_t)src_stride;
        uint32_t *dest = (uint32_t *)(pixels + (size_t)y * (size_t)dest_stride);
        for (int x = 0; x < width; x++) {
            const unsigned char *pixel = row + (size_t)x * (size_t)channels;
            unsigned int alpha = channels == 4 ? pixel[3] : 255;
            unsigned int red = pixel[0] * alpha / 255;
            unsigned int green = pixel[1] * alpha / 255;
            unsigned int blue = pixel[2] * alpha / 255;
            /* Cairo ARGB32 stores native-endian pixels with alpha in the high byte. */
            dest[x] = (alpha << 24) | (red << 16) | (green << 8) | blue;
        }
    }
    image = cairo_image_surface_create_for_data(
        pixels,
        CAIRO_FORMAT_ARGB32,
        width,
        height,
        dest_stride
    );
    status = cairo_surface_status(image);
    if (status != CAIRO_STATUS_SUCCESS) {
        set_error(error, error_len, cairo_status_to_string(status));
        goto done;
    }
    surface = cairo_pdf_surface_create(pdf_path, page->width, page->height);
    status = cairo_surface_status(surface);
    if (status != CAIRO_STATUS_SUCCESS) {
        set_error(error, error_len, cairo_status_to_string(status));
        goto done;
    }
    cr = cairo_create(surface);
    scale = content_w / (double)width;
    fitted = content_h / (double)height;
    if (fitted < scale) scale = fitted;
    cairo_set_source_rgb(cr, 1, 1, 1);
    cairo_paint(cr);
    cairo_save(cr);
    cairo_translate(
        cr,
        page->left + (content_w - (double)width * scale) / 2.0,
        page->top + (content_h - (double)height * scale) / 2.0
    );
    cairo_scale(cr, scale, scale);
    cairo_set_source_surface(cr, image, 0, 0);
    cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
    cairo_paint(cr);
    cairo_restore(cr);
    cairo_show_page(cr);
    cairo_surface_finish(surface);
    status = cairo_surface_status(surface);
    if (status != CAIRO_STATUS_SUCCESS) {
        set_error(error, error_len, cairo_status_to_string(status));
        goto done;
    }
    code = 0;
done:
    if (cr != NULL) cairo_destroy(cr);
    if (surface != NULL) cairo_surface_destroy(surface);
    if (image != NULL) cairo_surface_destroy(image);
    free(pixels);
    if (pixbuf != NULL) g_object_unref(pixbuf);
    return code;
}
