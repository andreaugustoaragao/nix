use std::time::Duration;

use crate::state::State;
use rune::AppHandle;

struct Manager {
    app: AppHandle<State>,
}

impl Manager {
    fn reveal(&self, uris: Vec<String>, folders: bool, properties: bool) -> zbus::fdo::Result<()> {
        let cwd = std::env::current_dir().unwrap_or_else(|_| "/".into());
        let mut paths = uris
            .into_iter()
            .map(|uri| crate::locations::Location::parse(&uri, &cwd))
            .collect::<Result<Vec<_>, _>>()
            .map_err(zbus::fdo::Error::InvalidArgs)?
            .into_iter();
        if let Some(path) = paths.next() {
            self.app
                .update(move |s, tx| s.reveal_location(path, folders, properties, tx));
            self.app.show();
            self.app.focus();
        }
        for path in paths {
            spawn_window(path.argument(), folders, properties, None)
                .map_err(|error| zbus::fdo::Error::Failed(error.to_string()))?;
        }
        Ok(())
    }
}

#[zbus::interface(name = "org.freedesktop.FileManager1")]
impl Manager {
    fn show_folders(&self, uris: Vec<String>, _startup_id: String) -> zbus::fdo::Result<()> {
        self.reveal(uris, true, false)
    }
    fn show_items(&self, uris: Vec<String>, _startup_id: String) -> zbus::fdo::Result<()> {
        self.reveal(uris, false, false)
    }
    fn show_item_properties(
        &self,
        uris: Vec<String>,
        _startup_id: String,
    ) -> zbus::fdo::Result<()> {
        self.reveal(uris, false, true)
    }
}

struct Control {
    app: AppHandle<State>,
}

#[zbus::interface(name = "io.github.yazi_rune.Manager")]
impl Control {
    fn command(&self, command: String) {
        self.app.update(move |s, tx| s.command(&command, tx));
    }

    async fn state(&self) -> zbus::fdo::Result<String> {
        let (sender, receiver) = tokio::sync::oneshot::channel();
        self.app.update_if(move |s, _| {
            let _ = sender.send(s.snapshot().to_string());
            false
        });
        tokio::time::timeout(Duration::from_secs(3), receiver)
            .await
            .map_err(|_| zbus::fdo::Error::Failed("Window did not respond".into()))?
            .map_err(|_| zbus::fdo::Error::Failed("Window closed".into()))
    }
}

pub struct Desktop {
    stop: Option<tokio::sync::oneshot::Sender<()>>,
}

impl Desktop {
    pub fn start(app: AppHandle<State>) -> Self {
        let (stop, stopped) = tokio::sync::oneshot::channel();
        std::thread::spawn(move || {
            let runtime = match tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
            {
                Ok(runtime) => runtime,
                Err(error) => {
                    eprintln!("Desktop service: {error}");
                    return;
                }
            };
            runtime.block_on(async move {
                let result = zbus::connection::Builder::session()
                    .name(format!("io.github.yazi_rune.p{}", std::process::id()))
                    .serve_at(
                        "/org/freedesktop/FileManager1",
                        Manager { app: app.clone() },
                    )
                    .serve_at("/io/github/yazi_rune", Control { app })
                    .build()
                    .await;
                let connection = match result {
                    Ok(connection) => connection,
                    Err(error) => {
                        eprintln!("Desktop service: {error}");
                        return;
                    }
                };
                if let Err(error) = connection
                    .request_name_with_flags(
                        "org.freedesktop.FileManager1",
                        zbus::fdo::RequestNameFlags::DO_NOT_QUEUE,
                    )
                    .await
                {
                    eprintln!("FileManager1 name is already in use: {error}");
                }
                let _ = stopped.await;
                drop(connection);
            });
        });
        Self { stop: Some(stop) }
    }
}

impl Drop for Desktop {
    fn drop(&mut self) {
        if let Some(stop) = self.stop.take() {
            let _ = stop.send(());
        }
    }
}

pub fn spawn_window(
    path: impl AsRef<std::ffi::OsStr>,
    folders: bool,
    properties: bool,
    config: Option<&std::path::Path>,
) -> std::io::Result<()> {
    let mut command = std::process::Command::new(std::env::current_exe()?);
    command
        .arg(if folders {
            "--directory"
        } else if properties {
            "--properties"
        } else {
            "--select"
        })
        .arg(path);
    if let Some(config) = config {
        command.arg("--config-dir").arg(config);
    }
    let mut child = command.spawn()?;
    std::thread::spawn(move || {
        let _ = child.wait();
    });
    Ok(())
}
