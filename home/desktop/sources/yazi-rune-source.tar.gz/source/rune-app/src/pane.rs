use crate::{
    file::{File, Folder, Preview},
    finder::{Engine, Matches, Picker},
    navigation::Address,
    preference::Preference,
    state::Tab,
    watcher::Watch,
};
use gio::prelude::CancellableExt;
use rune::{Latest, TextEdit};
use std::{
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

pub struct Pane {
    pub tabs: Vec<Tab>,
    pub active: usize,
    pub parent: Vec<File>,
    pub preview: Preview,
    pub picker: Option<Picker>,
    pub finder: Option<Engine>,
    pub finder_init: Latest<Result<Engine, String>>,
    pub finder_results: Latest<Result<Matches, String>>,
    pub finder_io: gio::Cancellable,
    pub finder_abort: Arc<AtomicBool>,
    pub finder_refresh: std::time::Instant,
    pub input: TextEdit,
    pub address: Address,
    pub revision: u64,
    pub page_size: usize,
    pub preview_scroll: rune::Live<[f32; 2]>,
    pub watch: Watch,
    pub directory: Latest<Folder>,
    pub previews: Latest<Preview>,
    pub directory_io: gio::Cancellable,
    pub preview_io: gio::Cancellable,
    pub remote_refresh: std::time::Instant,
    pub preview_path: Option<PathBuf>,
    pub resume_preview: Option<(PathBuf, f32)>,
}

impl Pane {
    pub fn new(cwd: PathBuf, preference: Preference) -> Self {
        Self {
            tabs: vec![Tab::new(cwd, preference)],
            active: 0,
            parent: Vec::new(),
            preview: Preview::Loading,
            picker: None,
            finder: None,
            finder_init: Latest::default(),
            finder_results: Latest::default().debounce(Duration::from_millis(35)),
            finder_io: gio::Cancellable::new(),
            finder_abort: Arc::new(AtomicBool::new(false)),
            finder_refresh: std::time::Instant::now(),
            input: TextEdit::new(""),
            address: Address::default(),
            revision: 0,
            page_size: 20,
            preview_scroll: rune::Live::new([0.0; 2]),
            watch: Watch::default(),
            directory: Latest::default(),
            previews: Latest::default().debounce(Duration::from_millis(30)),
            directory_io: gio::Cancellable::new(),
            preview_io: gio::Cancellable::new(),
            remote_refresh: std::time::Instant::now(),
            preview_path: None,
            resume_preview: None,
        }
    }
    pub fn tab(&self) -> &Tab {
        &self.tabs[self.active]
    }
    pub fn tab_mut(&mut self) -> &mut Tab {
        &mut self.tabs[self.active]
    }
    pub fn file(&self) -> Option<&File> {
        self.picker
            .as_ref()
            .map_or_else(|| self.tab().file(), |picker| picker.file())
    }
    pub fn list_key(side: usize) -> &'static str {
        ["current", "other-current"][side]
    }
    pub fn selection_count(&self) -> usize {
        if let Some(picker) = &self.picker {
            picker.selected.len().max(picker.file().is_some() as usize)
        } else if self.tab().visual.is_some() {
            (0..self.tab().visible.len())
                .filter(|&i| self.tab().selected(i))
                .count()
        } else {
            self.tab()
                .selected
                .len()
                .max(self.tab().file().is_some() as usize)
        }
    }
    pub fn finder_key(side: usize) -> &'static str {
        ["finder-results", "other-finder-results"][side]
    }
    pub fn suspend(&mut self) {
        self.address.close();
        self.directory_io.cancel();
        self.preview_io.cancel();
        self.finder_io.cancel();
        self.finder_abort.store(true, Ordering::Relaxed);
        self.directory.cancel();
        self.previews.cancel();
        self.finder_init.cancel();
        self.finder_results.cancel();
        self.finder = None;
        let _ = self.watch.update([]);
    }

    pub fn snapshot(&self) -> serde_json::Value {
        let tab = self.tab();
        serde_json::json!({
            "address": self.address.editing.then(|| serde_json::json!({
                "text": self.address.input.text, "choices": self.address.choices.iter().map(|choice| &choice.value).collect::<Vec<_>>(),
                "selected": self.address.selected, "opening": self.address.opening, "error": self.address.error,
                "fuzzy": self.address.fuzzy, "scanning": self.address.scanning,
            })),
            "cwd": tab.cwd, "hovered": tab.file().map(|file| &file.path),
            "files": tab.visible.iter().map(|&i| &tab.files[i].name).collect::<Vec<_>>(),
            "cursor": tab.cursor, "selected": tab.selected, "scroll": tab.scroll.get(),
            "loading": tab.loading, "active_tab": self.active,
            "tabs": self.tabs.iter().map(|tab| serde_json::json!({
                "cwd": tab.cwd, "name": tab.name, "cursor": tab.cursor,
                "loading": tab.loading, "file_count": tab.files.len(),
                "hovered": tab.file().map(|file| &file.path),
                "selected": tab.selected, "filter": tab.filter, "scroll": tab.scroll.get(),
                "history": tab.history, "history_cursor": tab.history_cursor,
            })).collect::<Vec<_>>(),
            "preference": tab.preference,
            "show_hidden": tab.preference.show_hidden, "sort_reverse": tab.preference.sort_reverse,
            "filter": tab.filter, "preview": self.preview.kind(), "preview_scroll": self.preview_scroll.get(),
            "finder": self.picker.as_ref().map(|picker| serde_json::json!({
                "root": picker.root, "query": picker.query, "content": picker.content,
                "recursive": picker.recursive, "regex": picker.regex, "cursor": picker.cursor,
                "files": picker.files.iter().map(|file| &file.name).collect::<Vec<_>>(),
                "selected": picker.selected, "scroll": picker.scroll.get(), "loading": picker.loading,
            })),
        })
    }
}
impl Drop for Pane {
    fn drop(&mut self) {
        self.suspend();
    }
}
