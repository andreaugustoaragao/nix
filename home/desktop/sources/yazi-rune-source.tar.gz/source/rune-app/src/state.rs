use std::{
    collections::{BTreeSet, HashMap, VecDeque},
    fs,
    path::{Path, PathBuf},
    time::Duration,
};

use gio::prelude::{CancellableExt, FileExt};
use rune::{ImageCache, KeyEvent, Latest, TextEdit, Tx, Waker};
use serde::{Deserialize, Serialize};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};

use crate::{
    clipboard::{self, Clipboard, Yank},
    context::{Action, Context, Target},
    file::{self, File, Preview, SortBy},
    finder::{Engine, FilterKind, Picker, SearchFilters, SearchRequest},
    keymap::{self, Binding},
    locations::{self, Applications, Bookmark, Place, PlaceKind, Properties},
    mounts::{self, Mounts},
    operations::{self, Choice, Operation},
    pane::Pane,
    preference::{DetailColumn, Details, Preference, Preferences, ViewMode},
    properties::Dialog as PropertiesDialog,
    session::Session,
    step::Step,
};

#[derive(Clone, Copy, Serialize)]
pub struct Visual {
    pub start: usize,
    pub wraps: isize,
    pub unset: bool,
}

impl Visual {
    fn contains(self, index: usize, end: usize, len: usize) -> bool {
        if len == 0 {
            return false;
        }
        let start = self.start.min(len - 1);
        let end = end.min(len - 1);
        match self.wraps {
            0 => (start.min(end)..=start.max(end)).contains(&index),
            1 if start > end + 1 => index <= end || index >= start,
            -1 if end > start + 1 => index <= start || index >= end,
            _ => true,
        }
    }
}

#[derive(Deserialize, Default)]
struct Config {
    #[serde(default)]
    mgr: Preference,
}

pub struct Tab {
    pub cwd: PathBuf,
    pub preference: Preference,
    pub name: Option<String>,
    pub files: Vec<File>,
    pub visible: Vec<usize>,
    pub cursor: usize,
    pub selected: BTreeSet<PathBuf>,
    pub visual: Option<Visual>,
    pub history: Vec<PathBuf>,
    pub history_cursor: usize,
    pub hovered: HashMap<PathBuf, PathBuf>,
    pub filter: String,
    pub loading: bool,
    pub saved_picker: Option<Picker>,
    pub scroll: rune::Live<f32>,
    pub resume_scroll: Option<f32>,
    select_after: Option<(u64, Vec<PathBuf>)>,
}

impl Tab {
    pub fn new(cwd: PathBuf, preference: Preference) -> Self {
        Self {
            history: vec![cwd.clone()],
            cwd,
            preference,
            name: None,
            files: Vec::new(),
            visible: Vec::new(),
            cursor: 0,
            selected: BTreeSet::new(),
            visual: None,
            history_cursor: 0,
            hovered: HashMap::new(),
            filter: String::new(),
            loading: true,
            saved_picker: None,
            scroll: rune::Live::new(0.0),
            resume_scroll: None,
            select_after: None,
        }
    }

    pub fn file(&self) -> Option<&File> {
        self.visible.get(self.cursor).map(|&i| &self.files[i])
    }
    pub fn entry(&self, index: usize) -> &File {
        &self.files[self.visible[index]]
    }
    pub fn selected(&self, index: usize) -> bool {
        let stored = self.selected.contains(&self.entry(index).path);
        match self.visual {
            Some(v) if v.contains(index, self.cursor, self.visible.len()) => !v.unset,
            _ => stored,
        }
    }

    fn finish_visual(&mut self) {
        if let Some(visual) = self.visual.take() {
            for i in 0..self.visible.len() {
                if !visual.contains(i, self.cursor, self.visible.len()) {
                    continue;
                }
                if let Some(&index) = self.visible.get(i) {
                    let path = self.files[index].path.clone();
                    if visual.unset {
                        self.selected.remove(&path);
                    } else {
                        self.selected.insert(path);
                    }
                }
            }
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Panel {
    Places,
    Applications,
    Trash,
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Prompt {
    Filter,
    TabRename,
    Create,
    CreateFolder,
    Rename,
    Permissions,
    Archive,
    Connect,
}

impl Prompt {
    pub fn title(self) -> &'static str {
        match self {
            Self::Filter => "Filter",
            Self::TabRename => "Rename tab",
            Self::Create => "New file",
            Self::CreateFolder => "New folder",
            Self::Rename => "Rename",
            Self::Permissions => "Permissions: octal mode; append -r for recursive",
            Self::Archive => "Compress",
            Self::Connect => "Server location (sftp://, smb://, ftp://, dav://)",
        }
    }
}

#[derive(Clone, Copy)]
pub enum PlaceOpen {
    Current,
    Other,
    Tab,
}

struct BookmarkResult {
    receipt: Option<(u32, u32)>,
    result: Result<String, String>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum FolderMenu {
    Sort,
    View,
}

pub struct State {
    pub panes: [Pane; 2],
    pub active_pane: usize,
    pub split: bool,
    pub split_width: f32,
    pub dnd: Option<crate::dnd::Dnd>,
    pub drop_targets: std::cell::RefCell<Vec<crate::dnd::Target>>,
    pub drop_hover: Option<PathBuf>,
    pub drop_decision: Option<crate::dnd::Drop>,
    drop_preference: Latest<(u32, u32)>,
    drop_preview: Option<(u32, Vec<PathBuf>, bool)>,
    pub mounts: Mounts,
    pub startup_uri: Option<String>,
    pub mount_intent: Option<(usize, bool, bool)>,
    pub authentication: Option<mounts::Authentication>,
    pub question: Option<mounts::Question>,
    closing: bool,
    pub trash: Option<Vec<crate::trash::Entry>>,
    pub trash_selected: BTreeSet<String>,
    pub trash_cursor: usize,
    trash_worker: Latest<Result<Vec<crate::trash::Entry>, String>>,
    pub panel: Option<Panel>,
    pub places: Vec<Place>,
    pub place_menu: Option<Place>,
    pub place_label: TextEdit,
    pub favorite_drag: Option<String>,
    pub favorite_hover: Option<usize>,
    bookmark_running: bool,
    bookmark_refreshing: Option<u64>,
    bookmark_queue: VecDeque<(Bookmark, Option<(u32, u32)>)>,
    bookmark_worker: Latest<BookmarkResult>,
    favorite_tx: Option<Vec<Place>>,
    favorite_saved: bool,
    pub properties: Option<Properties>,
    pub property_dialog: PropertiesDialog,
    pub property_focus: Option<String>,
    property_target: Option<PathBuf>,
    properties_io: gio::Cancellable,
    pub applications: Option<Applications>,
    pub selector: Option<crate::selector::Selector>,
    pub chooser: crate::chooser::Chooser,
    chooser_worker: Latest<Result<String, String>>,
    properties_worker: Latest<Result<Properties, String>>,
    applications_worker: Latest<Result<Applications, String>>,
    desktop_worker: Latest<Result<String, String>>,
    desktop_launches: VecDeque<locations::Launch>,

    pub queue: operations::Queue,
    pub tasks_open: bool,
    pub context: Option<Context>,
    pub tab_menu: Option<usize>,
    action_paths: Option<Vec<PathBuf>>,
    pub view_options: Option<FolderMenu>,
    pub views: Preferences,
    pub confirmation: Option<Operation>,
    pub conflict_all: bool,
    pub yank: Option<Yank>,
    pub sidebar_hidden: bool,
    pub peek: crate::peek::Peek,
    pub peek_scrolled: std::rc::Rc<std::cell::Cell<bool>>,
    pub window_focused: bool,
    pub preview_expanded: bool,
    pub preview_width: f32,
    pub bindings: Vec<Binding>,
    pub pending: Vec<String>,
    pub prompt: Option<Prompt>,
    pub help: bool,
    pub spot: bool,
    pub message: Option<String>,
    pub dark: Option<bool>,
    /// Whole-interface zoom, as an integer percent. Per window, starting at 100.
    pub zoom: u16,
    pub appearance: crate::appearance::Appearance,
    pub export: Option<std::rc::Rc<std::cell::RefCell<serde_json::Value>>>,
    clipboard: Clipboard,
    remaining_yank: Latest<(Yank, Yank)>,
    cache: Option<std::sync::Arc<ImageCache>>,
    pub thumbnails: Option<crate::thumbnail::Thumbnails>,
    pub print_busy: bool,
    print_worker: Latest<Result<crate::printing::Outcome, String>>,
    print_io: gio::Cancellable,
    thumbnail_views: [(bool, u64, usize, usize); 2],
    thumbnail_conflict: Option<(u64, PathBuf, PathBuf)>,
    headless: bool,
    config_dir: Option<PathBuf>,
    cwd_file: Option<PathBuf>,
    pub session_path: Option<PathBuf>,
    pub session_restored: bool,
    pub session_error: Option<String>,
    session_saving: bool,
    session_worker: Latest<Result<(), String>>,
}

fn replace_favorites(favorites: Vec<Place>, fresh: Vec<Place>) -> Vec<Place> {
    let mut merged = Vec::with_capacity(fresh.len() + favorites.len());
    let mut pending = Some(favorites);
    for place in fresh {
        if place.kind == PlaceKind::Favorite {
            if let Some(favorites) = pending.take() {
                merged.extend(favorites);
            }
            continue;
        }
        if pending.is_some() && place.uri == "trash:///" {
            merged.extend(pending.take().unwrap());
        }
        merged.push(place);
    }
    if let Some(favorites) = pending.take() {
        merged.extend(favorites);
    }
    merged
}

impl State {
    pub fn new(cwd: PathBuf, config_dir: Option<PathBuf>, cwd_file: Option<PathBuf>) -> Self {
        let launch_config = config_dir.clone();
        let appearance = crate::appearance::Appearance::new(config_dir.clone());
        let session_path = config_dir
            .clone()
            .unwrap_or_else(|| {
                std::env::var_os("XDG_STATE_HOME")
                    .map(PathBuf::from)
                    .unwrap_or_else(|| home().join(".local/state"))
                    .join("files")
            })
            .join("session.json");
        let views_path = config_dir
            .clone()
            .unwrap_or_else(|| {
                std::env::var_os("XDG_CONFIG_HOME")
                    .map(PathBuf::from)
                    .unwrap_or_else(|| home().join(".config"))
                    .join("files")
            })
            .join("folder-views.json");
        let config_dir = config_dir.unwrap_or_else(|| {
            std::env::var_os("YAZI_CONFIG_HOME")
                .map(PathBuf::from)
                .unwrap_or_else(|| {
                    std::env::var_os("XDG_CONFIG_HOME")
                        .map(PathBuf::from)
                        .unwrap_or_else(|| home().join(".config"))
                        .join("yazi")
                })
        });
        let custom = fs::read_to_string(config_dir.join("keymap.toml")).ok();
        let (bindings, key_error) = match keymap::load(custom.as_deref()) {
            Ok(b) => (b, None),
            Err(e) => (keymap::load(None).expect("upstream keymap"), Some(e)),
        };
        let preference = fs::read_to_string(config_dir.join("yazi.toml"))
            .ok()
            .and_then(|s| toml::from_str::<Config>(&s).ok())
            .unwrap_or_default()
            .mgr;
        let views = Preferences::new(views_path, preference);
        let preference = views.get(gio::File::for_path(&cwd).uri().as_str());
        let view_error = views
            .error
            .as_ref()
            .map(|error| format!("Folder views: {error}"));
        let appearance_error = appearance
            .error
            .as_ref()
            .map(|error| format!("Appearance: {error}"));
        Self {
            panes: [
                Pane::new(cwd.clone(), preference),
                Pane::new(cwd, preference),
            ],
            active_pane: 0,
            split: false,
            split_width: 0.5,
            dnd: None,
            drop_targets: std::cell::RefCell::new(Vec::new()),
            drop_hover: None,
            drop_decision: None,
            drop_preference: Latest::default(),
            drop_preview: None,
            closing: false,
            mounts: Mounts::default(),
            startup_uri: None,
            mount_intent: None,
            authentication: None,
            question: None,
            trash: None,
            trash_selected: BTreeSet::new(),
            trash_cursor: 0,
            trash_worker: Latest::default(),
            panel: None,
            places: Vec::new(),
            place_menu: None,
            place_label: TextEdit::new(""),
            favorite_drag: None,
            favorite_hover: None,
            bookmark_running: false,
            bookmark_refreshing: None,
            bookmark_queue: VecDeque::new(),
            bookmark_worker: Latest::default(),
            favorite_tx: None,
            favorite_saved: false,
            properties: None,
            property_dialog: PropertiesDialog::default(),
            property_focus: None,
            property_target: None,
            properties_io: gio::Cancellable::new(),
            applications: None,
            selector: None,
            chooser: crate::chooser::Chooser::default(),
            chooser_worker: Latest::default(),
            properties_worker: Latest::default(),
            applications_worker: Latest::default(),
            desktop_worker: Latest::default(),
            desktop_launches: VecDeque::new(),
            queue: operations::Queue::default(),
            tasks_open: false,
            context: None,
            tab_menu: None,
            action_paths: None,
            view_options: None,
            views,
            confirmation: None,
            conflict_all: false,
            yank: None,
            sidebar_hidden: false,
            peek: crate::peek::Peek::default(),
            peek_scrolled: Default::default(),
            window_focused: true,
            preview_expanded: false,
            preview_width: 0.5,
            bindings,
            pending: Vec::new(),
            prompt: None,
            help: false,
            spot: false,
            message: key_error.or(view_error).or(appearance_error),
            dark: None,
            zoom: 100,
            appearance,
            export: None,
            clipboard: Clipboard::default(),
            remaining_yank: Latest::default(),
            cache: None,
            thumbnails: None,
            print_busy: false,
            print_worker: Latest::default(),
            print_io: gio::Cancellable::new(),
            thumbnail_views: [(false, 0, 0, 0); 2],
            thumbnail_conflict: None,
            headless: rune::tooling::headless_run().is_some(),
            config_dir: launch_config,
            cwd_file,
            session_path: Some(session_path),
            session_restored: false,
            session_error: None,
            session_saving: false,
            session_worker: Latest::default(),
        }
    }

    pub fn restore_session(&mut self) {
        let Some(path) = &self.session_path else {
            return;
        };
        let result = Session::load(path).and_then(|session| {
            if let Some(session) = session {
                session.restore(self)?;
                self.session_restored = true;
            }
            Ok(())
        });
        if let Err(error) = result {
            self.message = Some(format!("Could not restore session: {error}"));
            self.session_path = None;
        }
    }

    pub fn pane(&self) -> &Pane {
        &self.panes[self.active_pane]
    }
    pub fn pane_mut(&mut self) -> &mut Pane {
        &mut self.panes[self.active_pane]
    }
    pub fn tab(&self) -> &Tab {
        self.pane().tab()
    }
    pub fn tab_mut(&mut self) -> &mut Tab {
        self.pane_mut().tab_mut()
    }

    pub fn edit_location(&mut self, side: usize, tx: &mut Tx) {
        self.tab_menu = None;
        if self.preview_expanded {
            self.toggle_preview(tx);
        }
        self.activate_pane(side, tx);
        self.prompt = None;
        self.action_paths = None;
        self.panel = None;
        self.help = false;
        if self.spot {
            self.close_properties(tx);
        }
        self.pending.clear();
        self.pane_mut().input.focused = false;
        if self.panes[side].address.editing {
            let editor = &mut self.panes[side].address.input;
            editor.set_selection(0, editor.text.len());
            editor.focused = true;
        } else {
            let value = self.display_location(&self.panes[side].tab().cwd);
            self.panes[side].address.edit(value);
        }
        tx.instant();
    }

    pub fn submit_location(&mut self, side: usize) {
        let cwd = self.panes[side].tab().cwd.clone();
        self.panes[side].address.submit(&cwd);
    }

    pub fn breadcrumbs(&self, side: usize) -> Vec<(String, PathBuf)> {
        let cwd = &self.panes[side].tab().cwd;
        let home = home();
        let (root, name) = if let Some(place) = self.remote_place(cwd) {
            (
                place.path.as_deref().unwrap_or(Path::new("/")),
                place.name.clone(),
            )
        } else if cwd.starts_with(&home) {
            (home.as_path(), "Home".into())
        } else {
            (Path::new("/"), "Filesystem".into())
        };
        let mut paths: Vec<_> = cwd
            .ancestors()
            .take_while(|path| path.starts_with(root))
            .collect();
        paths.reverse();
        paths
            .into_iter()
            .map(|path| {
                (
                    if path == root {
                        name.clone()
                    } else {
                        self.folder_name(path)
                    },
                    path.to_path_buf(),
                )
            })
            .collect()
    }

    pub fn activate_pane(&mut self, side: usize, tx: &mut Tx) {
        if side > 1 || side == self.active_pane || !self.split || self.preview_expanded {
            return;
        }
        self.peek.close();
        self.pane_mut().address.close();
        self.pane_mut().input.focused = false;
        self.tab_menu = None;
        self.active_pane = side;
        self.pane_mut().input.focused = false;
        self.pending.clear();
        tx.set_title(format!(
            "{} — Files",
            self.display_location(&self.tab().cwd)
        ));
        tx.blur();
    }

    pub fn toggle_split(&mut self, tx: &mut Tx) {
        self.tab_menu = None;
        for side in 0..2 {
            tx.scroll_to_instant(format!("breadcrumbs-{side}"), f32::MAX, 0.0);
        }
        for pane in &mut self.panes {
            pane.address.close();
        }
        self.split = !self.split;
        self.preview_expanded = false;
        let other = 1 - self.active_pane;
        if self.split {
            for pane in &mut self.panes {
                use gio::prelude::CancellableExt;
                pane.preview_io.cancel();
                pane.previews.cancel();
                if matches!(pane.preview, Preview::Loading) {
                    pane.preview_path = None;
                }
            }
            self.reload(other);
            if self.panes[other].picker.is_some() {
                self.restart_picker(other);
            }
            tx.scroll_to_instant(
                Pane::list_key(other),
                0.0,
                self.panes[other].tab().scroll.get(),
            );
            if let Some(picker) = &self.panes[other].picker {
                tx.scroll_to_instant(Pane::finder_key(other), 0.0, picker.scroll.get());
            }
        } else {
            self.panes[other].suspend();
            self.peek(self.active_pane);
        }
        self.pending.clear();
        if let Some(picker) = &self.pane().picker {
            tx.scroll_to_instant(Pane::finder_key(self.active_pane), 0.0, picker.scroll.get());
        }
        let offset = self.pane().preview_scroll.get();
        tx.scroll_to_instant("preview", 0.0, offset[0]);
        tx.scroll_to_instant(
            Pane::list_key(self.active_pane),
            0.0,
            self.tab().scroll.get(),
        );
        tx.blur();
    }

    pub fn transfer(&mut self, moving: bool) {
        if !self.split {
            return;
        }
        if self
            .pane()
            .picker
            .as_ref()
            .map_or(self.tab().loading, |picker| picker.loading)
        {
            return;
        }
        let sources = self.chosen();
        if sources.is_empty() {
            return;
        }
        let destination = self.panes[1 - self.active_pane].tab().cwd.clone();
        if sources
            .iter()
            .all(|path| path.parent() == Some(&destination))
        {
            self.message = Some("Choose a different destination folder".into());
            return;
        }
        let operation = if moving {
            Operation::Move {
                sources,
                destination,
            }
        } else {
            Operation::Copy {
                sources,
                destination,
            }
        };
        self.enqueue(operation, false);
    }

    pub fn setup(&mut self, waker: Waker) {
        self.peek.set_waker(waker.clone());
        self.print_worker.set_waker(waker.clone());
        self.appearance.start(waker.clone(), !self.headless);
        if let Some(selector) = &mut self.selector {
            selector.worker.set_waker(waker.clone());
        }
        for pane in &mut self.panes {
            if let Err(error) = pane.watch.start(waker.clone()) {
                self.message = Some(format!("Filesystem watcher: {error}"));
            }
            pane.address.set_waker(waker.clone());
            pane.directory.set_waker(waker.clone());
            pane.previews.set_waker(waker.clone());
            pane.preview_mimes.set_waker(waker.clone());
            pane.finder_init.set_waker(waker.clone());
            pane.finder_results.set_waker(waker.clone());
        }
        if !self.headless && std::env::var_os("WAYLAND_DISPLAY").is_some() {
            self.clipboard.start(waker.clone());
        }
        self.bookmark_worker.set_waker(waker.clone());
        self.views.set_waker(waker.clone());
        self.session_worker.set_waker(waker.clone());
        self.mounts.start(waker.clone());
        self.mounts.refresh_places();
        self.trash_worker.set_waker(waker.clone());
        self.drop_preference.set_waker(waker.clone());
        if let Some(uri) = self.startup_uri.take() {
            if uri.starts_with("trash:") {
                self.panel = Some(Panel::Trash);
                self.trash_worker.request((), |_| crate::trash::read());
            } else {
                self.mount_action(mounts::Action::Connect(uri));
            }
        }
        self.properties_worker.set_waker(waker.clone());
        self.applications_worker.set_waker(waker.clone());
        self.chooser_worker.set_waker(waker.clone());
        self.desktop_worker.set_waker(waker.clone());
        self.remaining_yank.set_waker(waker.clone());
        self.queue.start(waker.clone());
        let cache = std::sync::Arc::new(ImageCache::new(waker.clone()));
        self.thumbnails = Some(crate::thumbnail::Thumbnails::new(cache.clone(), waker));
        self.cache = Some(cache);
        for side in 0..2 {
            if side == self.active_pane || self.split {
                self.reload(side);
            }
        }
    }

    pub fn reload(&mut self, side: usize) {
        if self.closing || (!self.split && side != self.active_pane) {
            return;
        }
        self.panes[side].tab_mut().loading = true;
        self.panes[side].parent.clear();
        self.panes[side].preview = Preview::Loading;
        self.panes[side].preview_path = None;
        self.panes[side].previews.cancel();
        self.load_directory(side);
        self.update_watch(side);
    }

    fn load_directory(&mut self, side: usize) {
        let path = self.panes[side].tab().cwd.clone();
        use gio::prelude::CancellableExt;
        self.panes[side].directory_io.cancel();
        self.panes[side].directory_io = gio::Cancellable::new();
        if let Some(root) = self.remote_io(&path) {
            let cancel = self.panes[side].directory_io.clone();
            self.panes[side]
                .directory
                .request((path, root, cancel), |(path, root, cancel)| {
                    file::read_folder_remote(path, root, cancel)
                });
        } else {
            self.panes[side].directory.request(path, file::read_folder);
        }
    }

    fn update_watch(&mut self, side: usize) {
        if self.closing || (!self.split && side != self.active_pane) {
            return;
        }
        let mut paths = vec![self.panes[side].tab().cwd.clone()];
        if let Some(parent) = self.panes[side].tab().cwd.parent() {
            paths.push(parent.to_path_buf());
        }
        if let Some(file) = self.panes[side].tab().file()
            && file.directory
        {
            paths.push(file.path.clone());
        }
        if let Some(picker) = &self.panes[side].picker {
            paths.push(picker.root.clone());
        }
        paths.retain(|path| self.remote_place(path).is_none());
        if let Err(error) = self.panes[side].watch.update(paths) {
            self.message = Some(format!("Filesystem watcher: {error}"));
        }
    }

    pub fn file_columns(&mut self, side: usize, width: f32, tx: &mut Tx) {
        let columns = ((width - 16.0) / 136.0).floor().max(1.0) as usize;
        let pane = &mut self.panes[side];
        if pane.tab().preference.view_mode != ViewMode::Grid {
            pane.grid_columns = columns;
            if (pane.list_width - width).abs() > 0.5 {
                pane.list_width = width;
                pane.revision += 1;
            } else {
                tx.live_only();
            }
            return;
        }
        pane.list_width = width;
        if pane.grid_columns == columns {
            tx.live_only();
            return;
        }
        let old = pane.grid_columns;
        pane.grid_columns = columns;
        if pane.tab().preference.view_mode == crate::preference::ViewMode::Grid {
            pane.page_size = pane.page_size.div_ceil(old) * columns;
            pane.visible_files = pane.visible_files.start / old * columns
                ..(pane.visible_files.end.div_ceil(old) * columns).min(pane.tab().visible.len());
            pane.revision += 1;
            self.restore_cursor(side, tx);
            self.sync_thumbnails();
        } else {
            tx.live_only();
        }
    }

    pub fn sync_thumbnails(&mut self) {
        let views = std::array::from_fn(|side| {
            let pane = &self.panes[side];
            let shown = !self.closing
                && self.selector.is_none()
                && self.panel.is_none()
                && !self.preview_expanded
                && (self.split || side == self.active_pane)
                && pane.picker.is_none();
            (
                shown,
                pane.revision,
                pane.visible_files.start,
                pane.visible_files.end,
            )
        });
        let conflict = self.queue.conflict.as_ref().map(|conflict| {
            (
                conflict.task,
                conflict.source.clone(),
                conflict.destination.clone(),
            )
        });
        if views == self.thumbnail_views && conflict == self.thumbnail_conflict {
            return;
        }
        self.thumbnail_views = views;
        self.thumbnail_conflict = conflict;
        let mut files = Vec::new();
        for incoming in [true, false] {
            if let Some(file) = self.conflict_file(incoming) {
                let uri = self.location_uri(&file.path);
                files.push((file, uri));
            }
        }
        for (side, (shown, _, start, end)) in views.into_iter().enumerate() {
            if !shown {
                continue;
            }
            let tab = self.panes[side].tab();
            for index in start..end.min(tab.visible.len()) {
                let file = tab.entry(index);
                if !file.directory && self.remote_place(&file.path).is_none() {
                    files.push((file.clone(), self.location_uri(&file.path)));
                }
            }
        }
        if let Some(thumbnails) = &mut self.thumbnails {
            thumbnails.set_visible(files);
        }
    }

    pub fn thumbnail(&self, file: &File) -> Option<&rune::Image> {
        self.thumbnails.as_ref()?.image(file)
    }

    fn conflict_file(&self, incoming: bool) -> Option<File> {
        use std::os::unix::fs::PermissionsExt;

        let conflict = self.queue.conflict.as_ref()?;
        let (path, metadata) = if incoming {
            (&conflict.source, conflict.source_metadata.as_ref()?)
        } else {
            (
                &conflict.destination,
                conflict.destination_metadata.as_ref()?,
            )
        };
        if self.remote_place(path).is_some() {
            return None;
        }
        let crate::metadata::Metadata::Local(metadata) = metadata else {
            return None;
        };
        Some(File {
            path: path.clone(),
            name: path.file_name()?.to_string_lossy().into_owned(),
            directory: metadata.is_dir(),
            symlink: metadata.is_symlink(),
            size: metadata.len(),
            mode: metadata.permissions().mode(),
            modified: metadata.modified().ok(),
            owner: String::new(),
            key: String::new(),
        })
    }

    pub fn conflict_thumbnail(&self, incoming: bool) -> Option<&rune::Image> {
        self.thumbnail(&self.conflict_file(incoming)?)
    }

    pub fn poll(&mut self, tx: &mut Tx) -> bool {
        let print_result = self.print_worker.take();
        let print_changed = print_result.is_some();
        if let Some(result) = print_result {
            self.print_busy = false;
            self.message = Some(match result {
                Ok(crate::printing::Outcome::Submitted) => "Print job submitted".into(),
                Ok(crate::printing::Outcome::Cancelled) => "Printing cancelled".into(),
                Err(error) => format!("Could not print: {error}"),
            });
        }
        self.sync_thumbnails();
        let thumbnails_changed = self
            .thumbnails
            .as_mut()
            .is_some_and(|thumbnails| thumbnails.poll());
        let scrolled = self.peek_scrolled.replace(false);
        let mut peek_changed = false;
        if self.peek.target.is_some()
            && (!self.peek_allowed()
                || scrolled
                || self.peek.target.as_ref().is_some_and(|target| {
                    target.origin != self.panes[target.side].tab().cwd
                        || target.scroll != self.panes[target.side].tab().scroll.get()
                }))
        {
            self.peek.close();
            peek_changed = true;
        }
        peek_changed |= self.peek.poll();
        let appearance_changed = self.appearance.poll();
        let mut selector_changed =
            appearance_changed || peek_changed || thumbnails_changed || print_changed;
        self.appearance.apply_fonts(tx);
        if appearance_changed {
            if let Some(error) = &self.appearance.error {
                self.message = Some(format!("Appearance: {error}"));
            } else if self
                .message
                .as_ref()
                .is_some_and(|message| message.starts_with("Appearance:"))
            {
                self.message = None;
            }
        }
        if let Some(selector) = &mut self.selector {
            tx.set_title(format!("{} — Files", selector.request.title));
            if let Some(result) = selector.worker.take() {
                selector_changed = true;
                selector.busy = false;
                match result {
                    Ok(crate::selector::Outcome::Returned) => {
                        self.close(tx);
                        return true;
                    }
                    Ok(crate::selector::Outcome::Replace(paths)) => selector.replace = Some(paths),
                    Err(error) => selector.error = Some(error),
                }
            }
        }
        let session_result = self.session_worker.take();
        if let Some(result) = &session_result {
            self.session_saving = false;
            if let Err(error) = result {
                self.session_error = Some(error.clone());
                self.message = Some("Session could not be saved".into());
                self.closing = false;
                for side in 0..2 {
                    if self.split || side == self.active_pane {
                        self.reload(side);
                    }
                }
            }
        }
        let view_result = self.views.poll();
        let (mut changed, refresh) = self.queue.poll();
        changed |= selector_changed;
        if self.queue.conflict.is_some() {
            self.tab_menu = None;
        } else {
            self.conflict_all = false;
        }
        changed |= view_result.is_some() || session_result.is_some();
        if let Some(Err(error)) = view_result {
            self.message = Some(format!("Could not save folder view: {error}"));
        }
        if let Some(BookmarkResult {
            receipt: token,
            result,
        }) = self.bookmark_worker.take()
        {
            self.bookmark_running = false;
            if let Some((token, action)) = token
                && let Some(dnd) = &mut self.dnd
            {
                dnd.finish_bookmark(token, result.is_ok() && action == 1);
            }
            if result.is_err() {
                if !self.favorite_saved {
                    self.restore_favorite_tx();
                }
            } else if self.favorite_tx.is_some() && !self.favorite_saved {
                self.favorite_saved = true;
            }
            self.bookmark_refreshing = self.mounts.refresh_places();
            if self.favorite_tx.is_some() && self.bookmark_refreshing.is_none() {
                self.favorite_tx = None;
                self.favorite_saved = false;
            }
            self.message = Some(result.unwrap_or_else(|error| error));
            changed = true;
        }
        if !self.bookmark_running
            && let Some(edit) = self.bookmark_queue.pop_front()
        {
            self.bookmark_running = true;
            self.bookmark_worker
                .request(edit, |(edit, token)| BookmarkResult {
                    receipt: token,
                    result: locations::edit_bookmarks(edit),
                });
        }
        if self.dnd.is_some() {
            tx.wake_after(Duration::from_millis(30));
            let events = self.dnd.as_mut().unwrap().poll();
            for event in events {
                match event {
                    crate::dnd::Event::Hover { token, point } => {
                        let favorite = (token != 0).then(|| self.favorite_at(point)).flatten();
                        if favorite != self.favorite_hover {
                            self.favorite_hover = favorite;
                            changed = true;
                        }
                        if favorite.is_some() {
                            self.drop_preference.cancel();
                            self.dnd.as_mut().unwrap().prefer(token, 1);
                        }
                        let target = (token != 0 && favorite.is_none())
                            .then(|| self.drop_destination(point));
                        if self.drop_hover != target {
                            self.drop_hover = target;
                            if let Some((preview_token, paths, local)) = &self.drop_preview
                                && *preview_token == token
                                && let Some(destination) = &self.drop_hover
                            {
                                self.request_drop_preference(
                                    token,
                                    paths.clone(),
                                    destination.clone(),
                                    *local,
                                );
                            }
                            changed = true;
                        }
                        if token == 0 {
                            self.drop_preview = None;
                            self.drop_preference.cancel();
                        }
                    }
                    crate::dnd::Event::Preview {
                        token,
                        point,
                        paths,
                        local,
                    } => {
                        if self.favorite_at(point).is_some() {
                            self.drop_preference.cancel();
                            self.dnd.as_mut().unwrap().prefer(token, 1);
                        } else {
                            let destination = self.drop_destination(point);
                            self.request_drop_preference(token, paths.clone(), destination, local);
                        }
                        self.drop_preview = Some((token, paths, local));
                    }
                    crate::dnd::Event::Drop {
                        token,
                        point,
                        paths,
                        action,
                        choose,
                    } => {
                        if self.place_menu.is_some()
                            || self.context.is_some()
                            || self.view_options.is_some()
                            || self.session_error.is_some()
                        {
                            self.cancel_drop(token);
                            self.favorite_hover = None;
                            self.drop_hover = None;
                            self.drop_preview = None;
                            self.drop_preference.cancel();
                            changed = true;
                            continue;
                        }
                        if let Some(index) = self.favorite_at(point) {
                            let before = self.favorites().nth(index).map(|place| place.uri.clone());
                            let uris = paths.iter().map(|path| self.location_uri(path)).collect();
                            self.bookmark_queue.push_back((
                                Bookmark::Reorder { uris, before },
                                Some((token, action)),
                            ));
                            self.favorite_hover = None;
                            self.drop_hover = None;
                            self.drop_preview = None;
                            self.drop_preference.cancel();
                            changed = true;
                            continue;
                        }
                        let drop = crate::dnd::Drop {
                            action,
                            token,
                            paths,
                            destination: self.drop_destination(point),
                        };
                        self.drop_hover = None;
                        self.drop_preview = None;
                        self.drop_preference.cancel();
                        if let Some(previous) = self.drop_decision.take() {
                            self.cancel_drop(previous.token);
                        }
                        if action == 4 || choose {
                            self.drop_decision = Some(drop);
                        } else {
                            self.accept_drop(drop, action);
                        }
                        changed = true;
                    }
                    crate::dnd::Event::Error(error) => {
                        self.message = Some(error);
                        self.drop_hover = None;
                        self.favorite_hover = None;
                        changed = true;
                    }
                    crate::dnd::Event::End => {
                        self.drop_hover = None;
                        self.favorite_hover = None;
                        changed = true;
                    }
                }
            }
            if let Some((token, action)) = self.drop_preference.take() {
                self.dnd.as_mut().unwrap().prefer(token, action);
            }
            self.dnd.as_mut().unwrap().finish_tasks(&self.queue.tasks);
        }
        for event in self.mounts.take() {
            match event {
                mounts::Event::Places(places, refresh) => {
                    let disconnected: Vec<_> = self
                        .places
                        .iter()
                        .filter(|old| {
                            !old.uri.starts_with("file:")
                                && old.unmount
                                && !places.iter().any(|new| new.uri == old.uri && new.unmount)
                        })
                        .filter_map(|place| Some((place.path.clone()?, place.name.clone())))
                        .collect();
                    if refresh.is_some() && refresh == self.bookmark_refreshing {
                        self.places = places;
                        self.bookmark_refreshing = None;
                        if self.favorite_saved {
                            self.favorite_tx = None;
                            self.favorite_saved = false;
                        }
                    } else if self.favorite_tx.is_some() {
                        let favorites = self.favorites().cloned().collect();
                        self.places = replace_favorites(favorites, places);
                    } else {
                        self.places = places;
                    }
                    for (root, name) in disconnected {
                        for side in 0..2 {
                            if self.panes[side].tab().cwd.starts_with(&root) {
                                self.cd(side, home(), tx, true);
                                self.message = Some(format!("{name} disconnected"));
                            }
                        }
                    }
                    tx.set_title(format!(
                        "{} — Files",
                        self.display_location(&self.tab().cwd)
                    ));
                }
                mounts::Event::Authentication(mut auth) => {
                    let field = if auth.flags.contains(gio::AskPasswordFlags::NEED_USERNAME)
                        && auth.user.text.is_empty()
                    {
                        "auth-user"
                    } else if auth.flags.contains(gio::AskPasswordFlags::NEED_PASSWORD) {
                        "auth-password"
                    } else if auth.flags.contains(gio::AskPasswordFlags::NEED_DOMAIN) {
                        "auth-domain"
                    } else {
                        "auth-user"
                    };
                    match field {
                        "auth-password" => auth.password.focused = true,
                        "auth-domain" => auth.domain.focused = true,
                        _ => auth.user.focused = true,
                    }
                    self.tab_menu = None;
                    self.authentication = Some(*auth);
                }
                mounts::Event::Question(question) => {
                    self.tab_menu = None;
                    self.question = Some(question);
                }
                mounts::Event::Finished(result) => {
                    self.authentication = None;
                    self.question = None;
                    match result {
                        Ok(Some(path)) => {
                            self.panel = None;
                            if let Some((side, folders, properties)) = self.mount_intent.take() {
                                self.reveal(side, path, folders, properties, tx);
                            } else {
                                self.cd(self.active_pane, path, tx, true);
                            }
                        }
                        Ok(None) => self.message = Some("Device operation completed".into()),
                        Err(error) => self.message = Some(error),
                    }
                    self.mount_intent = None;
                    self.mounts.refresh_places();
                }
            }
            changed = true;
        }
        if let Some(result) = self.trash_worker.take() {
            match result {
                Ok(entries) => {
                    self.trash_selected
                        .retain(|uri| entries.iter().any(|entry| &entry.uri == uri));
                    self.trash_cursor = self.trash_cursor.min(entries.len().saturating_sub(1));
                    self.trash = Some(entries);
                }
                Err(error) => self.message = Some(format!("Trash: {error}")),
            }
            changed = true;
        }
        if let Some(properties) = self.properties_worker.take() {
            match properties {
                Ok(properties) if self.spot => {
                    self.property_dialog = PropertiesDialog::new(&properties);
                    self.properties = Some(properties);
                }
                Ok(_) => {}
                Err(error) if self.spot => self.message = Some(format!("Properties: {error}")),
                Err(_) => {}
            }
            changed = true;
        }
        if let Some(applications) = self.applications_worker.take() {
            match applications {
                Ok(applications) => {
                    self.chooser.selected = applications
                        .apps
                        .iter()
                        .find(|app| app.default || app.recommended)
                        .map(|app| app.id.clone());
                    self.applications = Some(applications);
                }
                Err(error) => self.chooser.error = Some(error),
            }
            changed = true;
        }
        if let Some(result) = self.chooser_worker.take() {
            self.chooser.busy = false;
            match result {
                Ok(message) => {
                    self.panel = None;
                    self.message = Some(message);
                }
                Err(error) => self.chooser.error = Some(error),
            }
            changed = true;
        }
        if let Some(result) = self.desktop_worker.take() {
            self.desktop_launches.pop_front();
            if let Some(launch) = self.desktop_launches.front() {
                self.desktop_worker
                    .request(launch.clone(), locations::Launch::run);
            }
            self.message = Some(result.unwrap_or_else(|error| error));
            self.mounts.refresh_places();
            changed = true;
        }
        for event in self.clipboard.take() {
            match event {
                clipboard::Event::Written(Err(error)) => {
                    self.message = Some(format!("File clipboard: {error}"))
                }
                clipboard::Event::Written(Ok(())) => {}
                clipboard::Event::Paste {
                    files: Ok(Some(files)),
                    destination,
                    force,
                } => self.paste_files(files, destination, force),
                clipboard::Event::Paste {
                    files: Ok(None), ..
                } => self.message = Some("The clipboard contains no files".into()),
                clipboard::Event::Paste {
                    files: Err(error), ..
                } => self.message = Some(format!("File clipboard: {error}")),
            }
            changed = true;
        }
        if refresh {
            if self.panel == Some(Panel::Trash) {
                self.trash_worker.request((), |_| crate::trash::read());
            }
            if let Some(task) = self.queue.tasks.iter().rev().find(|t| {
                matches!(
                    t.status,
                    operations::Status::Completed
                        | operations::Status::Failed
                        | operations::Status::Cancelled
                )
            }) {
                self.message = Some(if task.errors.is_empty() {
                    format!(
                        "{}: {:?}{}",
                        task.title,
                        task.status,
                        if task.warnings.is_empty() {
                            ""
                        } else {
                            "; see Tasks for metadata warnings"
                        }
                    )
                } else {
                    format!("{}: {}", task.title, task.errors.join("; "))
                });
            }
            if let Some(yank) = &self.yank
                && yank.cut
            {
                let roots: Vec<_> = yank
                    .paths
                    .iter()
                    .filter_map(|path| self.remote_io(path))
                    .collect();
                self.remaining_yank
                    .request((yank.clone(), roots), |(previous, roots)| {
                        let mut remaining = previous.clone();
                        remaining.paths.retain(|path| {
                            if let Some(root) =
                                roots.iter().find(|root| path.starts_with(&root.path))
                            {
                                use gio::prelude::FileExt;
                                file::remote_uri(root, path)
                                    .query_info(
                                        "standard::type",
                                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                                        gio::Cancellable::NONE,
                                    )
                                    .is_ok()
                            } else {
                                fs::symlink_metadata(path).is_ok()
                            }
                        });
                        (previous, remaining)
                    });
            }
            for side in 0..2 {
                if self.split || side == self.active_pane {
                    self.reload(side);
                }
            }
        }
        if let Some((previous, remaining)) = self.remaining_yank.take()
            && self.yank.as_ref() == Some(&previous)
        {
            if !self.headless && previous.paths.len() != remaining.paths.len() {
                self.clipboard.consume(&previous, &remaining);
            }
            self.yank = Some(remaining);
            changed = true;
        }
        if self.prompt == Some(Prompt::Filter)
            && self.panes[self.active_pane].input.text != self.tab().filter
        {
            self.edit_prompt(tx);
            changed = true;
        }
        for side in 0..2 {
            if self.split || side == self.active_pane {
                changed |= self.poll_pane(side, tx);
            }
        }
        if self.closing {
            if self.queue.active().is_none()
                && self.desktop_launches.is_empty()
                && !self.mounts.busy()
                && !self.favorites_saving()
                && !self.views.saving()
                && !self.appearance.saving()
                && !self.session_saving
            {
                self.dnd = None;
                tx.quit();
            } else {
                tx.wake_after(Duration::from_millis(60));
            }
        }
        changed
    }

    fn poll_pane(&mut self, side: usize, tx: &mut Tx) -> bool {
        if self.closing {
            return false;
        }
        if self.panes[side]
            .tab()
            .select_after
            .as_ref()
            .is_some_and(|(id, _)| {
                self.queue
                    .tasks
                    .iter()
                    .rev()
                    .find(|task| task.id == *id)
                    .is_some_and(|task| {
                        matches!(
                            task.status,
                            operations::Status::Failed | operations::Status::Cancelled
                        )
                    })
            })
        {
            self.panes[side].tab_mut().select_after = None;
        }
        let cwd = self.panes[side].tab().cwd.clone();
        let (mut changed, location) = self.panes[side].address.poll(&cwd);
        if self.panes[side].address.scanning {
            tx.wake_after(Duration::from_millis(120));
        }
        if let Some(location) = location {
            self.panes[side].address.close();
            match location {
                locations::Location::Path(path) => self.cd(side, path, tx, true),
                location => self.reveal_location(location, true, false, tx),
            }
            tx.blur();
        }
        if let Some(error) = self.panes[side].watch.error() {
            self.message = Some(format!("Filesystem watcher: {error}"));
        }
        let changes = self.panes[side].watch.take();
        if !changes.is_empty() {
            self.load_directory(side);
            if self.panes[side]
                .picker
                .as_ref()
                .is_some_and(|picker| !picker.recursive)
                && self.panes[side].finder.is_some()
            {
                self.restart_picker(side);
            }
            let invalidate = self.panes[side].tab().file().is_some_and(|file| {
                let mut paths = changes
                    .iter()
                    .filter(|path| !path.as_os_str().is_empty())
                    .peekable();
                paths.peek().is_none()
                    || paths.any(|path| {
                        path == &file.path || (file.directory && path.starts_with(&file.path))
                    })
            });
            if invalidate {
                use gio::prelude::CancellableExt;
                self.panes[side].preview_path = None;
                self.panes[side].preview_io.cancel();
                self.panes[side].previews.cancel();
            }
            changed = true;
        }
        changed |= self.poll_picker(side, tx);
        if let Some(folder) = self.panes[side].directory.take()
            && folder.path == self.panes[side].tab().cwd
        {
            self.panes[side].tab_mut().loading = false;
            tx.scroll_to_instant(format!("breadcrumbs-{side}"), f32::MAX, 0.0);
            if let Some(note) = folder.note {
                self.message = Some(note);
            }
            match folder.files {
                Ok(files) => {
                    let previous = self.panes[side].tab().file().cloned();
                    if let Some(path) = self.panes[side].tab().file().map(|f| f.path.clone()) {
                        let cwd = self.panes[side].tab().cwd.clone();
                        self.panes[side].tab_mut().hovered.insert(cwd, path);
                    }
                    self.panes[side].tab_mut().visible.clear();
                    self.panes[side].tab_mut().finish_visual();
                    let paths: BTreeSet<_> = files.iter().map(|f| &f.path).collect();
                    let select_after =
                        self.panes[side]
                            .tab()
                            .select_after
                            .as_ref()
                            .and_then(|(id, targets)| {
                                let task =
                                    self.queue.tasks.iter().rev().find(|task| task.id == *id)?;
                                if task.status != operations::Status::Completed {
                                    return None;
                                }
                                let targets = task
                                    .result
                                    .as_ref()
                                    .map_or_else(|| targets.clone(), |path| vec![path.clone()]);
                                targets
                                    .iter()
                                    .all(|path| paths.contains(path))
                                    .then_some(targets)
                            });

                    self.panes[side]
                        .tab_mut()
                        .selected
                        .retain(|path| paths.contains(path));
                    let selected_after = select_after.is_some();
                    if let Some(targets) = select_after {
                        let tab = self.panes[side].tab_mut();
                        tab.select_after = None;
                        tab.resume_scroll = None;
                        if targets.iter().any(|path| {
                            path.file_name()
                                .is_some_and(|name| name.as_encoded_bytes().starts_with(b"."))
                        }) {
                            tab.preference.show_hidden = true;
                        }
                        if targets.iter().any(|path| {
                            !smart_contains(
                                &path.file_name().unwrap_or_default().to_string_lossy(),
                                &tab.filter,
                            )
                        }) {
                            tab.filter.clear();
                        }

                        if let Some(path) = targets.first() {
                            tab.hovered.insert(tab.cwd.clone(), path.clone());
                        }
                        tab.selected = targets.into_iter().collect();
                    }
                    self.panes[side].tab_mut().files = files;
                    self.panes[side].parent = folder.parent;
                    self.reorder(side);
                    if previous.as_ref() != self.panes[side].tab().file() {
                        self.panes[side].preview_path = None;
                    }
                    self.peek(side);
                    if selected_after {
                        self.restore_cursor(side, tx);
                    } else if let Some(offset) = self.panes[side].tab_mut().resume_scroll.take() {
                        self.panes[side].tab().scroll.set(offset);
                        tx.scroll_to_instant(Pane::list_key(side), 0.0, offset);
                        if side == self.active_pane {
                            tx.set_title(format!(
                                "{} — Files",
                                self.display_location(&self.tab().cwd)
                            ));
                        }
                    } else if previous.is_none() {
                        self.restore_cursor(side, tx);
                    } else if side == self.active_pane {
                        tx.set_title(format!(
                            "{} — Files",
                            self.display_location(&self.tab().cwd)
                        ));
                    }
                    if self.spot && self.properties.is_none() && side == self.active_pane {
                        self.load_properties();
                    }
                }
                Err(error) => {
                    if let Some(fallback) = folder.fallback {
                        let target = if self.remote_place(&folder.path).is_some() {
                            home()
                        } else {
                            fallback
                        };
                        self.cd(side, target, tx, true);
                    }
                    self.panes[side].tab_mut().files.clear();
                    self.panes[side].tab_mut().visible.clear();
                    self.panes[side].preview = Preview::Empty;
                    self.message = Some(error);
                }
            }
            changed = true;
        }
        if let Some((file, mime)) = self.panes[side].preview_mimes.take()
            && self.panes[side].file() == Some(&file)
        {
            self.panes[side].preview_mime = mime;
            changed = true;
        }
        if let Some(mut preview) = self.panes[side].previews.take() {
            if let Preview::Directory(files) = &mut preview {
                files.retain(|f| {
                    self.panes[side].tab().preference.show_hidden || !f.name.starts_with('.')
                });
                file::sort(
                    files,
                    self.panes[side].tab().preference.sort_by,
                    self.panes[side].tab().preference.sort_reverse,
                    self.panes[side].tab().preference.sort_sensitive,
                    self.panes[side].tab().preference.sort_dir_first,
                );
            }
            self.panes[side].preview = preview;
            if let Some((path, offset)) = self.panes[side].resume_preview.take()
                && self.panes[side].preview_path.as_ref() == Some(&path)
                && side == self.active_pane
            {
                tx.scroll_to_y("preview", offset);
            }
            if side == self.active_pane
                && matches!(
                    self.panes[side].preview,
                    Preview::Code(_) | Preview::Text { .. }
                )
                && let Some(picker) = &self.panes[side].picker
                && let Some(file) = picker.file()
                && let Some(hit) = picker.hits.get(&file.path)
            {
                tx.scroll_to_y(
                    "preview",
                    hit.line.saturating_sub(1) as f32 * self.appearance.metrics().code_height(),
                );
            }
            changed = true;
        }
        if !self.closing && self.remote_place(&self.panes[side].tab().cwd).is_some() {
            if !self.panes[side].tab().loading
                && self.panes[side].remote_refresh.elapsed() >= Duration::from_secs(2)
            {
                self.panes[side].remote_refresh = std::time::Instant::now();
                self.panes[side].tab_mut().loading = true;
                self.load_directory(side);
            }
            tx.wake_after(Duration::from_secs(2));
        }
        changed
    }

    pub fn show_picker(&mut self, tx: &mut Tx) {
        if let Some(selector) = &mut self.selector {
            selector.name.focused = false;
        }
        self.pane_mut().address.close();
        self.prompt = None;
        self.action_paths = None;
        self.panel = None;
        self.help = false;
        if self.spot {
            self.close_properties(tx);
        }
        self.pending.clear();
        if self.panes[self.active_pane].picker.is_some() {
            self.panes[self.active_pane].input.focused = true;
            return;
        }
        let mut picker = self
            .tab_mut()
            .saved_picker
            .take()
            .unwrap_or_else(|| Picker::new(self.tab().cwd.clone()));
        picker.menu = None;
        self.panes[self.active_pane].input = TextEdit::new(&picker.query);
        self.panes[self.active_pane].input.focused = true;
        let scroll = picker.scroll.get();
        self.panes[self.active_pane].picker = Some(picker);
        self.restart_picker(self.active_pane);
        self.peek(self.active_pane);
        tx.scroll_to_instant(Pane::finder_key(self.active_pane), 0.0, scroll);
        tx.instant();
    }

    fn restart_picker(&mut self, side: usize) {
        use gio::prelude::CancellableExt;
        self.panes[side].finder_io.cancel();
        self.panes[side].finder_abort.store(true, Ordering::Relaxed);
        self.panes[side].finder_init.cancel();
        self.panes[side].finder_results.cancel();
        self.panes[side].finder = None;
        let Some(picker) = &mut self.panes[side].picker else {
            return;
        };
        self.panes[side].input.focused = true;
        picker.loading = true;
        picker.scanning = true;
        picker.indexed = 0;
        picker.watching = false;
        picker.error = None;
        let (root, all_files, recursive) =
            (picker.root.clone(), picker.all_files, picker.recursive);
        if self.remote_io(&root).is_some() {
            self.search_picker(side);
        } else {
            self.panes[side].finder_init.request(
                (root, all_files, recursive),
                |(root, all_files, recursive)| Engine::new(root, all_files, recursive),
            );
        }
    }

    fn search_picker(&mut self, side: usize) {
        let Some(picker) = &self.panes[side].picker else {
            return;
        };
        self.panes[side].finder_abort.store(true, Ordering::Relaxed);
        self.panes[side].finder_abort = Arc::new(AtomicBool::new(false));
        if let Some(root) = self.remote_io(&picker.root) {
            use gio::prelude::CancellableExt;
            self.panes[side].finder_io.cancel();
            self.panes[side].finder_io = gio::Cancellable::new();
            self.panes[side].finder_results.request(
                (
                    picker.root.clone(),
                    picker.query.clone(),
                    picker.all_files,
                    picker.recursive,
                    picker.filters,
                    root,
                    self.panes[side].finder_io.clone(),
                ),
                |(path, query, all_files, recursive, filters, root, cancel)| {
                    crate::search::remote(path, query, all_files, recursive, filters, root, cancel)
                },
            );
        } else if let Some(finder) = &self.panes[side].finder {
            self.panes[side].finder_results.request(
                (
                    finder.index.clone(),
                    SearchRequest::from(picker),
                    self.panes[side].finder_abort.clone(),
                ),
                |(index, request, abort)| Engine::search(index, request, abort),
            );
        }
        self.panes[side].finder_refresh = std::time::Instant::now();
    }

    fn poll_picker(&mut self, side: usize, tx: &mut Tx) -> bool {
        if self.panes[side].picker.is_none() {
            return false;
        }
        let mut changed = false;
        if let Some(result) = self.panes[side].finder_init.take() {
            match result {
                Ok(finder) => {
                    self.panes[side].picker.as_mut().unwrap().error = finder.warning.clone();
                    self.panes[side].finder = Some(finder);
                    self.search_picker(side);
                }
                Err(error) => {
                    let picker = self.panes[side].picker.as_mut().unwrap();
                    picker.loading = false;
                    picker.scanning = false;
                    picker.error = Some(error);
                }
            }
            changed = true;
        }
        let picker = self.panes[side].picker.as_mut().unwrap();
        if picker.query != self.panes[side].input.text {
            picker.query = self.panes[side].input.text.clone();
            picker.files.clear();
            picker.hits.clear();
            picker.cursor = 0;
            picker.scroll.set(0.0);
            picker.loading = true;
            self.search_picker(side);
            self.peek(side);
            tx.scroll_to_instant(Pane::finder_key(side), 0.0, 0.0);
            changed = true;
        }
        if let Some(result) = self.panes[side].finder_results.take() {
            let result = result.map(|mut matches| {
                if let Some(selector) = &self.selector {
                    matches.files.retain(|file| selector.matches(file));
                }
                matches
            });
            let note = result
                .as_ref()
                .ok()
                .and_then(|matches| matches.note.clone())
                .or_else(|| {
                    self.panes[side]
                        .finder
                        .as_ref()
                        .and_then(|finder| finder.warning.clone())
                });
            let picker = self.panes[side].picker.as_mut().unwrap();
            let updated = match result {
                Ok(matches)
                    if !picker.loading
                        && picker.files == matches.files
                        && picker.hits == matches.hits
                        && picker.error == note
                        && picker.indexed == matches.indexed
                        && picker.scanning == matches.scanning
                        && picker.watching == matches.watching =>
                {
                    false
                }
                Ok(matches) => {
                    picker.loading = false;
                    let previous = picker.file().cloned();
                    picker.files = matches.files;
                    picker.hits = matches.hits;
                    picker.cursor = previous
                        .as_ref()
                        .and_then(|file| {
                            picker
                                .files
                                .iter()
                                .position(|entry| entry.path == file.path)
                        })
                        .unwrap_or(picker.cursor)
                        .min(picker.files.len().saturating_sub(1));
                    if previous.as_ref() != picker.file() {
                        self.panes[side].preview_path = None;
                    }
                    picker.indexed = matches.indexed;
                    picker.scanning = matches.scanning;
                    picker.watching = matches.watching;
                    picker.error = note;
                    true
                }
                Err(error) => {
                    let updated = picker.loading || picker.error.as_ref() != Some(&error);
                    picker.loading = false;
                    picker.scanning = false;
                    picker.error = Some(error);
                    updated
                }
            };
            if updated {
                self.panes[side].revision += 1;
                self.peek(side);
                changed = true;
            }
        }
        if self.panes[side].finder.is_some()
            && self.panes[side]
                .picker
                .as_ref()
                .is_some_and(|picker| !picker.content || picker.scanning)
            && !self.panes[side].finder_results.is_pending()
            && self.panes[side].finder_refresh.elapsed() >= Duration::from_millis(400)
        {
            self.search_picker(side);
        }
        tx.wake_after(Duration::from_millis(100));
        changed
    }

    pub fn close_picker(&mut self, side: usize, tx: &mut Tx) {
        self.dismiss_picker(side);
        tx.scroll_to_instant(
            Pane::list_key(side),
            0.0,
            self.panes[side].tab().scroll.get(),
        );
        tx.blur();
    }

    pub fn dismiss_picker(&mut self, side: usize) {
        use gio::prelude::CancellableExt;
        self.panes[side].finder_io.cancel();
        self.panes[side].finder_abort.store(true, Ordering::Relaxed);
        self.panes[side].picker = None;
        self.panes[side].finder_init.cancel();
        self.panes[side].finder_results.cancel();
        self.panes[side].finder = None;
        self.peek(side);
    }

    fn suspend_picker(&mut self, side: usize, tx: &mut Tx) {
        if let Some(mut picker) = self.panes[side].picker.take() {
            picker.menu = None;
            self.panes[side].tab_mut().saved_picker = Some(picker);
            self.close_picker(side, tx);
        }
    }

    pub fn picker_hover(&mut self, side: usize, index: usize, tx: &mut Tx) {
        if let Some(picker) = &mut self.panes[side].picker {
            picker.cursor = index.min(picker.files.len().saturating_sub(1));
            if let Some(file) = picker.file() {
                tx.scroll_into_view_in(Pane::finder_key(side), &file.key);
            }
        }
        if let Some(selector) = &mut self.selector
            && matches!(selector.request.mode, crate::selector::Mode::Save)
            && let Some(file) = self.panes[side].file()
            && !file.directory
        {
            selector.name = TextEdit::new(file.path.file_name().unwrap().to_string_lossy());
        }
        self.peek(side);
    }

    pub fn picker_accept(&mut self, open: bool, tx: &mut Tx) {
        // A keystroke can arrive before poll has submitted a changed query.
        let Some(picker) = &self.panes[self.active_pane].picker else {
            return;
        };
        if picker.loading || picker.query != self.panes[self.active_pane].input.text {
            return;
        }
        let Some(file) = picker.file().cloned() else {
            return;
        };
        if self.selector.is_some() && open {
            if file.directory {
                self.cd(self.active_pane, file.path, tx, true);
            } else {
                self.selector_accept(false, tx);
            }
            return;
        }
        let remote = self.remote_io(&file.path).is_some();
        if !remote && !file.directory && !file.path.is_file() {
            self.panes[self.active_pane].picker.as_mut().unwrap().error =
                Some("This file is no longer available. Refresh the picker.".into());
            return;
        }
        let recorded = if remote || file.directory {
            None
        } else {
            Some(crate::finder::record(&file.path))
        };
        self.suspend_picker(self.active_pane, tx);
        self.reveal(
            self.active_pane,
            file.path.clone(),
            open && file.directory,
            false,
            tx,
        );
        if open && !file.directory {
            // Reveal reloads asynchronously, so launch the accepted path directly.
            self.open_default(&file.path);
        }
        if let Some(Err(error)) = recorded {
            self.message = Some(error);
        }
    }

    pub fn picker_scope(&mut self, recursive: bool) {
        self.panes[self.active_pane].input.focused = true;
        let Some(picker) = &mut self.panes[self.active_pane].picker else {
            return;
        };
        if picker.recursive == recursive {
            return;
        }
        picker.recursive = recursive;
        picker.files.clear();
        picker.hits.clear();
        picker.cursor = 0;
        picker.scroll.set(0.0);
        picker.selected.clear();
        self.restart_picker(self.active_pane);
        self.peek(self.active_pane);
    }

    pub fn picker_mode(&mut self, content: bool) {
        self.panes[self.active_pane].input.focused = true;
        let Some(picker) = &self.panes[self.active_pane].picker else {
            return;
        };
        if content && self.remote_io(&picker.root).is_some() {
            self.panes[self.active_pane].picker.as_mut().unwrap().error =
                Some("Content search is available in local folders.".into());
            return;
        }
        let picker = self.panes[self.active_pane].picker.as_mut().unwrap();
        if picker.content == content {
            return;
        }
        picker.content = content;
        picker.files.clear();
        picker.hits.clear();
        picker.cursor = 0;
        picker.selected.clear();
        picker.scroll.set(0.0);
        picker.loading = true;
        self.search_picker(self.active_pane);
        self.peek(self.active_pane);
    }

    pub fn picker_regex(&mut self) {
        self.panes[self.active_pane].input.focused = true;
        if let Some(picker) = &mut self.panes[self.active_pane].picker {
            picker.regex = !picker.regex;
            picker.loading = true;
        }
        self.search_picker(self.active_pane);
    }

    pub fn picker_all(&mut self) {
        if let Some(picker) = &mut self.panes[self.active_pane].picker {
            picker.all_files = !picker.all_files;
        }
        self.restart_picker(self.active_pane);
        self.peek(self.active_pane);
    }

    pub fn picker_menu(&mut self, kind: FilterKind) {
        if let Some(picker) = &mut self.panes[self.active_pane].picker {
            picker.menu = if picker.menu == Some(kind) {
                None
            } else {
                Some(kind)
            };
        }
    }

    pub fn picker_filter(&mut self, kind: FilterKind, option: usize) {
        let Some(picker) = &mut self.panes[self.active_pane].picker else {
            return;
        };
        picker.menu = None;
        if !picker.filters.set(kind, option) {
            return;
        }
        picker.files.clear();
        picker.hits.clear();
        picker.cursor = 0;
        picker.selected.clear();
        picker.scroll.set(0.0);
        picker.loading = true;
        self.search_picker(self.active_pane);
        self.peek(self.active_pane);
    }

    pub fn picker_clear_filters(&mut self) {
        let Some(picker) = &mut self.panes[self.active_pane].picker else {
            return;
        };
        picker.menu = None;
        if picker.filters == SearchFilters::default() {
            return;
        }
        picker.filters = SearchFilters::default();
        picker.files.clear();
        picker.hits.clear();
        picker.cursor = 0;
        picker.selected.clear();
        picker.scroll.set(0.0);
        picker.loading = true;
        self.search_picker(self.active_pane);
        self.peek(self.active_pane);
    }

    pub fn toggle_selection(&mut self, path: &Path) {
        if let Some(selector) = &self.selector {
            let file = self
                .pane()
                .picker
                .as_ref()
                .map_or(&self.tab().files, |picker| &picker.files)
                .iter()
                .find(|file| file.path == path);
            if !selector.request.multiple()
                || file.is_none_or(|file| file.directory != selector.request.folders())
            {
                return;
            }
        }
        if self.panes[self.active_pane]
            .picker
            .as_ref()
            .is_some_and(|picker| picker.loading)
        {
            return;
        }
        let selected = if let Some(picker) = &mut self.panes[self.active_pane].picker {
            &mut picker.selected
        } else {
            self.tab_mut().finish_visual();
            &mut self.tab_mut().selected
        };
        if !selected.remove(path) {
            selected.insert(path.to_path_buf());
        }
        self.panes[self.active_pane].revision += 1;
    }

    pub fn toggle_preview(&mut self, tx: &mut Tx) {
        for side in 0..2 {
            tx.scroll_to_instant(format!("breadcrumbs-{side}"), f32::MAX, 0.0);
        }
        self.pane_mut().address.close();
        self.preview_expanded = !self.preview_expanded;
        self.pending.clear();
        if self.preview_expanded || !self.split {
            self.peek(self.active_pane);
            let offset = self.pane().preview_scroll.get();
            tx.scroll_to_instant("preview", 0.0, offset[0]);
        } else {
            use gio::prelude::CancellableExt;
            let pane = self.pane_mut();
            pane.preview_io.cancel();
            pane.previews.cancel();
            if matches!(pane.preview, Preview::Loading) {
                pane.preview_path = None;
            }
        }
        self.panes[self.active_pane].input.focused =
            !self.preview_expanded && self.panes[self.active_pane].picker.is_some();
        if let Some(picker) = &self.panes[self.active_pane].picker {
            tx.scroll_to_instant(Pane::finder_key(self.active_pane), 0.0, picker.scroll.get());
        } else {
            tx.scroll_to_instant(
                Pane::list_key(self.active_pane),
                0.0,
                self.tab().scroll.get(),
            );
        }
        if self.split && !self.preview_expanded {
            let other = 1 - self.active_pane;
            tx.scroll_to_instant(
                Pane::list_key(other),
                0.0,
                self.panes[other].tab().scroll.get(),
            );
            if let Some(picker) = &self.panes[other].picker {
                tx.scroll_to_instant(Pane::finder_key(other), 0.0, picker.scroll.get());
            }
        }
        if self.preview_expanded || self.panes[self.active_pane].picker.is_none() {
            tx.blur();
        }
    }

    pub fn peek(&mut self, side: usize) {
        self.update_watch(side);
        if side != self.active_pane || (self.split && !self.preview_expanded) {
            return;
        }
        let Some(file) = self.panes[side].file().cloned() else {
            use gio::prelude::CancellableExt;
            self.panes[side].preview_io.cancel();
            self.panes[side].previews.cancel();
            self.panes[side].preview = Preview::Empty;
            self.panes[side].preview_path = None;
            self.panes[side].preview_mimes.cancel();
            self.panes[side].preview_mime_io.cancel();
            self.panes[side].preview_mime = None;
            self.panes[side].preview_mime_file = None;
            return;
        };
        if self.panes[side].preview_mime_file.as_ref() != Some(&file) {
            self.panes[side].preview_mime = None;
            self.panes[side].preview_mime_file = Some(file.clone());
            self.panes[side].preview_source = false;
            self.panes[side].preview_source_lines.clear();
            let uri = self.location_uri(&file.path);
            self.panes[side].preview_mime_io.cancel();
            self.panes[side].preview_mime_io = gio::Cancellable::new();
            let cancel = self.panes[side].preview_mime_io.clone();
            self.panes[side].preview_mimes.request(
                (file.clone(), uri, cancel),
                |(file, uri, cancel)| {
                    use gio::prelude::*;
                    let mime = gio::File::for_uri(&uri)
                        .query_info(
                            "standard::content-type",
                            gio::FileQueryInfoFlags::NONE,
                            Some(&cancel),
                        )
                        .ok()
                        .and_then(|info| info.content_type())
                        .and_then(|kind| gio::content_type_get_mime_type(&kind))
                        .map(Into::into);
                    (file, mime)
                },
            );
        }
        if self.panes[side].preview_path.as_ref() == Some(&file.path) {
            return;
        }
        let Some(cache) = self.cache.clone() else {
            return;
        };
        if self.panes[side]
            .resume_preview
            .as_ref()
            .is_some_and(|(path, _)| path != &file.path)
        {
            self.panes[side].resume_preview = None;
        }
        self.panes[side].preview_path = Some(file.path.clone());
        self.panes[side].preview = Preview::Loading;
        self.panes[side].preview_scroll.set([0.0; 2]);
        use gio::prelude::CancellableExt;
        self.panes[side].preview_io.cancel();
        self.panes[side].preview_io = gio::Cancellable::new();
        if let Some(root) = self.remote_io(&file.path) {
            let cancel = self.panes[side].preview_io.clone();
            self.panes[side].previews.request(
                (file.path, file.directory, root, cancel, cache),
                |(path, dir, root, cancel, cache)| {
                    file::preview_remote(path, dir, root, cancel, cache)
                },
            );
        } else {
            let cancel = self.panes[side].preview_io.clone();
            self.panes[side].previews.request(
                (file.path, file.directory, cancel, cache),
                |(path, dir, cancel, cache)| file::preview(path, dir, cancel, cache),
            );
        }
    }

    pub fn toggle_preview_source(&mut self, tx: &mut Tx) {
        if let Preview::Html(html) = &self.pane().preview {
            self.render_html(matches!(html.view, crate::html::View::Source), tx);
        } else if let Preview::Markdown { source, .. } = &self.pane().preview {
            let lines = source.lines().map(str::to_owned).collect();
            self.pane_mut().preview_source_lines = lines;
            self.pane_mut().preview_source = !self.pane().preview_source;
            self.pane().preview_scroll.set([0.0; 2]);
            tx.scroll_to_instant("preview", 0.0, 0.0);
        }
    }

    pub fn print_preview(&mut self) {
        if self.print_busy || self.closing {
            return;
        }
        let Some(file) = self.pane().file().filter(|file| !file.directory).cloned() else {
            return;
        };
        let Some(mime) = self
            .pane()
            .preview_mime
            .clone()
            .filter(|mime| crate::printing::supports(mime))
        else {
            return;
        };
        self.print_io = gio::Cancellable::new();
        self.print_busy = true;
        self.print_worker.request(
            (file.path, mime, self.print_io.clone()),
            |(path, mime, cancel)| crate::printing::run(path, mime, None, cancel),
        );
    }

    pub fn open_preview(&mut self, tx: &mut Tx) {
        if let Some(file) = self.pane().file().cloned() {
            self.open_file(file, tx, true);
        }
    }

    pub fn render_html(&mut self, render: bool, tx: &mut Tx) {
        let Preview::Html(html) = &self.panes[self.active_pane].preview else {
            return;
        };
        let source = html.source.clone();
        use gio::prelude::CancellableExt;
        self.panes[self.active_pane].preview_io.cancel();
        self.panes[self.active_pane].previews.cancel();
        self.panes[self.active_pane].preview_scroll.set([0.0; 2]);
        tx.scroll_to_y("preview", 0.0);
        let view = if render {
            let Some(cache) = self.cache.clone() else {
                return;
            };
            self.panes[self.active_pane].preview_io = gio::Cancellable::new();
            self.panes[self.active_pane].previews.request(
                (
                    source.clone(),
                    cache,
                    self.panes[self.active_pane].preview_io.clone(),
                ),
                |(source, cache, cancel)| {
                    Preview::Html(crate::html::Html::render(source, &cache, &cancel))
                },
            );
            crate::html::View::Loading
        } else {
            crate::html::View::Source
        };
        self.panes[self.active_pane].preview = Preview::Html(crate::html::Html { source, view });
    }

    pub fn open_html_link(&mut self, path: &Path, link: &str, tx: &mut Tx) {
        let Some(target) = url::Url::from_file_path(path)
            .ok()
            .and_then(|base| base.join(link).ok())
        else {
            return;
        };
        if !matches!(target.scheme(), "file" | "http" | "https" | "mailto") {
            return;
        }
        if let Some(anchor) = target.fragment()
            && target.to_file_path().ok().as_deref() == Some(path)
            && let Preview::Html(html) = &self.panes[self.active_pane].preview
            && let crate::html::View::Rendered(document) = &html.view
        {
            if anchor.is_empty() {
                tx.scroll_to_y("preview", 0.0);
                return;
            }
            let anchor = gio::glib::uri_unescape_string(anchor, None::<&str>);
            for (i, part) in document.parts.iter().enumerate() {
                if let crate::html::Part::Text { anchors, .. } = part
                    && anchor
                        .as_ref()
                        .is_some_and(|id| anchors.iter().any(|a| a == id.as_str()))
                {
                    tx.scroll_into_view(format!("preview/html-content/html-part-{i}"));
                    return;
                }
            }
            self.message = Some("HTML anchor not found".into());
        } else {
            self.open_preview_link(path, target.as_str(), tx);
        }
    }

    pub fn seek_pdf(&mut self, direction: i32) {
        let Preview::Pdf(pdf) = &self.panes[self.active_pane].preview else {
            return;
        };
        let Some(page) = pdf.turn(direction) else {
            return;
        };
        let Some(cache) = self.cache.clone() else {
            return;
        };
        use gio::prelude::CancellableExt;
        self.panes[self.active_pane].preview_io.cancel();
        self.panes[self.active_pane].preview_io = gio::Cancellable::new();
        self.panes[self.active_pane].previews.request(
            (
                page.clone(),
                self.panes[self.active_pane].preview_io.clone(),
                cache,
            ),
            |(page, cancel, cache)| Preview::Pdf(page.render(&cancel, &cache)),
        );
        self.panes[self.active_pane].preview = Preview::Pdf(page);
    }

    pub fn set_folder_view(&mut self, preference: Option<Preference>, tx: &mut Tx) {
        let uri = self.location_uri(&self.tab().cwd);
        self.views.set(uri.clone(), preference);
        let preference = self.views.get(&uri);
        for side in 0..2 {
            let indices: Vec<_> = self.panes[side]
                .tabs
                .iter()
                .enumerate()
                .filter(|(_, tab)| self.location_uri(&tab.cwd) == uri)
                .map(|(index, _)| index)
                .collect();
            let active = indices.contains(&self.panes[side].active);
            let visibility_changed =
                self.panes[side].tab().preference.show_hidden != preference.show_hidden;
            for index in indices {
                self.panes[side].tabs[index].finish_visual();
                self.panes[side].tabs[index].preference = preference;
            }
            if active && (self.split || side == self.active_pane) {
                if visibility_changed {
                    self.reload(side);
                } else {
                    self.reorder(side);
                    if let Preview::Directory(files) = &mut self.panes[side].preview {
                        file::sort(
                            files,
                            preference.sort_by,
                            preference.sort_reverse,
                            preference.sort_sensitive,
                            preference.sort_dir_first,
                        );
                    }
                    self.peek(side);
                    self.restore_cursor(side, tx);
                }
            }
        }
    }

    pub fn set_details(&mut self, side: usize, details: Details) {
        let uri = self.location_uri(&self.panes[side].tab().cwd);
        let mut preference = self.panes[side].tab().preference;
        preference.details = details;
        self.views.set(uri.clone(), Some(preference));
        for side in 0..2 {
            let active = self.panes[side].active;
            let indices: Vec<_> = self.panes[side]
                .tabs
                .iter()
                .enumerate()
                .filter(|(_, tab)| self.location_uri(&tab.cwd) == uri)
                .map(|(index, _)| index)
                .collect();
            for index in indices {
                self.panes[side].tabs[index].preference.details = details;
                if index == active {
                    self.panes[side].revision += 1;
                }
            }
        }
    }

    pub fn resize_detail_column(&mut self, side: usize, column: DetailColumn, width: f32) {
        let mut details = self.panes[side].tab().preference.details;
        details.resize(column, width);
        self.set_details(side, details);
    }

    pub fn reorder(&mut self, side: usize) {
        let hovered = self.panes[side]
            .tab()
            .file()
            .map(|f| f.path.clone())
            .or_else(|| {
                self.panes[side]
                    .tab()
                    .hovered
                    .get(&self.panes[side].tab().cwd)
                    .cloned()
            });
        let by = self.panes[side].tab().preference.sort_by;
        let p = self.panes[side].tab().preference;
        file::sort(
            &mut self.panes[side].tab_mut().files,
            by,
            p.sort_reverse,
            p.sort_sensitive,
            p.sort_dir_first,
        );
        self.panes[side]
            .parent
            .retain(|f| p.show_hidden || !f.name.starts_with('.'));
        file::sort(
            &mut self.panes[side].parent,
            by,
            p.sort_reverse,
            p.sort_sensitive,
            p.sort_dir_first,
        );
        let selector = self.selector.as_ref();
        let tab = self.panes[side].tab_mut();
        tab.visible = tab
            .files
            .iter()
            .enumerate()
            .filter(|(_, f)| {
                (p.show_hidden || !f.name.starts_with('.'))
                    && smart_contains(&f.name, &tab.filter)
                    && selector.is_none_or(|selector| selector.matches(f))
            })
            .map(|(i, _)| i)
            .collect();
        tab.cursor = hovered
            .and_then(|path| tab.visible.iter().position(|&i| tab.files[i].path == path))
            .unwrap_or(tab.cursor)
            .min(tab.visible.len().saturating_sub(1));
        self.panes[side].revision += 1;
    }

    fn restore_cursor(&self, side: usize, tx: &mut Tx) {
        if let Some(file) = self.panes[side].tab().file() {
            let key = if self.panes[side].tab().preference.view_mode
                == crate::preference::ViewMode::Grid
            {
                format!(
                    "grid-row-{}",
                    self.panes[side].tab().cursor / self.panes[side].columns()
                )
            } else {
                file.key.clone()
            };
            tx.scroll_into_view_in(Pane::list_key(side), key);
        }
        if side == self.active_pane
            && let Some(file) = self.panes[side]
                .parent
                .iter()
                .find(|f| f.path == self.panes[side].tab().cwd)
        {
            tx.scroll_into_view_in("parent", &file.key);
        }
        if side == self.active_pane {
            tx.set_title(format!(
                "{} — Files",
                self.display_location(&self.panes[side].tab().cwd)
            ));
        }
    }

    pub fn hover(&mut self, path: &Path, tx: &mut Tx) {
        if let Some(i) = self
            .tab()
            .visible
            .iter()
            .position(|&i| self.tab().files[i].path == path)
        {
            self.tab_mut().cursor = i;
            self.peek(self.active_pane);
            self.restore_cursor(self.active_pane, tx);
        }
    }

    fn arrow(&mut self, step: &str, tx: &mut Tx) {
        let len = self.tab().visible.len();
        if len == 0 {
            return;
        }
        let old = self.tab().cursor;
        let step: Step = step.parse().unwrap_or_default();
        let new = step.add(old, len, self.panes[self.active_pane].page_size, 0, 5);
        if old != new {
            if let Some(visual) = &mut self.tab_mut().visual {
                visual.wraps += match step {
                    Step::Prev if new > old => -1,
                    Step::Next if new < old => 1,
                    _ => 0,
                };
            }
            self.tab_mut().cursor = new;
            self.peek(self.active_pane);
            self.restore_cursor(self.active_pane, tx);
        }
    }

    pub fn peek_allowed(&self) -> bool {
        self.window_focused
            && self.selector.is_none()
            && self.context.is_none()
            && self.prompt.is_none()
            && self.pending.is_empty()
            && self.panel.is_none()
            && self.place_menu.is_none()
            && self.view_options.is_none()
            && !self.appearance.open
            && !self.help
            && !self.spot
            && !self.tasks_open
            && self.session_error.is_none()
            && self.confirmation.is_none()
            && self.queue.conflict.is_none()
            && self.authentication.is_none()
            && self.question.is_none()
            && self.drop_decision.is_none()
            && self.favorite_drag.is_none()
            && self.drop_hover.is_none()
            && self
                .panes
                .iter()
                .all(|pane| !pane.address.editing && pane.picker.is_none())
    }

    pub fn peek_folder(&mut self, path: PathBuf, anchor: String, side: usize, inside: bool) {
        if !inside {
            self.peek.leave(&anchor);
            return;
        }
        if !self.peek_allowed() {
            return;
        }
        let tab = self.panes[side].tab();
        let target = crate::peek::Target {
            path: path.clone(),
            anchor,
            side,
            origin: tab.cwd.clone(),
            scroll: tab.scroll.get(),
        };
        let preference = tab.preference;
        let remote = self.remote_io(&path).is_some();
        self.peek_scrolled.set(false);
        self.peek.open(target, preference, remote);
    }

    pub fn open_peek(&mut self, path: PathBuf, directory: bool, side: usize, tx: &mut Tx) {
        self.peek.close();
        self.activate_pane(side, tx);
        self.reveal(side, path.clone(), directory, false, tx);
        if !directory {
            let tab = self.panes[side].tab_mut();
            tab.selected.clear();
            tab.selected.insert(path);
        }
        tx.blur();
    }

    pub fn cd(&mut self, side: usize, path: PathBuf, tx: &mut Tx, history: bool) {
        self.peek.close();
        if let Some(selector) = &mut self.selector {
            selector.error = None;
            self.panes[side].tab_mut().filter.clear();
            self.panes[side].tab_mut().selected.clear();
        }
        self.panes[side].address.close();
        tx.scroll_to_instant(format!("breadcrumbs-{side}"), f32::MAX, 0.0);
        if self.panes[side].picker.is_some() {
            self.close_picker(side, tx);
        }
        if path == self.panes[side].tab().cwd {
            return;
        }
        let preference = self.views.get(&self.location_uri(&path));
        let tab = self.panes[side].tab_mut();
        tab.preference = preference;
        tab.finish_visual();
        if let Some(file) = tab.file() {
            tab.hovered.insert(tab.cwd.clone(), file.path.clone());
        }
        if history {
            tab.history.truncate(tab.history_cursor + 1);
            tab.history.push(path.clone());
            tab.history_cursor = tab.history.len() - 1;
        }
        tab.cwd = path;
        tab.selected.clear();
        tab.resume_scroll = None;
        tab.select_after = None;
        tab.files.clear();
        tab.visible.clear();
        tab.cursor = 0;
        tab.filter.clear();
        self.message = None;
        self.panes[side].revision += 1;
        tx.scroll_to_instant(Pane::list_key(side), 0.0, 0.0);
        self.restore_cursor(side, tx);
        self.reload(side);
    }

    fn remote_place(&self, path: &Path) -> Option<&Place> {
        self.places
            .iter()
            .filter(|place| {
                !place.uri.starts_with("file:")
                    && place
                        .path
                        .as_deref()
                        .is_some_and(|root| path.starts_with(root))
            })
            .max_by_key(|place| {
                place
                    .path
                    .as_ref()
                    .map_or(0, |root| root.components().count())
            })
    }

    fn remote_io(&self, path: &Path) -> Option<operations::RemoteRoot> {
        let place = self.remote_place(path)?;
        Some(operations::RemoteRoot {
            path: place.path.clone()?,
            uri: place.uri.clone(),
        })
    }

    fn remote_root(&self, path: &Path) -> bool {
        self.places.iter().any(|place| {
            !place.uri.starts_with("file:") && place.unmount && place.path.as_deref() == Some(path)
        })
    }

    pub fn location_uri(&self, path: &Path) -> String {
        if let Some(place) = self.remote_place(path)
            && let Some(root) = &place.path
            && let Ok(relative) = path.strip_prefix(root)
            && let Ok(mut uri) = url::Url::parse(&place.uri)
        {
            if let Ok(mut segments) = uri.path_segments_mut() {
                segments.pop_if_empty();
                for component in relative.components() {
                    segments.push(&component.as_os_str().to_string_lossy());
                }
            }
            return uri.into();
        }
        gio::File::for_path(path).uri().into()
    }

    pub fn display_location(&self, path: &Path) -> String {
        if self.remote_place(path).is_some() {
            self.location_uri(path)
        } else {
            path.display().to_string()
        }
    }

    pub fn folder_name(&self, path: &Path) -> String {
        if let Some(place) = self.remote_place(path)
            && place.path.as_deref() == Some(path)
        {
            return place.name.clone();
        }
        path.file_name()
            .map(|name| name.to_string_lossy().into_owned())
            .unwrap_or_else(|| "/".into())
    }

    pub fn reveal_location(
        &mut self,
        location: locations::Location,
        folders: bool,
        properties: bool,
        tx: &mut Tx,
    ) {
        match location {
            locations::Location::Path(path) => {
                self.reveal(self.active_pane, path, folders, properties, tx)
            }
            locations::Location::Uri(uri) => {
                if uri.starts_with("trash:") {
                    self.command("trash", tx);
                    return;
                }
                if self.mounts.busy() {
                    self.message = Some("A device operation is already running".into());
                    return;
                }
                self.mount_intent = Some((self.active_pane, folders, properties));
                self.mount_action(mounts::Action::Connect(uri));
            }
        }
    }

    pub fn reveal(
        &mut self,
        side: usize,
        path: PathBuf,
        folders: bool,
        properties: bool,
        tx: &mut Tx,
    ) {
        let cwd = if folders {
            path.clone()
        } else {
            path.parent()
                .unwrap_or(std::path::Path::new("/"))
                .to_path_buf()
        };
        let same_directory = cwd == self.panes[side].tab().cwd;
        if side == self.active_pane {
            self.prompt = None;
            self.action_paths = None;
            self.panel = None;
            self.help = false;
            self.pending.clear();
            self.properties = None;
            self.property_dialog.name.focused = false;
            self.properties_io.cancel();
            self.properties_worker.cancel();
            self.property_target = None;
            self.spot = properties;
        }
        if !folders {
            self.panes[side]
                .tab_mut()
                .hovered
                .insert(cwd.clone(), path.clone());
        }
        self.cd(side, cwd, tx, true);
        if path
            .file_name()
            .is_some_and(|name| name.as_encoded_bytes().starts_with(b"."))
        {
            self.panes[side].tab_mut().preference.show_hidden = true;
        }

        if same_directory {
            let tab = self.panes[side].tab_mut();
            tab.finish_visual();
            tab.files.clear();
            tab.visible.clear();
            tab.filter.clear();
            self.reload(side);
        }
    }

    fn load_properties(&mut self) {
        self.properties_worker.cancel();
        self.properties = None;
        self.property_dialog.name.focused = false;
        self.properties_io.cancel();
        self.properties_io = gio::Cancellable::new();
        let cancel = self.properties_io.clone();
        if let Some(path) = self.property_target.clone().or_else(|| {
            self.action_paths
                .as_ref()
                .and_then(|paths| paths.first())
                .cloned()
                .or_else(|| self.pane().file().map(|file| file.path.clone()))
        }) {
            let uri = self
                .remote_io(&path)
                .map(|root| file::remote_uri(&root, &path).uri().to_string());
            self.properties_worker
                .request((path, uri, cancel), |(path, uri, cancel)| {
                    locations::properties(path, uri, cancel)
                });
        }
    }

    pub fn dismiss_properties(&mut self) {
        self.spot = false;
        self.property_dialog.name.focused = false;
        self.properties = None;
        self.property_target = None;
        self.properties_io.cancel();
        self.properties_worker.cancel();
    }

    pub fn close_properties(&mut self, tx: &mut Tx) {
        self.dismiss_properties();
        tx.blur();
    }

    pub fn apply_properties(&mut self, tx: &mut Tx) {
        let Some(properties) = &self.properties else {
            return;
        };
        let dialog = &self.property_dialog;
        if properties.remote || !dialog.can_apply(properties) {
            return;
        }
        let source = properties.path.clone();
        let destination = if dialog.name.text == properties.name {
            source.clone()
        } else {
            source.with_file_name(&dialog.name.text)
        };
        let mode = (properties.can_change_mode
            && (dialog.mode != properties.mode.unwrap_or_default() || dialog.recursive))
            .then_some(dialog.mode);
        let recursive = dialog.recursive;
        let target = destination.clone();
        self.close_properties(tx);
        self.enqueue_select(
            Operation::Properties {
                source,
                destination,
                mode,
                recursive,
            },
            vec![target],
        );
    }

    pub fn favorites_saving(&self) -> bool {
        self.favorite_tx.is_some()
            || self.bookmark_running
            || self.bookmark_refreshing.is_some()
            || !self.bookmark_queue.is_empty()
    }

    fn restore_favorite_tx(&mut self) {
        let Some(snapshot) = self.favorite_tx.take() else {
            return;
        };
        self.favorite_saved = false;
        let current = std::mem::take(&mut self.places);
        self.places = replace_favorites(snapshot, current);
    }

    pub fn favorites(&self) -> impl Iterator<Item = &Place> {
        self.places
            .iter()
            .filter(|place| place.kind == PlaceKind::Favorite)
    }

    pub fn pin_place(&mut self, uri: String) {
        self.bookmark_queue
            .push_back((Bookmark::Pin(vec![uri]), None));
        self.place_menu = None;
    }

    pub fn toggle_favorite(&mut self, side: usize, tx: &mut Tx) {
        if self.favorites_saving() {
            return;
        }
        self.activate_pane(side, tx);
        let path = self.panes[side].tab().cwd.clone();
        let uri = self.location_uri(&path);
        self.favorite_tx = Some(self.favorites().cloned().collect());
        self.favorite_saved = false;
        if let Some(index) = self
            .places
            .iter()
            .position(|place| place.kind == PlaceKind::Favorite && place.uri == uri)
        {
            self.places.remove(index);
            self.remove_favorite(uri);
        } else {
            let place = Place {
                kind: PlaceKind::Favorite,
                name: self.folder_name(&path),
                uri: uri.clone(),
                path: gio::File::for_uri(&uri).path(),
                volume: None,
                icon_name: None,
                mounted: uri.starts_with("file:"),
                eject: false,
                unmount: false,
            };
            let index = self
                .places
                .iter()
                .rposition(|place| place.kind == PlaceKind::Favorite)
                .map(|index| index + 1)
                .or_else(|| {
                    self.places
                        .iter()
                        .position(|place| place.uri == "trash:///")
                })
                .unwrap_or(self.places.len());
            self.places.insert(index, place);
            self.pin_place(uri);
        }
    }

    pub fn pin_current(&mut self) {
        self.bookmark_queue.push_back((
            Bookmark::Pin(vec![self.location_uri(&self.tab().cwd)]),
            None,
        ));
    }

    pub fn pin_folders(&mut self) {
        let paths: Vec<_> = self.chosen();
        if paths.is_empty() {
            self.message = Some("Choose a folder to add to Favorites".into());
            return;
        }
        let uris = paths.iter().map(|path| self.location_uri(path)).collect();
        self.bookmark_queue.push_back((Bookmark::Pin(uris), None));
    }

    pub fn show_context(
        &mut self,
        side: usize,
        path: Option<&Path>,
        anchor: rune::PopupAnchor,
        tx: &mut Tx,
    ) {
        if self.selector.is_some() {
            return;
        }
        self.activate_pane(side, tx);
        self.pane_mut().address.close();
        self.place_menu = None;
        self.context = None;
        let directory = self.tab().cwd.clone();
        self.context = if let Some(path) = path {
            let file = if let Some(picker) = &self.pane().picker {
                picker.files.iter().find(|file| file.path == path).cloned()
            } else {
                self.tab()
                    .files
                    .iter()
                    .find(|file| file.path == path)
                    .cloned()
            };
            let Some(file) = file else { return };
            if self.pane().picker.is_some() {
                let index = self
                    .pane()
                    .picker
                    .as_ref()
                    .unwrap()
                    .files
                    .iter()
                    .position(|file| file.path == path)
                    .unwrap();
                self.picker_hover(side, index, tx);
                let picker = self.pane_mut().picker.as_mut().unwrap();
                if !picker.selected.contains(path) {
                    picker.selected.clear();
                    picker.selected.insert(path.to_path_buf());
                }
            } else {
                self.tab_mut().finish_visual();
                self.hover(path, tx);
                if !self.tab().selected.contains(path) {
                    self.tab_mut().selected.clear();
                    self.tab_mut().selected.insert(path.to_path_buf());
                }
            }
            let paths = self.chosen();
            let (entries, selected) = if let Some(picker) = &self.pane().picker {
                (&picker.files, &picker.selected)
            } else {
                (&self.tab().files, &self.tab().selected)
            };
            let mut matched = 0;
            let all_folders = entries
                .iter()
                .filter(|file| selected.contains(&file.path))
                .all(|file| {
                    matched += 1;
                    file.directory
                })
                && matched == paths.len();
            Some(Context::files(
                side,
                anchor,
                directory,
                file,
                paths,
                all_folders,
            ))
        } else {
            Some(Context::background(
                side,
                anchor,
                directory,
                self.queue.undo_available(),
            ))
        };
        self.context_shortcuts();
        self.pending.clear();
        tx.blur();
    }

    fn context_shortcuts(&mut self) {
        if let Some(menu) = &mut self.context {
            for item in menu.groups.iter_mut().flatten() {
                let key = match item.shortcut {
                    "Ctrl+C" => "<C-c>",
                    "Ctrl+X" => "<C-x>",
                    "Ctrl+V" => "<C-v>",
                    "F2" => "<F2>",
                    "Delete" => "<Delete>",
                    "Ctrl+Shift+N" => "<C-S-n>",
                    _ => continue,
                };
                let command = match item.action {
                    Action::Command(command) => command,
                    Action::Paste => "paste",
                    _ => continue,
                };
                if self
                    .bindings
                    .iter()
                    .find(|binding| binding.on.list() == [key])
                    .is_none_or(|binding| binding.run.list() != [command])
                {
                    item.shortcut = "";
                }
            }
        }
    }

    pub fn context_action(&mut self, key: &str, tx: &mut Tx) {
        let Some(menu) = self.context.take() else {
            return;
        };
        let Some(action) = menu
            .groups
            .iter()
            .flatten()
            .find(|item| item.key == key && item.enabled)
            .map(|item| item.action)
        else {
            return;
        };
        self.activate_pane(menu.side, tx);
        let paths = match &menu.target {
            Target::Files { paths, .. } => paths.clone(),
            _ => Vec::new(),
        };
        self.action_paths = Some(paths.clone());
        match action {
            Action::Open(target) => match menu.target {
                Target::Place(place) => self.open_place(&place, target, tx),
                Target::Files { file, .. } => match target {
                    PlaceOpen::Current => self.open_file(file, tx, true),
                    PlaceOpen::Other => {
                        if !self.split {
                            self.toggle_split(tx);
                        }
                        self.cd(1 - self.active_pane, file.path, tx, true);
                    }
                    PlaceOpen::Tab => {
                        let preference = self.views.get(&self.location_uri(&file.path));
                        self.pane_mut().tabs.push(Tab::new(file.path, preference));
                        self.pane_mut().active = self.pane().tabs.len() - 1;
                        self.reload(self.active_pane);
                    }
                },
                Target::Background => {}
            },
            Action::OpenWindow => {
                if let Target::Files { file, .. } = menu.target
                    && let Err(error) = crate::desktop::spawn_window(
                        self.location_uri(&file.path),
                        true,
                        false,
                        self.config_dir.as_deref(),
                    )
                {
                    self.message = Some(error.to_string());
                }
            }
            Action::Paste => {
                let destination = match menu.target {
                    Target::Files { file, .. } => file.path,
                    _ => menu.directory,
                };
                self.paste_to(destination, false, tx);
            }
            Action::CopyPaths => {
                let paths = if paths.is_empty() {
                    vec![menu.directory]
                } else {
                    paths
                };
                tx.copy(
                    paths
                        .iter()
                        .map(|path| self.display_location(path))
                        .collect::<Vec<_>>()
                        .join("\n"),
                );
                self.message = Some("Location copied".into());
            }
            Action::Properties => {
                if paths.is_empty() {
                    self.action_paths = Some(vec![menu.directory]);
                }
                self.property_target = self
                    .action_paths
                    .as_ref()
                    .and_then(|paths| paths.first())
                    .cloned();
                self.spot = true;
                self.property_focus = Some(Pane::list_key(self.active_pane).into());
                self.load_properties();
            }
            Action::Pin => match menu.target {
                Target::Place(place) => self.pin_place(place.uri),
                _ => {
                    let uris = paths.iter().map(|path| self.location_uri(path)).collect();
                    self.bookmark_queue.push_back((Bookmark::Pin(uris), None));
                }
            },
            Action::Command("extract") => {
                if let Target::Files { file, .. } = menu.target {
                    let destination = file
                        .path
                        .parent()
                        .unwrap_or(&menu.directory)
                        .join(crate::archive::stem(&file.path));
                    self.enqueue(
                        Operation::Extract {
                            source: file.path,
                            destination,
                        },
                        false,
                    );
                }
            }
            Action::Command(command) => self.command(command, tx),
            Action::FavoriteMove(down) => {
                if let Target::Place(place) = menu.target {
                    self.move_favorite(&place.uri, down);
                }
            }
            Action::FavoriteRename => {
                if let Target::Place(place) = menu.target {
                    self.rename_place(place);
                }
            }
            Action::FavoriteRemove => {
                if let Target::Place(place) = menu.target {
                    self.remove_favorite(place.uri);
                }
            }
            Action::Unmount => {
                if let Target::Place(place) = menu.target {
                    self.mount_action(mounts::Action::Unmount(place));
                }
            }
            Action::Eject => {
                if let Target::Place(place) = menu.target {
                    self.mount_action(mounts::Action::Eject(place));
                }
            }
        }
        if self.prompt.is_none() {
            self.action_paths = None;
        }
        tx.blur();
    }

    pub fn name_error(&self) -> Option<&'static str> {
        let prompt = self.prompt?;
        if !matches!(
            prompt,
            Prompt::Create | Prompt::CreateFolder | Prompt::Rename | Prompt::Archive
        ) {
            return None;
        }
        let value = self.pane().input.text.as_str();
        if value.trim().is_empty() {
            return Some("Enter a name");
        }
        if matches!(value, "." | "..") || value.contains(['/', '\0']) {
            return Some("Use a name without folder separators");
        }
        if prompt == Prompt::Archive && !crate::archive::supported(Path::new(value)) {
            return Some("Use .zip, .tar, .tar.gz, or .tgz");
        }
        if prompt == Prompt::Rename
            && let Some(paths) = &self.action_paths
        {
            if paths.len() == 1 && paths[0].file_name().is_some_and(|name| name == value) {
                return Some("Enter a different name");
            }
            if paths.len() > 1 && value == "{name}" {
                return Some("Change the naming pattern");
            }
        }
        if prompt == Prompt::Rename
            && self
                .action_paths
                .as_ref()
                .is_some_and(|paths| paths.len() > 1)
            && !["{name}", "{stem}", "{ext}", "{n}"]
                .iter()
                .any(|token| value.contains(token))
        {
            return Some("Include {name} or {n} to give each item a different name");
        }
        None
    }

    pub fn rename_preview(&self) -> Vec<(String, String)> {
        if self.prompt != Some(Prompt::Rename) {
            return Vec::new();
        }
        self.action_paths
            .iter()
            .flatten()
            .take(4)
            .enumerate()
            .map(|(i, path)| {
                (
                    path.file_name()
                        .unwrap_or_default()
                        .to_string_lossy()
                        .into_owned(),
                    rename_path(path, &self.pane().input.text, i)
                        .file_name()
                        .unwrap_or_default()
                        .to_string_lossy()
                        .into_owned(),
                )
            })
            .collect()
    }

    pub fn edit_place(&mut self, place: Place, anchor: rune::PopupAnchor, tx: &mut Tx) {
        self.pane_mut().address.close();
        self.pane_mut().input.focused = false;
        self.place_menu = None;
        let place_uri = place.uri.clone();
        self.context = Some(Context::place(
            self.active_pane,
            anchor,
            self.tab().cwd.clone(),
            place,
        ));
        let index = self
            .favorites()
            .position(|favorite| favorite.uri == place_uri);
        let count = self.favorites().count();
        if let Some(menu) = &mut self.context {
            for item in menu.groups.iter_mut().flatten() {
                if item.key == "favorite-up" {
                    item.enabled = index.is_some_and(|index| index > 0);
                }
                if item.key == "favorite-down" {
                    item.enabled = index.is_some_and(|index| index + 1 < count);
                }
            }
            if self.selector.is_some() {
                for group in &mut menu.groups {
                    group.retain(|item| {
                        !matches!(item.action, Action::Open(PlaceOpen::Tab | PlaceOpen::Other))
                    });
                }
                menu.groups.retain(|group| !group.is_empty());
            }
        }
        tx.blur();
    }

    pub fn rename_place(&mut self, place: Place) {
        self.place_label = TextEdit::new(&place.name);
        self.place_label
            .set_selection(0, self.place_label.text.len());
        self.place_label.focused = true;
        self.place_menu = Some(place);
    }

    pub fn save_place_label(&mut self) {
        if let Some(place) = &self.place_menu {
            let label = self.place_label.text.trim();
            if label.is_empty() {
                self.message = Some("Enter a favorite label".into());
                return;
            }
            self.bookmark_queue.push_back((
                Bookmark::Rename {
                    uri: place.uri.clone(),
                    label: label.into(),
                },
                None,
            ));
            self.place_menu = None;
            self.place_label.focused = false;
        }
    }

    pub fn remove_favorite(&mut self, uri: String) {
        self.bookmark_queue.push_back((Bookmark::Remove(uri), None));
        self.place_menu = None;
    }

    pub fn move_favorite(&mut self, uri: &str, down: bool) {
        let favorites: Vec<_> = self.favorites().collect();
        let Some(index) = favorites.iter().position(|place| place.uri == uri) else {
            return;
        };
        let before = if down {
            if index + 1 >= favorites.len() {
                return;
            }
            favorites.get(index + 2).map(|place| place.uri.clone())
        } else {
            if index == 0 {
                return;
            }
            Some(favorites[index - 1].uri.clone())
        };
        self.bookmark_queue.push_back((
            Bookmark::Reorder {
                uris: vec![uri.into()],
                before,
            },
            None,
        ));
        self.place_menu = None;
    }

    fn favorite_at(&self, point: [f32; 2]) -> Option<usize> {
        let targets = self.drop_targets.borrow();
        match &targets
            .iter()
            .rev()
            .find(|target| target.contains(point))?
            .destination
        {
            crate::dnd::Destination::Favorites(before) => Some(
                before
                    .as_ref()
                    .and_then(|uri| self.favorites().position(|place| &place.uri == uri))
                    .unwrap_or_else(|| self.favorites().count()),
            ),
            _ => None,
        }
    }

    pub fn reorder_favorite(&mut self, uri: &str, drag: &mut rune::Drag, tx: &mut Tx) {
        self.peek.close();
        let scale = self.zoom_factor();
        if drag.phase == rune::Phase::Down {
            self.favorite_drag = Some(uri.into());
            drag.data = self.drop_targets.borrow().iter().rev().find(|target| matches!(&target.destination, crate::dnd::Destination::Favorites(Some(before)) if before == uri))
                .map_or(0.0, |target| target.rect[1] + (target.rect[3] * 2.0 - drag.h * scale) / 2.0)
                + drag.start_y * scale;
        } else if drag.phase == rune::Phase::Move {
            let x = self
                .drop_targets
                .borrow()
                .iter()
                .find_map(|target| {
                    matches!(&target.destination, crate::dnd::Destination::Favorites(_))
                        .then_some(target.rect[0] + target.rect[2] / 2.0)
                })
                .unwrap_or(0.0);
            self.favorite_hover = self.favorite_at([x, drag.data + drag.dy]);
            tx.instant();
        } else {
            if !drag.cancelled()
                && drag.dy.abs() > 5.0
                && let Some(index) = self.favorite_hover
            {
                let before = self.favorites().nth(index).map(|place| place.uri.clone());
                self.bookmark_queue.push_back((
                    Bookmark::Reorder {
                        uris: vec![uri.into()],
                        before,
                    },
                    None,
                ));
            }
            self.favorite_drag = None;
            self.favorite_hover = None;
        }
    }

    pub fn drag_place(&mut self, uri: &str, drag: &mut rune::Drag) {
        self.peek.close();
        if drag.phase != rune::Phase::Move || drag.data != 0.0 || drag.dx.hypot(drag.dy) < 5.0 {
            return;
        }
        if let Some(dnd) = &mut self.dnd {
            match dnd.start(vec![uri.into()], true) {
                Ok(true) => drag.data = 1.0,
                Ok(false) => {}
                Err(error) => {
                    self.message = Some(error);
                    drag.data = 1.0;
                }
            }
        }
    }

    pub fn open_place(&mut self, place: &Place, target: PlaceOpen, tx: &mut Tx) {
        self.place_menu = None;
        self.place_label.focused = false;
        if place.uri.starts_with("trash:") {
            self.command("trash", tx);
            return;
        }
        if self.preview_expanded {
            self.toggle_preview(tx);
        }
        let side = match target {
            PlaceOpen::Current => self.active_pane,
            PlaceOpen::Other => {
                if !self.split {
                    self.toggle_split(tx);
                }
                1 - self.active_pane
            }
            PlaceOpen::Tab => {
                self.command("tab_create", tx);
                self.active_pane
            }
        };
        if !place.mounted && place.volume.is_some() {
            if self.mounts.busy() {
                self.message = Some("A device operation is already running".into());
                return;
            }
            self.mount_intent = Some((side, true, false));
            self.mount_action(mounts::Action::Mount(place.clone()));
        } else if let Ok(path) = locations::local_uri(&place.uri) {
            self.panel = None;
            self.cd(side, path, tx, true);
        } else {
            if self.mounts.busy() {
                self.message = Some("A device operation is already running".into());
                return;
            }
            self.mount_intent = Some((side, true, false));
            self.mount_action(mounts::Action::Connect(place.uri.clone()));
        }
        tx.blur();
    }

    pub fn mount_action(&mut self, action: mounts::Action) {
        match self.mounts.push(action) {
            Ok(()) => {
                self.mount_intent
                    .get_or_insert((self.active_pane, true, false));
            }
            Err(error) => {
                self.message = Some(error);
            }
        }
    }

    pub fn authenticate(&mut self, anonymous: bool) {
        if let Some(mut auth) = self.authentication.take() {
            let reply = mounts::Credentials {
                user: std::mem::take(&mut auth.user.text),
                password: std::mem::take(&mut auth.password.text).into(),
                domain: std::mem::take(&mut auth.domain.text),
                anonymous,
            };
            let _ = auth.reply.send(Some(reply));
        }
    }

    pub fn cancel_mount(&mut self) {
        self.mounts.cancel();
        self.mount_intent = None;
        self.authentication = None;
        self.question = None;
    }

    pub fn answer_conflict(&mut self, choice: Choice, all: bool) {
        let checked = std::mem::take(&mut self.conflict_all);
        let all = all || checked;
        self.queue.answer(choice, all);
    }

    pub fn open_application(&mut self) {
        if self.chooser.busy {
            return;
        }
        let Some(applications) = self.applications.clone() else {
            return;
        };
        let custom = self.chooser.custom.clone();
        let selected = self
            .chooser
            .selection(&applications)
            .map(|app| app.id.clone());
        if custom.is_none() && selected.is_none() {
            return;
        }
        self.chooser.error = None;
        if self.headless {
            self.panel = None;
            self.message = Some(format!(
                "Open with: {}",
                custom.map_or_else(
                    || selected.unwrap_or_default(),
                    |path| path.display().to_string()
                )
            ));
        } else {
            self.chooser.busy = true;
            let default = self.chooser.always && applications.paths.len() == 1;
            self.chooser_worker.request(
                (applications, custom, selected, default),
                |(apps, custom, selected, default)| {
                    if let Some(program) = custom {
                        locations::launch_custom(apps.paths, program)
                    } else {
                        locations::launch(apps, selected.expect("application selection"), default)
                    }
                },
            );
        }
    }

    pub fn browse_application(&mut self, tx: &mut Tx) {
        if self.chooser.busy || self.applications.is_none() {
            return;
        }
        self.chooser.busy = true;
        tx.open_file(
            rune::FileDialogOptions {
                title: "Choose an application".into(),
                directory: Some(if Path::new("/run/current-system/sw/bin").is_dir() {
                    PathBuf::from("/run/current-system/sw/bin")
                } else {
                    PathBuf::from("/usr/bin")
                }),
                ..Default::default()
            },
            |s: &mut State, result, _| {
                s.chooser.busy = false;
                match result {
                    Ok(Some(path)) => {
                        s.chooser.custom = Some(path);
                        s.chooser.selected = None;
                        s.chooser.always = false;
                        s.chooser.error = None;
                    }
                    Ok(None) => {}
                    Err(error) => {
                        s.chooser.error =
                            Some(format!("Could not open application picker: {error}"))
                    }
                }
            },
        );
    }

    pub fn enter(&mut self, tx: &mut Tx, open: bool) {
        let Some(file) = self.pane().file().cloned() else {
            return;
        };
        self.open_file(file, tx, open);
    }

    fn launch_desktop(&mut self, launch: locations::Launch) {
        if self.desktop_launches.is_empty() {
            self.desktop_worker
                .request(launch.clone(), locations::Launch::run);
        }
        self.desktop_launches.push_back(launch);
    }

    fn open_default(&mut self, path: &Path) {
        if self.headless {
            self.message = Some(format!("Open: {}", path.display()));
        } else {
            self.message = Some("Opening in default application…".into());
            self.launch_desktop(locations::Launch::Default(self.location_uri(path)));
        }
    }

    fn open_file(&mut self, file: File, tx: &mut Tx, open: bool) {
        if !file.directory && self.selector.is_some() {
            self.selector_hover(&file.path, tx);
            self.selector_accept(false, tx);
            return;
        }
        if file.directory {
            self.cd(self.active_pane, file.path, tx, true);
        } else if open && !self.headless {
            if self.remote_place(&file.path).is_none()
                && let Err(error) = crate::finder::record(&file.path)
            {
                self.message = Some(error);
            }
            self.open_default(&file.path);
        } else if open {
            if self.remote_place(&file.path).is_none() {
                let _ = crate::finder::record(&file.path);
            }
            self.message = Some(format!("Open: {}", file.path.display()));
        }
    }

    pub fn open_preview_link(&mut self, path: &Path, link: &str, tx: &mut Tx) {
        let target = match url::Url::from_file_path(path)
            .ok()
            .and_then(|base| base.join(link).ok())
        {
            Some(target) => target,
            None => {
                self.message = Some(format!("Could not open link: {link}"));
                return;
            }
        };
        if let Some(anchor) = target.fragment()
            && target.to_file_path().ok().as_deref() == Some(path)
            && let Preview::Markdown { source, .. } = &self.panes[self.active_pane].preview
        {
            if anchor.is_empty() {
                tx.scroll_to_y("preview", 0.0);
                return;
            }
            for (index, block) in rune_kit::markdown::parse_cached(source).iter().enumerate() {
                if let rune_kit::markdown::Block::Heading(_, inline) = block {
                    let slug: String = inline
                        .text
                        .to_lowercase()
                        .chars()
                        .filter(|c| c.is_alphanumeric() || matches!(c, ' ' | '-' | '_'))
                        .map(|c| if c == ' ' { '-' } else { c })
                        .collect();
                    if slug == anchor {
                        tx.scroll_into_view(format!("preview/markdown/b{index}"));
                        return;
                    }
                }
            }
            self.message = Some(format!("Heading not found: {anchor}"));
        } else if target.scheme() == "file" {
            match target.to_file_path() {
                Ok(path) => self.open_default(&path),
                Err(()) => self.message = Some("Could not open link: invalid file location".into()),
            }
        } else if self.headless {
            self.message = Some(format!("Open: {target}"));
        } else if let Err(error) = tx.open_url(target.as_str()) {
            self.message = Some(format!("Could not open link: {error}"));
        }
    }

    pub fn show_prompt(&mut self, prompt: Prompt, tx: &mut Tx) {
        let paths = matches!(
            prompt,
            Prompt::Rename | Prompt::Archive | Prompt::Permissions
        )
        .then(|| self.chosen());
        let source = paths.as_ref().and_then(|paths| paths.first());
        let source_is_directory = source.is_some_and(|path| {
            self.tab()
                .files
                .iter()
                .chain(self.pane().picker.iter().flat_map(|picker| &picker.files))
                .any(|file| &file.path == path && file.directory)
        });
        let source_name = source
            .and_then(|path| path.file_name())
            .map(|name| name.to_string_lossy().into_owned())
            .unwrap_or_default();
        self.pane_mut().address.close();
        self.suspend_picker(self.active_pane, tx);
        let value = match prompt {
            Prompt::Filter => self.tab().filter.clone(),
            Prompt::TabRename => self.tab().name.clone().unwrap_or_default(),
            Prompt::Rename if paths.as_ref().is_some_and(|paths| paths.len() > 1) => {
                "{name}".into()
            }
            Prompt::Rename => source_name,
            Prompt::Archive => format!(
                "{}.zip",
                source
                    .and_then(|path| path.file_stem())
                    .map(|name| name.to_string_lossy())
                    .unwrap_or("archive".into())
            ),
            Prompt::Permissions => self
                .tab()
                .file()
                .map(|file| format!("{:o}", file.mode & 0o7777))
                .unwrap_or_else(|| "644".into()),
            _ => String::new(),
        };
        self.panes[self.active_pane].input = TextEdit::new(value);
        if matches!(
            prompt,
            Prompt::Rename | Prompt::Permissions | Prompt::Archive
        ) {
            self.panes[self.active_pane]
                .input
                .set_selection(0, self.panes[self.active_pane].input.text.len());
        }
        if prompt == Prompt::Rename && paths.as_ref().is_some_and(|paths| paths.len() == 1) {
            let input = &mut self.panes[self.active_pane].input;
            let stem = if source_is_directory {
                input.text.len()
            } else {
                Path::new(&input.text)
                    .file_stem()
                    .map_or(input.text.len(), |stem| stem.as_encoded_bytes().len())
            };
            input.set_selection(0, stem);
        }
        self.action_paths = paths;
        self.panes[self.active_pane].input.focused = true;
        self.prompt = Some(prompt);
        self.pending.clear();
        tx.instant();
    }

    pub fn edit_prompt(&mut self, tx: &mut Tx) {
        if self.prompt == Some(Prompt::Filter) {
            self.tab_mut().filter = self.panes[self.active_pane].input.text.clone();
            self.reorder(self.active_pane);
            self.peek(self.active_pane);
            self.restore_cursor(self.active_pane, tx);
        }
    }

    pub fn submit_prompt(&mut self, tx: &mut Tx) {
        let value = self.panes[self.active_pane].input.text.clone();
        if let Some(error) = self.name_error() {
            self.message = Some(error.into());
            return;
        }
        let prompt = self.prompt.take();
        match prompt {
            Some(Prompt::Filter) => {
                self.tab_mut().filter = value;
                self.reorder(self.active_pane);
                self.peek(self.active_pane);
                self.restore_cursor(self.active_pane, tx);
            }
            Some(Prompt::Connect) => match locations::Location::parse(&value, &self.tab().cwd) {
                Ok(location) => self.reveal_location(location, true, false, tx),
                Err(error) => self.message = Some(error),
            },
            Some(Prompt::TabRename) => self.tab_mut().name = (!value.is_empty()).then_some(value),
            Some(Prompt::Create | Prompt::CreateFolder) => {
                let path = self.tab().cwd.join(&value);
                self.enqueue_select(
                    Operation::Create {
                        path: path.clone(),
                        directory: prompt == Some(Prompt::CreateFolder),
                    },
                    vec![path],
                );
            }
            Some(Prompt::Rename) => {
                let pairs: Vec<_> = self
                    .chosen()
                    .iter()
                    .enumerate()
                    .map(|(index, source)| (source.clone(), rename_path(source, &value, index)))
                    .collect();
                let mut targets: Vec<_> = pairs.iter().map(|(_, target)| target.clone()).collect();
                if let Some(index) = pairs.iter().position(|(source, _)| {
                    self.tab().file().is_some_and(|file| &file.path == source)
                }) {
                    targets.swap(0, index);
                }
                self.enqueue_select(Operation::Rename(pairs), targets);
            }
            Some(Prompt::Permissions) => {
                let mut words = value.split_whitespace();
                let mode = words.next().unwrap_or_default().trim_start_matches("0o");
                match u32::from_str_radix(mode, 8) {
                    Ok(mode) if mode <= 0o7777 => {
                        let recursive =
                            words.any(|word| matches!(word, "-r" | "-R" | "--recursive"));
                        let sources = self.chosen();
                        self.enqueue(
                            Operation::Permissions {
                                sources,
                                mode,
                                recursive,
                            },
                            false,
                        );
                    }
                    _ => {
                        self.message =
                            Some("Enter an octal permission mode, such as 644 or 755".into())
                    }
                }
            }
            Some(Prompt::Archive) => {
                let sources = self.chosen();
                if !sources.is_empty() && !value.trim().is_empty() {
                    let destination = self.tab().cwd.join(&value);
                    self.enqueue(
                        Operation::Archive {
                            sources,
                            destination,
                        },
                        false,
                    );
                }
            }
            _ => {}
        }
        self.action_paths = None;
        tx.blur();
    }

    pub fn chosen(&mut self) -> Vec<PathBuf> {
        if let Some(paths) = &self.action_paths {
            return paths.clone();
        }
        if let Some(picker) = &self.panes[self.active_pane].picker {
            return if picker.loading {
                Vec::new()
            } else if picker.selected.is_empty() {
                picker
                    .file()
                    .map(|file| vec![file.path.clone()])
                    .unwrap_or_default()
            } else {
                picker.selected.iter().cloned().collect()
            };
        }
        self.tab_mut().finish_visual();
        if self.tab().selected.is_empty() {
            self.tab()
                .file()
                .map(|file| vec![file.path.clone()])
                .unwrap_or_default()
        } else {
            self.tab().selected.iter().cloned().collect()
        }
    }

    pub fn paste_to(&mut self, destination: PathBuf, force: bool, tx: &mut Tx) {
        if self.headless {
            if let Some(files) = self.yank.clone() {
                self.paste_files(files, destination, force);
            } else {
                self.message = Some("The clipboard contains no files".into());
            }
        } else if std::env::var_os("WAYLAND_DISPLAY").is_some() {
            self.clipboard.paste(destination, force);
        } else {
            tx.read_clipboard(move |s: &mut State, content, _| {
                let paths = content.files().to_vec();
                let cut = s.yank.as_ref().is_some_and(|y| y.cut && y.paths == paths);
                s.paste_files(Yank { paths, cut }, destination, force);
            });
        }
    }

    fn paste_files(&mut self, files: Yank, destination: PathBuf, force: bool) {
        if files.paths.is_empty() {
            self.message = Some("The clipboard contains no files".into());
            return;
        }
        self.yank = Some(files.clone());
        let sources = files.paths;
        let operation = if files.cut {
            Operation::Move {
                sources,
                destination,
            }
        } else {
            Operation::Copy {
                sources,
                destination,
            }
        };
        self.enqueue(operation, force);
    }

    fn selected_trash(&self) -> Vec<String> {
        if self.trash_selected.is_empty() {
            self.trash
                .as_ref()
                .and_then(|entries| entries.get(self.trash_cursor))
                .map(|entry| vec![entry.uri.clone()])
                .unwrap_or_default()
        } else {
            self.trash_selected.iter().cloned().collect()
        }
    }

    fn enqueue_select(&mut self, operation: Operation, paths: Vec<PathBuf>) {
        let previous = self.queue.tasks.len();
        self.enqueue(operation, false);
        if self.queue.tasks.len() > previous
            && let Some(task) = self.queue.tasks.last()
        {
            let id = task.id;
            let paths: Vec<_> = paths
                .into_iter()
                .filter(|path| path.parent() == Some(&self.tab().cwd))
                .collect();
            if !paths.is_empty() {
                self.tab_mut().select_after = Some((id, paths));
            }
        }
    }

    pub fn enqueue(&mut self, operation: Operation, force: bool) {
        self.message = Some(format!("Queued: {}", operation.title()));
        self.queue.remote_roots = self
            .places
            .iter()
            .filter_map(|place| {
                if place.uri.starts_with("file:") || place.uri.starts_with("trash:") {
                    return None;
                }
                place.path.clone().map(|path| operations::RemoteRoot {
                    path,
                    uri: place.uri.clone(),
                })
            })
            .collect();
        self.queue.push(operation, force);
        self.tab_mut().selected.clear();
    }

    fn request_drop_preference(
        &mut self,
        token: u32,
        paths: Vec<PathBuf>,
        destination: PathBuf,
        local: bool,
    ) {
        if !local {
            self.drop_preference.cancel();
            if let Some(dnd) = &mut self.dnd {
                dnd.prefer(token, 4);
            }
            return;
        }
        if self.remote_place(&destination).is_some()
            || paths.iter().any(|path| self.remote_place(path).is_some())
        {
            self.drop_preference.cancel();
            let moving = self.remote_place(&destination).is_some_and(|target| {
                paths.iter().all(|path| {
                    self.remote_place(path)
                        .is_some_and(|source| source.uri == target.uri)
                })
            });
            if let Some(dnd) = &mut self.dnd {
                dnd.prefer(token, if moving { 2 } else { 1 });
            }
            return;
        }
        self.drop_preference.request(
            (token, paths, destination),
            |(token, paths, destination)| (token, crate::dnd::preferred(&paths, &destination)),
        );
    }

    fn drop_destination(&self, point: [f32; 2]) -> PathBuf {
        self.drop_targets
            .borrow()
            .iter()
            .rev()
            .find(|target| target.contains(point))
            .and_then(|target| match &target.destination {
                crate::dnd::Destination::Folder(path) => Some(path.clone()),
                _ => None,
            })
            .unwrap_or_else(|| self.tab().cwd.clone())
    }

    pub fn drag_file(&mut self, path: &Path, directory: bool, drag: &mut rune::Drag) {
        self.peek.close();
        if drag.phase != rune::Phase::Move || drag.data != 0.0 || drag.dx.hypot(drag.dy) < 5.0 {
            return;
        }
        if self.panes[self.active_pane]
            .picker
            .as_ref()
            .is_some_and(|picker| picker.loading)
        {
            return;
        }
        let selected = self.panes[self.active_pane]
            .picker
            .as_ref()
            .map_or(&self.tab().selected, |picker| &picker.selected);
        let paths = if selected.contains(path) {
            self.chosen()
        } else {
            vec![path.to_path_buf()]
        };
        let uris = paths.iter().map(|path| self.location_uri(path)).collect();
        if let Some(dnd) = &mut self.dnd {
            match dnd.start(uris, directory) {
                Ok(true) => drag.data = 1.0,
                Ok(false) => {}
                Err(error) => {
                    self.message = Some(error);
                    drag.data = 1.0;
                }
            }
        }
    }

    pub fn accept_drop(&mut self, drop: crate::dnd::Drop, action: u32) {
        let operation = match action {
            1 => Operation::Copy {
                sources: drop.paths,
                destination: drop.destination,
            },
            2 => Operation::Move {
                sources: drop.paths,
                destination: drop.destination,
            },
            8 => Operation::Link {
                sources: drop.paths,
                destination: drop.destination,
                relative: false,
                hard: false,
            },
            _ => {
                self.cancel_drop(drop.token);
                return;
            }
        };
        let previous = self.queue.tasks.len();
        self.enqueue(operation, false);
        if self.queue.tasks.len() > previous {
            if let Some(task) = self.queue.tasks.last()
                && let Some(dnd) = &mut self.dnd
            {
                let acknowledged = if drop.action == 4 {
                    if action == 8 { 1 } else { action }
                } else if drop.action == 2 && action != 2 {
                    // A MOVE acknowledgement can make an external source delete its files.
                    // Cancelling the offer after our copy/link preserves those source files.
                    0
                } else if drop.action == 8 {
                    1
                } else {
                    drop.action
                };
                dnd.track(task.id, drop.token, acknowledged);
            }
        } else {
            self.cancel_drop(drop.token);
            self.message = Some("Could not queue the dropped files".into());
        }
    }

    pub fn cancel_drop(&mut self, token: u32) {
        if let Some(dnd) = &mut self.dnd {
            dnd.cancel(token);
        }
    }

    pub fn close(&mut self, tx: &mut Tx) {
        if self.closing {
            return;
        }
        self.closing = true;
        self.session_error = None;
        if self.panes[self.active_pane].picker.is_some() {
            self.close_picker(self.active_pane, tx);
        }
        for pane in &mut self.panes {
            for tab in &mut pane.tabs {
                tab.finish_visual();
            }
        }
        if let Some(path) = self.session_path.clone() {
            self.session_saving = true;
            self.session_worker
                .request((Session::capture(self), path), |(session, path)| {
                    session.save(path)
                });
        }
        for pane in &mut self.panes {
            pane.suspend();
        }
        self.queue.cancel_all();
        use gio::prelude::CancellableExt;
        self.print_io.cancel();
        if let Some(thumbnails) = &mut self.thumbnails {
            thumbnails.cancel();
        }
        self.cancel_mount();
        if self.queue.active().is_none()
            && self.desktop_launches.is_empty()
            && !self.mounts.busy()
            && !self.favorites_saving()
            && !self.views.saving()
            && !self.appearance.saving()
            && !self.session_saving
        {
            self.dnd = None;
            tx.quit();
        } else {
            self.message = Some("Saving workspace and cancelling operations…".into());
            tx.wake_after(Duration::from_millis(60));
        }
    }

    pub fn command(&mut self, command: &str, tx: &mut Tx) {
        self.tab_menu = None;
        self.peek.close();
        let mut words = command.split_whitespace();
        let action = words.next().unwrap_or_default();
        let arg = words.next().unwrap_or_default();
        if action == "settings" {
            self.appearance.open = true;
            self.appearance.page_dark = arg != "light";
            self.appearance.fonts_open = arg == "fonts";
            self.context = None;
            self.pending.clear();
            self.pane_mut().address.close();
            return;
        }
        if self.selector.is_some() {
            match action {
                "picker_accept" => {
                    self.selector_accept(false, tx);
                    return;
                }
                "picker_replace" => {
                    self.selector_accept(true, tx);
                    return;
                }
                "picker_cancel" | "quit" | "close" => {
                    self.close(tx);
                    return;
                }
                "picker_filter" => {
                    self.selector_filter(arg.parse().unwrap_or_default());
                    return;
                }
                "escape" if self.prompt.is_some() => {}
                "create" if command.contains("--dir") => {}
                "arrow" | "enter" | "open" | "leave" | "back" | "forward" | "cd" | "hidden"
                | "toggle" | "toggle_all" | "sort" | "sort_dir_first" | "folder_view"
                | "find_files" | "finder_refresh" | "connect" => {}
                _ => return,
            }
        }
        if matches!(
            action,
            "tab_create"
                | "tab_switch"
                | "tab_swap"
                | "close"
                | "tab_close"
                | "places"
                | "trash"
                | "refresh_trash"
                | "spot"
                | "help"
                | "open_with"
        ) {
            self.pane_mut().address.close();
            self.suspend_picker(self.active_pane, tx);
        }
        match action {
            "split" => self.toggle_split(tx),
            "pane_switch" => {
                let side = arg.parse().unwrap_or(1 - self.active_pane);
                self.activate_pane(side, tx);
            }
            "copy_to_other" => self.transfer(false),
            "move_to_other" => self.transfer(true),
            "sidebar_toggle" => self.sidebar_hidden = !self.sidebar_hidden,
            "preview_expand" => self.toggle_preview(tx),
            "yank" => {
                let paths = self.chosen();
                if !paths.is_empty() {
                    let cut = command.contains("--cut");
                    self.message = Some(format!(
                        "{} {} item(s)",
                        if cut { "Cut" } else { "Copied" },
                        paths.len()
                    ));
                    let files = Yank { paths, cut };
                    if !self.headless {
                        if std::env::var_os("WAYLAND_DISPLAY").is_some() {
                            self.clipboard.write(&files);
                        } else {
                            tx.copy_rich(
                                rune::ClipboardContent::default().with_files(files.paths.clone()),
                            );
                        }
                    }
                    self.yank = Some(files);
                }
            }
            "unyank" => {
                self.yank = None;
                self.message = Some("File clipboard cleared".into());
            }
            "paste" => self.paste_to(self.tab().cwd.clone(), command.contains("--force"), tx),
            "link" | "hardlink" => {
                if let Some(yank) = &self.yank {
                    let sources = yank.paths.clone();
                    if !sources.is_empty() {
                        self.enqueue(
                            Operation::Link {
                                sources,
                                destination: self.tab().cwd.clone(),
                                relative: command.contains("--relative"),
                                hard: action == "hardlink",
                            },
                            false,
                        );
                    }
                } else {
                    self.message = Some("Copy files to the clipboard first".into());
                }
            }
            "remove" => {
                let sources = self.chosen();
                if !sources.is_empty() {
                    self.confirmation = Some(if command.contains("--permanently") {
                        Operation::Delete(sources)
                    } else {
                        Operation::Trash(sources)
                    });
                }
            }
            "create" => self.show_prompt(
                if command.contains("--dir") {
                    Prompt::CreateFolder
                } else {
                    Prompt::Create
                },
                tx,
            ),
            "rename" => {
                if self
                    .action_paths
                    .as_ref()
                    .is_some_and(|paths| !paths.is_empty())
                    || self.pane().file().is_some()
                {
                    self.show_prompt(Prompt::Rename, tx);
                }
            }
            "permissions" => {
                if self
                    .action_paths
                    .as_ref()
                    .is_some_and(|paths| !paths.is_empty())
                    || self.pane().file().is_some()
                {
                    self.show_prompt(Prompt::Permissions, tx);
                }
            }
            "archive" => {
                if self
                    .action_paths
                    .as_ref()
                    .is_some_and(|paths| !paths.is_empty())
                    || self.pane().file().is_some()
                {
                    self.show_prompt(Prompt::Archive, tx);
                }
            }
            "extract" => {
                if let Some(file) = self.tab().file() {
                    let source = file.path.clone();
                    let destination = self.tab().cwd.join(crate::archive::stem(&source));
                    self.enqueue(
                        Operation::Extract {
                            source,
                            destination,
                        },
                        false,
                    );
                }
            }
            "undo" => {
                self.message = Some(match self.queue.undo() {
                    Ok(()) => "Queued: Undo".into(),
                    Err(error) => error,
                });
            }
            "tasks:show" => self.tasks_open = !self.tasks_open,
            "task_retry" => {
                self.message = Some(match arg.parse() {
                    Ok(id) => match self.queue.retry(id) {
                        Ok(()) => "Queued failed items for retry".into(),
                        Err(error) => error,
                    },
                    Err(_) => "Choose a failed transfer to retry".into(),
                });
            }
            "task_cancel" => {
                let id = if arg.is_empty() {
                    self.queue.active().map(|task| task.id)
                } else {
                    arg.parse().ok()
                };
                if let Some(id) = id {
                    self.queue.cancel(id);
                }
            }
            "restore" if self.panel == Some(Panel::Trash) => {
                let uris = self.selected_trash();
                self.enqueue(Operation::Restore(uris), false);
            }
            "trash_select" => {
                if let Some(entries) = &self.trash {
                    let selected: Vec<_> = if command.contains("--all") {
                        entries.iter().map(|entry| entry.uri.clone()).collect()
                    } else {
                        entries
                            .get(self.trash_cursor)
                            .map(|entry| vec![entry.uri.clone()])
                            .unwrap_or_default()
                    };
                    for uri in selected {
                        if !self.trash_selected.remove(&uri) {
                            self.trash_selected.insert(uri);
                        }
                    }
                }
            }
            "trash_delete" | "trash_empty" => {
                let selected = self.selected_trash();
                if let Some(entries) = &self.trash {
                    let uris: Vec<_> = entries
                        .iter()
                        .filter(|entry| action == "trash_empty" || selected.contains(&entry.uri))
                        .map(|entry| entry.uri.clone())
                        .collect();
                    if !uris.is_empty() {
                        self.confirmation = Some(Operation::DeleteTrash(uris));
                    }
                }
            }
            "trash" | "refresh_trash" => {
                self.panel = Some(Panel::Trash);
                self.trash = None;
                self.trash_worker.request((), |_| crate::trash::read());
            }
            "restore" => self.message = Some("Open Trash and select the items to restore".into()),
            "quit" => {
                if command.contains("--no-session") {
                    self.session_path = None;
                }
                if !command.contains("--no-cwd-file")
                    && let Some(path) = &self.cwd_file
                    && let Err(e) = fs::write(path, self.tab().cwd.as_os_str().as_encoded_bytes())
                {
                    self.message = Some(format!("Could not save cwd: {e}"));
                    return;
                }
                self.close(tx);
            }
            "close" | "tab_close" => {
                if self.panes[self.active_pane].tabs.len() == 1 && self.split {
                    self.activate_pane(1 - self.active_pane, tx);
                    self.toggle_split(tx);
                } else if self.panes[self.active_pane].tabs.len() == 1 {
                    self.command("quit", tx);
                } else {
                    self.panes[self.active_pane]
                        .tabs
                        .remove(self.panes[self.active_pane].active);
                    self.panes[self.active_pane].active = self.panes[self.active_pane]
                        .active
                        .min(self.panes[self.active_pane].tabs.len() - 1);
                    tx.scroll_to_instant(
                        Pane::list_key(self.active_pane),
                        0.0,
                        self.tab().scroll.get(),
                    );
                    self.reload(self.active_pane);
                }
            }
            "escape" => {
                if self.panel.take().is_some() {
                } else if self.help {
                    self.help = false;
                } else if self.spot {
                    self.close_properties(tx);
                } else if self.prompt.take().is_some() {
                    self.action_paths = None;
                    tx.blur();
                } else if self.tab().visual.is_some() {
                    self.tab_mut().finish_visual();
                } else if !self.tab().selected.is_empty() {
                    self.tab_mut().selected.clear();
                } else if !self.tab().filter.is_empty() {
                    self.tab_mut().filter.clear();
                    self.reorder(self.active_pane);
                    self.peek(self.active_pane);
                }
                self.message = None;
                self.pending.clear();
            }
            "arrow" => self.arrow(arg, tx),
            "leave" if self.remote_root(&self.tab().cwd) => self.command("places", tx),
            "leave" => {
                if let Some(parent) = self.tab().cwd.parent().map(PathBuf::from) {
                    let path = self.tab().cwd.clone();
                    self.tab_mut().hovered.insert(parent.clone(), path);
                    self.cd(self.active_pane, parent, tx, true);
                }
            }
            "enter" => self.enter(tx, false),
            "open" if command.contains("--interactive") => self.command("open_with", tx),
            "open_with" if !arg.is_empty() => {
                let paths = self.chosen();
                let id = arg.to_owned();
                let default = command.contains("--default");
                if self.headless {
                    self.message = Some(format!("Open with: {id}"));
                } else {
                    let uri = paths.first().and_then(|path| {
                        self.remote_io(path)
                            .map(|root| file::remote_uri(&root, path).uri().to_string())
                    });
                    self.launch_desktop(locations::Launch::Application {
                        paths,
                        uri,
                        id,
                        default,
                    });
                }
            }
            "open_with" => {
                let paths = self.chosen();
                if !paths.is_empty() && !self.chooser.busy {
                    self.panel = Some(Panel::Applications);
                    self.chooser = crate::chooser::Chooser::default();
                    self.message = None;
                    self.applications = None;
                    let uri = paths.first().and_then(|path| {
                        self.remote_io(path)
                            .map(|root| file::remote_uri(&root, path).uri().to_string())
                    });
                    let cache = self.cache.clone();
                    self.applications_worker
                        .request((paths, uri, cache), |(paths, uri, cache)| {
                            let mut applications = locations::applications(paths, uri)?;
                            if let Some(cache) = cache {
                                applications.load_icons(&cache);
                            }
                            Ok(applications)
                        });
                }
            }
            "finder_refresh" => {
                self.restart_picker(self.active_pane);
                self.peek(self.active_pane);
            }
            "find_files" => {
                self.show_picker(tx);
                if command.contains("--recursive") {
                    self.picker_scope(true);
                }
                if command.contains("--content") {
                    self.picker_mode(true);
                }
            }
            "browse_application" => self.browse_application(tx),
            "connect" if !arg.is_empty() => {
                match locations::Location::parse(
                    command.strip_prefix("connect ").unwrap_or(arg),
                    &self.tab().cwd,
                ) {
                    Ok(location) => self.reveal_location(location, true, false, tx),
                    Err(error) => self.message = Some(error),
                }
            }
            "connect" => self.show_prompt(Prompt::Connect, tx),
            "mount_cancel" => self.cancel_mount(),
            "places" => {
                self.panel = Some(Panel::Places);
                self.mounts.refresh_places();
            }
            "bookmark" => self.pin_current(),
            "favorite_pin_selection" => self.pin_folders(),
            "refresh_places" => {
                self.mounts.refresh_places();
            }
            "open" => self.enter(tx, true),
            "back" | "forward" => {
                let tab = self.tab_mut();
                let next = if action == "back" {
                    tab.history_cursor.saturating_sub(1)
                } else {
                    (tab.history_cursor + 1).min(tab.history.len() - 1)
                };
                if next != tab.history_cursor {
                    tab.history_cursor = next;
                    let path = tab.history[next].clone();
                    self.cd(self.active_pane, path, tx, false);
                }
            }
            "toggle" => {
                self.tab_mut().finish_visual();
                if let Some(path) = self.tab().file().map(|f| f.path.clone())
                    && !self.tab_mut().selected.remove(&path)
                {
                    self.tab_mut().selected.insert(path);
                }
            }
            "toggle_all" => {
                self.tab_mut().finish_visual();
                let files: Vec<_> = self
                    .tab()
                    .visible
                    .iter()
                    .map(|&i| self.tab().files[i].path.clone())
                    .collect();
                for path in files {
                    let select =
                        command.contains("--state=on") || !self.tab().selected.contains(&path);
                    if select {
                        self.tab_mut().selected.insert(path);
                    } else {
                        self.tab_mut().selected.remove(&path);
                    }
                }
            }
            "visual_mode" => {
                self.tab_mut().finish_visual();
                let cursor = self.tab().cursor;
                self.tab_mut().visual = Some(Visual {
                    start: cursor,
                    wraps: 0,
                    unset: command.contains("--unset"),
                });
            }
            "folder_view" => {
                self.view_options = Some(FolderMenu::Sort);
                self.pending.clear();
                tx.blur();
            }
            "view_options" => {
                self.view_options = Some(FolderMenu::View);
                self.pending.clear();
                tx.blur();
            }
            "view" => {
                let Some(mode) = ViewMode::ALL.into_iter().find(|mode| mode.key() == arg) else {
                    return;
                };
                let mut preference = self.tab().preference;
                preference.view_mode = mode;
                self.set_folder_view(Some(preference), tx);
                self.view_options = None;
                tx.blur();
            }
            "view_reset" => self.set_folder_view(None, tx),
            "hidden" | "sort_reverse" | "sort_dir_first" => {
                let mut preference = self.tab().preference;
                match action {
                    "hidden" => preference.show_hidden = !preference.show_hidden,
                    "sort_reverse" => preference.sort_reverse = !preference.sort_reverse,
                    "sort_dir_first" => preference.sort_dir_first = !preference.sort_dir_first,
                    _ => unreachable!(),
                }
                self.set_folder_view(Some(preference), tx);
            }
            "filter" => self.show_prompt(Prompt::Filter, tx),
            "cd" if command.contains("--interactive") => self.edit_location(self.active_pane, tx),
            "cd" => {
                let value = command.trim_start_matches("cd").trim();
                match locations::Location::parse(value, &self.tab().cwd) {
                    Ok(locations::Location::Path(path)) => {
                        self.cd(self.active_pane, path, tx, true)
                    }
                    Ok(location) => self.reveal_location(location, true, false, tx),
                    Err(error) => self.message = Some(error),
                }
            }
            "new_window" => {
                if let Err(error) = crate::desktop::spawn_window(
                    self.location_uri(&self.tab().cwd),
                    true,
                    false,
                    self.config_dir.as_deref(),
                ) {
                    self.message = Some(error.to_string());
                }
            }
            "tab_create" => {
                let path = self.tab().cwd.clone();
                let preference = self.views.get(&self.location_uri(&path));
                self.panes[self.active_pane]
                    .tabs
                    .push(Tab::new(path, preference));
                self.panes[self.active_pane].active = self.panes[self.active_pane].tabs.len() - 1;
                tx.scroll_to_instant(
                    Pane::list_key(self.active_pane),
                    0.0,
                    self.tab().scroll.get(),
                );
                self.reload(self.active_pane);
            }
            "tab_switch" | "tab_swap" => {
                let index: isize = arg.parse().unwrap_or(0);
                let next = if command.contains("--relative") || action == "tab_swap" {
                    (self.panes[self.active_pane].active as isize + index)
                        .rem_euclid(self.panes[self.active_pane].tabs.len() as isize)
                        as usize
                } else {
                    index.max(0) as usize
                };
                if next < self.panes[self.active_pane].tabs.len()
                    && next != self.panes[self.active_pane].active
                {
                    if action == "tab_swap" {
                        self.panes[self.active_pane]
                            .tabs
                            .swap(self.panes[self.active_pane].active, next);
                    }
                    self.panes[self.active_pane].active = next;
                    tx.scroll_to_instant(
                        Pane::list_key(self.active_pane),
                        0.0,
                        self.tab().scroll.get(),
                    );
                    self.reload(self.active_pane);
                }
            }
            "tab_rename" => self.show_prompt(Prompt::TabRename, tx),
            "sort" => {
                if let Some(by) = parse_sort(arg) {
                    let mut preference = self.tab().preference;
                    preference.sort_by = by;
                    preference.sort_reverse = command.contains("--reverse=yes");
                    self.set_folder_view(Some(preference), tx);
                } else {
                    self.message = Some(format!("Sort not available yet: {arg}"));
                }
            }
            "linemode" if arg == "none" || arg == "size" || arg == "mtime" => {}
            "preview_render" => {
                let render = match arg {
                    "source" => false,
                    "render" => true,
                    _ => {
                        matches!(&self.panes[self.active_pane].preview, Preview::Html(html) if matches!(html.view, crate::html::View::Source))
                    }
                };
                self.render_html(render, tx);
            }
            "seek" if matches!(self.panes[self.active_pane].preview, Preview::Pdf(_)) => {
                self.seek_pdf(arg.parse::<i32>().unwrap_or(0).signum());
            }
            "seek" => {
                let pos = self.panes[self.active_pane].preview_scroll.get();
                let y = (pos[0]
                    + arg.parse::<f32>().unwrap_or(0.0) * self.appearance.metrics().code_height())
                .clamp(0.0, pos[1]);
                tx.scroll_to_y("preview", y);
            }
            "help" => self.help = !self.help,
            "spot" => {
                self.property_target = None;
                self.spot = !self.spot;
                if self.spot {
                    self.property_focus = Some(
                        tx.focused()
                            .filter(|key| !self.tab().files.iter().any(|file| file.key == *key))
                            .unwrap_or(Pane::list_key(self.active_pane))
                            .into(),
                    );
                    self.load_properties();
                } else {
                    self.close_properties(tx);
                }
            }
            "copy" => {
                if let Some(file) = self.tab().file() {
                    let value = match arg {
                        "filename" => file.name.clone(),
                        "name_without_ext" => file
                            .path
                            .file_stem()
                            .unwrap_or_default()
                            .to_string_lossy()
                            .into_owned(),
                        "dirpath" => self.tab().cwd.to_string_lossy().into_owned(),
                        "path" => file.path.to_string_lossy().into_owned(),
                        _ => {
                            self.message = Some(format!("Copy not available yet: {arg}"));
                            return;
                        }
                    };
                    tx.copy(&value);
                    self.message = Some(format!("Copied {value}"));
                }
            }
            _ => self.message = Some(format!("Not available yet: {command}")),
        }
    }

    pub fn zoom_factor(&self) -> f32 {
        self.zoom as f32 / 100.
    }

    fn zoom_key(&mut self, event: &KeyEvent, tx: &mut Tx) -> bool {
        if !event.mods.ctrl || !event.mods.shift {
            return false;
        }
        let key = match &event.key {
            rune::Key::Command(key) => *key,
            rune::Key::Text(text) if text.len() == 1 => text.as_bytes()[0] as char,
            _ => return false,
        };
        let next = match key {
            '+' | '=' => self.zoom.saturating_add(10).min(200),
            '-' | '_' => self.zoom.saturating_sub(10).max(50),
            '0' | ')' => 100,
            _ => return false,
        };
        if next != self.zoom {
            self.zoom = next;
            self.tab_menu = None;
            self.peek.close();
            self.context = None;
            tx.instant();
        }
        true
    }

    fn place_menu_key(&mut self, key: &str, tx: &mut Tx) -> Option<bool> {
        self.place_menu.as_ref()?;
        Some(match key {
            "<Esc>" | "<C-[>" => {
                self.place_menu = None;
                self.place_label.focused = false;
                tx.blur();
                true
            }
            "<Enter>" => {
                self.save_place_label();
                tx.blur();
                true
            }
            _ => false,
        })
    }

    fn context_key(&mut self, key: &str, tx: &mut Tx) -> Option<bool> {
        self.context.as_ref()?;
        if matches!(key, "<Esc>" | "<C-[>") {
            self.context = None;
            return Some(true);
        }
        if keymap::desktop_key(key) || key == "<C-z>" {
            let binding = self
                .bindings
                .iter()
                .find(|binding| binding.on.list() == [key]);
            let command = binding
                .and_then(|binding| {
                    (binding.run.list().len() == 1).then(|| binding.run.list()[0].as_str())
                })
                .or_else(|| (key == "<C-z>").then_some("undo"));
            let action = command.and_then(|command| {
                self.context
                    .as_ref()
                    .unwrap()
                    .groups
                    .iter()
                    .flatten()
                    .find(|item| {
                        item.enabled
                            && match item.action {
                                Action::Command(value) => value == command,
                                Action::Paste => command == "paste",
                                _ => false,
                            }
                    })
                    .map(|item| item.key)
            });
            if let Some(action) = action {
                self.context_action(action, tx);
                return Some(true);
            }
        }
        Some(false)
    }

    pub fn key(&mut self, event: &KeyEvent, tx: &mut Tx) -> bool {
        if self.zoom_key(event, tx) {
            return true;
        }
        if self.spot {
            if matches!(event.key, rune::Key::Escape) {
                self.close_properties(tx);
                return true;
            }
            return false;
        }
        if self.peek.target.is_some() && matches!(event.key, rune::Key::Escape) {
            self.peek.close();
            return true;
        }
        if self.appearance.open {
            if matches!(event.key, rune::Key::Escape) {
                self.appearance.open = false;
                tx.blur();
                return true;
            }
            return false;
        }
        if keymap::key_name(event).as_deref() == Some("<C-,>") {
            self.command("settings", tx);
            return true;
        }
        if self.selector.is_some() {
            return self.selector_key(event, tx);
        }
        let Some(key) = keymap::key_name(event) else {
            return false;
        };
        if self.session_error.is_some() {
            if matches!(key.as_str(), "<Esc>" | "<C-[>") {
                self.session_error = None;
                tx.blur();
                return true;
            }
            return false;
        }
        if self.view_options.is_some() {
            if matches!(key.as_str(), "<Esc>" | "<C-[>") {
                self.view_options = None;
                tx.blur();
                return true;
            }
            return false;
        }
        if let Some(handled) = self.place_menu_key(&key, tx) {
            return handled;
        }
        if self.panel == Some(Panel::Applications) {
            if self.chooser.busy {
                return true;
            }
            match key.as_str() {
                "<Esc>" | "<C-[>" => {
                    self.panel = None;
                    self.chooser.query.focused = false;
                    tx.blur();
                    return true;
                }
                "<Down>" | "<Up>" => {
                    if let Some(applications) = &self.applications {
                        let visible = self.chooser.visible(applications);
                        let current = visible
                            .iter()
                            .position(|app| Some(&app.id) == self.chooser.selected.as_ref());
                        let next = match (current, key.as_str()) {
                            (Some(index), "<Down>") => {
                                (index + 1).min(visible.len().saturating_sub(1))
                            }
                            (Some(index), _) => index.saturating_sub(1),
                            _ => 0,
                        };
                        if let Some(app) = visible.get(next) {
                            let id = app.id.clone();
                            self.chooser.select(id.clone());
                            tx.scroll_into_view_in("application-list", format!("application-{id}"));
                        }
                    }
                    return true;
                }
                _ => return false,
            }
        }
        if self.drop_decision.is_some() {
            match key.as_str() {
                "c" | "m" | "l" => {
                    if let Some(drop) = self.drop_decision.take() {
                        self.accept_drop(
                            drop,
                            if key == "c" {
                                1
                            } else if key == "m" {
                                2
                            } else {
                                8
                            },
                        );
                    }
                }
                "<Esc>" | "q" => {
                    if let Some(drop) = self.drop_decision.take() {
                        self.cancel_drop(drop.token);
                    }
                }
                _ => return false,
            }
            return true;
        }
        if self.authentication.is_some() || self.question.is_some() {
            if matches!(key.as_str(), "<Esc>" | "<C-[>") {
                self.cancel_mount();
                return true;
            }
            return false;
        }
        if self.tab_menu.is_some() {
            if matches!(key.as_str(), "<Esc>" | "<C-[>") {
                self.tab_menu = None;
                tx.blur();
                return true;
            }
            return false;
        }
        if self.queue.conflict.is_some() {
            match key.as_str() {
                "r" | "R" => self.answer_conflict(operations::Choice::Replace, key == "R"),
                "m" | "M" => self.answer_conflict(operations::Choice::Merge, key == "M"),
                "k" | "K" => self.answer_conflict(operations::Choice::KeepBoth, key == "K"),
                "s" | "S" => self.answer_conflict(operations::Choice::Skip, key == "S"),
                "c" | "<Esc>" | "<C-[>" => self.answer_conflict(operations::Choice::Cancel, false),
                _ => return false,
            }
            return true;
        }
        if self.confirmation.is_some() {
            match key.as_str() {
                "y" => {
                    if let Some(operation) = self.confirmation.take() {
                        self.enqueue(operation, false);
                    }
                }
                "n" | "<Esc>" | "<C-[>" => self.confirmation = None,
                _ => return false,
            }
            return true;
        }
        if self.tasks_open {
            if matches!(key.as_str(), "q" | "<Esc>" | "w") {
                self.tasks_open = false;
                return true;
            }
            return false;
        }
        if let Some(handled) = self.context_key(&key, tx) {
            return handled;
        }
        if matches!(key.as_str(), "<Tab>" | "<S-Tab>")
            && tx
                .focused()
                .is_some_and(|focused| focused.starts_with("details-"))
        {
            return false;
        }
        if self.prompt.is_none() && self.panel.is_none() && !self.help && !self.spot {
            if key == "<A-Enter>"
                && !self.pane().address.editing
                && !self.pane().input.focused
                && self.pane().file().is_some()
            {
                self.command("spot", tx);
                return true;
            }
            if matches!(key.as_str(), "<S-F10>" | "<Menu>") {
                if let Some(file) = self.pane().file().cloned() {
                    self.show_context(
                        self.active_pane,
                        Some(&file.path),
                        rune::PopupAnchor::Key(file.key),
                        tx,
                    );
                } else {
                    self.show_context(
                        self.active_pane,
                        None,
                        rune::PopupAnchor::Key(Pane::list_key(self.active_pane).into()),
                        tx,
                    );
                }
                return true;
            }
            if keymap::desktop_key(&key)
                && let Some(commands) = self
                    .bindings
                    .iter()
                    .find(|binding| binding.on.list() == [key.as_str()])
                    .map(|binding| binding.run.list().to_vec())
            {
                for command in commands {
                    self.command(&command, tx);
                }
                return true;
            }

            match key.as_str() {
                "<C-l>" => {
                    self.edit_location(self.active_pane, tx);
                    return true;
                }
                "<A-Left>" | "<A-Right>" | "<A-Up>" if !self.preview_expanded => {
                    self.pane_mut().address.close();
                    self.command(
                        match key.as_str() {
                            "<A-Left>" => "back",
                            "<A-Right>" => "forward",
                            _ => "leave",
                        },
                        tx,
                    );
                    tx.blur();
                    return true;
                }
                _ => {}
            }
            if self.pane().address.editing {
                match key.as_str() {
                    "<Esc>" | "<C-[>" => {
                        self.pane_mut().address.close();
                        tx.blur();
                    }
                    "<Down>" => self.pane_mut().address.step(true),
                    "<Up>" => self.pane_mut().address.step(false),
                    "<Tab>" => {
                        let index = self.pane().address.selected.unwrap_or(0);
                        self.pane_mut().address.choose(index);
                    }
                    "<Enter>" => self.submit_location(self.active_pane),
                    _ => return false,
                }
                return true;
            }
        }
        if self.prompt.is_none() && self.panel.is_none() && !self.help && !self.spot {
            match key.as_str() {
                "<F3>" => {
                    self.toggle_split(tx);
                    return true;
                }
                "<Tab>" if self.split && !self.preview_expanded && tx.focused().is_none() => {
                    self.activate_pane(1 - self.active_pane, tx);
                    return true;
                }
                "<F5>" if self.split && !self.preview_expanded => {
                    self.transfer(false);
                    return true;
                }
                "<F6>" if self.split && !self.preview_expanded => {
                    self.transfer(true);
                    return true;
                }
                "<F4>" => {
                    self.toggle_preview(tx);
                    return true;
                }
                "<F9>" => {
                    self.sidebar_hidden = !self.sidebar_hidden;
                    return true;
                }
                "<C-f>" if !self.preview_expanded => {
                    self.show_picker(tx);
                    return true;
                }
                "<Esc>" | "<C-[>" if self.preview_expanded => {
                    self.toggle_preview(tx);
                    return true;
                }
                _ => {}
            }
            if self.preview_expanded {
                match key.as_str() {
                    "j" | "<Down>" => self.command("seek 5", tx),
                    "k" | "<Up>" => self.command("seek -5", tx),
                    "<PageDown>" => tx.scroll_page("preview", 1),
                    "<PageUp>" => tx.scroll_page("preview", -1),
                    _ => return false,
                }
                return true;
            }
        }
        if self.pane().picker.is_some() {
            return self.finder_key(&key, tx);
        }
        if key == "<Esc>" || key == "<C-[>" {
            self.context = None;
            self.command("escape", tx);
            return true;
        }
        if self.prompt.is_some() {
            return false;
        }
        if self.panel == Some(Panel::Trash) {
            match key.as_str() {
                "j" | "<Down>" => {
                    self.trash_cursor = (self.trash_cursor + 1)
                        .min(self.trash.as_ref().map_or(0, |v| v.len().saturating_sub(1)))
                }
                "k" | "<Up>" => self.trash_cursor = self.trash_cursor.saturating_sub(1),
                "<Space>" => self.command("trash_select", tx),
                "<C-a>" => self.command("trash_select --all", tx),
                "r" | "<Enter>" => self.command("restore", tx),
                "d" | "<Delete>" => self.command("trash_delete", tx),
                "<F5>" => self.command("refresh_trash", tx),
                "q" => self.panel = None,
                _ => return false,
            }
            if self.panel == Some(Panel::Trash) {
                tx.scroll_into_view_in(
                    "desktop-content",
                    format!("trash-entry-{}", self.trash_cursor),
                );
            }
            return true;
        }
        if self.panel.is_some() {
            if key == "q" {
                self.panel = None;
                return true;
            }
            return false;
        }
        if self.help {
            if key == "q" || key == "<Tab>" {
                self.help = false;
                return true;
            }
            return false;
        }
        if key == "<C-z>" {
            self.command("undo", tx);
            return true;
        }
        if self.pane().picker.is_none()
            && self.pending.is_empty()
            && self.tab().preference.view_mode == crate::preference::ViewMode::Grid
            && matches!(key.as_str(), "<Up>" | "<Down>" | "<Left>" | "<Right>")
        {
            let columns = self.pane().columns();
            let cursor = self.tab().cursor;
            let last = self.tab().visible.len().saturating_sub(1);
            let next = match key.as_str() {
                "<Up>" => cursor.saturating_sub(columns),
                "<Down>" => (cursor + columns).min(last),
                "<Left>" => cursor.saturating_sub(1),
                _ => (cursor + 1).min(last),
            };
            self.tab_mut().cursor = next;
            self.peek(self.active_pane);
            self.restore_cursor(self.active_pane, tx);
            return true;
        }
        self.message = None;
        self.pending.push(key.clone());
        let candidates: Vec<_> = self
            .bindings
            .iter()
            .filter(|b| b.on.list().starts_with(&self.pending))
            .collect();
        if let Some(binding) = candidates
            .iter()
            .find(|b| b.on.list().len() == self.pending.len())
        {
            let commands = binding.run.list().to_vec();
            self.pending.clear();
            for command in commands {
                self.command(&command, tx);
            }
            tx.instant();
            return true;
        }
        if !candidates.is_empty() {
            return true;
        }
        let retry = self.pending.len() > 1;
        self.pending.clear();
        if retry {
            return self.key(event, tx);
        }
        false
    }

    fn finder_key(&mut self, key: &str, tx: &mut Tx) -> bool {
        let picker = self.pane().picker.as_ref().expect("search view");
        if picker.menu.is_some() && matches!(key, "<Esc>" | "<C-[>") {
            self.pane_mut().picker.as_mut().unwrap().menu = None;
            return true;
        }
        match key {
            "<Esc>" | "<C-[>" => self.close_picker(self.active_pane, tx),
            "<Down>" | "<C-n>" => self.picker_hover(self.active_pane, picker.cursor + 1, tx),
            "<Up>" | "<C-p>" => {
                self.picker_hover(self.active_pane, picker.cursor.saturating_sub(1), tx)
            }
            "<PageDown>" => self.picker_hover(self.active_pane, picker.cursor + 10, tx),
            "<PageUp>" => self.picker_hover(self.active_pane, picker.cursor.saturating_sub(10), tx),
            "<Enter>" => self.picker_accept(true, tx),
            "<S-Enter>" => self.picker_accept(false, tx),
            "<C-i>" => self.picker_all(),
            "<C-Space>" => {
                if let Some(file) = picker.file() {
                    self.toggle_selection(&file.path.clone());
                }
            }
            "<C-r>" => {
                self.restart_picker(self.active_pane);
                self.peek(self.active_pane);
            }
            _ => return false,
        }
        true
    }

    pub fn selector_hover(&mut self, path: &Path, tx: &mut Tx) {
        self.hover(path, tx);
        self.tab_mut().selected.clear();
        if let Some(file) = self.tab().file().cloned() {
            let selector = self.selector.as_mut().expect("file picker");
            if !file.directory && matches!(selector.request.mode, crate::selector::Mode::Save) {
                selector.name = TextEdit::new(&file.name);
            }
            selector.error = None;
            if selector.request.folders() == file.directory {
                self.tab_mut().selected.insert(path.to_path_buf());
            }
        }
        self.panes[self.active_pane].revision += 1;
    }

    pub fn selector_filter(&mut self, index: usize) {
        self.selector
            .as_mut()
            .expect("file picker")
            .set_filter(index);
        self.tab_mut().selected.clear();
        self.reorder(self.active_pane);
        if self.pane().picker.is_some() {
            self.pane_mut().picker.as_mut().unwrap().selected.clear();
            self.restart_picker(self.active_pane);
        }
        self.peek(self.active_pane);
    }

    pub fn selector_accept(&mut self, replace: bool, tx: &mut Tx) {
        use crate::selector::{Mode, byte_path, filename};
        let selector = self.selector.as_ref().expect("file picker");
        if selector.busy
            || self.tab().loading
            || self
                .pane()
                .picker
                .as_ref()
                .is_some_and(|picker| picker.loading || picker.query != self.pane().input.text)
        {
            return;
        }
        let selected = self
            .pane()
            .picker
            .as_ref()
            .map_or(&self.tab().selected, |picker| &picker.selected);
        if matches!(
            selector.request.mode,
            Mode::Open {
                directory: false,
                ..
            }
        ) && selected.is_empty()
            && self.pane().file().is_some_and(|file| file.directory)
        {
            self.enter(tx, false);
            return;
        }
        let cwd = if self.pane().picker.is_some()
            && !matches!(selector.request.mode, Mode::Open { .. })
        {
            self.pane()
                .file()
                .map(|file| {
                    if file.directory {
                        file.path.clone()
                    } else {
                        file.path.parent().unwrap().to_path_buf()
                    }
                })
                .unwrap_or_else(|| self.tab().cwd.clone())
        } else {
            self.tab().cwd.clone()
        };
        let folder = selected
            .iter()
            .next()
            .cloned()
            .unwrap_or_else(|| cwd.clone());
        let paths = match &selector.request.mode {
            Mode::Open {
                directory: true, ..
            } => {
                if selected.is_empty() {
                    vec![
                        self.pane()
                            .file()
                            .filter(|file| file.directory && self.pane().picker.is_some())
                            .map_or(cwd, |file| file.path.clone()),
                    ]
                } else {
                    selected.iter().cloned().collect()
                }
            }
            Mode::Open { multiple, .. } => {
                if selected.is_empty() {
                    self.pane()
                        .file()
                        .map(|file| vec![file.path.clone()])
                        .unwrap_or_default()
                } else if *multiple {
                    selected.iter().cloned().collect()
                } else {
                    selected.iter().take(1).cloned().collect()
                }
            }
            Mode::Save => {
                if let Err(error) = filename(selector.name.text.as_ref()) {
                    self.selector.as_mut().unwrap().error = Some(error);
                    return;
                }
                vec![cwd.join(&selector.name.text)]
            }
            Mode::SaveFiles { files } => files
                .iter()
                .map(|file| folder.join(byte_path(file.clone())))
                .collect(),
        };
        self.selector.as_mut().unwrap().accept(paths, replace);
    }

    fn selector_key(&mut self, event: &KeyEvent, tx: &mut Tx) -> bool {
        let Some(key) = keymap::key_name(event) else {
            return false;
        };
        let selector = self.selector.as_mut().expect("file picker");
        if selector.busy {
            return true;
        }
        if selector.replace.is_some() {
            if key == "<Esc>" {
                selector.replace = None;
                return true;
            }
            return false;
        }
        if selector.menu.is_some() {
            if key == "<Esc>" {
                selector.menu = None;
                return true;
            }
            return false;
        }
        if self.prompt.is_some() {
            if key == "<Esc>" {
                self.prompt = None;
                self.action_paths = None;
                tx.blur();
                return true;
            }
            return false;
        }
        if self.view_options.is_some() {
            if key == "<Esc>" {
                self.view_options = None;
                return true;
            }
            return false;
        }
        if self.authentication.is_some() || self.question.is_some() {
            if key == "<Esc>" {
                self.cancel_mount();
                return true;
            }
            return false;
        }
        if let Some(handled) = self.place_menu_key(&key, tx) {
            return handled;
        }
        if let Some(handled) = self.context_key(&key, tx) {
            return handled;
        }
        if self.pane().address.editing {
            match key.as_str() {
                "<Esc>" => {
                    self.pane_mut().address.close();
                    tx.blur();
                }
                "<Down>" => self.pane_mut().address.step(true),
                "<Up>" => self.pane_mut().address.step(false),
                "<Tab>" => {
                    let index = self.pane().address.selected.unwrap_or(0);
                    self.pane_mut().address.choose(index);
                }
                "<Enter>" => self.submit_location(self.active_pane),
                _ => return false,
            }
            return true;
        }
        match key.as_str() {
            "<Esc>" if self.pane().picker.is_some() => self.close_picker(self.active_pane, tx),
            "<Esc>" => self.close(tx),
            "<C-l>" => self.edit_location(self.active_pane, tx),
            "<C-f>" => self.show_picker(tx),
            "<A-Left>" => self.command("back", tx),
            "<A-Right>" => self.command("forward", tx),
            "<A-Up>" => self.command("leave", tx),
            _ if tx.focused() == Some("selector-name") => return false,
            _ if self.pane().picker.is_some() => return self.finder_key(&key, tx),
            "/" => self.show_picker(tx),
            "<Down>" | "<Up>" => {
                self.arrow(if key == "<Down>" { "1" } else { "-1" }, tx);
                if let Some(path) = self.tab().file().map(|file| file.path.clone()) {
                    self.selector_hover(&path, tx);
                }
            }
            "<Enter>" => self.enter(tx, true),
            "<C-h>" => self.command("hidden", tx),
            "<Space>" if self.selector.as_ref().unwrap().request.multiple() => {
                if let Some(file) = self.tab().file().cloned()
                    && file.directory == self.selector.as_ref().unwrap().request.folders()
                {
                    self.toggle_selection(&file.path);
                }
            }
            "<C-a>" if self.selector.as_ref().unwrap().request.multiple() => {
                let folders = self.selector.as_ref().unwrap().request.folders();
                self.tab_mut().selected = self
                    .tab()
                    .visible
                    .iter()
                    .map(|&index| &self.tab().files[index])
                    .filter(|file| file.directory == folders)
                    .map(|file| file.path.clone())
                    .collect();
                self.panes[self.active_pane].revision += 1;
            }
            _ => return false,
        }
        true
    }

    pub fn snapshot(&self) -> serde_json::Value {
        let tab = self.tab();
        let mut snapshot = serde_json::json!({
            "cwd": tab.cwd, "hovered": tab.file().map(|f| &f.path),
            "cursor": tab.cursor, "files": tab.visible.iter().map(|&i| &tab.files[i].name).collect::<Vec<_>>(),
            "selected": tab.visible.iter().enumerate().filter(|(i, _)| tab.selected(*i)).map(|(_, &i)| &tab.files[i].path).collect::<Vec<_>>(),
            "selection_count": tab.selected.len(), "visual": tab.visual, "tab_count": self.panes[self.active_pane].tabs.len(), "active_tab": self.panes[self.active_pane].active, "native_drag_drop": self.dnd.is_some(), "drop_hover": self.drop_hover, "drop_choice": self.drop_decision.is_some(),
            "show_hidden": self.tab().preference.show_hidden, "filter": tab.filter, "prompt": self.prompt,
            "location": self.display_location(&self.tab().cwd),
            "mount_busy": self.mounts.busy(), "authentication": self.authentication.is_some(), "question": self.question.is_some(),
            "panel": self.panel, "places": self.places, "properties": self.properties, "applications": self.applications,
            "chooser": { "query": self.chooser.query.text, "selected": self.chooser.selected, "all": self.chooser.all, "always": self.chooser.always, "custom": self.chooser.custom, "busy": self.chooser.busy, "error": self.chooser.error,
                "visible": self.applications.as_ref().map(|apps| self.chooser.visible(apps).into_iter().map(|app| &app.id).collect::<Vec<_>>()) }, "trash": self.trash, "trash_selected": self.trash_selected, "trash_cursor": self.trash_cursor,
            "preview_scroll": self.panes[self.active_pane].preview_scroll.get(), "spot": self.spot, "help": self.help,
            "tasks": self.queue.tasks, "undo_available": self.queue.undo_available(), "confirmation": self.confirmation.as_ref().map(Operation::title),
            "conflict": self.queue.conflict.as_ref().map(|c| serde_json::json!({"source": c.source, "destination": c.destination})),
            "yank": self.yank.as_ref().map(|y| serde_json::json!({"paths": y.paths, "cut": y.cut})),
            "preview": self.panes[self.active_pane].preview.kind(), "loading": tab.loading, "message": self.message,
        });
        snapshot["tab_menu"] = self.tab_menu.into();
        snapshot["zoom"] = self.zoom.into();
        snapshot["printing"] = self.print_busy.into();
        snapshot["thumbnails"] = self.thumbnails.as_ref().map(|thumbs| {
            let stats = thumbs.counters();
            serde_json::json!({"visible":stats.visible,"ready":stats.ready,"failed":stats.failed,"queued":stats.queued,"skipped":stats.skipped,"deferred":stats.deferred,"service":stats.service})
        }).into();
        snapshot["appearance"] = self.appearance.snapshot();
        snapshot["selector"] = self.selector.as_ref().map(|selector| serde_json::json!({
            "request": selector.request, "name": selector.name.text, "filter": selector.filter, "choices": selector.choices,
            "error": selector.error, "busy": selector.busy, "replace": selector.replace,
        })).into();
        snapshot["session_error"] = self.session_error.clone().into();
        snapshot["session_restored"] = self.session_restored.into();
        snapshot["session_saving"] = self.session_saving.into();
        snapshot["preference"] = serde_json::to_value(tab.preference).unwrap();
        snapshot["view_options"] = self.view_options.is_some().into();
        snapshot["view_customized"] = self.views.customized(&self.location_uri(&tab.cwd)).into();
        snapshot["view_saving"] = self.views.saving().into();
        snapshot["view_error"] = self.views.error.clone().into();
        snapshot["favorite_saving"] = self.favorites_saving().into();
        snapshot["place_menu"] = self.place_menu.as_ref().map(|place| serde_json::json!({"kind":"rename","uri":place.uri,"label":self.place_label.text})).into();
        snapshot["context"] = self.context.as_ref().map(|menu| serde_json::json!({
            "title": menu.title(), "side":menu.side,
            "paths": match &menu.target { Target::Files{paths,..} => paths.clone(), _ => Vec::new() },
            "background":matches!(menu.target, Target::Background),
            "items":menu.groups.iter().flatten().map(|item| item.key).collect::<Vec<_>>(),
        })).into();
        snapshot["sidebar_hidden"] = self.sidebar_hidden.into();
        snapshot["folder_peek"] = self.peek.target.as_ref().map(|target| serde_json::json!({
            "path": target.path, "anchor": target.anchor, "side": target.side,
            "loading": self.peek.result.is_none(),
            "files": self.peek.result.as_ref().and_then(|result| result.as_ref().ok())
                .map(|contents| contents.files.iter().map(|file| &file.name).collect::<Vec<_>>()),
            "truncated": self.peek.result.as_ref().and_then(|result| result.as_ref().ok())
                .is_some_and(|contents| contents.truncated),
            "error": self.peek.result.as_ref().and_then(|result| result.as_ref().err()),
        })).into();
        snapshot["preview_expanded"] = self.preview_expanded.into();
        snapshot["preview_width"] = self.preview_width.into();
        snapshot["results_available"] = tab.saved_picker.is_some().into();
        snapshot["file_scroll"] = tab.scroll.get().into();
        snapshot["split"] = self.split.into();
        snapshot["active_pane"] = self.active_pane.into();
        snapshot["split_width"] = self.split_width.into();
        snapshot["panes"] = self.panes.iter().map(Pane::snapshot).collect();
        if let Some(picker) = &self.panes[self.active_pane].picker {
            snapshot["finder"] = serde_json::json!({
                "root": picker.root, "recursive": picker.recursive, "content": picker.content, "regex": picker.regex, "query": picker.query, "hits": picker.hits,
                "filters": { "type": FilterKind::Type.options()[picker.filters.file_type], "modified": FilterKind::Modified.options()[picker.filters.modified], "size": FilterKind::Size.options()[picker.filters.size] },
                "filter_menu": picker.menu.map(FilterKind::key),
                "all_files": picker.all_files, "cursor": picker.cursor,
                "selected": picker.selected, "scroll": picker.scroll.get(),
                "files": picker.files.iter().map(|file| &file.name).collect::<Vec<_>>(),
                "hovered": picker.file().map(|file| &file.path),
                "loading": picker.loading, "indexed": picker.indexed,
                "scanning": picker.scanning, "watching": picker.watching, "error": picker.error,
            });
        }
        if let Preview::Zip(zip) = &self.panes[self.active_pane].preview {
            snapshot["zip"] = serde_json::to_value(zip).unwrap();
        }
        if let Preview::Core(core) = &self.panes[self.active_pane].preview {
            snapshot["core"] = serde_json::to_value(core).unwrap();
        }
        if let Preview::Pdf(pdf) = &self.panes[self.active_pane].preview {
            snapshot["pdf"] =
                serde_json::json!({"page": pdf.page, "pages": pdf.pages(), "status": pdf.status()});
        }
        if let Preview::Html(html) = &self.panes[self.active_pane].preview {
            snapshot["html"] =
                serde_json::json!({"status": html.status(), "truncated": html.source.truncated});
            if let crate::html::View::Rendered(document) = &html.view {
                snapshot["html"]["limited"] = document.limited.into();
                snapshot["html"]["parts"] = document.parts.len().into();
                snapshot["html"]["images"] = document
                    .parts
                    .iter()
                    .filter(|p| matches!(p, crate::html::Part::Image { .. }))
                    .count()
                    .into();
            }
        }
        snapshot
    }
}

impl Drop for State {
    fn drop(&mut self) {
        use gio::prelude::CancellableExt;
        self.print_io.cancel();
        if let Some(export) = &self.export {
            *export.borrow_mut() = self.snapshot();
        }
    }
}

pub fn home() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/"))
}

pub fn expand_path(value: &str, cwd: &Path) -> PathBuf {
    let path = if value == "~" {
        home()
    } else if let Some(rest) = value.strip_prefix("~/") {
        home().join(rest)
    } else {
        PathBuf::from(value)
    };
    if path.is_absolute() {
        path
    } else {
        cwd.join(path)
    }
}

fn parse_sort(value: &str) -> Option<SortBy> {
    match value {
        "alphabetical" => Some(SortBy::Alphabetical),
        "natural" => Some(SortBy::Natural),
        "extension" => Some(SortBy::Extension),
        "owner" => Some(SortBy::Owner),
        "size" => Some(SortBy::Size),
        "mtime" => Some(SortBy::Modified),
        _ => None,
    }
}

pub(crate) fn smart_contains(haystack: &str, needle: &str) -> bool {
    if needle.chars().any(char::is_uppercase) {
        haystack.contains(needle)
    } else {
        haystack.to_lowercase().contains(&needle.to_lowercase())
    }
}

fn rename_path(source: &Path, pattern: &str, index: usize) -> PathBuf {
    source.with_file_name(
        pattern
            .replace(
                "{name}",
                &source.file_name().unwrap_or_default().to_string_lossy(),
            )
            .replace(
                "{stem}",
                &source.file_stem().unwrap_or_default().to_string_lossy(),
            )
            .replace(
                "{ext}",
                &source.extension().unwrap_or_default().to_string_lossy(),
            )
            .replace("{n}", &(index + 1).to_string()),
    )
}
