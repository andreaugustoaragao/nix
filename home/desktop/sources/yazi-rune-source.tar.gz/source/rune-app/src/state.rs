use std::{
    collections::{BTreeSet, HashMap},
    fs,
    path::{Path, PathBuf},
    time::Duration,
};

use gio::prelude::FileExt;
use rune::{ImageCache, KeyEvent, Latest, TextEdit, Tx, Waker};
use serde::{Deserialize, Serialize};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};

use crate::{
    clipboard::{self, Clipboard, Yank},
    file::{self, File, Folder, Preview, SortBy},
    keymap::{self, Binding},
    locations::{self, Applications, Place, Properties},
    mounts::{self, Mounts},
    operations::{self, Operation},
    step::Step,
    watcher::Watch,
};

#[derive(Clone, Copy, Serialize)]
pub struct Visual {
    pub start: usize,
    pub wraps: isize,
    pub unset: bool,
}

impl Visual {
    fn contains(self, index: usize, end: usize, len: usize) -> bool {
        if len == 0 {
            return false;
        }
        let start = self.start.min(len - 1);
        let end = end.min(len - 1);
        match self.wraps {
            0 => (start.min(end)..=start.max(end)).contains(&index),
            1 if start > end + 1 => index <= end || index >= start,
            -1 if end > start + 1 => index <= start || index >= end,
            _ => true,
        }
    }
}

#[derive(Clone, Deserialize)]
#[serde(default)]
pub struct Preference {
    pub ratio: [f32; 3],
    pub show_hidden: bool,
    pub sort_sensitive: bool,
    pub sort_dir_first: bool,
    pub sort_reverse: bool,
    pub sort_by: String,
}

impl Default for Preference {
    fn default() -> Self {
        Self {
            ratio: [1.0, 4.0, 3.0],
            show_hidden: false,
            sort_sensitive: false,
            sort_dir_first: true,
            sort_reverse: true,
            sort_by: "mtime".into(),
        }
    }
}

#[derive(Deserialize, Default)]
struct Config {
    #[serde(default)]
    mgr: Preference,
}

#[derive(Clone)]
pub struct Tab {
    pub cwd: PathBuf,
    pub name: Option<String>,
    pub files: Vec<File>,
    pub visible: Vec<usize>,
    pub cursor: usize,
    pub selected: BTreeSet<PathBuf>,
    pub visual: Option<Visual>,
    pub history: Vec<PathBuf>,
    pub history_cursor: usize,
    pub hovered: HashMap<PathBuf, PathBuf>,
    pub filter: String,
    pub search: String,
    pub loading: bool,
}

impl Tab {
    fn new(cwd: PathBuf) -> Self {
        Self {
            history: vec![cwd.clone()],
            cwd,
            name: None,
            files: Vec::new(),
            visible: Vec::new(),
            cursor: 0,
            selected: BTreeSet::new(),
            visual: None,
            history_cursor: 0,
            hovered: HashMap::new(),
            filter: String::new(),
            search: String::new(),
            loading: true,
        }
    }

    pub fn file(&self) -> Option<&File> {
        self.visible.get(self.cursor).map(|&i| &self.files[i])
    }
    pub fn entry(&self, index: usize) -> &File {
        &self.files[self.visible[index]]
    }
    pub fn selected(&self, index: usize) -> bool {
        let stored = self.selected.contains(&self.entry(index).path);
        match self.visual {
            Some(v) if v.contains(index, self.cursor, self.visible.len()) => !v.unset,
            _ => stored,
        }
    }

    fn finish_visual(&mut self) {
        if let Some(visual) = self.visual.take() {
            for i in 0..self.visible.len() {
                if !visual.contains(i, self.cursor, self.visible.len()) {
                    continue;
                }
                if let Some(&index) = self.visible.get(i) {
                    let path = self.files[index].path.clone();
                    if visual.unset {
                        self.selected.remove(&path);
                    } else {
                        self.selected.insert(path);
                    }
                }
            }
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Panel {
    Places,
    Applications,
    Trash,
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Prompt {
    Filter,
    Find,
    FindPrevious,
    Cd,
    TabRename,
    Create,
    Rename,
    Permissions,
    Archive,
    Connect,
    Search,
    OpenCommand,
}

impl Prompt {
    pub fn title(self) -> &'static str {
        match self {
            Self::Filter => "Filter",
            Self::Find => "Find",
            Self::FindPrevious => "Find previous",
            Self::Cd => "Go to",
            Self::TabRename => "Rename tab",
            Self::Create => "Create file (end with / for a folder)",
            Self::Rename => "Rename (batch: {name}, {stem}, {ext}, {n})",
            Self::Permissions => "Permissions: octal mode; append -r for recursive",
            Self::Archive => "Archive name (.zip, .tar, .tar.gz)",
            Self::Connect => "Server location (sftp://, smb://, ftp://, dav://)",
            Self::Search => "Search filenames recursively",
            Self::OpenCommand => "Program command (%f for a file)",
        }
    }
}

pub struct State {
    pub dnd: Option<crate::dnd::Dnd>,
    pub drop_targets: std::cell::RefCell<Vec<crate::dnd::Target>>,
    pub drop_hover: Option<PathBuf>,
    pub drop_decision: Option<crate::dnd::Drop>,
    drop_preference: Latest<(u32, u32)>,
    drop_preview: Option<(u32, Vec<PathBuf>, bool)>,
    pub mounts: Mounts,
    pub startup_uri: Option<String>,
    pub mount_intent: Option<(bool, bool)>,
    pub authentication: Option<mounts::Authentication>,
    pub question: Option<mounts::Question>,
    closing: bool,
    pub trash: Option<Vec<crate::trash::Entry>>,
    pub trash_selected: BTreeSet<String>,
    pub trash_cursor: usize,
    trash_worker: Latest<Result<Vec<crate::trash::Entry>, String>>,
    pub panel: Option<Panel>,
    pub places: Vec<Place>,
    pub properties: Option<Properties>,
    pub applications: Option<Applications>,
    properties_worker: Latest<Result<Properties, String>>,
    applications_worker: Latest<Result<Applications, String>>,
    desktop_worker: Latest<Result<String, String>>,

    pub queue: operations::Queue,
    pub tasks_open: bool,
    pub context_open: bool,
    pub confirmation: Option<Operation>,
    pub yank: Option<Yank>,
    pub tabs: Vec<Tab>,
    pub active: usize,
    pub parent: Vec<File>,
    pub preview: Preview,
    pub preference: Preference,
    pub sort_by: SortBy,
    pub bindings: Vec<Binding>,
    pub pending: Vec<String>,
    pub prompt: Option<Prompt>,
    pub input: TextEdit,
    pub find: String,
    pub help: bool,
    pub spot: bool,
    pub message: Option<String>,
    pub dark: Option<bool>,
    pub revision: u64,
    pub page_size: usize,
    pub preview_scroll: rune::Live<[f32; 2]>,
    pub export: Option<std::rc::Rc<std::cell::RefCell<serde_json::Value>>>,
    clipboard: Clipboard,
    remaining_yank: Latest<(Yank, Yank)>,
    watch: Watch,
    search_cancel: Arc<AtomicBool>,
    directory: Latest<Folder>,
    previews: Latest<Preview>,
    directory_io: gio::Cancellable,
    preview_io: gio::Cancellable,
    remote_refresh: std::time::Instant,
    preview_path: Option<PathBuf>,
    cache: Option<std::sync::Arc<ImageCache>>,
    headless: bool,
    config_dir: PathBuf,
    cwd_file: Option<PathBuf>,
}

impl State {
    pub fn new(cwd: PathBuf, config_dir: Option<PathBuf>, cwd_file: Option<PathBuf>) -> Self {
        let config_dir = config_dir.unwrap_or_else(|| {
            std::env::var_os("YAZI_CONFIG_HOME")
                .map(PathBuf::from)
                .unwrap_or_else(|| {
                    std::env::var_os("XDG_CONFIG_HOME")
                        .map(PathBuf::from)
                        .unwrap_or_else(|| home().join(".config"))
                        .join("yazi")
                })
        });
        let custom = fs::read_to_string(config_dir.join("keymap.toml")).ok();
        let (bindings, key_error) = match keymap::load(custom.as_deref()) {
            Ok(b) => (b, None),
            Err(e) => (keymap::load(None).expect("upstream keymap"), Some(e)),
        };
        let preference = fs::read_to_string(config_dir.join("yazi.toml"))
            .ok()
            .and_then(|s| toml::from_str::<Config>(&s).ok())
            .unwrap_or_default()
            .mgr;
        let sort_by = parse_sort(&preference.sort_by).unwrap_or_default();
        Self {
            dnd: None,
            drop_targets: std::cell::RefCell::new(Vec::new()),
            drop_hover: None,
            drop_decision: None,
            drop_preference: Latest::default(),
            drop_preview: None,
            closing: false,
            mounts: Mounts::default(),
            startup_uri: None,
            mount_intent: None,
            authentication: None,
            question: None,
            trash: None,
            trash_selected: BTreeSet::new(),
            trash_cursor: 0,
            trash_worker: Latest::default(),
            panel: None,
            places: Vec::new(),
            properties: None,
            applications: None,
            properties_worker: Latest::default(),
            applications_worker: Latest::default(),
            desktop_worker: Latest::default(),
            queue: operations::Queue::default(),
            tasks_open: false,
            context_open: false,
            confirmation: None,
            yank: None,
            tabs: vec![Tab::new(cwd)],
            active: 0,
            parent: Vec::new(),
            preview: Preview::Loading,
            preference,
            sort_by,
            bindings,
            pending: Vec::new(),
            prompt: None,
            input: TextEdit::new(""),
            find: String::new(),
            help: false,
            spot: false,
            message: key_error,
            dark: None,
            revision: 0,
            page_size: 20,
            preview_scroll: rune::Live::new([0.0; 2]),
            export: None,
            clipboard: Clipboard::default(),
            remaining_yank: Latest::default(),
            watch: Watch::default(),
            search_cancel: Arc::new(AtomicBool::new(false)),
            directory: Latest::default(),
            previews: Latest::default().debounce(Duration::from_millis(30)),
            directory_io: gio::Cancellable::new(),
            preview_io: gio::Cancellable::new(),
            remote_refresh: std::time::Instant::now(),
            preview_path: None,
            cache: None,
            headless: rune::tooling::headless_run().is_some(),
            config_dir,
            cwd_file,
        }
    }

    pub fn tab(&self) -> &Tab {
        &self.tabs[self.active]
    }
    pub fn tab_mut(&mut self) -> &mut Tab {
        &mut self.tabs[self.active]
    }

    pub fn setup(&mut self, waker: Waker) {
        if let Err(error) = self.watch.start(waker.clone()) {
            self.message = Some(format!("Filesystem watcher: {error}"));
        }
        if !self.headless && std::env::var_os("WAYLAND_DISPLAY").is_some() {
            self.clipboard.start(waker.clone());
        }
        self.mounts.start(waker.clone());
        self.trash_worker.set_waker(waker.clone());
        self.drop_preference.set_waker(waker.clone());
        if let Some(uri) = self.startup_uri.take() {
            if uri.starts_with("trash:") {
                self.panel = Some(Panel::Trash);
                self.trash_worker.request((), |_| crate::trash::read());
            } else {
                self.mount_action(mounts::Action::Connect(uri));
            }
        }
        self.properties_worker.set_waker(waker.clone());
        self.applications_worker.set_waker(waker.clone());
        self.desktop_worker.set_waker(waker.clone());
        self.remaining_yank.set_waker(waker.clone());
        self.queue.start(waker.clone());
        self.directory.set_waker(waker.clone());
        self.previews.set_waker(waker.clone());
        self.cache = Some(std::sync::Arc::new(ImageCache::new(waker)));
        self.reload();
    }

    pub fn reload(&mut self) {
        self.tab_mut().loading = true;
        self.parent.clear();
        self.preview = Preview::Loading;
        self.preview_path = None;
        self.previews.cancel();
        self.load_directory();
        self.update_watch();
    }

    fn load_directory(&mut self) {
        self.search_cancel.store(true, Ordering::Relaxed);
        self.search_cancel = Arc::new(AtomicBool::new(false));
        let path = self.tab().cwd.clone();
        use gio::prelude::CancellableExt;
        self.directory_io.cancel();
        self.directory_io = gio::Cancellable::new();
        if let Some(root) = self.remote_io(&path) {
            let cancel = self.directory_io.clone();
            if self.tab().search.is_empty() {
                self.directory
                    .request((path, root, cancel), |(path, root, cancel)| {
                        file::read_folder_remote(path, root, cancel)
                    });
            } else {
                let query = self.tab().search.clone();
                let hidden = self.preference.show_hidden;
                self.directory.request(
                    (path, query, hidden, root, cancel),
                    |(path, query, hidden, root, cancel)| {
                        crate::search::read_remote(path, query, hidden, root, cancel)
                    },
                );
            }
            return;
        }
        if self.tab().search.is_empty() {
            self.directory.request(path, file::read_folder);
        } else {
            let query = self.tab().search.clone();
            let hidden = self.preference.show_hidden;
            let cancel = self.search_cancel.clone();
            self.directory.request(
                (path, query, hidden, cancel),
                |(path, query, hidden, cancel)| crate::search::read(path, query, hidden, cancel),
            );
        }
    }

    fn update_watch(&mut self) {
        let mut paths = vec![self.tab().cwd.clone()];
        if let Some(parent) = self.tab().cwd.parent() {
            paths.push(parent.to_path_buf());
        }
        if let Some(file) = self.tab().file()
            && file.directory
        {
            paths.push(file.path.clone());
        }
        if !self.tab().search.is_empty() {
            paths.extend(
                self.tab()
                    .files
                    .iter()
                    .filter_map(|f| f.path.parent().map(Path::to_path_buf)),
            );
        }
        paths.retain(|path| self.remote_place(path).is_none());
        if let Err(error) = self.watch.update(paths) {
            self.message = Some(format!("Filesystem watcher: {error}"));
        }
    }

    pub fn poll(&mut self, tx: &mut Tx) -> bool {
        let (mut changed, refresh) = self.queue.poll();
        if self.dnd.is_some() {
            tx.wake_after(Duration::from_millis(30));
            let events = self.dnd.as_mut().unwrap().poll();
            for event in events {
                match event {
                    crate::dnd::Event::Hover { token, point } => {
                        let target = (token != 0).then(|| self.drop_destination(point));
                        if self.drop_hover != target {
                            self.drop_hover = target;
                            if let Some((preview_token, paths, local)) = &self.drop_preview
                                && *preview_token == token
                                && let Some(destination) = &self.drop_hover
                            {
                                self.request_drop_preference(
                                    token,
                                    paths.clone(),
                                    destination.clone(),
                                    *local,
                                );
                            }
                            changed = true;
                        }
                        if token == 0 {
                            self.drop_preview = None;
                            self.drop_preference.cancel();
                        }
                    }
                    crate::dnd::Event::Preview {
                        token,
                        point,
                        paths,
                        local,
                    } => {
                        let destination = self.drop_destination(point);
                        self.request_drop_preference(token, paths.clone(), destination, local);
                        self.drop_preview = Some((token, paths, local));
                    }
                    crate::dnd::Event::Drop {
                        token,
                        point,
                        paths,
                        action,
                        choose,
                    } => {
                        let drop = crate::dnd::Drop {
                            action,
                            token,
                            paths,
                            destination: self.drop_destination(point),
                        };
                        self.drop_hover = None;
                        self.drop_preview = None;
                        self.drop_preference.cancel();
                        if let Some(previous) = self.drop_decision.take() {
                            self.cancel_drop(previous.token);
                        }
                        if action == 4 || choose {
                            self.drop_decision = Some(drop);
                        } else {
                            self.accept_drop(drop, action);
                        }
                        changed = true;
                    }
                    crate::dnd::Event::Error(error) => {
                        self.message = Some(error);
                        self.drop_hover = None;
                        changed = true;
                    }
                    crate::dnd::Event::End => {
                        self.drop_hover = None;
                        changed = true;
                    }
                }
            }
            if let Some((token, action)) = self.drop_preference.take() {
                self.dnd.as_mut().unwrap().prefer(token, action);
            }
            self.dnd.as_mut().unwrap().finish_tasks(&self.queue.tasks);
        }
        for event in self.mounts.take() {
            match event {
                mounts::Event::Places(places) => {
                    let disconnected = self
                        .places
                        .iter()
                        .find(|old| {
                            !old.uri.starts_with("file:")
                                && old.unmount
                                && old
                                    .path
                                    .as_deref()
                                    .is_some_and(|root| self.tab().cwd.starts_with(root))
                                && !places.iter().any(|new| new.uri == old.uri && new.unmount)
                        })
                        .map(|place| place.name.clone());
                    self.places = places;
                    if let Some(name) = disconnected {
                        self.cd(home(), tx, true);
                        self.message = Some(format!("{name} disconnected"));
                    }
                    tx.set_title(format!(
                        "{} — Yazi Rune",
                        self.display_location(&self.tab().cwd)
                    ));
                }
                mounts::Event::Authentication(mut auth) => {
                    let field = if auth.flags.contains(gio::AskPasswordFlags::NEED_USERNAME)
                        && auth.user.text.is_empty()
                    {
                        "auth-user"
                    } else if auth.flags.contains(gio::AskPasswordFlags::NEED_PASSWORD) {
                        "auth-password"
                    } else if auth.flags.contains(gio::AskPasswordFlags::NEED_DOMAIN) {
                        "auth-domain"
                    } else {
                        "auth-user"
                    };
                    match field {
                        "auth-password" => auth.password.focused = true,
                        "auth-domain" => auth.domain.focused = true,
                        _ => auth.user.focused = true,
                    }
                    self.authentication = Some(*auth);
                }
                mounts::Event::Question(question) => self.question = Some(question),
                mounts::Event::Finished(result) => {
                    self.authentication = None;
                    self.question = None;
                    match result {
                        Ok(Some(path)) => {
                            self.panel = None;
                            if let Some((folders, properties)) = self.mount_intent.take() {
                                self.reveal(path, folders, properties, tx);
                            } else {
                                self.cd(path, tx, true);
                            }
                        }
                        Ok(None) => self.message = Some("Device operation completed".into()),
                        Err(error) => self.message = Some(error),
                    }
                    self.mount_intent = None;
                    self.mounts.refresh_places();
                }
            }
            changed = true;
        }
        if let Some(result) = self.trash_worker.take() {
            match result {
                Ok(entries) => {
                    self.trash_selected
                        .retain(|uri| entries.iter().any(|entry| &entry.uri == uri));
                    self.trash_cursor = self.trash_cursor.min(entries.len().saturating_sub(1));
                    self.trash = Some(entries);
                }
                Err(error) => self.message = Some(format!("Trash: {error}")),
            }
            changed = true;
        }
        if let Some(properties) = self.properties_worker.take() {
            match properties {
                Ok(properties) => self.properties = Some(properties),
                Err(error) => self.message = Some(error),
            }
            changed = true;
        }
        if let Some(applications) = self.applications_worker.take() {
            match applications {
                Ok(applications) => self.applications = Some(applications),
                Err(error) => self.message = Some(error),
            }
            changed = true;
        }
        if let Some(result) = self.desktop_worker.take() {
            self.message = Some(result.unwrap_or_else(|error| error));
            self.mounts.refresh_places();
            changed = true;
        }
        for event in self.clipboard.take() {
            match event {
                clipboard::Event::Written(Err(error)) => {
                    self.message = Some(format!("File clipboard: {error}"))
                }
                clipboard::Event::Written(Ok(())) => {}
                clipboard::Event::Paste {
                    files: Ok(Some(files)),
                    destination,
                    force,
                } => self.paste_files(files, destination, force),
                clipboard::Event::Paste {
                    files: Ok(None), ..
                } => self.message = Some("The clipboard contains no files".into()),
                clipboard::Event::Paste {
                    files: Err(error), ..
                } => self.message = Some(format!("File clipboard: {error}")),
            }
            changed = true;
        }
        if let Some(error) = self.watch.error() {
            self.message = Some(format!("Filesystem watcher: {error}"));
        }
        let changes = self.watch.take();
        if !changes.is_empty() {
            self.load_directory();
            self.preview_path = None;
            self.previews.cancel();
            changed = true;
        }
        if refresh {
            if self.panel == Some(Panel::Trash) {
                self.trash_worker.request((), |_| crate::trash::read());
            }
            if let Some(task) = self.queue.tasks.iter().rev().find(|t| {
                matches!(
                    t.status,
                    operations::Status::Completed
                        | operations::Status::Failed
                        | operations::Status::Cancelled
                )
            }) {
                self.message = Some(if task.errors.is_empty() {
                    format!(
                        "{}: {:?}{}",
                        task.title,
                        task.status,
                        if task.warnings.is_empty() {
                            ""
                        } else {
                            "; see Tasks for metadata warnings"
                        }
                    )
                } else {
                    format!("{}: {}", task.title, task.errors.join("; "))
                });
            }
            if let Some(yank) = &self.yank
                && yank.cut
            {
                let roots: Vec<_> = yank
                    .paths
                    .iter()
                    .filter_map(|path| self.remote_io(path))
                    .collect();
                self.remaining_yank
                    .request((yank.clone(), roots), |(previous, roots)| {
                        let mut remaining = previous.clone();
                        remaining.paths.retain(|path| {
                            if let Some(root) =
                                roots.iter().find(|root| path.starts_with(&root.path))
                            {
                                use gio::prelude::FileExt;
                                file::remote_uri(root, path)
                                    .query_info(
                                        "standard::type",
                                        gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS,
                                        gio::Cancellable::NONE,
                                    )
                                    .is_ok()
                            } else {
                                fs::symlink_metadata(path).is_ok()
                            }
                        });
                        (previous, remaining)
                    });
            }
            self.reload();
        }
        if let Some((previous, remaining)) = self.remaining_yank.take()
            && self.yank.as_ref() == Some(&previous)
        {
            if !self.headless && previous.paths.len() != remaining.paths.len() {
                self.clipboard.consume(&previous, &remaining);
            }
            self.yank = Some(remaining);
            changed = true;
        }
        if self.prompt == Some(Prompt::Filter) && self.input.text != self.tab().filter {
            self.edit_prompt(tx);
            changed = true;
        }
        if let Some(folder) = self.directory.take()
            && folder.path == self.tab().cwd
        {
            self.tab_mut().loading = false;
            if let Some(note) = folder.note {
                self.message = Some(note);
            }
            match folder.files {
                Ok(files) => {
                    let previous = self.tab().file().cloned();
                    if let Some(path) = self.tab().file().map(|f| f.path.clone()) {
                        let cwd = self.tab().cwd.clone();
                        self.tab_mut().hovered.insert(cwd, path);
                    }
                    self.tab_mut().visible.clear();
                    self.tab_mut().finish_visual();
                    let paths: BTreeSet<_> = files.iter().map(|f| &f.path).collect();
                    self.tab_mut().selected.retain(|path| paths.contains(path));
                    self.tab_mut().files = files;
                    self.parent = folder.parent;
                    self.reorder();
                    if previous.as_ref() != self.tab().file() {
                        self.preview_path = None;
                    }
                    self.peek();
                    self.restore_cursor(tx);
                    if self.spot {
                        self.load_properties();
                    }
                }
                Err(error) => {
                    if let Some(fallback) = folder.fallback {
                        let target = if self.remote_place(&folder.path).is_some() {
                            home()
                        } else {
                            fallback
                        };
                        self.cd(target, tx, true);
                    }
                    self.tab_mut().files.clear();
                    self.tab_mut().visible.clear();
                    self.preview = Preview::Empty;
                    self.message = Some(error);
                }
            }
            changed = true;
        }
        if let Some(mut preview) = self.previews.take() {
            if let Preview::Directory(files) = &mut preview {
                files.retain(|f| self.preference.show_hidden || !f.name.starts_with('.'));
                file::sort(
                    files,
                    self.sort_by,
                    self.preference.sort_reverse,
                    self.preference.sort_sensitive,
                    self.preference.sort_dir_first,
                );
            }
            self.preview = preview;
            changed = true;
        }
        if !self.closing
            && self.tab().search.is_empty()
            && self.remote_place(&self.tab().cwd).is_some()
        {
            if !self.tab().loading && self.remote_refresh.elapsed() >= Duration::from_secs(2) {
                self.remote_refresh = std::time::Instant::now();
                self.tab_mut().loading = true;
                self.load_directory();
            }
            tx.wake_after(Duration::from_secs(2));
        }
        if self.closing {
            if self.queue.active().is_none() && !self.mounts.busy() {
                self.dnd = None;
                tx.quit();
            } else {
                tx.wake_after(Duration::from_millis(60));
            }
        }
        changed
    }

    pub fn peek(&mut self) {
        self.update_watch();
        let Some(file) = self.tab().file().cloned() else {
            use gio::prelude::CancellableExt;
            self.preview_io.cancel();
            self.previews.cancel();
            self.preview = Preview::Empty;
            self.preview_path = None;
            return;
        };
        if self.preview_path.as_ref() == Some(&file.path) {
            return;
        }
        let Some(cache) = self.cache.clone() else {
            return;
        };
        self.preview_path = Some(file.path.clone());
        self.preview = Preview::Loading;
        self.preview_scroll.set([0.0; 2]);
        use gio::prelude::CancellableExt;
        self.preview_io.cancel();
        self.preview_io = gio::Cancellable::new();
        if let Some(root) = self.remote_io(&file.path) {
            let cancel = self.preview_io.clone();
            self.previews.request(
                (file.path, file.directory, root, cancel, cache),
                |(path, dir, root, cancel, cache)| {
                    file::preview_remote(path, dir, root, cancel, cache)
                },
            );
        } else {
            self.previews
                .request((file.path, file.directory, cache), |(path, dir, cache)| {
                    file::preview(path, dir, cache)
                });
        }
    }

    pub fn reorder(&mut self) {
        let hovered = self
            .tab()
            .file()
            .map(|f| f.path.clone())
            .or_else(|| self.tab().hovered.get(&self.tab().cwd).cloned());
        let by = self.sort_by;
        let p = self.preference.clone();
        file::sort(
            &mut self.tab_mut().files,
            by,
            p.sort_reverse,
            p.sort_sensitive,
            p.sort_dir_first,
        );
        self.parent
            .retain(|f| p.show_hidden || !f.name.starts_with('.'));
        file::sort(
            &mut self.parent,
            by,
            p.sort_reverse,
            p.sort_sensitive,
            p.sort_dir_first,
        );
        let tab = self.tab_mut();
        tab.visible = tab
            .files
            .iter()
            .enumerate()
            .filter(|(_, f)| {
                (p.show_hidden || !f.name.starts_with('.')) && smart_contains(&f.name, &tab.filter)
            })
            .map(|(i, _)| i)
            .collect();
        tab.cursor = hovered
            .and_then(|path| tab.visible.iter().position(|&i| tab.files[i].path == path))
            .unwrap_or(tab.cursor)
            .min(tab.visible.len().saturating_sub(1));
        self.revision += 1;
    }

    fn restore_cursor(&self, tx: &mut Tx) {
        if let Some(file) = self.tab().file() {
            tx.scroll_into_view_in("current", &file.key);
        }
        if let Some(file) = self.parent.iter().find(|f| f.path == self.tab().cwd) {
            tx.scroll_into_view_in("parent", &file.key);
        }
        tx.set_title(format!(
            "{} — Yazi Rune",
            self.display_location(&self.tab().cwd)
        ));
    }

    pub fn hover(&mut self, path: &Path, tx: &mut Tx) {
        if let Some(i) = self
            .tab()
            .visible
            .iter()
            .position(|&i| self.tab().files[i].path == path)
        {
            self.tab_mut().cursor = i;
            self.peek();
            self.restore_cursor(tx);
        }
    }

    fn arrow(&mut self, step: &str, tx: &mut Tx) {
        let len = self.tab().visible.len();
        if len == 0 {
            return;
        }
        let old = self.tab().cursor;
        let step: Step = step.parse().unwrap_or_default();
        let new = step.add(old, len, self.page_size, 0, 5);
        if old != new {
            if let Some(visual) = &mut self.tab_mut().visual {
                visual.wraps += match step {
                    Step::Prev if new > old => -1,
                    Step::Next if new < old => 1,
                    _ => 0,
                };
            }
            self.tab_mut().cursor = new;
            self.peek();
            self.restore_cursor(tx);
        }
    }

    pub fn cd(&mut self, path: PathBuf, tx: &mut Tx, history: bool) {
        if path == self.tab().cwd {
            return;
        }
        let tab = self.tab_mut();
        tab.finish_visual();
        if let Some(file) = tab.file() {
            tab.hovered.insert(tab.cwd.clone(), file.path.clone());
        }
        if history {
            tab.history.truncate(tab.history_cursor + 1);
            tab.history.push(path.clone());
            tab.history_cursor = tab.history.len() - 1;
        }
        tab.cwd = path;
        tab.files.clear();
        tab.visible.clear();
        tab.cursor = 0;
        tab.filter.clear();
        tab.search.clear();
        self.message = None;
        self.revision += 1;
        tx.scroll_to_instant("current", 0.0, 0.0);
        self.restore_cursor(tx);
        self.reload();
    }

    fn remote_place(&self, path: &Path) -> Option<&Place> {
        self.places
            .iter()
            .filter(|place| {
                !place.uri.starts_with("file:")
                    && place
                        .path
                        .as_deref()
                        .is_some_and(|root| path.starts_with(root))
            })
            .max_by_key(|place| {
                place
                    .path
                    .as_ref()
                    .map_or(0, |root| root.components().count())
            })
    }

    fn remote_io(&self, path: &Path) -> Option<operations::RemoteRoot> {
        let place = self.remote_place(path)?;
        Some(operations::RemoteRoot {
            path: place.path.clone()?,
            uri: place.uri.clone(),
        })
    }

    fn remote_root(&self, path: &Path) -> bool {
        self.places.iter().any(|place| {
            !place.uri.starts_with("file:") && place.unmount && place.path.as_deref() == Some(path)
        })
    }

    pub fn location_uri(&self, path: &Path) -> String {
        if let Some(place) = self.remote_place(path)
            && let Some(root) = &place.path
            && let Ok(relative) = path.strip_prefix(root)
            && let Ok(mut uri) = url::Url::parse(&place.uri)
        {
            if let Ok(mut segments) = uri.path_segments_mut() {
                segments.pop_if_empty();
                for component in relative.components() {
                    segments.push(&component.as_os_str().to_string_lossy());
                }
            }
            return uri.into();
        }
        gio::File::for_path(path).uri().into()
    }

    pub fn display_location(&self, path: &Path) -> String {
        if self.remote_place(path).is_some() {
            self.location_uri(path)
        } else {
            path.display().to_string()
        }
    }

    pub fn folder_name(&self, path: &Path) -> String {
        if let Some(place) = self.remote_place(path)
            && place.path.as_deref() == Some(path)
        {
            return place.name.clone();
        }
        path.file_name()
            .map(|name| name.to_string_lossy().into_owned())
            .unwrap_or_else(|| "/".into())
    }

    pub fn reveal_location(
        &mut self,
        location: locations::Location,
        folders: bool,
        properties: bool,
        tx: &mut Tx,
    ) {
        match location {
            locations::Location::Path(path) => self.reveal(path, folders, properties, tx),
            locations::Location::Uri(uri) => {
                if uri.starts_with("trash:") {
                    self.command("trash", tx);
                    return;
                }
                if self.mounts.busy() {
                    self.message = Some("A device operation is already running".into());
                    return;
                }
                self.mount_intent = Some((folders, properties));
                self.mount_action(mounts::Action::Connect(uri));
            }
        }
    }

    pub fn reveal(&mut self, path: PathBuf, folders: bool, properties: bool, tx: &mut Tx) {
        let cwd = if folders {
            path.clone()
        } else {
            path.parent()
                .unwrap_or(std::path::Path::new("/"))
                .to_path_buf()
        };
        let same_directory = cwd == self.tab().cwd;
        if path
            .file_name()
            .is_some_and(|name| name.as_encoded_bytes().starts_with(b"."))
        {
            self.preference.show_hidden = true;
        }
        self.prompt = None;
        self.panel = None;
        self.help = false;
        self.pending.clear();
        self.properties = None;
        self.properties_worker.cancel();
        self.spot = properties;
        if !folders {
            self.tab_mut().hovered.insert(cwd.clone(), path);
        }
        self.cd(cwd, tx, true);
        if same_directory {
            let tab = self.tab_mut();
            tab.finish_visual();
            tab.files.clear();
            tab.visible.clear();
            tab.filter.clear();
            tab.search.clear();
            self.reload();
        }
    }

    fn load_properties(&mut self) {
        self.properties = None;
        if let Some(path) = self.tab().file().map(|f| f.path.clone()) {
            let uri = self
                .remote_io(&path)
                .map(|root| file::remote_uri(&root, &path).uri().to_string());
            self.properties_worker
                .request((path, uri), |(path, uri)| locations::properties(path, uri));
        }
    }

    pub fn open_place(&mut self, place: &Place, tx: &mut Tx) {
        if place.uri.starts_with("trash:") {
            self.command("trash", tx);
            return;
        }

        if !place.mounted && place.volume.is_some() {
            self.mount_action(mounts::Action::Mount(place.clone()));
        } else if let Ok(path) = locations::local_uri(&place.uri) {
            self.panel = None;
            self.cd(path, tx, true);
        } else {
            self.mount_action(mounts::Action::Connect(place.uri.clone()));
        }
    }

    pub fn mount_action(&mut self, action: mounts::Action) {
        if let Err(error) = self.mounts.push(action) {
            self.mount_intent = None;
            self.message = Some(error);
        }
    }

    pub fn authenticate(&mut self, anonymous: bool) {
        if let Some(mut auth) = self.authentication.take() {
            let reply = mounts::Credentials {
                user: std::mem::take(&mut auth.user.text),
                password: std::mem::take(&mut auth.password.text).into(),
                domain: std::mem::take(&mut auth.domain.text),
                anonymous,
            };
            let _ = auth.reply.send(Some(reply));
        }
    }

    pub fn cancel_mount(&mut self) {
        self.mounts.cancel();
        self.mount_intent = None;
        self.authentication = None;
        self.question = None;
    }

    pub fn launch_app(&mut self, id: String, default: bool) {
        if let Some(applications) = self.applications.clone() {
            self.panel = None;
            if self.headless {
                self.message = Some(format!("Open with: {id}"));
            } else {
                self.desktop_worker
                    .request((applications, id, default), |(apps, id, default)| {
                        locations::launch(apps, id, default)
                    });
            }
        }
    }

    pub fn enter(&mut self, tx: &mut Tx, open: bool) {
        let Some(file) = self.tab().file().cloned() else {
            return;
        };
        if file.directory {
            self.cd(file.path, tx, true);
        } else if open && !self.headless {
            let target = file.path.to_string_lossy();
            if let Err(e) = tx.open_url(&target) {
                self.message = Some(format!("Could not open file: {e}"));
            }
        } else if open {
            self.message = Some(format!("Open: {}", file.path.display()));
        }
    }

    pub fn open_preview_link(&mut self, path: &Path, link: &str, tx: &mut Tx) {
        let target = match url::Url::from_file_path(path)
            .ok()
            .and_then(|base| base.join(link).ok())
        {
            Some(target) => target,
            None => {
                self.message = Some(format!("Could not open link: {link}"));
                return;
            }
        };
        if let Some(anchor) = target.fragment()
            && target.to_file_path().ok().as_deref() == Some(path)
            && let Preview::Markdown { source, .. } = &self.preview
        {
            if anchor.is_empty() {
                tx.scroll_to_y("preview", 0.0);
                return;
            }
            for (index, block) in rune_kit::markdown::parse_cached(source).iter().enumerate() {
                if let rune_kit::markdown::Block::Heading(_, inline) = block {
                    let slug: String = inline
                        .text
                        .to_lowercase()
                        .chars()
                        .filter(|c| c.is_alphanumeric() || matches!(c, ' ' | '-' | '_'))
                        .map(|c| if c == ' ' { '-' } else { c })
                        .collect();
                    if slug == anchor {
                        tx.scroll_into_view(format!("preview/markdown/b{index}"));
                        return;
                    }
                }
            }
            self.message = Some(format!("Heading not found: {anchor}"));
        } else if self.headless {
            self.message = Some(format!("Open: {target}"));
        } else if let Err(error) = tx.open_url(target.as_str()) {
            self.message = Some(format!("Could not open link: {error}"));
        }
    }

    pub fn show_prompt(&mut self, prompt: Prompt, tx: &mut Tx) {
        let value = match prompt {
            Prompt::Filter => self.tab().filter.clone(),
            Prompt::Cd => self.display_location(&self.tab().cwd),
            Prompt::TabRename => self.tab().name.clone().unwrap_or_default(),
            Prompt::Rename => self
                .tab()
                .file()
                .map(|f| f.name.clone())
                .unwrap_or_default(),
            Prompt::Archive => format!(
                "{}.zip",
                self.tab()
                    .file()
                    .map(|f| f
                        .path
                        .file_stem()
                        .unwrap_or_default()
                        .to_string_lossy()
                        .into_owned())
                    .unwrap_or_else(|| "archive".into())
            ),
            Prompt::Permissions => self
                .tab()
                .file()
                .map(|file| format!("{:o}", file.mode & 0o7777))
                .unwrap_or_else(|| "644".into()),
            _ => String::new(),
        };
        self.input = TextEdit::new(value);
        if matches!(
            prompt,
            Prompt::Cd | Prompt::Rename | Prompt::Permissions | Prompt::Archive
        ) {
            self.input.set_selection(0, self.input.text.len());
        }
        self.input.focused = true;
        self.prompt = Some(prompt);
        self.pending.clear();
        tx.instant();
    }

    pub fn edit_prompt(&mut self, tx: &mut Tx) {
        if self.prompt == Some(Prompt::Filter) {
            self.tab_mut().filter = self.input.text.clone();
            self.reorder();
            self.peek();
            self.restore_cursor(tx);
        }
    }

    pub fn submit_prompt(&mut self, tx: &mut Tx) {
        let value = self.input.text.clone();
        let prompt = self.prompt.take();
        match prompt {
            Some(Prompt::Filter) => {
                self.tab_mut().filter = value;
                self.reorder();
                self.peek();
                self.restore_cursor(tx);
            }
            Some(Prompt::Cd) => match locations::Location::parse(&value, &self.tab().cwd) {
                Ok(locations::Location::Path(path)) => self.cd(path, tx, true),
                Ok(location) => self.reveal_location(location, true, false, tx),
                Err(error) => self.message = Some(error),
            },
            Some(Prompt::Search) => {
                self.tab_mut().search = value;
                self.tab_mut().filter.clear();
                self.reload();
            }
            Some(Prompt::OpenCommand) => {
                if let Some(apps) = self.applications.clone() {
                    if self.headless {
                        self.message = Some(format!("Open with command: {value}"));
                    } else {
                        self.desktop_worker
                            .request((apps.paths, value), |(paths, command)| {
                                locations::launch_custom(paths, command)
                            });
                    }
                }
            }
            Some(Prompt::Connect) => match locations::Location::parse(&value, &self.tab().cwd) {
                Ok(location) => self.reveal_location(location, true, false, tx),
                Err(error) => self.message = Some(error),
            },
            Some(Prompt::TabRename) => self.tab_mut().name = (!value.is_empty()).then_some(value),
            Some(Prompt::Find | Prompt::FindPrevious) => {
                self.find = value;
                self.find_arrow(prompt == Some(Prompt::FindPrevious), tx);
            }
            Some(Prompt::Create) if !value.trim().is_empty() => {
                let path = expand_path(value.trim_end_matches('/'), &self.tab().cwd);
                self.enqueue(
                    Operation::Create {
                        path,
                        directory: value.ends_with('/'),
                    },
                    false,
                );
            }
            Some(Prompt::Rename) => {
                let sources = self.chosen();
                if value.is_empty() || value == "." || value == ".." || value.contains('/') {
                    self.message = Some("Enter a filename without directory separators".into());
                } else if sources.len() > 1
                    && !["{name}", "{stem}", "{ext}", "{n}"]
                        .iter()
                        .any(|token| value.contains(token))
                {
                    self.message =
                        Some("Batch rename requires {name}, {stem}, {ext}, or {n}".into());
                } else {
                    let pairs = sources
                        .iter()
                        .enumerate()
                        .map(|(index, source)| {
                            let name = value
                                .replace(
                                    "{name}",
                                    &source.file_name().unwrap_or_default().to_string_lossy(),
                                )
                                .replace(
                                    "{stem}",
                                    &source.file_stem().unwrap_or_default().to_string_lossy(),
                                )
                                .replace(
                                    "{ext}",
                                    &source.extension().unwrap_or_default().to_string_lossy(),
                                )
                                .replace("{n}", &(index + 1).to_string());
                            (source.clone(), source.with_file_name(name))
                        })
                        .collect();
                    self.enqueue(Operation::Rename(pairs), false);
                }
            }
            Some(Prompt::Permissions) => {
                let mut words = value.split_whitespace();
                let mode = words.next().unwrap_or_default().trim_start_matches("0o");
                match u32::from_str_radix(mode, 8) {
                    Ok(mode) if mode <= 0o7777 => {
                        let recursive =
                            words.any(|word| matches!(word, "-r" | "-R" | "--recursive"));
                        let sources = self.chosen();
                        self.enqueue(
                            Operation::Permissions {
                                sources,
                                mode,
                                recursive,
                            },
                            false,
                        );
                    }
                    _ => {
                        self.message =
                            Some("Enter an octal permission mode, such as 644 or 755".into())
                    }
                }
            }
            Some(Prompt::Archive) => {
                let sources = self.chosen();
                if !sources.is_empty() && !value.trim().is_empty() {
                    let destination = expand_path(value.trim(), &self.tab().cwd);
                    self.enqueue(
                        Operation::Archive {
                            sources,
                            destination,
                        },
                        false,
                    );
                }
            }
            _ => {}
        }
        tx.blur();
    }

    pub fn chosen(&mut self) -> Vec<PathBuf> {
        self.tab_mut().finish_visual();
        if self.tab().selected.is_empty() {
            self.tab()
                .file()
                .map(|file| vec![file.path.clone()])
                .unwrap_or_default()
        } else {
            self.tab().selected.iter().cloned().collect()
        }
    }

    fn paste_files(&mut self, files: Yank, destination: PathBuf, force: bool) {
        if files.paths.is_empty() {
            self.message = Some("The clipboard contains no files".into());
            return;
        }
        self.yank = Some(files.clone());
        let sources = files.paths;
        let operation = if files.cut {
            Operation::Move {
                sources,
                destination,
            }
        } else {
            Operation::Copy {
                sources,
                destination,
            }
        };
        self.enqueue(operation, force);
    }

    fn selected_trash(&self) -> Vec<String> {
        if self.trash_selected.is_empty() {
            self.trash
                .as_ref()
                .and_then(|entries| entries.get(self.trash_cursor))
                .map(|entry| vec![entry.uri.clone()])
                .unwrap_or_default()
        } else {
            self.trash_selected.iter().cloned().collect()
        }
    }

    pub fn enqueue(&mut self, operation: Operation, force: bool) {
        self.message = Some(format!("Queued: {}", operation.title()));
        self.queue.remote_roots = self
            .places
            .iter()
            .filter_map(|place| {
                if place.uri.starts_with("file:") || place.uri.starts_with("trash:") {
                    return None;
                }
                place.path.clone().map(|path| operations::RemoteRoot {
                    path,
                    uri: place.uri.clone(),
                })
            })
            .collect();
        self.queue.push(operation, force);
        self.tab_mut().selected.clear();
    }

    fn find_arrow(&mut self, previous: bool, tx: &mut Tx) {
        let len = self.tab().visible.len();
        if len == 0 || self.find.is_empty() {
            return;
        }
        let cursor = self.tab().cursor;
        for offset in 1..=len {
            let i = if previous {
                (cursor + len - offset) % len
            } else {
                (cursor + offset) % len
            };
            if smart_contains(&self.tab().entry(i).name, &self.find) {
                self.tab_mut().cursor = i;
                self.peek();
                self.restore_cursor(tx);
                return;
            }
        }
        self.message = Some(format!("No file matches {}", self.find));
    }

    fn request_drop_preference(
        &mut self,
        token: u32,
        paths: Vec<PathBuf>,
        destination: PathBuf,
        local: bool,
    ) {
        if !local {
            self.drop_preference.cancel();
            if let Some(dnd) = &mut self.dnd {
                dnd.prefer(token, 4);
            }
            return;
        }
        if self.remote_place(&destination).is_some()
            || paths.iter().any(|path| self.remote_place(path).is_some())
        {
            self.drop_preference.cancel();
            let moving = self.remote_place(&destination).is_some_and(|target| {
                paths.iter().all(|path| {
                    self.remote_place(path)
                        .is_some_and(|source| source.uri == target.uri)
                })
            });
            if let Some(dnd) = &mut self.dnd {
                dnd.prefer(token, if moving { 2 } else { 1 });
            }
            return;
        }
        self.drop_preference.request(
            (token, paths, destination),
            |(token, paths, destination)| (token, crate::dnd::preferred(&paths, &destination)),
        );
    }

    fn drop_destination(&self, point: [f32; 2]) -> PathBuf {
        self.drop_targets
            .borrow()
            .iter()
            .rev()
            .find(|target| target.contains(point))
            .map(|target| target.path.clone())
            .unwrap_or_else(|| self.tab().cwd.clone())
    }

    pub fn drag_file(&mut self, path: &Path, drag: &mut rune::Drag) {
        if drag.phase != rune::Phase::Move || drag.data != 0.0 || drag.dx.hypot(drag.dy) < 5.0 {
            return;
        }
        let paths = if self.tab().selected.contains(path) {
            self.chosen()
        } else {
            vec![path.to_path_buf()]
        };
        let uris = paths.iter().map(|path| self.location_uri(path)).collect();
        if let Some(dnd) = &mut self.dnd {
            match dnd.start(uris) {
                Ok(true) => drag.data = 1.0,
                Ok(false) => {}
                Err(error) => {
                    self.message = Some(error);
                    drag.data = 1.0;
                }
            }
        }
    }

    pub fn accept_drop(&mut self, drop: crate::dnd::Drop, action: u32) {
        let operation = match action {
            1 => Operation::Copy {
                sources: drop.paths,
                destination: drop.destination,
            },
            2 => Operation::Move {
                sources: drop.paths,
                destination: drop.destination,
            },
            8 => Operation::Link {
                sources: drop.paths,
                destination: drop.destination,
                relative: false,
                hard: false,
            },
            _ => {
                self.cancel_drop(drop.token);
                return;
            }
        };
        let previous = self.queue.tasks.len();
        self.enqueue(operation, false);
        if self.queue.tasks.len() > previous {
            if let Some(task) = self.queue.tasks.last()
                && let Some(dnd) = &mut self.dnd
            {
                let acknowledged = if drop.action == 4 {
                    if action == 8 { 1 } else { action }
                } else if drop.action == 2 && action != 2 {
                    // A MOVE acknowledgement can make an external source delete its files.
                    // Cancelling the offer after our copy/link preserves those source files.
                    0
                } else if drop.action == 8 {
                    1
                } else {
                    drop.action
                };
                dnd.track(task.id, drop.token, acknowledged);
            }
        } else {
            self.cancel_drop(drop.token);
            self.message = Some("Could not queue the dropped files".into());
        }
    }

    pub fn cancel_drop(&mut self, token: u32) {
        if let Some(dnd) = &mut self.dnd {
            dnd.cancel(token);
        }
    }

    pub fn close(&mut self, tx: &mut Tx) {
        use gio::prelude::CancellableExt;
        self.closing = true;
        self.directory_io.cancel();
        self.preview_io.cancel();
        self.queue.cancel_all();
        self.cancel_mount();
        if self.queue.active().is_none() && !self.mounts.busy() {
            self.dnd = None;
            tx.quit();
        } else {
            self.message = Some("Cancelling operations before closing…".into());
            tx.wake_after(Duration::from_millis(60));
        }
    }

    pub fn command(&mut self, command: &str, tx: &mut Tx) {
        let mut words = command.split_whitespace();
        let action = words.next().unwrap_or_default();
        let arg = words.next().unwrap_or_default();
        match action {
            "yank" => {
                let paths = self.chosen();
                if !paths.is_empty() {
                    let cut = command.contains("--cut");
                    self.message = Some(format!(
                        "{} {} item(s)",
                        if cut { "Cut" } else { "Copied" },
                        paths.len()
                    ));
                    let files = Yank { paths, cut };
                    if !self.headless {
                        if std::env::var_os("WAYLAND_DISPLAY").is_some() {
                            self.clipboard.write(&files);
                        } else {
                            tx.copy_rich(
                                rune::ClipboardContent::default().with_files(files.paths.clone()),
                            );
                        }
                    }
                    self.yank = Some(files);
                }
            }
            "unyank" => {
                self.yank = None;
                self.message = Some("File clipboard cleared".into());
            }
            "paste" => {
                let destination = self.tab().cwd.clone();
                let force = command.contains("--force");
                if self.headless {
                    if let Some(files) = self.yank.clone() {
                        self.paste_files(files, destination, force);
                    } else {
                        self.message = Some("Copy or cut files first with y or x".into());
                    }
                } else if std::env::var_os("WAYLAND_DISPLAY").is_some() {
                    self.clipboard.paste(destination, force);
                } else {
                    tx.read_clipboard(move |s: &mut State, content, _| {
                        let paths = content.files().to_vec();
                        let cut = s.yank.as_ref().is_some_and(|y| y.cut && y.paths == paths);
                        s.paste_files(Yank { paths, cut }, destination, force);
                    });
                }
            }
            "link" | "hardlink" => {
                if let Some(yank) = &self.yank {
                    let sources = yank.paths.clone();
                    if !sources.is_empty() {
                        self.enqueue(
                            Operation::Link {
                                sources,
                                destination: self.tab().cwd.clone(),
                                relative: command.contains("--relative"),
                                hard: action == "hardlink",
                            },
                            false,
                        );
                    }
                } else {
                    self.message = Some("Copy files first with y".into());
                }
            }
            "remove" => {
                let sources = self.chosen();
                if !sources.is_empty() {
                    self.confirmation = Some(if command.contains("--permanently") {
                        Operation::Delete(sources)
                    } else {
                        Operation::Trash(sources)
                    });
                }
            }
            "create" => self.show_prompt(Prompt::Create, tx),
            "rename" => {
                if self.tab().file().is_some() {
                    self.show_prompt(Prompt::Rename, tx);
                }
            }
            "permissions" => {
                if self.tab().file().is_some() {
                    self.show_prompt(Prompt::Permissions, tx);
                }
            }
            "archive" => {
                if self.tab().file().is_some() {
                    self.show_prompt(Prompt::Archive, tx);
                }
            }
            "extract" => {
                if let Some(file) = self.tab().file() {
                    let source = file.path.clone();
                    let destination = self.tab().cwd.join(crate::archive::stem(&source));
                    self.enqueue(
                        Operation::Extract {
                            source,
                            destination,
                        },
                        false,
                    );
                }
            }
            "undo" => {
                self.message = Some(match self.queue.undo() {
                    Ok(()) => "Queued: Undo".into(),
                    Err(error) => error,
                });
            }
            "tasks:show" => self.tasks_open = !self.tasks_open,
            "task_cancel" => {
                if let Some(task) = self.queue.active() {
                    let id = task.id;
                    self.queue.cancel(id);
                }
            }
            "restore" if self.panel == Some(Panel::Trash) => {
                let uris = self.selected_trash();
                self.enqueue(Operation::Restore(uris), false);
            }
            "trash_select" => {
                if let Some(entries) = &self.trash {
                    let selected: Vec<_> = if command.contains("--all") {
                        entries.iter().map(|entry| entry.uri.clone()).collect()
                    } else {
                        entries
                            .get(self.trash_cursor)
                            .map(|entry| vec![entry.uri.clone()])
                            .unwrap_or_default()
                    };
                    for uri in selected {
                        if !self.trash_selected.remove(&uri) {
                            self.trash_selected.insert(uri);
                        }
                    }
                }
            }
            "trash_delete" | "trash_empty" => {
                let selected = self.selected_trash();
                if let Some(entries) = &self.trash {
                    let uris: Vec<_> = entries
                        .iter()
                        .filter(|entry| action == "trash_empty" || selected.contains(&entry.uri))
                        .map(|entry| entry.uri.clone())
                        .collect();
                    if !uris.is_empty() {
                        self.confirmation = Some(Operation::DeleteTrash(uris));
                    }
                }
            }
            "trash" | "refresh_trash" => {
                self.panel = Some(Panel::Trash);
                self.trash = None;
                self.trash_worker.request((), |_| crate::trash::read());
            }
            "restore" => self.message = Some("Open Trash and select the items to restore".into()),
            "quit" => {
                if !command.contains("--no-cwd-file")
                    && let Some(path) = &self.cwd_file
                    && let Err(e) = fs::write(path, self.tab().cwd.as_os_str().as_encoded_bytes())
                {
                    self.message = Some(format!("Could not save cwd: {e}"));
                    return;
                }
                self.close(tx);
            }
            "close" | "tab_close" => {
                if self.tabs.len() == 1 {
                    self.command("quit", tx);
                } else {
                    self.tabs.remove(self.active);
                    self.active = self.active.min(self.tabs.len() - 1);
                    self.reload();
                }
            }
            "escape" => {
                if self.panel.take().is_some() {
                } else if self.help {
                    self.help = false;
                } else if self.spot {
                    self.spot = false;
                } else if self.prompt.take().is_some() {
                    tx.blur();
                } else if self.tab().visual.is_some() {
                    self.tab_mut().finish_visual();
                } else if !self.tab().selected.is_empty() {
                    self.tab_mut().selected.clear();
                } else if !self.tab().filter.is_empty() {
                    self.tab_mut().filter.clear();
                    self.reorder();
                    self.peek();
                } else if !self.tab().search.is_empty() {
                    self.tab_mut().search.clear();
                    self.reload();
                }
                self.message = None;
                self.pending.clear();
            }
            "arrow" => self.arrow(arg, tx),
            "leave" if self.remote_root(&self.tab().cwd) => self.command("places", tx),
            "leave" => {
                if let Some(parent) = self.tab().cwd.parent().map(PathBuf::from) {
                    let path = self.tab().cwd.clone();
                    self.tab_mut().hovered.insert(parent.clone(), path);
                    self.cd(parent, tx, true);
                }
            }
            "enter" => self.enter(tx, false),
            "open" if command.contains("--interactive") => self.command("open_with", tx),
            "open_with" if !arg.is_empty() => {
                let paths = self.chosen();
                let id = arg.to_owned();
                let default = command.contains("--default");
                if self.headless {
                    self.message = Some(format!("Open with: {id}"));
                } else {
                    let uri = paths.first().and_then(|path| {
                        self.remote_io(path)
                            .map(|root| file::remote_uri(&root, path).uri().to_string())
                    });
                    self.desktop_worker.request(
                        (paths, uri, id, default),
                        |(paths, uri, id, default)| {
                            locations::applications(paths, uri)
                                .and_then(|apps| locations::launch(apps, id, default))
                        },
                    );
                }
            }
            "open_with" => {
                let paths = self.chosen();
                if !paths.is_empty() {
                    self.panel = Some(Panel::Applications);
                    self.applications = None;
                    let uri = paths.first().and_then(|path| {
                        self.remote_io(path)
                            .map(|root| file::remote_uri(&root, path).uri().to_string())
                    });
                    self.applications_worker
                        .request((paths, uri), |(paths, uri)| {
                            locations::applications(paths, uri)
                        });
                }
            }
            "search" => self.show_prompt(Prompt::Search, tx),
            "search_stop" => {
                use gio::prelude::CancellableExt;
                self.directory_io.cancel();
                self.search_cancel.store(true, Ordering::Relaxed);
                self.directory.cancel();
                self.tab_mut().loading = false;
                self.message = Some("Search stopped".into());
            }
            "open_command" => {
                self.panel = None;
                self.show_prompt(Prompt::OpenCommand, tx);
            }
            "connect" if !arg.is_empty() => {
                match locations::Location::parse(
                    command.strip_prefix("connect ").unwrap_or(arg),
                    &self.tab().cwd,
                ) {
                    Ok(location) => self.reveal_location(location, true, false, tx),
                    Err(error) => self.message = Some(error),
                }
            }
            "connect" => self.show_prompt(Prompt::Connect, tx),
            "mount_cancel" => self.cancel_mount(),
            "places" => {
                self.panel = Some(Panel::Places);
                self.mounts.refresh_places();
            }
            "bookmark" => {
                self.desktop_worker
                    .request(self.location_uri(&self.tab().cwd), locations::bookmark);
            }
            "refresh_places" => {
                self.mounts.refresh_places();
            }
            "open" => self.enter(tx, true),
            "back" | "forward" => {
                let tab = self.tab_mut();
                let next = if action == "back" {
                    tab.history_cursor.saturating_sub(1)
                } else {
                    (tab.history_cursor + 1).min(tab.history.len() - 1)
                };
                if next != tab.history_cursor {
                    tab.history_cursor = next;
                    let path = tab.history[next].clone();
                    self.cd(path, tx, false);
                }
            }
            "toggle" => {
                self.tab_mut().finish_visual();
                if let Some(path) = self.tab().file().map(|f| f.path.clone())
                    && !self.tab_mut().selected.remove(&path)
                {
                    self.tab_mut().selected.insert(path);
                }
            }
            "toggle_all" => {
                self.tab_mut().finish_visual();
                let files: Vec<_> = self
                    .tab()
                    .visible
                    .iter()
                    .map(|&i| self.tab().files[i].path.clone())
                    .collect();
                for path in files {
                    let select =
                        command.contains("--state=on") || !self.tab().selected.contains(&path);
                    if select {
                        self.tab_mut().selected.insert(path);
                    } else {
                        self.tab_mut().selected.remove(&path);
                    }
                }
            }
            "visual_mode" => {
                self.tab_mut().finish_visual();
                let cursor = self.tab().cursor;
                self.tab_mut().visual = Some(Visual {
                    start: cursor,
                    wraps: 0,
                    unset: command.contains("--unset"),
                });
            }
            "hidden" => {
                self.preference.show_hidden = !self.preference.show_hidden;
                self.reload();
            }
            "filter" => self.show_prompt(Prompt::Filter, tx),
            "find" => self.show_prompt(
                if command.contains("--previous") {
                    Prompt::FindPrevious
                } else {
                    Prompt::Find
                },
                tx,
            ),
            "find_arrow" => self.find_arrow(command.contains("--previous"), tx),
            "cd" if command.contains("--interactive") => self.show_prompt(Prompt::Cd, tx),
            "cd" => {
                let value = command.trim_start_matches("cd").trim();
                match locations::Location::parse(value, &self.tab().cwd) {
                    Ok(locations::Location::Path(path)) => self.cd(path, tx, true),
                    Ok(location) => self.reveal_location(location, true, false, tx),
                    Err(error) => self.message = Some(error),
                }
            }
            "new_window" => {
                if let Err(error) = crate::desktop::spawn_window(
                    self.location_uri(&self.tab().cwd),
                    true,
                    false,
                    Some(&self.config_dir),
                ) {
                    self.message = Some(error.to_string());
                }
            }
            "tab_create" => {
                let path = self.tab().cwd.clone();
                self.tabs.push(Tab::new(path));
                self.active = self.tabs.len() - 1;
                self.reload();
            }
            "tab_switch" | "tab_swap" => {
                let index: isize = arg.parse().unwrap_or(0);
                let next = if command.contains("--relative") || action == "tab_swap" {
                    (self.active as isize + index).rem_euclid(self.tabs.len() as isize) as usize
                } else {
                    index.max(0) as usize
                };
                if next < self.tabs.len() && next != self.active {
                    if action == "tab_swap" {
                        self.tabs.swap(self.active, next);
                    }
                    self.active = next;
                    self.reload();
                }
            }
            "tab_rename" => self.show_prompt(Prompt::TabRename, tx),
            "sort" => {
                if let Some(by) = parse_sort(arg) {
                    self.sort_by = by;
                    self.preference.sort_reverse = command.contains("--reverse=yes");
                    self.reorder();
                    if let Preview::Directory(files) = &mut self.preview {
                        file::sort(
                            files,
                            by,
                            self.preference.sort_reverse,
                            self.preference.sort_sensitive,
                            self.preference.sort_dir_first,
                        );
                    }
                    self.peek();
                    self.restore_cursor(tx);
                } else {
                    self.message = Some(format!("Sort not available yet: {arg}"));
                }
            }
            "linemode" if arg == "none" || arg == "size" || arg == "mtime" => {}
            "seek" => {
                let pos = self.preview_scroll.get();
                let y = (pos[0] + arg.parse::<f32>().unwrap_or(0.0) * 20.0).clamp(0.0, pos[1]);
                tx.scroll_to_y("preview", y);
            }
            "help" => self.help = !self.help,
            "spot" => {
                self.spot = !self.spot;
                if self.spot {
                    self.load_properties();
                }
            }
            "copy" => {
                if let Some(file) = self.tab().file() {
                    let value = match arg {
                        "filename" => file.name.clone(),
                        "name_without_ext" => file
                            .path
                            .file_stem()
                            .unwrap_or_default()
                            .to_string_lossy()
                            .into_owned(),
                        "dirpath" => self.tab().cwd.to_string_lossy().into_owned(),
                        "path" => file.path.to_string_lossy().into_owned(),
                        _ => {
                            self.message = Some(format!("Copy not available yet: {arg}"));
                            return;
                        }
                    };
                    tx.copy(&value);
                    self.message = Some(format!("Copied {value}"));
                }
            }
            _ => self.message = Some(format!("Not available yet: {command}")),
        }
    }

    pub fn key(&mut self, event: &KeyEvent, tx: &mut Tx) -> bool {
        let Some(key) = keymap::key_name(event) else {
            return false;
        };
        if self.drop_decision.is_some() {
            match key.as_str() {
                "c" | "m" | "l" => {
                    if let Some(drop) = self.drop_decision.take() {
                        self.accept_drop(
                            drop,
                            if key == "c" {
                                1
                            } else if key == "m" {
                                2
                            } else {
                                8
                            },
                        );
                    }
                }
                "<Esc>" | "q" => {
                    if let Some(drop) = self.drop_decision.take() {
                        self.cancel_drop(drop.token);
                    }
                }
                _ => {}
            }
            return true;
        }
        if self.authentication.is_some() || self.question.is_some() {
            if matches!(key.as_str(), "<Esc>" | "<C-[>") {
                self.cancel_mount();
                return true;
            }
            if key == "<Enter>" && self.authentication.is_some() {
                self.authenticate(false);
                return true;
            }
            return false;
        }
        if self.queue.conflict.is_some() {
            match key.as_str() {
                "r" | "R" => self.queue.answer(operations::Choice::Replace, key == "R"),
                "m" | "M" => self.queue.answer(operations::Choice::Merge, key == "M"),
                "k" | "K" => self.queue.answer(operations::Choice::KeepBoth, key == "K"),
                "s" | "S" => self.queue.answer(operations::Choice::Skip, key == "S"),
                "c" | "<Esc>" | "<C-[>" => self.queue.answer(operations::Choice::Cancel, false),
                _ => {}
            }
            return true;
        }
        if self.confirmation.is_some() {
            match key.as_str() {
                "y" | "<Enter>" => {
                    if let Some(operation) = self.confirmation.take() {
                        self.enqueue(operation, false);
                    }
                }
                "n" | "<Esc>" | "<C-[>" => self.confirmation = None,
                _ => {}
            }
            return true;
        }
        if self.tasks_open {
            if matches!(key.as_str(), "q" | "<Esc>" | "w") {
                self.tasks_open = false;
                return true;
            }
            return false;
        }
        if self.context_open {
            if matches!(key.as_str(), "q" | "<Esc>") {
                self.context_open = false;
                return true;
            }
            return false;
        }
        if key == "<Esc>" || key == "<C-[>" {
            self.context_open = false;
            self.command("escape", tx);
            return true;
        }
        if self.prompt.is_some() {
            return false;
        }
        if self.panel == Some(Panel::Trash) {
            match key.as_str() {
                "j" | "<Down>" => {
                    self.trash_cursor = (self.trash_cursor + 1)
                        .min(self.trash.as_ref().map_or(0, |v| v.len().saturating_sub(1)))
                }
                "k" | "<Up>" => self.trash_cursor = self.trash_cursor.saturating_sub(1),
                "<Space>" => self.command("trash_select", tx),
                "<C-a>" => self.command("trash_select --all", tx),
                "r" | "<Enter>" => self.command("restore", tx),
                "d" | "<Delete>" => self.command("trash_delete", tx),
                "<F5>" => self.command("refresh_trash", tx),
                "q" => self.panel = None,
                _ => return false,
            }
            if self.panel == Some(Panel::Trash) {
                tx.scroll_into_view_in(
                    "desktop-content",
                    format!("trash-entry-{}", self.trash_cursor),
                );
            }
            return true;
        }
        if self.panel.is_some() {
            if key == "q" {
                self.panel = None;
                return true;
            }
            return false;
        }
        if self.help || self.spot {
            if key == "q" || key == "<Tab>" {
                self.help = false;
                self.spot = false;
                return true;
            }
            return false;
        }
        if key == "<C-z>" {
            self.command("undo", tx);
            return true;
        }
        self.message = None;
        self.pending.push(key.clone());
        let candidates: Vec<_> = self
            .bindings
            .iter()
            .filter(|b| b.on.list().starts_with(&self.pending))
            .collect();
        if let Some(binding) = candidates
            .iter()
            .find(|b| b.on.list().len() == self.pending.len())
        {
            let commands = binding.run.list().to_vec();
            self.pending.clear();
            for command in commands {
                self.command(&command, tx);
            }
            tx.instant();
            return true;
        }
        if !candidates.is_empty() {
            return true;
        }
        let retry = self.pending.len() > 1;
        self.pending.clear();
        if retry {
            return self.key(event, tx);
        }
        false
    }

    pub fn snapshot(&self) -> serde_json::Value {
        let tab = self.tab();
        serde_json::json!({
            "cwd": tab.cwd, "hovered": tab.file().map(|f| &f.path),
            "cursor": tab.cursor, "files": tab.visible.iter().map(|&i| &tab.files[i].name).collect::<Vec<_>>(),
            "selected": tab.visible.iter().enumerate().filter(|(i, _)| tab.selected(*i)).map(|(_, &i)| &tab.files[i].path).collect::<Vec<_>>(),
            "selection_count": tab.selected.len(), "visual": tab.visual, "tab_count": self.tabs.len(), "active_tab": self.active, "native_drag_drop": self.dnd.is_some(), "drop_hover": self.drop_hover, "drop_choice": self.drop_decision.is_some(),
            "show_hidden": self.preference.show_hidden, "filter": tab.filter, "search": tab.search, "prompt": self.prompt, "find": self.find,
            "location": self.display_location(&self.tab().cwd),
            "mount_busy": self.mounts.busy(), "authentication": self.authentication.is_some(), "question": self.question.is_some(),
            "panel": self.panel, "places": self.places, "properties": self.properties, "applications": self.applications, "trash": self.trash, "trash_selected": self.trash_selected, "trash_cursor": self.trash_cursor,
            "preview_scroll": self.preview_scroll.get(), "spot": self.spot, "help": self.help,
            "tasks": self.queue.tasks, "undo_available": self.queue.undo_available(), "confirmation": self.confirmation.as_ref().map(Operation::title),
            "conflict": self.queue.conflict.as_ref().map(|c| serde_json::json!({"source": c.source, "destination": c.destination})),
            "yank": self.yank.as_ref().map(|y| serde_json::json!({"paths": y.paths, "cut": y.cut})),
            "preview": self.preview.kind(), "loading": tab.loading, "message": self.message,
        })
    }
}

impl Drop for State {
    fn drop(&mut self) {
        if let Some(export) = &self.export {
            *export.borrow_mut() = self.snapshot();
        }
    }
}

pub fn home() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/"))
}

pub fn expand_path(value: &str, cwd: &Path) -> PathBuf {
    let path = if value == "~" {
        home()
    } else if let Some(rest) = value.strip_prefix("~/") {
        home().join(rest)
    } else {
        PathBuf::from(value)
    };
    if path.is_absolute() {
        path
    } else {
        cwd.join(path)
    }
}

fn parse_sort(value: &str) -> Option<SortBy> {
    match value {
        "alphabetical" => Some(SortBy::Alphabetical),
        "natural" => Some(SortBy::Natural),
        "extension" => Some(SortBy::Extension),
        "size" => Some(SortBy::Size),
        "mtime" => Some(SortBy::Modified),
        _ => None,
    }
}

pub(crate) fn smart_contains(haystack: &str, needle: &str) -> bool {
    if needle.chars().any(char::is_uppercase) {
        haystack.contains(needle)
    } else {
        haystack.to_lowercase().contains(&needle.to_lowercase())
    }
}
