use std::{collections::BTreeSet, process::Command, sync::LazyLock};

use rune::{Family, TextStyle};
use serde::Serialize;

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Role {
    Interface,
    Files,
    Preview,
}

impl Role {
    pub fn prefix(self) -> &'static str {
        match self {
            Self::Interface => "ui",
            Self::Files => "list",
            Self::Preview => "preview",
        }
    }
    pub fn title(self) -> &'static str {
        match self {
            Self::Interface => "Interface font",
            Self::Files => "File-list font",
            Self::Preview => "Preview font",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct Font {
    pub family: String,
    pub points: f32,
}

impl Font {
    pub fn parse(description: &str) -> Option<Self> {
        let (name, size) = description.trim().rsplit_once(char::is_whitespace)?;
        let (size, pixels) = size
            .strip_suffix("px")
            .map_or((size, false), |size| (size, true));
        let mut points: f32 = size.parse().ok()?;
        if pixels {
            points *= 72.0 / 96.0;
        }
        if !points.is_finite() || points <= 0.0 {
            return None;
        }
        let mut words: Vec<_> = name.split_whitespace().collect();
        while words.len() > 1
            && matches!(
                words.last()?.to_ascii_lowercase().as_str(),
                "regular"
                    | "normal"
                    | "book"
                    | "medium"
                    | "bold"
                    | "semibold"
                    | "semi-bold"
                    | "light"
                    | "thin"
                    | "heavy"
                    | "italic"
                    | "oblique"
            )
        {
            words.pop();
        }
        let family = words.join(" ").trim_end_matches(',').to_owned();
        (!family.is_empty()).then_some(Self { family, points })
    }
}

pub fn installed() -> &'static BTreeSet<String> {
    static FAMILIES: LazyLock<BTreeSet<String>> = LazyLock::new(|| {
        Command::new("fc-list")
            .arg("--format=%{family[0]}\n")
            .output()
            .ok()
            .filter(|output| output.status.success())
            .map(|output| {
                String::from_utf8_lossy(&output.stdout)
                    .lines()
                    .map(str::to_owned)
                    .collect()
            })
            .unwrap_or_default()
    });
    &FAMILIES
}

pub fn canonical(family: &str) -> Option<String> {
    if family.eq_ignore_ascii_case("Inter") {
        return Some("Inter".into());
    }
    installed()
        .iter()
        .find(|name| name.eq_ignore_ascii_case(family))
        .cloned()
}

pub fn named(family: &str) -> Family {
    if family.eq_ignore_ascii_case("Inter") {
        Family::Named("Inter")
    } else {
        installed()
            .iter()
            .find(|name| name.eq_ignore_ascii_case(family))
            .map_or(Family::Sans, |name| Family::Named(name))
    }
}

pub fn fallback(mono: bool) -> Font {
    static SANS: LazyLock<Font> = LazyLock::new(|| resolve("sans-serif"));
    static MONO: LazyLock<Font> = LazyLock::new(|| resolve("monospace"));
    if mono { MONO.clone() } else { SANS.clone() }
}

fn resolve(generic: &str) -> Font {
    let family = Command::new("fc-match")
        .args(["--format=%{family[0]}", generic])
        .output()
        .ok()
        .filter(|output| output.status.success())
        .and_then(|output| String::from_utf8(output.stdout).ok())
        .filter(|family| !family.trim().is_empty())
        .unwrap_or_else(|| {
            if generic == "monospace" {
                "ui-monospace"
            } else {
                "Inter"
            }
            .into()
        });
    Font {
        family,
        points: 10.0,
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Metrics {
    pub ui: f32,
    pub list: f32,
    pub list_family: Family,
    pub preview: f32,
}

impl Metrics {
    pub fn font(self, size: f32, weight: f32) -> TextStyle {
        TextStyle::new(size * self.ui / 13.0, weight)
    }
    pub fn code(self) -> TextStyle {
        TextStyle::new(self.preview, 400.0)
            .mono()
            .lh(self.code_height())
    }
    pub fn list(self) -> TextStyle {
        TextStyle::new(self.list, 400.0).family(self.list_family)
    }
    pub fn code_height(self) -> f32 {
        (self.preview * 1.5).ceil()
    }
    pub fn height(self, height: f32) -> f32 {
        (height + (self.ui - 13.0).max(0.0) * 1.25).ceil()
    }
}
