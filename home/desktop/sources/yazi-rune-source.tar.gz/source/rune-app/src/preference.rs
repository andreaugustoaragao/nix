use std::{collections::BTreeMap, fs, path::PathBuf};

use rune::{Latest, Waker};
use serde::{Deserialize, Serialize};

use crate::file::SortBy;

#[derive(Clone, Copy, PartialEq, Eq, Deserialize, Serialize)]
#[serde(default)]
pub struct Preference {
    pub show_hidden: bool,
    pub sort_sensitive: bool,
    pub sort_dir_first: bool,
    pub sort_reverse: bool,
    pub sort_by: SortBy,
}

impl Default for Preference {
    fn default() -> Self {
        Self {
            show_hidden: false,
            sort_sensitive: false,
            sort_dir_first: true,
            sort_reverse: true,
            sort_by: SortBy::Modified,
        }
    }
}

type Changes = BTreeMap<String, Option<Preference>>;

pub struct Preferences {
    defaults: Preference,
    folders: BTreeMap<String, Preference>,
    pending: Changes,
    worker: Latest<(Changes, Result<(), String>)>,
    running: bool,
    pub error: Option<String>,
    path: PathBuf,
}

impl Preferences {
    pub fn new(path: PathBuf, defaults: Preference) -> Self {
        let result = match fs::read(&path) {
            Ok(data) => serde_json::from_slice(&data).map_err(|error| error.to_string()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(BTreeMap::new()),
            Err(error) => Err(error.to_string()),
        };
        let (folders, error) = match result {
            Ok(folders) => (folders, None),
            Err(error) => (BTreeMap::new(), Some(error)),
        };
        Self {
            defaults,
            folders,
            pending: BTreeMap::new(),
            worker: Latest::default(),
            running: false,
            error,
            path,
        }
    }

    pub fn get(&self, uri: &str) -> Preference {
        self.folders.get(uri).copied().unwrap_or(self.defaults)
    }

    pub fn customized(&self, uri: &str) -> bool {
        self.folders.contains_key(uri)
    }

    pub fn set(&mut self, uri: String, preference: Option<Preference>) {
        if let Some(preference) = preference {
            self.folders.insert(uri.clone(), preference);
        } else {
            self.folders.remove(&uri);
        }
        self.pending.insert(uri, preference);
        self.error = None;
    }

    pub fn set_waker(&mut self, waker: Waker) {
        self.worker.set_waker(waker);
    }

    pub fn saving(&self) -> bool {
        self.running || (self.error.is_none() && !self.pending.is_empty())
    }

    pub fn poll(&mut self) -> Option<Result<(), String>> {
        let result = self.worker.take().map(|(changes, result)| {
            self.running = false;
            if let Err(error) = &result {
                for (uri, preference) in changes {
                    self.pending.entry(uri).or_insert(preference);
                }
                self.error = Some(error.clone());
            }
            result
        });
        if !self.running && self.error.is_none() && !self.pending.is_empty() {
            self.running = true;
            self.worker.request(
                (self.path.clone(), std::mem::take(&mut self.pending)),
                |(path, changes)| {
                    let result = save(path, &changes);
                    (changes, result)
                },
            );
        }
        result
    }
}

fn save(path: PathBuf, changes: &Changes) -> Result<(), String> {
    let parent = path
        .parent()
        .ok_or("Folder views need a configuration directory")?;
    fs::create_dir_all(parent).map_err(|error| error.to_string())?;
    let lock = fs::OpenOptions::new()
        .create(true)
        .truncate(false)
        .read(true)
        .write(true)
        .open(path.with_extension("lock"))
        .map_err(|error| error.to_string())?;
    lock.lock().map_err(|error| error.to_string())?;

    let mut folders: BTreeMap<String, Preference> = match fs::read(&path) {
        Ok(data) => serde_json::from_slice(&data).map_err(|error| error.to_string())?,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => BTreeMap::new(),
        Err(error) => return Err(error.to_string()),
    };
    for (uri, preference) in changes {
        if let Some(preference) = preference {
            folders.insert(uri.clone(), *preference);
        } else {
            folders.remove(uri);
        }
    }
    let mut temporary =
        tempfile::NamedTempFile::new_in(parent).map_err(|error| error.to_string())?;
    serde_json::to_writer_pretty(&mut temporary, &folders).map_err(|error| error.to_string())?;
    temporary.persist(path).map_err(|error| error.to_string())?;
    Ok(())
}
