use std::{
    fs,
    os::unix::fs::{MetadataExt, PermissionsExt},
};

#[derive(Clone, Debug)]
pub(crate) enum Metadata {
    Local(fs::Metadata),
    Remote(Remote),
}

#[derive(Clone, Debug)]
pub(crate) struct Remote {
    kind: gio::FileType,
    size: u64,
    mode: u32,
    modified: filetime::FileTime,
    accessed: filetime::FileTime,
    changed: Option<filetime::FileTime>,
    identity: Option<String>,
    etag: Option<String>,
}

impl From<fs::Metadata> for Metadata {
    fn from(value: fs::Metadata) -> Self {
        Self::Local(value)
    }
}
impl Metadata {
    pub fn remote(info: &gio::FileInfo) -> Self {
        fn time(info: &gio::FileInfo, attribute: &str) -> filetime::FileTime {
            let nanos = if info.has_attribute(&format!("{attribute}-nsec")) {
                info.attribute_uint32(&format!("{attribute}-nsec"))
            } else {
                info.attribute_uint32(&format!("{attribute}-usec")) * 1000
            };
            filetime::FileTime::from_unix_time(info.attribute_uint64(attribute) as i64, nanos)
        }
        Self::Remote(Remote {
            kind: info.file_type(),
            size: info.size().max(0) as u64,
            mode: if info.has_attribute("unix::mode") {
                info.attribute_uint32("unix::mode")
            } else if info.file_type() == gio::FileType::Directory {
                0o755
            } else {
                0o644
            },
            modified: time(info, "time::modified"),
            accessed: time(info, "time::access"),
            changed: info
                .has_attribute("time::changed")
                .then(|| time(info, "time::changed")),
            identity: info.attribute_string("id::file").map(Into::into),
            etag: info.attribute_string("etag::value").map(Into::into),
        })
    }
    pub fn len(&self) -> u64 {
        match self {
            Self::Local(m) => m.len(),
            Self::Remote(m) => m.size,
        }
    }
    pub fn is_dir(&self) -> bool {
        match self {
            Self::Local(m) => m.is_dir(),
            Self::Remote(m) => m.kind == gio::FileType::Directory,
        }
    }
    pub fn is_file(&self) -> bool {
        match self {
            Self::Local(m) => m.is_file(),
            Self::Remote(m) => m.kind == gio::FileType::Regular,
        }
    }
    pub fn is_symlink(&self) -> bool {
        match self {
            Self::Local(m) => m.is_symlink(),
            Self::Remote(m) => m.kind == gio::FileType::SymbolicLink,
        }
    }
    pub fn permissions(&self) -> fs::Permissions {
        match self {
            Self::Local(m) => m.permissions(),
            Self::Remote(m) => fs::Permissions::from_mode(m.mode),
        }
    }
    pub fn accessed(&self) -> filetime::FileTime {
        match self {
            Self::Local(m) => filetime::FileTime::from_last_access_time(m),
            Self::Remote(m) => m.accessed,
        }
    }
    pub fn modified(&self) -> filetime::FileTime {
        match self {
            Self::Local(m) => filetime::FileTime::from_last_modification_time(m),
            Self::Remote(m) => m.modified,
        }
    }
    pub fn same_version(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Local(a), Self::Local(b)) => {
                a.dev() == b.dev()
                    && a.ino() == b.ino()
                    && a.len() == b.len()
                    && a.modified().ok() == b.modified().ok()
                    && a.ctime() == b.ctime()
                    && a.ctime_nsec() == b.ctime_nsec()
            }
            (Self::Remote(a), Self::Remote(b)) => {
                a.kind == b.kind
                    && a.size == b.size
                    && a.mode == b.mode
                    && a.modified == b.modified
                    && a.changed == b.changed
                    && a.identity == b.identity
                    && a.etag == b.etag
            }
            _ => false,
        }
    }
}
