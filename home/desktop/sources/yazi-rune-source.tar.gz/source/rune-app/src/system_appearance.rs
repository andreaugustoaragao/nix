use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
    sync::mpsc,
};

use futures_util::StreamExt;
use rune::{Color, Waker};
use tokio::sync::oneshot;
use zbus::{OwnedVariant, Variant};

use crate::scheme::{Palette, Scheme};

enum Setting {
    Accent(Option<Color>),
    Ui(Option<crate::font::Font>),
    Preview(Option<crate::font::Font>),
    Scale(f32),
}

pub struct System {
    pub accent: Option<Color>,
    pub ui_font: Option<crate::font::Font>,
    pub preview_font: Option<crate::font::Font>,
    pub text_scale: f32,
    changes: Option<mpsc::Receiver<Setting>>,
    stop: Option<oneshot::Sender<()>>,
}

impl Default for System {
    fn default() -> Self {
        Self {
            accent: None,
            ui_font: None,
            preview_font: None,
            text_scale: 1.0,
            changes: None,
            stop: None,
        }
    }
}

impl System {
    pub fn start(&mut self, waker: Waker) {
        let (output, changes) = mpsc::channel();
        let (stop, stopped) = oneshot::channel();
        self.changes = Some(changes);
        self.stop = Some(stop);
        std::thread::spawn(move || {
            let Ok(runtime) = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
            else {
                return;
            };
            runtime.block_on(async {
                tokio::select! {
                    _ = watch(output, waker) => {},
                    _ = stopped => {},
                }
            });
        });
    }

    pub fn poll(&mut self) -> bool {
        let mut changed = false;
        if let Some(changes) = &self.changes {
            for setting in changes.try_iter() {
                match setting {
                    Setting::Accent(value) => {
                        changed |= self.accent != value;
                        self.accent = value;
                    }
                    Setting::Ui(value) => {
                        changed |= self.ui_font != value;
                        self.ui_font = value;
                    }
                    Setting::Preview(value) => {
                        changed |= self.preview_font != value;
                        self.preview_font = value;
                    }
                    Setting::Scale(value) => {
                        changed |= self.text_scale != value;
                        self.text_scale = value;
                    }
                }
            }
        }
        changed
    }
}

impl Drop for System {
    fn drop(&mut self) {
        if let Some(stop) = self.stop.take() {
            let _ = stop.send(());
        }
    }
}

async fn watch(output: mpsc::Sender<Setting>, waker: Waker) {
    let setup = tokio::time::timeout(std::time::Duration::from_secs(5), async {
        let connection = zbus::Connection::session().await.ok()?;
        let proxy = zbus::Proxy::new(
            &connection,
            "org.freedesktop.portal.Desktop",
            "/org/freedesktop/portal/desktop",
            "org.freedesktop.portal.Settings",
        )
        .await
        .ok()?;
        let changes = proxy.receive_signal("SettingChanged").await.ok()?;
        for (namespace, key) in [
            ("org.freedesktop.appearance", "accent-color"),
            ("org.gnome.desktop.interface", "font-name"),
            ("org.gnome.desktop.interface", "monospace-font-name"),
            ("org.gnome.desktop.interface", "text-scaling-factor"),
        ] {
            let value = match proxy
                .call::<_, _, OwnedVariant>("ReadOne", &(namespace, key))
                .await
            {
                Ok(value) => Some(value),
                Err(_) => proxy
                    .call::<_, _, OwnedVariant>("Read", &(namespace, key))
                    .await
                    .ok(),
            };
            if let Some(value) = value.and_then(|value| setting(namespace, key, &value)) {
                let _ = output.send(value);
                (waker)();
            }
        }
        Some((connection, changes))
    })
    .await
    .ok()
    .flatten();
    let Some((_connection, mut changes)) = setup else {
        return;
    };
    while let Some(message) = changes.next().await {
        if let Ok((namespace, key, value)) = message
            .body()
            .deserialize::<(String, String, OwnedVariant)>()
            && let Some(value) = setting(&namespace, &key, &value)
        {
            if output.send(value).is_err() {
                return;
            }
            (waker)();
        }
    }
}

fn setting(namespace: &str, key: &str, value: &Variant<'_>) -> Option<Setting> {
    if let Variant::Variant(value) = value {
        return setting(namespace, key, value);
    }
    match (namespace, key, value) {
        ("org.freedesktop.appearance", "accent-color", value) => {
            Some(Setting::Accent(accent(value)))
        }
        ("org.gnome.desktop.interface", "font-name", Variant::Str(value)) => {
            Some(Setting::Ui(crate::font::Font::parse(value)))
        }
        ("org.gnome.desktop.interface", "monospace-font-name", Variant::Str(value)) => {
            Some(Setting::Preview(crate::font::Font::parse(value)))
        }
        ("org.gnome.desktop.interface", "text-scaling-factor", Variant::F64(value))
            if value.is_finite() && (0.5..=3.0).contains(value) =>
        {
            Some(Setting::Scale(*value as f32))
        }
        _ => None,
    }
}

pub fn gtk_fonts(
    config: &Path,
) -> (
    Option<crate::font::Font>,
    Option<crate::font::Font>,
    Vec<PathBuf>,
) {
    let mut ui = None;
    let mut preview = None;
    let mut paths = Vec::new();
    for version in ["gtk-4.0", "gtk-3.0"] {
        let path = config.join(version).join("settings.ini");
        paths.push(path.clone());
        let file = gio::glib::KeyFile::new();
        if file
            .load_from_file(&path, gio::glib::KeyFileFlags::NONE)
            .is_err()
        {
            continue;
        }
        if ui.is_none() {
            ui = file
                .string("Settings", "gtk-font-name")
                .ok()
                .and_then(|value| crate::font::Font::parse(&value));
        }
        if preview.is_none() {
            preview = file
                .string("Settings", "gtk-monospaced-font-name")
                .ok()
                .and_then(|value| crate::font::Font::parse(&value));
        }
    }
    (ui, preview, paths)
}

fn accent(value: &Variant<'_>) -> Option<Color> {
    match value {
        Variant::Variant(inner) => accent(inner),
        Variant::Structure(value) => {
            let values: Vec<_> = value
                .fields()
                .iter()
                .map(|value| match value {
                    Variant::F64(value) if value.is_finite() && (0.0..=1.0).contains(value) => {
                        Some(*value as f32)
                    }
                    _ => None,
                })
                .collect::<Option<_>>()?;
            let [r, g, b] = values.as_slice() else {
                return None;
            };
            Some(Color {
                r: rune::color::srgb_decode(*r),
                g: rune::color::srgb_decode(*g),
                b: rune::color::srgb_decode(*b),
                a: 1.0,
            })
        }
        _ => None,
    }
}

pub fn gtk(config: &Path, builtins: &[Scheme]) -> (Option<Palette>, Vec<PathBuf>) {
    let mut paths = Vec::new();
    for version in ["gtk-4.0", "gtk-3.0"] {
        let root = config.join(version).join("gtk.css");
        let mut definitions = BTreeMap::new();
        let mut visited = BTreeSet::new();
        read_css(&root, &mut definitions, &mut visited, 0);
        paths.extend(visited);
        if let Some(palette) = gtk_palette(&definitions, builtins) {
            return (Some(palette), paths);
        }
    }
    (None, paths)
}

fn read_css(
    path: &Path,
    definitions: &mut BTreeMap<String, String>,
    visited: &mut BTreeSet<PathBuf>,
    depth: usize,
) {
    if depth >= 8 || !visited.insert(path.to_path_buf()) {
        return;
    }
    let Ok(source) = fs::read_to_string(path) else {
        return;
    };
    for statement in source.split(';') {
        if let Some((_, import)) = statement.rsplit_once("@import") {
            let import = import
                .trim()
                .trim_start_matches("url(")
                .trim_end_matches(')')
                .trim()
                .trim_matches(['\'', '"']);
            if !import.contains("://") && !import.is_empty() {
                read_css(
                    &path.parent().unwrap_or(Path::new(".")).join(import),
                    definitions,
                    visited,
                    depth + 1,
                );
            }
        } else if let Some((_, definition)) = statement.rsplit_once("@define-color") {
            let mut parts = definition.split_whitespace();
            if let (Some(name), Some(value), None) = (parts.next(), parts.next(), parts.next()) {
                definitions.insert(name.into(), value.into());
            }
        }
    }
}

fn named(definitions: &BTreeMap<String, String>, names: &[&str]) -> Option<Color> {
    names.iter().find_map(|name| {
        let mut value = definitions.get(*name)?;
        for _ in 0..definitions.len() {
            if let Some(name) = value.strip_prefix('@') {
                value = definitions.get(name)?;
            } else {
                return crate::scheme::color(value).ok();
            }
        }
        None
    })
}

fn gtk_palette(definitions: &BTreeMap<String, String>, builtins: &[Scheme]) -> Option<Palette> {
    let background = named(
        definitions,
        &["window_bg_color", "theme_bg_color", "theme_base_color"],
    )?;
    let text = named(
        definitions,
        &["window_fg_color", "theme_fg_color", "theme_text_color"],
    )?;
    let luminance = |color: Color| color.r * 0.2126 + color.g * 0.7152 + color.b * 0.0722;
    let dark = luminance(background) < luminance(text);
    if (luminance(background) - luminance(text)).abs() < 0.1 {
        return None;
    }
    let mut palette = builtins
        .iter()
        .find(|scheme| scheme.palette.background == background && scheme.palette.text == text)
        .or_else(|| {
            builtins
                .iter()
                .find(|scheme| scheme.id == if dark { "files-dark" } else { "files-light" })
        })?
        .palette;
    palette.background = background;
    palette.text = text;
    for (names, slot) in [
        (
            &[
                "card_bg_color",
                "sidebar_bg_color",
                "theme_unfocused_bg_color",
            ][..],
            &mut palette.panel,
        ),
        (
            &["insensitive_fg_color", "theme_unfocused_fg_color"][..],
            &mut palette.muted,
        ),
        (&["borders", "sidebar_border_color"][..], &mut palette.line),
        (
            &["warning_color", "warning_bg_color"][..],
            &mut palette.warning,
        ),
        (
            &["error_color", "destructive_color"][..],
            &mut palette.error,
        ),
        (
            &["success_color", "success_bg_color"][..],
            &mut palette.success,
        ),
    ] {
        if let Some(color) = named(definitions, names) {
            *slot = color;
        }
    }
    palette.folder = palette.warning;
    palette.comment = palette.muted;
    if let Some(color) = named(
        definitions,
        &["accent_color", "accent_bg_color", "theme_selected_bg_color"],
    ) {
        palette = palette.with_accent(color);
    }
    Some(palette)
}
