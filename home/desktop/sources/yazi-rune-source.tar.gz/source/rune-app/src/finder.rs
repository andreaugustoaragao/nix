use std::{
    collections::{BTreeSet, HashMap},
    path::{Path, PathBuf},
    sync::{Arc, OnceLock, atomic::AtomicBool},
};

use fff_search::{
    FFFMode, FilePicker, FilePickerIgnoreOptions, FilePickerOptions, FrecencyTracker,
    FuzzySearchOptions, GrepMode, GrepSearchOptions, PaginationArgs, QueryParser, SharedFilePicker,
    SharedFrecency,
};

use crate::file::{self, File};

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize)]
pub struct Hit {
    pub line: u64,
    pub text: String,
}

pub struct Picker {
    pub root: PathBuf,
    pub query: String,
    pub all_files: bool,
    pub recursive: bool,
    pub content: bool,
    pub regex: bool,
    pub files: Vec<File>,
    pub hits: HashMap<PathBuf, Hit>,
    pub cursor: usize,
    pub selected: BTreeSet<PathBuf>,
    pub scroll: rune::Live<f32>,
    pub loading: bool,
    pub indexed: usize,
    pub scanning: bool,
    pub watching: bool,
    pub error: Option<String>,
}

impl Picker {
    pub fn new(folder: PathBuf) -> Self {
        Self {
            root: folder,
            query: String::new(),
            all_files: false,
            recursive: false,
            content: false,
            regex: false,
            files: Vec::new(),
            hits: HashMap::new(),
            cursor: 0,
            selected: BTreeSet::new(),
            scroll: rune::Live::new(0.0),
            loading: true,
            indexed: 0,
            scanning: true,
            watching: false,
            error: None,
        }
    }

    pub fn file(&self) -> Option<&File> {
        self.files.get(self.cursor)
    }
}

pub struct Matches {
    pub files: Vec<File>,
    pub hits: HashMap<PathBuf, Hit>,
    pub indexed: usize,
    pub scanning: bool,
    pub watching: bool,
    pub note: Option<String>,
}

pub struct Engine {
    pub index: SharedFilePicker,
    pub warning: Option<String>,
}

impl Engine {
    pub fn new(root: PathBuf, all_files: bool, recursive: bool) -> Result<Self, String> {
        Self::create(root, all_files, recursive, recursive)
    }

    pub fn navigation(root: PathBuf) -> Result<Self, String> {
        Self::create(root, false, true, false)
    }

    fn create(
        root: PathBuf,
        all_files: bool,
        recursive: bool,
        watch: bool,
    ) -> Result<Self, String> {
        if recursive && root.parent().is_none() {
            return Err("Choose a folder below / before including subfolders.".into());
        }
        let root = root
            .to_str()
            .ok_or("Find files requires a folder with a UTF-8 path.")?;
        let (history, warning) = match history() {
            Ok(history) => (history.clone(), None),
            Err(error) => (SharedFrecency::default(), Some(error.clone())),
        };
        let engine = Self {
            index: SharedFilePicker::default(),
            warning,
        };
        let mut extra_ignore: Vec<String> = Vec::new();
        if !recursive {
            extra_ignore.push("/*/".into());
        }
        if !all_files {
            extra_ignore.push("**/.*".into());
        }

        FilePicker::new_with_shared_state_and_ignore_options(
            engine.index.clone(),
            history,
            FilePickerOptions {
                base_path: root.into(),
                mode: FFFMode::Neovim,
                enable_home_dir_scanning: true,
                enable_fs_root_scanning: !recursive,
                watch,
                ..Default::default()
            },
            FilePickerIgnoreOptions {
                extra_ignore: extra_ignore.into(),
                disable_git: all_files,
                disable_ignore_files: all_files,
            },
        )
        .map_err(|error| format!("Could not index this folder: {error}"))?;
        Ok(engine)
    }

    pub fn search(
        index: SharedFilePicker,
        query: String,
        all_files: bool,
        content: bool,
        regex: bool,
        abort: Arc<AtomicBool>,
    ) -> Result<Matches, String> {
        let guard = index.read().map_err(|error| error.to_string())?;
        let picker = guard.as_ref().ok_or("File index is unavailable")?;
        if content {
            let query = fff_search::parse_grep_query(&query);
            let result = picker.grep(
                &query,
                &GrepSearchOptions {
                    max_file_size: 32 * 1024 * 1024,
                    max_matches_per_file: 1,
                    page_limit: 100,
                    mode: if regex {
                        GrepMode::Regex
                    } else {
                        GrepMode::PlainText
                    },
                    abort_signal: Some(abort),
                    ..Default::default()
                },
            );
            let mut files = Vec::new();
            let mut hits = HashMap::new();
            for hit in result.matches {
                let item = result.files[hit.file_index];
                let relative = item.relative_path(picker);
                if !all_files && relative.split('/').any(|part| part.starts_with('.')) {
                    continue;
                }
                if let Some(mut file) =
                    file::read_file(item.absolute_path(picker, picker.base_path()))
                {
                    file.name = relative;
                    hits.insert(
                        file.path.clone(),
                        Hit {
                            line: hit.line_number,
                            text: hit.line_content,
                        },
                    );
                    files.push(file);
                }
            }
            let progress = picker.get_scan_progress();
            return Ok(Matches {
                files,
                hits,
                indexed: picker.live_file_count(),
                scanning: progress.is_scanning,
                watching: progress.is_watcher_ready,
                note: result.regex_fallback_error.map(|error| {
                    format!("Invalid regular expression; showing literal matches: {error}")
                }),
            });
        }
        let parser = QueryParser::default();
        let query = parser.parse(&query);
        let mut files = Vec::new();
        let mut offset = 0;
        loop {
            let matches = picker.fuzzy_search(
                &query,
                None,
                FuzzySearchOptions {
                    max_threads: 2,
                    pagination: PaginationArgs { offset, limit: 100 },
                    ..Default::default()
                },
            );
            for item in &matches.items {
                let relative = item.relative_path(picker);
                if !all_files && relative.split('/').any(|part| part.starts_with('.')) {
                    continue;
                }
                if let Some(mut file) =
                    file::read_file(item.absolute_path(picker, picker.base_path()))
                {
                    file.name = relative;
                    files.push(file);
                    if files.len() == 100 {
                        break;
                    }
                }
            }
            offset += matches.items.len();
            if files.len() == 100 || matches.items.is_empty() || offset >= matches.total_matched {
                break;
            }
        }
        let progress = picker.get_scan_progress();
        Ok(Matches {
            files,
            hits: HashMap::new(),
            indexed: picker.live_file_count(),
            scanning: progress.is_scanning,
            watching: progress.is_watcher_ready,
            note: None,
        })
    }
}

impl Drop for Engine {
    fn drop(&mut self) {
        self.index.cancel();
        if let Ok(mut guard) = self.index.write()
            && let Some(index) = guard.as_mut()
        {
            index.stop_background_monitor();
        }
    }
}

fn history() -> &'static Result<SharedFrecency, String> {
    static HISTORY: OnceLock<Result<SharedFrecency, String>> = OnceLock::new();
    HISTORY.get_or_init(|| {
        let path = std::env::var_os("XDG_STATE_HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|| crate::state::home().join(".local/state"))
            .join("yazi-rune/fff/frecency");
        let tracker = FrecencyTracker::open(path)
            .map_err(|error| format!("Ranking history is unavailable: {error}"))?;
        let history = SharedFrecency::default();
        history.init(tracker).map_err(|error| error.to_string())?;
        Ok(history)
    })
}

pub fn record(path: &Path) -> Result<(), String> {
    let guard = history()
        .as_ref()
        .map_err(Clone::clone)?
        .read()
        .map_err(|error| error.to_string())?;
    if let Some(history) = guard.as_ref() {
        history
            .track_access(path)
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}
