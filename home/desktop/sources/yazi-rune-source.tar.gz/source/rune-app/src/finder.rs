use std::{
    path::{Path, PathBuf},
    sync::OnceLock,
};

use fff_search::{
    FFFMode, FilePicker, FilePickerIgnoreOptions, FilePickerOptions, FrecencyTracker,
    FuzzySearchOptions, PaginationArgs, QueryParser, SharedFilePicker, SharedFrecency,
};

use crate::file::{self, File};

pub struct Picker {
    pub folder: PathBuf,
    pub root: PathBuf,
    pub query: String,
    pub all_files: bool,
    pub files: Vec<File>,
    pub cursor: usize,
    pub loading: bool,
    pub indexed: usize,
    pub scanning: bool,
    pub watching: bool,
    pub error: Option<String>,
}

impl Picker {
    pub fn new(folder: PathBuf) -> Self {
        Self {
            root: folder.clone(),
            folder,
            query: String::new(),
            all_files: false,
            files: Vec::new(),
            cursor: 0,
            loading: true,
            indexed: 0,
            scanning: true,
            watching: false,
            error: None,
        }
    }

    pub fn file(&self) -> Option<&File> {
        self.files.get(self.cursor)
    }

    pub fn project(&self) -> Option<PathBuf> {
        self.folder
            .ancestors()
            .find(|path| path.join(".git").exists())
            .map(Path::to_path_buf)
    }
}

pub struct Matches {
    pub files: Vec<File>,
    pub indexed: usize,
    pub scanning: bool,
    pub watching: bool,
}

pub struct Engine {
    pub index: SharedFilePicker,
    pub history: SharedFrecency,
    pub warning: Option<String>,
}

impl Engine {
    pub fn new(root: PathBuf, all_files: bool) -> Result<Self, String> {
        if root.parent().is_none() {
            return Err("Choose a project or folder below / before using Go to file.".into());
        }
        let root = root
            .to_str()
            .ok_or("Go to file requires a folder with a UTF-8 path.")?;
        let (history, warning) = match history() {
            Ok(history) => (history.clone(), None),
            Err(error) => (SharedFrecency::default(), Some(error.clone())),
        };
        let engine = Self {
            index: SharedFilePicker::default(),
            history,
            warning,
        };
        FilePicker::new_with_shared_state_and_ignore_options(
            engine.index.clone(),
            engine.history.clone(),
            FilePickerOptions {
                base_path: root.into(),
                mode: FFFMode::Neovim,
                enable_home_dir_scanning: true,
                ..Default::default()
            },
            FilePickerIgnoreOptions {
                disable_git: all_files,
                disable_ignore_files: all_files,
                ..Default::default()
            },
        )
        .map_err(|error| format!("Could not index this folder: {error}"))?;
        Ok(engine)
    }

    pub fn search(
        index: SharedFilePicker,
        query: String,
        all_files: bool,
    ) -> Result<Matches, String> {
        let guard = index.read().map_err(|error| error.to_string())?;
        let picker = guard.as_ref().ok_or("File index is unavailable")?;
        let parser = QueryParser::default();
        let query = parser.parse(&query);
        let mut files = Vec::new();
        let mut offset = 0;
        loop {
            let matches = picker.fuzzy_search(
                &query,
                None,
                FuzzySearchOptions {
                    max_threads: 2,
                    pagination: PaginationArgs { offset, limit: 100 },
                    ..Default::default()
                },
            );
            for item in &matches.items {
                let relative = item.relative_path(picker);
                if !all_files && relative.split('/').any(|part| part.starts_with('.')) {
                    continue;
                }
                if let Some(mut file) =
                    file::read_file(item.absolute_path(picker, picker.base_path()))
                {
                    file.name = relative;
                    files.push(file);
                    if files.len() == 100 {
                        break;
                    }
                }
            }
            offset += matches.items.len();
            if files.len() == 100 || matches.items.is_empty() || offset >= matches.total_matched {
                break;
            }
        }
        let progress = picker.get_scan_progress();
        Ok(Matches {
            files,
            indexed: picker.live_file_count(),
            scanning: progress.is_scanning,
            watching: progress.is_watcher_ready,
        })
    }

    pub fn record(&self, path: &Path) -> Result<(), String> {
        record(path)?;
        let history = self.history.read().map_err(|error| error.to_string())?;
        if let Some(history) = history.as_ref()
            && let Some(index) = self
                .index
                .write()
                .map_err(|error| error.to_string())?
                .as_mut()
        {
            index
                .update_single_file_frecency(path, history)
                .map_err(|error| error.to_string())?;
        }
        Ok(())
    }
}

impl Drop for Engine {
    fn drop(&mut self) {
        self.index.cancel();
        if let Ok(mut guard) = self.index.write()
            && let Some(index) = guard.as_mut()
        {
            index.stop_background_monitor();
        }
    }
}

fn history() -> &'static Result<SharedFrecency, String> {
    static HISTORY: OnceLock<Result<SharedFrecency, String>> = OnceLock::new();
    HISTORY.get_or_init(|| {
        let path = std::env::var_os("XDG_STATE_HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|| crate::state::home().join(".local/state"))
            .join("yazi-rune/fff/frecency");
        let tracker = FrecencyTracker::open(path)
            .map_err(|error| format!("Ranking history is unavailable: {error}"))?;
        let history = SharedFrecency::default();
        history.init(tracker).map_err(|error| error.to_string())?;
        Ok(history)
    })
}

pub fn record(path: &Path) -> Result<(), String> {
    let guard = history()
        .as_ref()
        .map_err(Clone::clone)?
        .read()
        .map_err(|error| error.to_string())?;
    if let Some(history) = guard.as_ref() {
        history
            .track_access(path)
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}
