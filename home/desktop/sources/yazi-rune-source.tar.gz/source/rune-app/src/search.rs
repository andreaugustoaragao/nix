use crate::file::{self, Folder};
use gio::prelude::CancellableExt;
use std::{
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

pub fn read(path: PathBuf, query: String, hidden: bool, cancel: Arc<AtomicBool>) -> Folder {
    let mut files = Vec::new();
    let mut skipped = 0usize;
    let mut limited = false;
    let entries = walkdir::WalkDir::new(&path)
        .follow_links(false)
        .into_iter()
        .filter_entry(|entry| {
            entry.depth() == 0 || hidden || !entry.file_name().as_encoded_bytes().starts_with(b".")
        });
    for entry in entries {
        if cancel.load(Ordering::Relaxed) {
            break;
        }
        let entry = match entry {
            Ok(entry) => entry,
            Err(_) => {
                skipped += 1;
                continue;
            }
        };
        if entry.depth() == 0 {
            continue;
        }
        let relative = entry
            .path()
            .strip_prefix(&path)
            .unwrap_or(entry.path())
            .to_string_lossy();
        if crate::state::smart_contains(&relative, &query)
            && let Some(mut file) = file::read_file(entry.path().to_path_buf())
        {
            file.name = relative.into_owned();
            files.push(file);
            if files.len() == 5000 {
                limited = true;
                break;
            }
        }
    }
    let note = if limited {
        Some("Showing the first 5,000 matches. Refine the search for more specific results.".into())
    } else if skipped > 0 {
        Some(format!(
            "Search finished; {skipped} inaccessible locations skipped"
        ))
    } else {
        None
    };
    let parent = path
        .parent()
        .and_then(|p| file::read_dir(p).ok())
        .unwrap_or_default();
    Folder {
        fallback: None,
        path,
        files: Ok(files),
        parent,
        note,
    }
}

pub fn read_remote(
    path: PathBuf,
    query: String,
    hidden: bool,
    root: crate::operations::RemoteRoot,
    cancel: gio::Cancellable,
) -> Folder {
    let mut pending = vec![path.clone()];
    let mut files = Vec::new();
    let mut skipped = 0;
    let mut error = None;
    while let Some(directory) = pending.pop() {
        if cancel.is_cancelled() {
            break;
        }
        match file::read_dir_remote(&directory, &root, &cancel) {
            Ok(entries) => {
                for mut entry in entries {
                    if !hidden && entry.name.starts_with('.') {
                        continue;
                    }
                    if entry.directory && !entry.symlink {
                        pending.push(entry.path.clone());
                    }
                    let relative = entry
                        .path
                        .strip_prefix(&path)
                        .expect("remote search descendant")
                        .to_string_lossy();
                    if crate::state::smart_contains(&relative, &query) {
                        entry.name = relative.into_owned();
                        files.push(entry);
                        if files.len() == 5000 {
                            break;
                        }
                    }
                }
            }
            Err(message) if directory == path => {
                error = Some(message);
                break;
            }
            Err(_) => skipped += 1,
        }
        if files.len() == 5000 {
            break;
        }
    }
    let note = if files.len() == 5000 {
        Some("Showing the first 5,000 matches. Refine the search for more specific results.".into())
    } else if skipped > 0 {
        Some(format!(
            "Search finished; {skipped} inaccessible locations skipped"
        ))
    } else {
        None
    };
    let parent = path
        .parent()
        .filter(|path| path.starts_with(&root.path))
        .and_then(|path| file::read_dir_remote(path, &root, &cancel).ok())
        .unwrap_or_default();
    Folder {
        path,
        files: error.map_or_else(|| Ok(files), Err),
        parent,
        note,
        fallback: None,
    }
}
