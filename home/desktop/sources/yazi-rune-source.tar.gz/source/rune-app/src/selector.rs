use std::{
    collections::HashMap,
    ffi::OsString,
    fs,
    os::unix::ffi::{OsStrExt, OsStringExt},
    path::{Component, Path, PathBuf},
};

use gio::prelude::FileExt;
use rune::{Latest, TextEdit};
use serde::{Deserialize, Serialize};
use zbus::zvariant::OwnedVariant;

use crate::file::File;

pub type Filter = (String, Vec<(u32, String)>);
pub type Choice = (String, String, Vec<(String, String)>, String);

#[derive(Clone, Deserialize, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Mode {
    Open { multiple: bool, directory: bool },
    Save,
    SaveFiles { files: Vec<Vec<u8>> },
}

#[derive(Clone, Deserialize, Serialize)]
pub struct Request {
    pub mode: Mode,
    pub title: String,
    pub app_id: String,
    pub parent_window: String,
    pub accept_label: String,
    pub folder: Vec<u8>,
    pub name: String,
    pub filters: Vec<Filter>,
    pub current_filter: Option<Filter>,
    pub choices: Vec<Choice>,
}

impl Request {
    pub fn from_options(
        mode: Mode,
        title: String,
        app_id: String,
        parent_window: String,
        options: HashMap<String, OwnedVariant>,
    ) -> Result<Self, String> {
        let current_file = option::<Vec<u8>>(&options, "current_file")?.map(byte_path);
        let folder = option::<Vec<u8>>(&options, "current_folder")?
            .map(byte_path)
            .or_else(|| {
                current_file
                    .as_ref()
                    .and_then(|path| path.parent())
                    .map(Path::to_path_buf)
            })
            .unwrap_or_else(crate::state::home);
        let name = option::<String>(&options, "current_name")?
            .or_else(|| {
                current_file
                    .as_ref()
                    .and_then(|path| path.file_name())
                    .map(|name| name.to_string_lossy().into_owned())
            })
            .unwrap_or_default();
        let save = !matches!(mode, Mode::Open { .. });
        let filters = option::<Vec<Filter>>(&options, "filters")?.unwrap_or_default();
        for filter in &filters {
            compile(filter)?;
        }
        let current_filter = option::<Filter>(&options, "current_filter")?;
        if let Some(filter) = &current_filter {
            compile(filter)?;
        }
        let choices = option::<Vec<Choice>>(&options, "choices")?.unwrap_or_default();
        for (_, _, values, selected) in &choices {
            if values.is_empty() && !matches!(selected.as_str(), "" | "true" | "false") {
                return Err("Invalid checkbox value".into());
            }
            if !values.is_empty()
                && !selected.is_empty()
                && !values.iter().any(|(id, _)| id == selected)
            {
                return Err("Unknown choice value".into());
            }
        }
        Ok(Self {
            mode,
            title: if title.is_empty() {
                if save { "Save file" } else { "Open file" }.into()
            } else {
                title
            },
            app_id,
            parent_window,
            accept_label: option::<String>(&options, "accept_label")?
                .map(|label| label.replace('_', ""))
                .filter(|label| !label.is_empty())
                .unwrap_or_else(|| if save { "Save" } else { "Open" }.into()),
            folder: folder.as_os_str().as_bytes().to_vec(),
            name,
            filters,
            current_filter,
            choices,
        })
    }

    pub fn folder(&self) -> PathBuf {
        byte_path(self.folder.clone())
    }
    pub fn multiple(&self) -> bool {
        matches!(self.mode, Mode::Open { multiple: true, .. })
    }
    pub fn folders(&self) -> bool {
        matches!(
            self.mode,
            Mode::Open {
                directory: true,
                ..
            } | Mode::SaveFiles { .. }
        )
    }
}

pub fn option<T>(options: &HashMap<String, OwnedVariant>, key: &str) -> Result<Option<T>, String>
where
    T: TryFrom<OwnedVariant>,
    T::Error: std::fmt::Display,
{
    options
        .get(key)
        .map(|value| {
            let value = value.try_clone().map_err(|error| error.to_string())?;
            T::try_from(value).map_err(|error| format!("Invalid {key}: {error}"))
        })
        .transpose()
}

pub fn byte_path(mut bytes: Vec<u8>) -> PathBuf {
    if bytes.last() == Some(&0) {
        bytes.pop();
    }
    OsString::from_vec(bytes).into()
}

#[derive(Deserialize, Serialize)]
pub struct Reply {
    pub uris: Vec<String>,
    pub choices: Vec<(String, String)>,
    pub current_filter: Option<Filter>,
    pub writable: bool,
}

pub enum Outcome {
    Replace(Vec<PathBuf>),
    Returned,
}

enum Matcher {
    Glob(globset::GlobMatcher),
    Mime(String),
}

fn compile(filter: &Filter) -> Result<Vec<Matcher>, String> {
    filter
        .1
        .iter()
        .map(|(kind, pattern)| match kind {
            0 => globset::Glob::new(pattern)
                .map(|glob| Matcher::Glob(glob.compile_matcher()))
                .map_err(|error| error.to_string()),
            1 => Ok(Matcher::Mime(pattern.clone())),
            _ => Err("Unsupported file filter".into()),
        })
        .collect()
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Menu {
    Filter,
    Choice(usize),
}

pub struct Selector {
    pub request: Request,
    pub result: PathBuf,
    pub name: TextEdit,
    pub filter: usize,
    matchers: Vec<Matcher>,
    pub menu: Option<Menu>,
    pub choices: Vec<String>,
    pub replace: Option<Vec<PathBuf>>,
    pub busy: bool,
    pub error: Option<String>,
    pub worker: Latest<Result<Outcome, String>>,
}

impl Selector {
    pub fn new(mut request: Request, result: PathBuf) -> Result<Self, String> {
        if let Some(filter) = &request.current_filter
            && !request.filters.contains(filter)
        {
            request.filters.insert(0, filter.clone());
        }
        let filter = request
            .current_filter
            .as_ref()
            .and_then(|current| request.filters.iter().position(|filter| filter == current))
            .unwrap_or(0);
        let matchers = request
            .filters
            .get(filter)
            .map(compile)
            .transpose()?
            .unwrap_or_default();
        let choices = request
            .choices
            .iter()
            .map(|(_, _, values, selected)| {
                if selected.is_empty() {
                    values
                        .first()
                        .map(|(id, _)| id.clone())
                        .unwrap_or_else(|| "false".into())
                } else {
                    selected.clone()
                }
            })
            .collect();
        Ok(Self {
            name: TextEdit::new(&request.name),
            request,
            result,
            filter,
            matchers,
            menu: None,
            choices,
            replace: None,
            busy: false,
            error: None,
            worker: Latest::default(),
        })
    }

    pub fn matches(&self, file: &File) -> bool {
        if file.directory {
            return true;
        }
        if self.request.folders() {
            return false;
        }
        self.matchers.is_empty()
            || self.matchers.iter().any(|matcher| match matcher {
                Matcher::Glob(glob) => glob.is_match(file.path.file_name().unwrap_or_default()),
                Matcher::Mime(mime) => {
                    let (content, _) =
                        gio::content_type_guess(Some(Path::new(&file.name)), None::<&[u8]>);
                    if let Some(prefix) = mime.strip_suffix("/*") {
                        content.starts_with(&format!("{prefix}/"))
                    } else {
                        gio::content_type_is_a(&content, mime)
                    }
                }
            })
    }

    pub fn set_filter(&mut self, index: usize) {
        if let Some(filter) = self.request.filters.get(index) {
            self.matchers = compile(filter).expect("validated file filter");
            self.filter = index;
        }
        self.menu = None;
    }

    pub fn accept(&mut self, paths: Vec<PathBuf>, replace: bool) {
        if self.busy {
            return;
        }
        self.busy = true;
        self.error = None;
        self.replace = None;
        let reply = Reply {
            uris: Vec::new(),
            current_filter: self.request.filters.get(self.filter).cloned(),
            choices: self
                .request
                .choices
                .iter()
                .zip(&self.choices)
                .map(|((id, _, _, _), value)| (id.clone(), value.clone()))
                .collect(),
            writable: true,
        };
        self.worker.request(
            (
                paths,
                self.request.mode.clone(),
                reply,
                self.result.clone(),
                replace,
            ),
            |(mut paths, mode, mut reply, result, replace)| {
                if matches!(mode, Mode::SaveFiles { .. }) {
                    let mut used = std::collections::HashSet::new();
                    for path in &mut paths {
                        let original = path.clone();
                        let mut index = 0;
                        while !used.insert(path.clone()) {
                            index += 1;
                            let mut name = original.file_stem().unwrap_or_default().to_os_string();
                            name.push(format!(" ({index})"));
                            if let Some(extension) = original.extension() {
                                name.push(".");
                                name.push(extension);
                            }
                            *path = original.with_file_name(name);
                        }
                    }
                }
                let mut existing = Vec::new();
                if paths.is_empty() {
                    return Err("Select an item first".into());
                }
                for path in &paths {
                    match &mode {
                        Mode::Open { directory, .. } => {
                            let metadata = fs::metadata(path).map_err(|error| error.to_string())?;
                            reply.writable &= gio::File::for_path(path)
                                .query_info(
                                    "access::can-write",
                                    gio::FileQueryInfoFlags::NONE,
                                    gio::Cancellable::NONE,
                                )
                                .map(|info| info.boolean("access::can-write"))
                                .unwrap_or(false);
                            if metadata.is_dir() != *directory {
                                return Err(if *directory {
                                    "Select a folder"
                                } else {
                                    "Select a file"
                                }
                                .into());
                            }
                        }
                        _ => {
                            if !path.parent().is_some_and(Path::is_dir) {
                                return Err("The destination folder is unavailable".into());
                            }
                            match fs::symlink_metadata(path) {
                                Ok(metadata) if metadata.is_dir() => {
                                    return Err("A folder already has this name".into());
                                }
                                Ok(_) => existing.push(path.clone()),
                                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                                Err(error) => return Err(error.to_string()),
                            }
                        }
                    }
                    reply.uris.push(
                        url::Url::from_file_path(path)
                            .map_err(|_| "Choose a local or mounted location")?
                            .into(),
                    );
                }
                if !replace && !existing.is_empty() {
                    return Ok(Outcome::Replace(existing));
                }
                let data = serde_json::to_vec(&reply).map_err(|error| error.to_string())?;
                fs::write(result, data).map_err(|error| error.to_string())?;
                Ok(Outcome::Returned)
            },
        );
    }
}

pub fn filename(name: &std::ffi::OsStr) -> Result<(), String> {
    let mut components = Path::new(name).components();
    if !matches!(components.next(), Some(Component::Normal(_)))
        || components.next().is_some()
        || name.as_bytes().contains(&0)
    {
        Err("Enter a file name without a slash".into())
    } else {
        Ok(())
    }
}
