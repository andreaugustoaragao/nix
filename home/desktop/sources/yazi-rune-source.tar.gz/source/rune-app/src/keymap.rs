use rune::{Key, KeyEvent};
use serde::Deserialize;

#[derive(Clone, Deserialize)]
#[serde(untagged)]
pub enum Strings {
    One(String),
    Many(Vec<String>),
}

impl Strings {
    pub fn list(&self) -> &[String] {
        match self {
            Self::One(s) => std::slice::from_ref(s),
            Self::Many(v) => v,
        }
    }
}

#[derive(Clone, Deserialize)]
pub struct Binding {
    pub on: Strings,
    pub run: Strings,
    #[serde(default)]
    pub desc: String,
}

#[derive(Default, Deserialize)]
struct Section {
    #[serde(default)]
    keymap: Vec<Binding>,
    #[serde(default)]
    prepend_keymap: Vec<Binding>,
    #[serde(default)]
    append_keymap: Vec<Binding>,
}

#[derive(Default, Deserialize)]
struct Config {
    #[serde(default)]
    mgr: Section,
}

pub fn load(custom: Option<&str>) -> Result<Vec<Binding>, String> {
    let defaults: Config =
        toml::from_str(include_str!("../../yazi-config/preset/keymap-default.toml"))
            .map_err(|e| e.to_string())?;
    let Some(custom) = custom else {
        return Ok(defaults.mgr.keymap);
    };
    let user: Config = toml::from_str(custom).map_err(|e| format!("keymap.toml: {e}"))?;
    let mut bindings = user.mgr.prepend_keymap;
    bindings.extend(if user.mgr.keymap.is_empty() {
        defaults.mgr.keymap
    } else {
        user.mgr.keymap
    });
    bindings.extend(user.mgr.append_keymap);
    let mut seen = std::collections::HashSet::new();
    bindings.retain(|b| seen.insert(b.on.list().to_vec()));
    Ok(bindings)
}

pub fn key_name(event: &KeyEvent) -> Option<String> {
    let key = match &event.key {
        Key::Text(s) if s == " " => "Space".into(),
        Key::Text(s) => s.clone(),
        Key::Command(c) => c.to_string(),
        Key::Up => "Up".into(),
        Key::Down => "Down".into(),
        Key::Left => "Left".into(),
        Key::Right => "Right".into(),
        Key::Enter => "Enter".into(),
        Key::Escape => "Esc".into(),
        Key::Home => "Home".into(),
        Key::End => "End".into(),
        Key::PageUp => "PageUp".into(),
        Key::PageDown => "PageDown".into(),
        Key::Tab => "Tab".into(),
        Key::Backspace => "Backspace".into(),
        Key::Delete => "Delete".into(),
        Key::Function(n) => format!("F{n}"),
        _ => return None,
    };
    let m = event.mods;
    let modified = m.ctrl || m.alt || m.logo || m.cmd;
    let special = key.chars().count() != 1;
    if !modified && !special {
        return Some(key);
    }
    let mut prefix = String::new();
    if m.ctrl {
        prefix.push_str("C-");
    }
    if m.alt {
        prefix.push_str("A-");
    }
    if m.logo {
        prefix.push_str("D-");
    }
    if m.shift && (special || modified) {
        prefix.push_str("S-");
    }
    Some(format!("<{prefix}{key}>"))
}
