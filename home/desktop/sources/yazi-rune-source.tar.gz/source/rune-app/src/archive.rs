use std::{
    fs::{self, File},
    io::{self, Read, Seek, SeekFrom, Write},
    path::{Component, Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

use flate2::{Compression, read::GzDecoder, write::GzEncoder};
use zip::{ZipArchive, ZipWriter, write::SimpleFileOptions};

pub fn stem(path: &Path) -> String {
    let name = path.file_name().unwrap_or_default().to_string_lossy();
    for suffix in [".tar.gz", ".tar", ".tgz", ".zip"] {
        if name.to_ascii_lowercase().ends_with(suffix) {
            return name[..name.len() - suffix.len()].into();
        }
    }
    path.file_stem()
        .unwrap_or_default()
        .to_string_lossy()
        .into_owned()
}

pub fn create(
    sources: &[PathBuf],
    output: &Path,
    format: &Path,
    cancel: Arc<AtomicBool>,
) -> io::Result<()> {
    let name = format.to_string_lossy().to_ascii_lowercase();
    let file = Checked {
        inner: File::create(output)?,
        cancel: cancel.clone(),
    };
    if name.ends_with(".zip") {
        let mut writer = ZipWriter::new(file);
        for source in sources {
            zip_entry(
                &mut writer,
                source,
                Path::new(
                    source
                        .file_name()
                        .ok_or_else(|| io::Error::other("Cannot archive the filesystem root"))?,
                ),
                &cancel,
            )?;
        }
        writer.finish()?.inner.sync_all()
    } else if name.ends_with(".tar.gz") || name.ends_with(".tgz") {
        let mut writer = tar::Builder::new(GzEncoder::new(file, Compression::default()));
        append_tar(&mut writer, sources, &cancel)?;
        writer.into_inner()?.finish()?.inner.sync_all()
    } else if name.ends_with(".tar") {
        let mut writer = tar::Builder::new(file);
        append_tar(&mut writer, sources, &cancel)?;
        writer.into_inner()?.inner.sync_all()
    } else {
        Err(io::Error::other(
            "Choose .zip, .tar, .tar.gz or .tgz for the archive name",
        ))
    }
}

fn append_tar<W: Write>(
    writer: &mut tar::Builder<W>,
    sources: &[PathBuf],
    cancel: &AtomicBool,
) -> io::Result<()> {
    writer.follow_symlinks(false);
    for source in sources {
        check_tree(source, cancel)?;
        let name = source
            .file_name()
            .ok_or_else(|| io::Error::other("Cannot archive the filesystem root"))?;
        if fs::symlink_metadata(source)?.is_dir() {
            writer.append_dir_all(name, source)?;
        } else {
            writer.append_path_with_name(source, name)?;
        }
    }
    writer.finish()
}

fn check_tree(path: &Path, cancel: &AtomicBool) -> io::Result<()> {
    check(cancel)?;
    let metadata = fs::symlink_metadata(path)?;
    if metadata.is_dir() {
        for entry in fs::read_dir(path)? {
            check_tree(&entry?.path(), cancel)?;
        }
    } else if !metadata.is_file() && !metadata.is_symlink() {
        return Err(io::Error::other("Archiving special files is not supported"));
    }
    Ok(())
}

fn zip_entry(
    writer: &mut ZipWriter<Checked<File>>,
    source: &Path,
    name: &Path,
    cancel: &Arc<AtomicBool>,
) -> io::Result<()> {
    use std::os::unix::fs::MetadataExt;
    check(cancel)?;
    let metadata = fs::symlink_metadata(source)?;
    let options = SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated)
        .unix_permissions(metadata.mode());
    let text = name.to_string_lossy().replace('\\', "/");
    if metadata.is_symlink() {
        writer.add_symlink(text, fs::read_link(source)?.to_string_lossy(), options)?;
    } else if metadata.is_dir() {
        writer.add_directory(format!("{text}/"), options)?;
        for entry in fs::read_dir(source)? {
            let entry = entry?;
            zip_entry(writer, &entry.path(), &name.join(entry.file_name()), cancel)?;
        }
    } else if metadata.is_file() {
        writer.start_file(text, options)?;
        io::copy(
            &mut Checked {
                inner: File::open(source)?,
                cancel: cancel.clone(),
            },
            writer,
        )?;
    } else {
        return Err(io::Error::other("Archiving special files is not supported"));
    }
    Ok(())
}

pub fn extract(source: &Path, destination: &Path, cancel: Arc<AtomicBool>) -> io::Result<()> {
    let name = source.to_string_lossy().to_ascii_lowercase();
    let file = Checked {
        inner: File::open(source)?,
        cancel: cancel.clone(),
    };
    if name.ends_with(".zip") {
        extract_zip(file, destination, &cancel)
    } else if name.ends_with(".tar.gz") || name.ends_with(".tgz") {
        extract_tar(GzDecoder::new(file), destination, &cancel)
    } else if name.ends_with(".tar") {
        extract_tar(file, destination, &cancel)
    } else {
        Err(io::Error::other(
            "Supported archives: .zip, .tar, .tar.gz, .tgz",
        ))
    }
}

fn extract_tar<R: Read>(input: R, destination: &Path, cancel: &AtomicBool) -> io::Result<()> {
    let mut archive = tar::Archive::new(input);
    for entry in archive.entries()? {
        check(cancel)?;
        let mut entry = entry?;
        let path = entry.path()?.into_owned();
        safe_path(&path)?;
        let kind = entry.header().entry_type();
        if kind.is_symlink() || kind.is_hard_link() {
            let link = entry
                .link_name()?
                .ok_or_else(|| io::Error::other("Archive link has no target"))?;
            let relative = if kind.is_symlink() {
                path.parent().unwrap_or(Path::new("")).join(link)
            } else {
                link.into_owned()
            };
            safe_path(&relative)?;
        } else if !kind.is_file() && !kind.is_dir() {
            return Err(io::Error::other("Archive contains a special file"));
        }
        if !entry.unpack_in(destination)? {
            return Err(io::Error::other("Archive entry escapes the destination"));
        }
    }
    Ok(())
}

fn extract_zip(
    input: Checked<File>,
    destination: &Path,
    cancel: &Arc<AtomicBool>,
) -> io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let mut archive = ZipArchive::new(input)?;
    let mut directories = Vec::new();
    for index in 0..archive.len() {
        check(cancel)?;
        let mut entry = archive.by_index(index)?;
        let name = entry
            .enclosed_name()
            .ok_or_else(|| io::Error::other("Archive entry escapes the destination"))?;
        safe_path(&name)?;
        let output = destination.join(&name);
        safe_parents(destination, &output)?;
        let mode = entry.unix_mode().unwrap_or(0o644);
        if entry.is_dir() {
            fs::create_dir_all(&output)?;
            directories.push((output, mode));
        } else if mode & 0o170000 == 0o120000 {
            let mut target = String::new();
            (&mut entry).take(65537).read_to_string(&mut target)?;
            if target.len() > 65536 {
                return Err(io::Error::other("Archive link target is too long"));
            }
            safe_path(&name.parent().unwrap_or(Path::new("")).join(&target))?;
            if let Some(parent) = output.parent() {
                fs::create_dir_all(parent)?;
            }
            std::os::unix::fs::symlink(target, output)?;
        } else {
            if let Some(parent) = output.parent() {
                fs::create_dir_all(parent)?;
            }
            let mut file = fs::OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(&output)?;
            io::copy(
                &mut Checked {
                    inner: &mut entry,
                    cancel: cancel.clone(),
                },
                &mut file,
            )?;
            fs::set_permissions(output, fs::Permissions::from_mode(mode & 0o777))?;
        }
    }
    for (path, mode) in directories.into_iter().rev() {
        fs::set_permissions(path, fs::Permissions::from_mode(mode & 0o777))?;
    }
    Ok(())
}

fn safe_path(path: &Path) -> io::Result<()> {
    let mut depth = 0;
    for component in path.components() {
        match component {
            Component::Normal(_) => depth += 1,
            Component::CurDir => {}
            Component::ParentDir if depth > 0 => depth -= 1,
            _ => return Err(io::Error::other("Archive path escapes the destination")),
        }
    }
    Ok(())
}

fn safe_parents(root: &Path, path: &Path) -> io::Result<()> {
    let relative = path.strip_prefix(root).map_err(io::Error::other)?;
    let mut parent = root.to_path_buf();
    for part in relative.components() {
        parent.push(part);
        if fs::symlink_metadata(&parent).is_ok_and(|m| m.is_symlink()) {
            return Err(io::Error::other("Archive entry traverses a symbolic link"));
        }
    }
    Ok(())
}

fn check(cancel: &AtomicBool) -> io::Result<()> {
    if cancel.load(Ordering::Relaxed) {
        Err(io::Error::new(io::ErrorKind::Interrupted, "Cancelled"))
    } else {
        Ok(())
    }
}

struct Checked<T> {
    inner: T,
    cancel: Arc<AtomicBool>,
}
impl<T: Read> Read for Checked<T> {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        check(&self.cancel)?;
        self.inner.read(buffer)
    }
}
impl<T: Write> Write for Checked<T> {
    fn write(&mut self, buffer: &[u8]) -> io::Result<usize> {
        check(&self.cancel)?;
        self.inner.write(buffer)
    }
    fn flush(&mut self) -> io::Result<()> {
        self.inner.flush()
    }
}
impl<T: Seek> Seek for Checked<T> {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        check(&self.cancel)?;
        self.inner.seek(position)
    }
}
