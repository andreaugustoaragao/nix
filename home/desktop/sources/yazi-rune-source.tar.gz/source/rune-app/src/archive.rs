use std::{
    fs::{self, File},
    io::{self, Read, Seek, SeekFrom, Write},
    path::{Component, Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

use flate2::{Compression, read::GzDecoder, write::GzEncoder};
use zip::{ZipArchive, ZipWriter, write::SimpleFileOptions};

const SUFFIXES: [&str; 4] = [".tar.gz", ".tar", ".tgz", ".zip"];

pub fn supported(path: &Path) -> bool {
    let name = path.as_os_str().to_string_lossy().to_ascii_lowercase();
    SUFFIXES.iter().any(|suffix| name.ends_with(suffix))
}

pub fn stem(path: &Path) -> String {
    let name = path.file_name().unwrap_or_default().to_string_lossy();
    for suffix in SUFFIXES {
        if name.to_ascii_lowercase().ends_with(suffix) {
            return name[..name.len() - suffix.len()].into();
        }
    }
    path.file_stem()
        .unwrap_or_default()
        .to_string_lossy()
        .into_owned()
}

pub fn create(
    sources: &[PathBuf],
    output: &Path,
    format: &Path,
    cancel: Arc<AtomicBool>,
) -> io::Result<()> {
    let name = format.to_string_lossy().to_ascii_lowercase();
    let file = Checked {
        inner: File::create(output)?,
        cancel: cancel.clone(),
    };
    if name.ends_with(".zip") {
        let mut writer = ZipWriter::new(file);
        for source in sources {
            zip_entry(
                &mut writer,
                source,
                Path::new(
                    source
                        .file_name()
                        .ok_or_else(|| io::Error::other("Cannot archive the filesystem root"))?,
                ),
                &cancel,
            )?;
        }
        writer.finish()?.inner.sync_all()
    } else if name.ends_with(".tar.gz") || name.ends_with(".tgz") {
        let mut writer = tar::Builder::new(GzEncoder::new(file, Compression::default()));
        append_tar(&mut writer, sources, &cancel)?;
        writer.into_inner()?.finish()?.inner.sync_all()
    } else if name.ends_with(".tar") {
        let mut writer = tar::Builder::new(file);
        append_tar(&mut writer, sources, &cancel)?;
        writer.into_inner()?.inner.sync_all()
    } else {
        Err(io::Error::other(
            "Choose .zip, .tar, .tar.gz or .tgz for the archive name",
        ))
    }
}

fn append_tar<W: Write>(
    writer: &mut tar::Builder<W>,
    sources: &[PathBuf],
    cancel: &AtomicBool,
) -> io::Result<()> {
    writer.follow_symlinks(false);
    for source in sources {
        check_tree(source, cancel)?;
        let name = source
            .file_name()
            .ok_or_else(|| io::Error::other("Cannot archive the filesystem root"))?;
        if fs::symlink_metadata(source)?.is_dir() {
            writer.append_dir_all(name, source)?;
        } else {
            writer.append_path_with_name(source, name)?;
        }
    }
    writer.finish()
}

fn check_tree(path: &Path, cancel: &AtomicBool) -> io::Result<()> {
    check(cancel)?;
    let metadata = fs::symlink_metadata(path)?;
    if metadata.is_dir() {
        for entry in fs::read_dir(path)? {
            check_tree(&entry?.path(), cancel)?;
        }
    } else if !metadata.is_file() && !metadata.is_symlink() {
        return Err(io::Error::other("Archiving special files is not supported"));
    }
    Ok(())
}

fn zip_entry(
    writer: &mut ZipWriter<Checked<File>>,
    source: &Path,
    name: &Path,
    cancel: &Arc<AtomicBool>,
) -> io::Result<()> {
    use std::os::unix::fs::MetadataExt;
    check(cancel)?;
    let metadata = fs::symlink_metadata(source)?;
    let options = SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated)
        .unix_permissions(metadata.mode());
    let text = name.to_string_lossy().replace('\\', "/");
    if metadata.is_symlink() {
        writer.add_symlink(text, fs::read_link(source)?.to_string_lossy(), options)?;
    } else if metadata.is_dir() {
        writer.add_directory(format!("{text}/"), options)?;
        for entry in fs::read_dir(source)? {
            let entry = entry?;
            zip_entry(writer, &entry.path(), &name.join(entry.file_name()), cancel)?;
        }
    } else if metadata.is_file() {
        writer.start_file(text, options)?;
        io::copy(
            &mut Checked {
                inner: File::open(source)?,
                cancel: cancel.clone(),
            },
            writer,
        )?;
    } else {
        return Err(io::Error::other("Archiving special files is not supported"));
    }
    Ok(())
}

pub fn extract(source: &Path, destination: &Path, cancel: Arc<AtomicBool>) -> io::Result<()> {
    let name = source.to_string_lossy().to_ascii_lowercase();
    let file = Checked {
        inner: File::open(source)?,
        cancel: cancel.clone(),
    };
    if name.ends_with(".zip") {
        extract_zip(file, destination, &cancel)
    } else if name.ends_with(".tar.gz") || name.ends_with(".tgz") {
        extract_tar(GzDecoder::new(file), destination, &cancel)
    } else if name.ends_with(".tar") {
        extract_tar(file, destination, &cancel)
    } else {
        Err(io::Error::other(
            "Supported archives: .zip, .tar, .tar.gz, .tgz",
        ))
    }
}

fn extract_tar<R: Read>(input: R, destination: &Path, cancel: &AtomicBool) -> io::Result<()> {
    let mut archive = tar::Archive::new(input);
    for entry in archive.entries()? {
        check(cancel)?;
        let mut entry = entry?;
        let path = entry.path()?.into_owned();
        safe_path(&path)?;
        let kind = entry.header().entry_type();
        if kind.is_symlink() || kind.is_hard_link() {
            let link = entry
                .link_name()?
                .ok_or_else(|| io::Error::other("Archive link has no target"))?;
            let relative = if kind.is_symlink() {
                path.parent().unwrap_or(Path::new("")).join(link)
            } else {
                link.into_owned()
            };
            safe_path(&relative)?;
        } else if !kind.is_file() && !kind.is_dir() {
            return Err(io::Error::other("Archive contains a special file"));
        }
        if !entry.unpack_in(destination)? {
            return Err(io::Error::other("Archive entry escapes the destination"));
        }
    }
    Ok(())
}

fn extract_zip(
    input: Checked<File>,
    destination: &Path,
    cancel: &Arc<AtomicBool>,
) -> io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let mut archive = ZipArchive::new(input)?;
    let mut directories = Vec::new();
    for index in 0..archive.len() {
        check(cancel)?;
        let mut entry = archive.by_index(index)?;
        let name = entry
            .enclosed_name()
            .ok_or_else(|| io::Error::other("Archive entry escapes the destination"))?;
        safe_path(&name)?;
        let output = destination.join(&name);
        safe_parents(destination, &output)?;
        let mode = entry.unix_mode().unwrap_or(0o644);
        if entry.is_dir() {
            fs::create_dir_all(&output)?;
            directories.push((output, mode));
        } else if mode & 0o170000 == 0o120000 {
            let mut target = String::new();
            (&mut entry).take(65537).read_to_string(&mut target)?;
            if target.len() > 65536 {
                return Err(io::Error::other("Archive link target is too long"));
            }
            safe_path(&name.parent().unwrap_or(Path::new("")).join(&target))?;
            if let Some(parent) = output.parent() {
                fs::create_dir_all(parent)?;
            }
            std::os::unix::fs::symlink(target, output)?;
        } else {
            if let Some(parent) = output.parent() {
                fs::create_dir_all(parent)?;
            }
            let mut file = fs::OpenOptions::new()
                .create_new(true)
                .write(true)
                .open(&output)?;
            io::copy(
                &mut Checked {
                    inner: &mut entry,
                    cancel: cancel.clone(),
                },
                &mut file,
            )?;
            fs::set_permissions(output, fs::Permissions::from_mode(mode & 0o777))?;
        }
    }
    for (path, mode) in directories.into_iter().rev() {
        fs::set_permissions(path, fs::Permissions::from_mode(mode & 0o777))?;
    }
    Ok(())
}

fn safe_path(path: &Path) -> io::Result<()> {
    let mut depth = 0;
    for component in path.components() {
        match component {
            Component::Normal(_) => depth += 1,
            Component::CurDir => {}
            Component::ParentDir if depth > 0 => depth -= 1,
            _ => return Err(io::Error::other("Archive path escapes the destination")),
        }
    }
    Ok(())
}

fn safe_parents(root: &Path, path: &Path) -> io::Result<()> {
    let relative = path.strip_prefix(root).map_err(io::Error::other)?;
    let mut parent = root.to_path_buf();
    for part in relative.components() {
        parent.push(part);
        if fs::symlink_metadata(&parent).is_ok_and(|m| m.is_symlink()) {
            return Err(io::Error::other("Archive entry traverses a symbolic link"));
        }
    }
    Ok(())
}

fn check(cancel: &AtomicBool) -> io::Result<()> {
    if cancel.load(Ordering::Relaxed) {
        Err(io::Error::new(io::ErrorKind::Interrupted, "Cancelled"))
    } else {
        Ok(())
    }
}

struct Checked<T> {
    inner: T,
    cancel: Arc<AtomicBool>,
}
impl<T: Read> Read for Checked<T> {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        check(&self.cancel)?;
        self.inner.read(buffer)
    }
}
impl<T: Write> Write for Checked<T> {
    fn write(&mut self, buffer: &[u8]) -> io::Result<usize> {
        check(&self.cancel)?;
        self.inner.write(buffer)
    }
    fn flush(&mut self) -> io::Result<()> {
        self.inner.flush()
    }
}
impl<T: Seek> Seek for Checked<T> {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        check(&self.cancel)?;
        self.inner.seek(position)
    }
}

const ZIP_ENTRY_LIMIT: usize = 10_000;
const ZIP_REPORT_LIMIT: u64 = 16 * 1024 * 1024;

#[derive(serde::Deserialize, serde::Serialize)]
pub struct ZipPreview {
    pub archive_size: u64,
    pub packed: u64,
    pub unpacked: u64,
    pub files: usize,
    pub folders: usize,
    pub folders_limited: bool,
    pub encrypted: usize,
    pub skipped: usize,
    pub entries: Vec<ZipEntry>,
    pub types: Vec<ZipType>,
    pub largest: Vec<usize>,
    pub tree: Vec<ZipNode>,
    pub tree_limited: bool,
    pub issues: Vec<String>,
    #[serde(default)]
    pub contents: bool,
}

#[derive(serde::Deserialize, serde::Serialize)]
pub struct ZipEntry {
    pub path: String,
    pub packed: u64,
    pub unpacked: u64,
    pub directory: bool,
    pub date: String,
    pub method: String,
    pub flags: String,
}

#[derive(serde::Deserialize, serde::Serialize)]
pub struct ZipType {
    pub name: String,
    pub files: usize,
    pub bytes: u64,
}

#[derive(serde::Deserialize, serde::Serialize)]
pub struct ZipNode {
    pub path: String,
    pub directory: bool,
}

pub fn is_zip(bytes: &[u8]) -> bool {
    bytes.starts_with(b"PK\x03\x04") || bytes.starts_with(b"PK\x05\x06")
}

pub fn zip_preview(path: &Path, cancel: &gio::Cancellable) -> Result<ZipPreview, String> {
    use gio::prelude::CancellableExt;
    use std::{
        process::{Command, Stdio},
        time::{Duration, Instant},
    };

    if cancel.is_cancelled() {
        return Err("ZIP preview cancelled".into());
    }
    let mut output = tempfile::tempfile().map_err(|e| e.to_string())?;
    let mut child = Command::new(std::env::current_exe().map_err(|e| e.to_string())?)
        .arg("--zip-metadata")
        .arg(path)
        .stdin(Stdio::null())
        .stderr(Stdio::null())
        .stdout(output.try_clone().map_err(|e| e.to_string())?)
        .spawn()
        .map_err(|e| format!("Could not start ZIP inspection: {e}"))?;
    let start = Instant::now();
    let result =
        loop {
            if cancel.is_cancelled() {
                break Err("ZIP preview cancelled".into());
            }
            if start.elapsed() > Duration::from_secs(4) {
                break Err("ZIP inspection exceeded its 4-second limit".into());
            }
            if output
                .metadata()
                .map_or(true, |m| m.len() > ZIP_REPORT_LIMIT)
            {
                break Err("ZIP metadata exceeds the 16 MiB preview limit".into());
            }
            match child.try_wait() {
                Ok(Some(status)) if status.success() => break Ok(()),
                Ok(Some(_)) => break Err(
                    "ZIP inspection exceeded its resource limits or could not read the directory"
                        .into(),
                ),
                Ok(None) => std::thread::sleep(Duration::from_millis(20)),
                Err(error) => break Err(error.to_string()),
            }
        };
    if result.is_err() {
        let _ = child.kill();
        let _ = child.wait();
    }
    result?;
    output.rewind().map_err(|e| e.to_string())?;
    let mut bytes = Vec::new();
    output
        .take(ZIP_REPORT_LIMIT + 1)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() as u64 > ZIP_REPORT_LIMIT {
        return Err("ZIP metadata exceeds the preview limit".into());
    }
    serde_json::from_slice::<Result<ZipPreview, String>>(&bytes)
        .map_err(|_| "Could not read the ZIP directory report".to_owned())?
}

pub fn zip_metadata_main() {
    let result = (|| -> Result<ZipPreview, String> {
        for (resource, limit) in [(libc::RLIMIT_AS, 256 * 1024 * 1024), (libc::RLIMIT_CPU, 2)] {
            let value = libc::rlimit {
                rlim_cur: limit,
                rlim_max: limit,
            };
            if unsafe { libc::setrlimit(resource, &value) } != 0 {
                return Err(format!(
                    "Could not bound ZIP inspection: {}",
                    io::Error::last_os_error()
                ));
            }
        }
        let path = std::env::args_os().nth(2).ok_or("Missing ZIP path")?;
        let path = Path::new(&path);
        if !fs::metadata(path).map_err(|e| e.to_string())?.is_file() {
            return Err("ZIP previews require a regular file".into());
        }
        inspect_zip(path).map_err(|error| format!("Could not inspect ZIP: {error}"))
    })();
    let _ = serde_json::to_writer(io::stdout().lock(), &result);
}

struct ZipReader {
    file: File,
    remaining: usize,
    deadline: std::time::Instant,
}

impl Read for ZipReader {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        if bytes.is_empty() {
            return Ok(0);
        }
        if self.remaining == 0 || std::time::Instant::now() > self.deadline {
            return Err(io::Error::other(
                "ZIP directory exceeds the inspection budget",
            ));
        }
        let length = bytes.len().min(self.remaining);
        let count = self.file.read(&mut bytes[..length])?;
        self.remaining -= count;
        Ok(count)
    }
}

impl Seek for ZipReader {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        self.file.seek(position)
    }
}

fn inspect_zip(path: &Path) -> io::Result<ZipPreview> {
    use std::collections::{BTreeMap, BTreeSet};
    use std::time::{Duration, Instant};

    let mut file = File::open(path)?;
    let archive_size = file.metadata()?.len();
    let length = archive_size.min(65_557) as usize;
    file.seek(SeekFrom::End(-(length as i64)))?;
    let mut tail = vec![0; length];
    file.read_exact(&mut tail)?;
    let declared = tail
        .windows(4)
        .rposition(|w| w == b"PK\x05\x06")
        .filter(|&i| i + 22 <= tail.len())
        .map(|i| u16::from_le_bytes([tail[i + 10], tail[i + 11]]))
        .filter(|&n| n != u16::MAX);
    file.rewind()?;
    let reader = ZipReader {
        file,
        remaining: ZIP_REPORT_LIMIT as usize,
        deadline: Instant::now() + Duration::from_secs(2),
    };
    let mut archive = ZipArchive::new(reader)?;
    if archive.len() > ZIP_ENTRY_LIMIT {
        return Err(io::Error::other("ZIP preview is limited to 10,000 entries"));
    }
    let mut preview = ZipPreview {
        archive_size,
        packed: 0,
        unpacked: 0,
        files: 0,
        folders: 0,
        folders_limited: false,
        encrypted: 0,
        skipped: 0,
        entries: Vec::new(),
        types: Vec::new(),
        largest: Vec::new(),
        tree: Vec::new(),
        tree_limited: false,
        issues: Vec::new(),
        contents: false,
    };
    if declared.is_some_and(|count| usize::from(count) != archive.len()) {
        preview.issues.push("Directory count differs from distinct names; entries may be duplicated or inconsistent.".into());
    }
    let mut folders = BTreeSet::new();
    let mut types: BTreeMap<String, (usize, u64)> = BTreeMap::new();
    let mut warnings: BTreeMap<&str, usize> = BTreeMap::new();
    let mut ranges = Vec::new();
    let directory_start = archive.central_directory_start();
    for index in 0..archive.len() {
        let entry = match archive.by_index_raw(index) {
            Ok(entry) => entry,
            Err(_) => {
                preview.skipped += 1;
                continue;
            }
        };
        let name = entry.name();
        let directory = entry.is_dir();
        let mut flags = Vec::new();
        let mut warn = |label| {
            *warnings.entry(label).or_default() += 1;
            flags.push(label);
        };
        if name.starts_with(['/', '\\'])
            || name.split(['/', '\\']).any(|p| p == "..")
            || name.as_bytes().get(1) == Some(&b':')
        {
            warn("unsafe paths");
        }
        if name.chars().any(char::is_control) {
            warn("control characters in paths");
        }
        if name.chars().count() > 512 {
            warn("long paths; display shortened");
        }
        if name.len() > 2048 {
            preview.folders_limited = true;
        }
        if entry.encrypted() {
            preview.encrypted += 1;
            flags.push("encrypted");
        }
        if entry.is_symlink() {
            flags.push("symbolic link");
        }
        let packed = entry.compressed_size();
        let unpacked = entry.size();
        if unpacked > 0 && (packed == 0 || unpacked / packed > 1000) {
            *warnings.entry("extreme declared expansion").or_default() += 1;
            flags.push("extreme expansion");
        }
        let date = entry
            .last_modified()
            .map(|date| date.to_string())
            .unwrap_or_else(|| {
                *warnings.entry("missing or invalid timestamps").or_default() += 1;
                "Timestamp unavailable".into()
            });
        match entry.data_start().checked_add(packed) {
            Some(end) if end <= directory_start && end <= archive_size => {
                if packed > 0 {
                    ranges.push((entry.data_start(), end));
                }
            }
            _ => {
                *warnings
                    .entry("entry data outside the declared payload area")
                    .or_default() += 1;
            }
        }
        if directory && unpacked != 0 {
            *warnings
                .entry("directories declaring payload data")
                .or_default() += 1;
        }
        preview.packed = preview
            .packed
            .checked_add(packed)
            .ok_or_else(|| io::Error::other("Compressed size totals overflow"))?;
        preview.unpacked = preview
            .unpacked
            .checked_add(unpacked)
            .ok_or_else(|| io::Error::other("Unpacked size totals overflow"))?;
        if name.len() <= 2048 {
            let components: Vec<_> = name.trim_end_matches('/').split('/').collect();
            let count = components.len().saturating_sub((!directory) as usize);
            if count > 64 {
                preview.folders_limited = true;
            }
            for end in 1..=count.min(64) {
                if folders.len() >= 20_000 {
                    preview.folders_limited = true;
                    break;
                }
                folders.insert(components[..end].join("/"));
            }
        }
        if !directory {
            preview.files += 1;
            let kind = if entry.is_symlink() {
                "symbolic link".into()
            } else {
                Path::new(name)
                    .extension()
                    .map(|e| clean_zip_text(&e.to_string_lossy(), 32).to_lowercase())
                    .filter(|e| !e.is_empty())
                    .unwrap_or_else(|| "no extension".into())
            };
            let stats = types.entry(kind).or_default();
            stats.0 += 1;
            stats.1 = stats
                .1
                .checked_add(unpacked)
                .ok_or_else(|| io::Error::other("File type size totals overflow"))?;
        }
        preview.entries.push(ZipEntry {
            path: clean_zip_text(name, 512),
            packed,
            unpacked,
            directory,
            date,
            method: format!("{:?}", entry.compression()),
            flags: flags.join(" · "),
        });
    }
    ranges.sort_unstable();
    if ranges.windows(2).any(|pair| pair[0].1 > pair[1].0) {
        preview
            .issues
            .push("Compressed entry ranges overlap.".into());
    }
    if preview.skipped > 0 {
        preview.issues.push(format!(
            "{} entries have unreadable local headers; totals cover readable entries only.",
            preview.skipped
        ));
    }
    if preview.folders_limited {
        preview.issues.push("Folder count and structure are partial: limited to 20,000 folders, 64 levels, and paths up to 2 KiB.".into());
    }
    preview
        .issues
        .extend(warnings.into_iter().map(|(label, count)| {
            format!(
                "{count} {}: {label}.",
                if count == 1 { "entry" } else { "entries" }
            )
        }));
    preview.folders = folders.len();
    let mut nodes: BTreeMap<String, bool> = folders.into_iter().map(|name| (name, true)).collect();
    for entry in &preview.entries {
        nodes.insert(entry.path.trim_end_matches('/').to_owned(), entry.directory);
    }
    preview.tree_limited = nodes.len() > 200 || preview.folders_limited;
    preview.tree = nodes
        .into_iter()
        .take(200)
        .map(|(path, directory)| ZipNode {
            path: clean_zip_text(&path, 512),
            directory,
        })
        .collect();
    preview.types = types
        .into_iter()
        .map(|(name, (files, bytes))| ZipType { name, files, bytes })
        .collect();
    preview
        .types
        .sort_by_key(|kind| std::cmp::Reverse(kind.bytes));
    preview.entries.sort_by(|a, b| a.path.cmp(&b.path));
    preview.largest = (0..preview.entries.len())
        .filter(|&i| !preview.entries[i].directory)
        .collect();
    preview
        .largest
        .sort_by_key(|&i| std::cmp::Reverse(preview.entries[i].unpacked));
    preview.largest.truncate(8);
    Ok(preview)
}

fn clean_zip_text(value: &str, limit: usize) -> String {
    let mut chars = value.chars();
    let mut text: String = chars
        .by_ref()
        .take(limit)
        .map(|c| if c.is_control() { '�' } else { c })
        .collect();
    if chars.next().is_some() {
        text.push('…');
    }
    text
}
