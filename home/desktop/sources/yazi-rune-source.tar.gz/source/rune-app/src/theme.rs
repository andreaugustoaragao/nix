use rune::TextStyle;

use crate::{font::Metrics, scheme::Palette};

#[derive(Clone, Copy)]
pub struct Theme {
    pub colors: Palette,
    pub metrics: Metrics,
}

impl std::ops::Deref for Theme {
    type Target = Palette;
    fn deref(&self) -> &Palette {
        &self.colors
    }
}

impl Theme {
    pub const fn space(&self, steps: u8) -> f32 {
        steps as f32 * 4.0
    }

    pub fn leading(self, height: f32) -> f32 {
        height * self.metrics.ui / 13.0
    }
    pub fn font(self, size: f32, weight: f32) -> TextStyle {
        self.metrics.font(size, weight)
    }
    pub fn code(self) -> TextStyle {
        self.metrics.code()
    }
    pub fn code_height(self) -> f32 {
        self.metrics.code_height()
    }
    pub fn height(self, height: f32) -> f32 {
        (self.metrics.height(height) / self.space(1)).ceil() * self.space(1)
    }
    pub fn row(self) -> f32 {
        let height = 36.0 + (self.metrics.ui.max(self.metrics.list) - 13.0).max(0.0) * 1.25;
        (height / self.space(1)).ceil() * self.space(1)
    }
    pub fn list(self) -> TextStyle {
        self.metrics.list()
    }
}
