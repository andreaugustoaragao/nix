use std::path::PathBuf;

use rune::TextEdit;

use crate::locations::{Application, Applications};

pub struct Chooser {
    pub query: TextEdit,
    pub selected: Option<String>,
    pub all: bool,
    pub always: bool,
    pub custom: Option<PathBuf>,
    pub busy: bool,
    pub error: Option<String>,
}

impl Default for Chooser {
    fn default() -> Self {
        Self {
            query: TextEdit::new(""),
            selected: None,
            all: false,
            always: false,
            custom: None,
            busy: false,
            error: None,
        }
    }
}

impl Chooser {
    pub fn visible<'a>(&self, applications: &'a Applications) -> Vec<&'a Application> {
        let query = self.query.text.trim().to_lowercase();
        applications
            .apps
            .iter()
            .filter(|app| {
                if !query.is_empty() {
                    app.name.to_lowercase().contains(&query)
                } else {
                    self.all || app.recommended || app.default
                }
            })
            .collect()
    }

    pub fn selection<'a>(&self, applications: &'a Applications) -> Option<&'a Application> {
        self.visible(applications)
            .into_iter()
            .find(|app| Some(&app.id) == self.selected.as_ref())
    }

    pub fn select(&mut self, id: String) {
        self.selected = Some(id);
        self.custom = None;
        self.error = None;
    }
}
