#![allow(dead_code)]

//! Print a file through the desktop Print portal.
//!
//! [`run`] blocks on the portal dialog, so call it off the UI thread. The path and
//! MIME belong to that call: changing the preview selection does not change the job.
//! PDF files are submitted unchanged. Text and common images are drawn to a temporary
//! PDF with Cairo, Pango, and GdkPixbuf after the dialog returns a page setup.

use std::{
    collections::HashMap,
    ffi::CString,
    fs,
    io::Read,
    os::unix::ffi::OsStrExt,
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

use futures_util::StreamExt;
use gio::prelude::*;
use zbus::{Fd, OwnedObjectPath, OwnedVariant, Variant};

const UNSUPPORTED: &str = "Printing is available for PDF, text, and common image files";
const TEXT_LIMIT: u64 = 32 * 1024 * 1024;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Outcome {
    Submitted,
    Cancelled,
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum Kind {
    Pdf,
    Text,
    Image,
}

#[repr(C)]
struct NativePage {
    width: f64,
    height: f64,
    left: f64,
    top: f64,
    right: f64,
    bottom: f64,
}

struct Page {
    width_mm: f64,
    height_mm: f64,
    top_mm: f64,
    right_mm: f64,
    bottom_mm: f64,
    left_mm: f64,
    landscape: bool,
}

struct CancelWatch {
    cancel: gio::Cancellable,
    flag: Arc<AtomicBool>,
    handler: Option<gio::CancelledHandlerId>,
    rx: tokio::sync::oneshot::Receiver<()>,
}

struct Document {
    file: fs::File,
    _temporary: Option<tempfile::NamedTempFile>,
}

type Dict = HashMap<String, Variant<'static>>;

unsafe extern "C" {
    fn yr_print_text_pdf(
        text: *const libc::c_char,
        text_len: usize,
        page: *const NativePage,
        path: *const libc::c_char,
        cancelled: Option<unsafe extern "C" fn(*mut libc::c_void) -> i32>,
        cancel_data: *mut libc::c_void,
        error: *mut libc::c_char,
        error_len: usize,
    ) -> i32;

    fn yr_print_image_pdf(
        image_path: *const libc::c_char,
        page: *const NativePage,
        path: *const libc::c_char,
        error: *mut libc::c_char,
        error_len: usize,
    ) -> i32;

    fn yr_print_image_supported(mime: *const libc::c_char) -> i32;
}

pub fn supports(mime: &str) -> bool {
    kind_of(mime).is_some()
}

pub fn unsupported_reason(mime: &str) -> Option<&'static str> {
    if supports(mime) {
        None
    } else {
        Some(UNSUPPORTED)
    }
}

pub fn run(
    path: PathBuf,
    mime: String,
    parent: Option<String>,
    cancel: gio::Cancellable,
) -> Result<Outcome, String> {
    let task = move || {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .map_err(|error| error.to_string())?;
        runtime.block_on(print_job(path, mime, parent, cancel))
    };
    if tokio::runtime::Handle::try_current().is_ok() {
        std::thread::scope(|scope| scope.spawn(task).join().expect("print task panicked"))
    } else {
        task()
    }
}

fn kind_of(mime: &str) -> Option<Kind> {
    let mime = media_type(mime);
    if mime.is_empty() {
        return None;
    }
    if is_raster(mime) {
        return Some(Kind::Image);
    }
    if mime.starts_with("image/") {
        return None;
    }
    if is_pdf(mime) {
        return Some(Kind::Pdf);
    }
    if gio::content_type_is_a(mime, "text/plain") {
        return Some(Kind::Text);
    }
    None
}

fn media_type(mime: &str) -> &str {
    mime.split(';').next().unwrap_or(mime).trim()
}

fn is_pdf(mime: &str) -> bool {
    mime.eq_ignore_ascii_case("application/pdf") || gio::content_type_is_a(mime, "application/pdf")
}

fn is_raster(mime: &str) -> bool {
    let owned = mime.to_ascii_lowercase();
    let queried = match owned.as_str() {
        "image/jpg" | "image/pjpeg" => "image/jpeg",
        other => other,
    };
    let Ok(mime) = CString::new(queried) else {
        return false;
    };
    unsafe { yr_print_image_supported(mime.as_ptr()) != 0 }
}

async fn print_job(
    path: PathBuf,
    mime: String,
    parent: Option<String>,
    cancel: gio::Cancellable,
) -> Result<Outcome, String> {
    let mut watch = CancelWatch::new(&cancel);
    if watch.cancelled() {
        return Ok(Outcome::Cancelled);
    }
    let kind = kind_of(&mime).ok_or(UNSUPPORTED)?;
    let metadata =
        fs::metadata(&path).map_err(|error| format!("Could not read the file: {error}"))?;
    if !metadata.is_file() {
        return Err("Only files can be printed".into());
    }
    if kind == Kind::Text && metadata.len() > TEXT_LIMIT {
        return Err("This text file is too large to print".into());
    }

    let title = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("Print")
        .to_string();
    let parent = parent.unwrap_or_default();
    let connection = zbus::connection::Builder::session()
        .build()
        .await
        .map_err(portal_failure)?;
    let prepare_token = handle_token()?;
    let prepare = (
        parent.as_str(),
        title.as_str(),
        Dict::new(),
        Dict::new(),
        options(&prepare_token, None),
    );
    let Some(results) = exchange(
        &connection,
        "PreparePrint",
        &prepare,
        &prepare_token,
        &mut watch,
    )
    .await?
    else {
        return Ok(Outcome::Cancelled);
    };
    let (page, job) = page_from(&results)?;
    if watch.cancelled() {
        return Ok(Outcome::Cancelled);
    }

    let document = match kind {
        Kind::Pdf => Document::open(&path, None)?,
        Kind::Text => match render_text(&path, &page, &watch.flag)? {
            None => return Ok(Outcome::Cancelled),
            Some(file) => {
                let rendered = file.path().to_path_buf();
                Document::open(&rendered, Some(file))?
            }
        },
        Kind::Image => match render_image(&path, &page)? {
            None => return Ok(Outcome::Cancelled),
            Some(file) => {
                let rendered = file.path().to_path_buf();
                Document::open(&rendered, Some(file))?
            }
        },
    };
    if watch.cancelled() {
        return Ok(Outcome::Cancelled);
    }

    let print_token = handle_token()?;
    let print = (
        parent.as_str(),
        title.as_str(),
        Fd::from(&document.file),
        options(&print_token, Some(job)),
    );
    let submitted = exchange(&connection, "Print", &print, &print_token, &mut watch).await?;
    drop(document);
    if submitted.is_none() {
        Ok(Outcome::Cancelled)
    } else {
        Ok(Outcome::Submitted)
    }
}

impl Document {
    fn open(path: &Path, temporary: Option<tempfile::NamedTempFile>) -> Result<Self, String> {
        let file =
            fs::File::open(path).map_err(|error| format!("Could not read the file: {error}"))?;
        Ok(Self {
            file,
            _temporary: temporary,
        })
    }
}

fn render_text(
    path: &Path,
    page: &Page,
    flag: &AtomicBool,
) -> Result<Option<tempfile::NamedTempFile>, String> {
    let text =
        decode_text(&fs::read(path).map_err(|error| format!("Could not read the file: {error}"))?);
    let file = tempfile::Builder::new()
        .prefix("yazi-rune-print-")
        .suffix(".pdf")
        .tempfile()
        .map_err(|error| error.to_string())?;
    let pdf = c_path(file.path())?;
    let native = native_page(page);
    let mut error = [0u8; 512];
    let code = unsafe {
        yr_print_text_pdf(
            text.as_ptr().cast(),
            text.len(),
            &native,
            pdf.as_ptr(),
            Some(poll_cancel),
            std::ptr::from_ref(flag) as *mut libc::c_void,
            error.as_mut_ptr().cast(),
            error.len(),
        )
    };
    if native_cancelled(code, &error)? {
        Ok(None)
    } else {
        Ok(Some(file))
    }
}

fn render_image(path: &Path, page: &Page) -> Result<Option<tempfile::NamedTempFile>, String> {
    let file = tempfile::Builder::new()
        .prefix("yazi-rune-print-")
        .suffix(".pdf")
        .tempfile()
        .map_err(|error| error.to_string())?;
    let image = c_path(path)?;
    let pdf = c_path(file.path())?;
    let native = native_page(page);
    let mut error = [0u8; 512];
    let code = unsafe {
        yr_print_image_pdf(
            image.as_ptr(),
            &native,
            pdf.as_ptr(),
            error.as_mut_ptr().cast(),
            error.len(),
        )
    };
    if native_cancelled(code, &error)? {
        Ok(None)
    } else {
        Ok(Some(file))
    }
}

fn native_cancelled(code: i32, error: &[u8]) -> Result<bool, String> {
    match code {
        0 => Ok(false),
        1 => Ok(true),
        _ => Err(native_message(error)),
    }
}

fn native_message(error: &[u8]) -> String {
    let end = error
        .iter()
        .position(|byte| *byte == 0)
        .unwrap_or(error.len());
    let message = String::from_utf8_lossy(&error[..end]);
    if message.is_empty() {
        "Could not prepare the document for printing".into()
    } else {
        message.into_owned()
    }
}

fn decode_text(bytes: &[u8]) -> String {
    if let Some(text) = bytes.strip_prefix(&[0xEF, 0xBB, 0xBF]) {
        return String::from_utf8_lossy(text).into_owned();
    }
    if let Some(text) = bytes.strip_prefix(&[0xFF, 0xFE]) {
        let units = text
            .chunks_exact(2)
            .map(|unit| u16::from_le_bytes([unit[0], unit[1]]))
            .collect::<Vec<_>>();
        return String::from_utf16_lossy(&units);
    }
    if let Some(text) = bytes.strip_prefix(&[0xFE, 0xFF]) {
        let units = text
            .chunks_exact(2)
            .map(|unit| u16::from_be_bytes([unit[0], unit[1]]))
            .collect::<Vec<_>>();
        return String::from_utf16_lossy(&units);
    }
    String::from_utf8_lossy(bytes).into_owned()
}

fn native_page(page: &Page) -> NativePage {
    let mut width = (page.width_mm * 72.0 / 25.4).max(72.0);
    let mut height = (page.height_mm * 72.0 / 25.4).max(72.0);
    if page.landscape {
        std::mem::swap(&mut width, &mut height);
    }
    let inset = |margin: f64, limit: f64| {
        (margin.max(0.0) * 72.0 / 25.4).clamp(0.0, ((limit - 36.0) / 2.0).max(0.0))
    };
    NativePage {
        width,
        height,
        left: inset(page.left_mm, width),
        top: inset(page.top_mm, height),
        right: inset(page.right_mm, width),
        bottom: inset(page.bottom_mm, height),
    }
}

fn c_path(path: &Path) -> Result<CString, String> {
    CString::new(path.as_os_str().as_bytes()).map_err(|_| "The file path cannot be printed".into())
}

unsafe extern "C" fn poll_cancel(data: *mut libc::c_void) -> i32 {
    let flag = unsafe { &*data.cast::<AtomicBool>() };
    i32::from(flag.load(Ordering::Acquire))
}

impl CancelWatch {
    fn new(cancel: &gio::Cancellable) -> Self {
        let flag = Arc::new(AtomicBool::new(false));
        let (tx, rx) = tokio::sync::oneshot::channel();
        let notified = Arc::clone(&flag);
        let handler = cancel.connect_cancelled(move |_| {
            notified.store(true, Ordering::Release);
            let _ = tx.send(());
        });
        if handler.is_none() {
            flag.store(true, Ordering::Release);
        }
        Self {
            cancel: cancel.clone(),
            flag,
            handler,
            rx,
        }
    }

    fn cancelled(&self) -> bool {
        self.flag.load(Ordering::Acquire)
    }

    async fn wait(&mut self) {
        if self.cancelled() {
            return;
        }
        let _ = (&mut self.rx).await;
    }
}

impl Drop for CancelWatch {
    fn drop(&mut self) {
        if let Some(handler) = self.handler.take() {
            self.cancel.disconnect_cancelled(handler);
        }
    }
}

fn options(handle_token: &str, job: Option<u32>) -> Dict {
    let mut options = Dict::new();
    options.insert(
        "handle_token".into(),
        Variant::from(handle_token.to_string()),
    );
    options.insert("modal".into(), Variant::from(true));
    options.insert(
        "supported_output_file_formats".into(),
        Variant::from(vec!["pdf".to_string()]),
    );
    if let Some(job) = job {
        options.insert("token".into(), Variant::from(job));
    }
    options
}

fn handle_token() -> Result<String, String> {
    let mut bytes = [0u8; 8];
    fs::File::open("/dev/urandom")
        .and_then(|mut file| file.read_exact(&mut bytes))
        .map_err(|error| format!("Could not start the print dialog: {error}"))?;
    Ok(format!("yazi_rune_{:016x}", u64::from_ne_bytes(bytes)))
}

fn request_path(connection: &zbus::Connection, token: &str) -> Result<String, String> {
    let unique = connection
        .unique_name()
        .ok_or("Desktop bus connection has no unique name")?;
    let sender = unique.trim_start_matches(':').replace('.', "_");
    Ok(format!(
        "/org/freedesktop/portal/desktop/request/{sender}/{token}"
    ))
}

async fn exchange<B>(
    connection: &zbus::Connection,
    method: &str,
    body: &B,
    token: &str,
    watch: &mut CancelWatch,
) -> Result<Option<HashMap<String, OwnedVariant>>, String>
where
    B: serde::Serialize + zbus::DynamicType,
{
    if watch.cancelled() {
        return Ok(None);
    }
    let path = request_path(connection, token)?;
    let portal = zbus::Proxy::new(
        connection,
        "org.freedesktop.portal.Desktop",
        "/org/freedesktop/portal/desktop",
        "org.freedesktop.portal.Print",
    )
    .await
    .map_err(portal_failure)?;
    let mut request = zbus::Proxy::new(
        connection,
        "org.freedesktop.portal.Desktop",
        path.as_str(),
        "org.freedesktop.portal.Request",
    )
    .await
    .map_err(portal_failure)?;
    let mut signals = request
        .receive_signal("Response")
        .await
        .map_err(portal_failure)?;
    let call = portal.call_method(method, body);
    tokio::pin!(call);
    let message = tokio::select! {
        biased;
        _ = watch.wait() => {
            let _ = request.call_method("Close", &()).await;
            return Ok(None);
        }
        result = &mut call => result.map_err(portal_failure)?,
    };
    let handle: OwnedObjectPath = message
        .body()
        .deserialize()
        .map_err(|error| error.to_string())?;
    if handle.as_str() != path {
        request = zbus::Proxy::new(
            connection,
            "org.freedesktop.portal.Desktop",
            handle.as_str(),
            "org.freedesktop.portal.Request",
        )
        .await
        .map_err(portal_failure)?;
        signals = request
            .receive_signal("Response")
            .await
            .map_err(portal_failure)?;
    }

    let message = tokio::select! {
        biased;
        message = signals.next() => message,
        _ = watch.wait() => {
            let _ = request.call_method("Close", &()).await;
            return Ok(None);
        }
    };
    let Some(message) = message else {
        return Err("Print dialog closed without a response".into());
    };
    let (response, results): (u32, HashMap<String, OwnedVariant>) = message
        .body()
        .deserialize()
        .map_err(|error| error.to_string())?;
    match response {
        0 => Ok(Some(results)),
        1 => Ok(None),
        _ => Err("Print dialog failed".into()),
    }
}

fn page_from(results: &HashMap<String, OwnedVariant>) -> Result<(Page, u32), String> {
    let token = results
        .get("token")
        .ok_or("Print dialog did not return a job token")?;
    let token = u32::try_from(token).map_err(|_| "Print dialog returned an invalid job token")?;
    let mut page = Page {
        width_mm: 210.0,
        height_mm: 297.0,
        top_mm: 12.7,
        right_mm: 12.7,
        bottom_mm: 12.7,
        left_mm: 12.7,
        landscape: false,
    };
    if let Some(setup) = dict_field(results, "page-setup") {
        if let Some(width) = number_field(&setup, "Width") {
            page.width_mm = width;
        }
        if let Some(height) = number_field(&setup, "Height") {
            page.height_mm = height;
        }
        if let Some(margin) = number_field(&setup, "MarginTop") {
            page.top_mm = margin;
        }
        if let Some(margin) = number_field(&setup, "MarginBottom") {
            page.bottom_mm = margin;
        }
        if let Some(margin) = number_field(&setup, "MarginLeft") {
            page.left_mm = margin;
        }
        if let Some(margin) = number_field(&setup, "MarginRight") {
            page.right_mm = margin;
        }
        if let Some(orientation) = text_field(&setup, "Orientation") {
            page.landscape = matches!(
                orientation.as_str(),
                "landscape" | "reverse-landscape" | "reverse_landscape"
            );
        }
    }
    Ok((page, token))
}

fn dict_field(
    map: &HashMap<String, OwnedVariant>,
    key: &str,
) -> Option<HashMap<String, OwnedVariant>> {
    let value = map.get(key)?.try_clone().ok()?;
    HashMap::try_from(value).ok()
}

fn number_field(map: &HashMap<String, OwnedVariant>, key: &str) -> Option<f64> {
    let value = map.get(key)?;
    f64::try_from(value).ok().or_else(|| {
        <&str>::try_from(value)
            .ok()
            .and_then(|text| text.parse().ok())
    })
}

fn text_field(map: &HashMap<String, OwnedVariant>, key: &str) -> Option<String> {
    map.get(key)
        .and_then(|value| <&str>::try_from(value).ok().map(str::to_owned))
}

fn portal_failure(error: zbus::Error) -> String {
    let text = error.to_string();
    if text.contains("NameHasNoOwner") || text.contains("ServiceUnknown") {
        format!("Print dialog is unavailable: {text}")
    } else {
        format!("Print dialog failed: {text}")
    }
}
