use std::{
    fs,
    io::{BufWriter, Write},
    path::{Path, PathBuf},
};

use gio::prelude::FileExt;
use serde::{Deserialize, Serialize};

use crate::{
    pane::Pane,
    preference::Preferences,
    state::{State, Tab},
};

#[derive(Deserialize, Serialize)]
pub struct Session {
    version: u32,
    panes: [SessionPane; 2],
    active_pane: usize,
    split: bool,
    split_width: f32,
    sidebar_hidden: bool,
    preview_expanded: bool,
    preview_width: f32,
}

#[derive(Deserialize, Serialize)]
struct SessionPane {
    tabs: Vec<SessionTab>,
    active: usize,
    preview_file: Option<String>,
    preview_scroll: f32,
}

#[derive(Deserialize, Serialize)]
struct SessionTab {
    cwd: String,
    location: String,
    name: Option<String>,
    hovered: Option<String>,
    selected: Vec<String>,
    filter: String,
    scroll: f32,
}

impl Session {
    pub fn capture(state: &State) -> Self {
        let panes = std::array::from_fn(|side| {
            let pane = &state.panes[side];
            let tabs = pane
                .tabs
                .iter()
                .map(|tab| SessionTab {
                    cwd: uri(&tab.cwd),
                    location: state.location_uri(&tab.cwd),
                    name: tab.name.clone(),
                    hovered: tab
                        .file()
                        .map(|file| &file.path)
                        .or_else(|| tab.hovered.get(&tab.cwd))
                        .map(|path| uri(path)),
                    selected: tab.selected.iter().map(|path| uri(path)).collect(),
                    filter: tab.filter.clone(),
                    scroll: tab.resume_scroll.unwrap_or_else(|| tab.scroll.get()),
                })
                .collect();
            let (preview_file, preview_scroll) = if let Some((path, offset)) = &pane.resume_preview
            {
                (Some(uri(path)), *offset)
            } else {
                (
                    pane.preview_path.as_deref().map(uri),
                    pane.preview_scroll.get()[0],
                )
            };
            SessionPane {
                tabs,
                active: pane.active,
                preview_file,
                preview_scroll,
            }
        });
        Self {
            version: 1,
            panes,
            active_pane: state.active_pane,
            split: state.split,
            split_width: state.split_width,
            sidebar_hidden: state.sidebar_hidden,
            preview_expanded: state.preview_expanded,
            preview_width: state.preview_width,
        }
    }

    pub fn load(path: &Path) -> Result<Option<Self>, String> {
        let data = match fs::read(path) {
            Ok(data) => data,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(error) => return Err(error.to_string()),
        };
        let session: Self = serde_json::from_slice(&data).map_err(|error| error.to_string())?;
        if session.version != 1 {
            return Err("Unsupported session version".into());
        }
        if session.active_pane >= 2
            || session
                .panes
                .iter()
                .any(|pane| pane.tabs.is_empty() || pane.active >= pane.tabs.len())
        {
            return Err("Session contains an invalid active pane or tab".into());
        }
        Ok(Some(session))
    }

    pub fn restore(self, state: &mut State) -> Result<(), String> {
        let [left, right] = self.panes;
        let panes = [left.restore(&state.views)?, right.restore(&state.views)?];
        state.panes = panes;
        state.active_pane = self.active_pane;
        state.split = self.split;
        state.split_width = self.split_width.clamp(0.25, 0.75);
        state.sidebar_hidden = self.sidebar_hidden;
        state.preview_expanded = self.preview_expanded;
        state.preview_width = self.preview_width.clamp(0.25, 0.75);
        Ok(())
    }

    pub fn save(self, path: PathBuf) -> Result<(), String> {
        let parent = path.parent().ok_or("Session needs a state directory")?;
        fs::create_dir_all(parent).map_err(|error| error.to_string())?;
        let mut temporary =
            tempfile::NamedTempFile::new_in(parent).map_err(|error| error.to_string())?;
        {
            let mut writer = BufWriter::new(&mut temporary);
            serde_json::to_writer_pretty(&mut writer, &self).map_err(|error| error.to_string())?;
            writer.flush().map_err(|error| error.to_string())?;
        }
        temporary.persist(path).map_err(|error| error.to_string())?;
        Ok(())
    }
}

impl SessionPane {
    fn restore(self, views: &Preferences) -> Result<Pane, String> {
        let tabs = self
            .tabs
            .into_iter()
            .map(|tab| tab.restore(views))
            .collect::<Result<Vec<_>, _>>()?;
        let mut pane = Pane::new(tabs[self.active].cwd.clone(), tabs[self.active].preference);
        pane.tabs = tabs;
        pane.active = self.active;
        pane.resume_preview = self
            .preview_file
            .map(|file| path(&file).map(|file| (file, self.preview_scroll.max(0.0))))
            .transpose()?;
        Ok(pane)
    }
}

impl SessionTab {
    fn restore(self, views: &Preferences) -> Result<Tab, String> {
        let cwd = path(&self.cwd)?;
        let mut tab = Tab::new(cwd.clone(), views.get(&self.location));
        tab.name = self.name;
        if let Some(file) = self.hovered {
            let file = path(&file)?;
            if file.parent() == Some(&cwd) {
                if file
                    .file_name()
                    .is_some_and(|name| name.as_encoded_bytes().starts_with(b"."))
                {
                    tab.preference.show_hidden = true;
                }
                tab.hovered.insert(cwd.clone(), file);
            }
        }
        for file in self.selected {
            let file = path(&file)?;
            if file.parent() == Some(&cwd) {
                tab.selected.insert(file);
            }
        }
        tab.filter = self.filter;
        tab.resume_scroll = Some(self.scroll.max(0.0));
        Ok(tab)
    }
}

fn uri(path: &Path) -> String {
    gio::File::for_path(path).uri().into()
}

fn path(uri: &str) -> Result<PathBuf, String> {
    gio::File::for_uri(uri)
        .path()
        .filter(|path| path.is_absolute())
        .ok_or_else(|| "Session contains an invalid local file URI".into())
}
