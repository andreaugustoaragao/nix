use rune::Icon;

use crate::file::File;

pub static FOLDER: Icon = Icon {
    name: "folder",
    view: 16.0,
    body: r#"<path d="M1.5 3h5l2 2h6v8h-13Z" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static FILE: Icon = Icon {
    name: "file",
    view: 16.0,
    body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static CODE: Icon = Icon {
    name: "source-code",
    view: 16.0,
    body: r#"<path d="m5 4-4 4 4 4m6-8 4 4-4 4m-2-10-2 12" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

static IMAGE: Icon = Icon {
    name: "image-file",
    view: 16.0,
    body: r#"<rect x="1.5" y="2" width="13" height="12" rx="1" stroke="currentColor"/><circle cx="5" cy="5.5" r="1" fill="currentColor"/><path d="m2 12 4-4 3 3 2-2 3 3" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static AUDIO: Icon = Icon {
    name: "audio-file",
    view: 16.0,
    body: r#"<path d="M6 11V3l7-1v8M6 5l7-1" stroke="currentColor"/><ellipse cx="4" cy="12" rx="2" ry="1.5" stroke="currentColor"/><ellipse cx="11" cy="11" rx="2" ry="1.5" stroke="currentColor"/>"#,
};

static VIDEO: Icon = Icon {
    name: "video-file",
    view: 16.0,
    body: r#"<rect x="1.5" y="3" width="9" height="10" rx="1" stroke="currentColor"/><path d="m10.5 6 4-2v8l-4-2" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static ARCHIVE: Icon = Icon {
    name: "archive-file",
    view: 16.0,
    body: r#"<rect x="2" y="2" width="12" height="3" rx=".5" stroke="currentColor"/><path d="M3 5v9h10V5M6 8h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static DOCUMENT: Icon = Icon {
    name: "document-file",
    view: 16.0,
    body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4M5 8h6M5 10h6M5 12h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static CONFIG: Icon = Icon {
    name: "configuration-file",
    view: 16.0,
    body: r#"<path d="M2 4h3m3 0h6M2 8h7m3 0h2M2 12h1m3 0h8" stroke="currentColor"/><circle cx="6.5" cy="4" r="1.5" stroke="currentColor"/><circle cx="10.5" cy="8" r="1.5" stroke="currentColor"/><circle cx="4.5" cy="12" r="1.5" stroke="currentColor"/>"#,
};

static DATABASE: Icon = Icon {
    name: "database-file",
    view: 16.0,
    body: r#"<ellipse cx="8" cy="3.5" rx="5.5" ry="2" stroke="currentColor"/><path d="M2.5 3.5v9c0 2.5 11 2.5 11 0v-9M2.5 8c0 2.5 11 2.5 11 0" stroke="currentColor"/>"#,
};

static TERMINAL: Icon = Icon {
    name: "shell-script",
    view: 16.0,
    body: r#"<path d="m2 4 4 4-4 4m6 0h6" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static LINK: Icon = Icon {
    name: "symbolic-link",
    view: 16.0,
    body: r#"<path d="M4 12 12 4M5 4h7v7" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static CHECK: Icon = Icon {
    name: "selected",
    view: 16.0,
    body: r#"<path d="m2.5 8 3.5 3.5 7.5-7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub fn for_file(file: &File) -> &'static Icon {
    if file.directory {
        return &FOLDER;
    }
    let name = file.name.to_ascii_lowercase();
    match name.as_str() {
        "dockerfile" | "makefile" | "justfile" | "rakefile" => return &CODE,
        ".gitignore" | ".gitattributes" | ".gitmodules" | ".editorconfig" | ".env"
        | "cargo.lock" | "flake.lock" | "package-lock.json" => return &CONFIG,
        "license" | "licence" | "readme" | "changelog" | "authors" => return &DOCUMENT,
        _ => {}
    }
    let extension = file
        .path
        .extension()
        .unwrap_or_default()
        .to_string_lossy()
        .to_ascii_lowercase();
    match extension.as_str() {
        "rs" | "go" | "py" | "pyw" | "js" | "jsx" | "ts" | "tsx" | "c" | "h" | "cpp" | "hpp"
        | "cc" | "cs" | "java" | "kt" | "swift" | "rb" | "php" | "lua" | "nix" | "html" | "htm"
        | "css" | "scss" | "sass" | "vue" | "svelte" | "zig" | "ex" | "exs" | "erl" | "hs"
        | "r" | "dart" | "sql" | "wasm" => &CODE,
        "png" | "jpg" | "jpeg" | "gif" | "webp" | "bmp" | "tiff" | "tif" | "ico" | "svg"
        | "svgz" | "avif" | "heic" | "raw" | "psd" => &IMAGE,
        "mp3" | "flac" | "wav" | "ogg" | "opus" | "aac" | "m4a" | "aiff" | "mid" | "midi" => &AUDIO,
        "mp4" | "mkv" | "webm" | "mov" | "avi" | "m4v" | "mpeg" | "mpg" => &VIDEO,
        "zip" | "tar" | "gz" | "bz2" | "xz" | "zst" | "7z" | "rar" | "tgz" | "deb" | "rpm"
        | "iso" => &ARCHIVE,
        "txt" | "md" | "markdown" | "rst" | "pdf" | "doc" | "docx" | "odt" | "rtf" | "epub"
        | "csv" | "tsv" | "xls" | "xlsx" | "ods" | "ppt" | "pptx" | "tex" | "log" => &DOCUMENT,
        "json" | "jsonc" | "toml" | "yaml" | "yml" | "xml" | "ini" | "conf" | "cfg" | "env"
        | "lock" | "properties" => &CONFIG,
        "db" | "sqlite" | "sqlite3" | "mdb" => &DATABASE,
        "sh" | "bash" | "zsh" | "fish" | "ps1" | "bat" | "cmd" => &TERMINAL,
        _ => &FILE,
    }
}
