use rune::Icon;

use crate::file::File;

pub static FOLDER: Icon = Icon {
    name: "folder",
    view: 16.0,
    body: r#"<path d="M1.5 3h5l2 2h6v8h-13Z" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static FILE: Icon = Icon {
    name: "file",
    view: 16.0,
    body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static CODE: Icon = Icon {
    name: "source-code",
    view: 16.0,
    body: r#"<path d="m5 4-4 4 4 4m6-8 4 4-4 4m-2-10-2 12" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

static IMAGE: Icon = Icon {
    name: "image-file",
    view: 16.0,
    body: r#"<rect x="1.5" y="2" width="13" height="12" rx="1" stroke="currentColor"/><circle cx="5" cy="5.5" r="1" fill="currentColor"/><path d="m2 12 4-4 3 3 2-2 3 3" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static AUDIO: Icon = Icon {
    name: "audio-file",
    view: 16.0,
    body: r#"<path d="M6 11V3l7-1v8M6 5l7-1" stroke="currentColor"/><ellipse cx="4" cy="12" rx="2" ry="1.5" stroke="currentColor"/><ellipse cx="11" cy="11" rx="2" ry="1.5" stroke="currentColor"/>"#,
};

static VIDEO: Icon = Icon {
    name: "video-file",
    view: 16.0,
    body: r#"<rect x="1.5" y="3" width="9" height="10" rx="1" stroke="currentColor"/><path d="m10.5 6 4-2v8l-4-2" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static ARCHIVE: Icon = Icon {
    name: "archive-file",
    view: 16.0,
    body: r#"<rect x="2" y="2" width="12" height="3" rx=".5" stroke="currentColor"/><path d="M3 5v9h10V5M6 8h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static DOCUMENT: Icon = Icon {
    name: "document-file",
    view: 16.0,
    body: r#"<path d="M3 1.5h6l4 4v9H3ZM9 1.5v4h4M5 8h6M5 10h6M5 12h4" stroke="currentColor" stroke-linejoin="round"/>"#,
};

static CONFIG: Icon = Icon {
    name: "configuration-file",
    view: 16.0,
    body: r#"<path d="M2 4h3m3 0h6M2 8h7m3 0h2M2 12h1m3 0h8" stroke="currentColor"/><circle cx="6.5" cy="4" r="1.5" stroke="currentColor"/><circle cx="10.5" cy="8" r="1.5" stroke="currentColor"/><circle cx="4.5" cy="12" r="1.5" stroke="currentColor"/>"#,
};

static DATABASE: Icon = Icon {
    name: "database-file",
    view: 16.0,
    body: r#"<ellipse cx="8" cy="3.5" rx="5.5" ry="2" stroke="currentColor"/><path d="M2.5 3.5v9c0 2.5 11 2.5 11 0v-9M2.5 8c0 2.5 11 2.5 11 0" stroke="currentColor"/>"#,
};

static TERMINAL: Icon = Icon {
    name: "shell-script",
    view: 16.0,
    body: r#"<path d="m2 4 4 4-4 4m6 0h6" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static LINK: Icon = Icon {
    name: "symbolic-link",
    view: 16.0,
    body: r#"<path d="M4 12 12 4M5 4h7v7" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static CHECK: Icon = Icon {
    name: "selected",
    view: 16.0,
    body: r#"<path d="m2.5 8 3.5 3.5 7.5-7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

pub static BACK: Icon = Icon {
    name: "back",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m10 3-5 5 5 5"/>"#,
};

pub static FORWARD: Icon = Icon {
    name: "forward",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m6 3 5 5-5 5"/>"#,
};

pub static UP: Icon = Icon {
    name: "up",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 14V2m-5 5 5-5 5 5"/>"#,
};

pub static SIDEBAR: Icon = Icon {
    name: "sidebar",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="1.5" y="2.5" width="13" height="11" rx="1.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M6 3v10"/>"#,
};

pub static SEARCH: Icon = Icon {
    name: "search",
    view: 16.0,
    body: r#"<circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="7" cy="7" r="4.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m10.5 10.5 4 4"/>"#,
};

pub static SPLIT: Icon = Icon {
    name: "split-view",
    view: 16.0,
    body: r#"<rect fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" x="1.5" y="2.5" width="13" height="11" rx="1.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 3v10"/>"#,
};

pub static SETTINGS: Icon = Icon {
    name: "settings",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M2 4h12M2 8h12M2 12h12"/><circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="5" cy="4" r="1.5"/><circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="11" cy="8" r="1.5"/><circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="6" cy="12" r="1.5"/>"#,
};

pub static REFRESH: Icon = Icon {
    name: "refresh",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M3 5a5.5 5.5 0 1 1-1 4M3 1v4h4"/>"#,
};

pub static VIEW: Icon = Icon {
    name: "view-options",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M3 2v12m-2-2 2 2 2-2M8 4h6M8 8h4M8 12h2"/>"#,
};

pub static EDIT: Icon = Icon {
    name: "edit-path",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m3 10 8-8 3 3-8 8-4 1Zm6-6 3 3"/>"#,
};

pub static EXPAND: Icon = Icon {
    name: "expand",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M10 2h4v4M2 10v4h4m8-12-5 5m-7 7 5-5"/>"#,
};

pub static RESTORE: Icon = Icon {
    name: "restore",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M14 6h-4V2M6 14v-4H2m8-4 4-4m-8 8-4 4"/>"#,
};

pub static HELP: Icon = Icon {
    name: "help",
    view: 16.0,
    body: r#"<circle fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" cx="8" cy="8" r="6.5"/><path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M6 5.5a2 2 0 1 1 3 1.7C8 7.7 8 8 8 9m0 2v.5"/>"#,
};

pub static CLOSE: Icon = Icon {
    name: "close",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m4 4 8 8m0-8-8 8"/>"#,
};

pub static PLUS: Icon = Icon {
    name: "new-tab",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="M8 3v10M3 8h10"/>"#,
};

pub static CHEVRON: Icon = Icon {
    name: "open-folder",
    view: 16.0,
    body: r#"<path fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" d="m6 3 5 5-5 5"/>"#,
};

pub fn for_file(file: &File) -> &'static Icon {
    if file.directory {
        return &FOLDER;
    }
    let name = file.name.to_ascii_lowercase();
    match name.as_str() {
        "dockerfile" | "makefile" | "justfile" | "rakefile" => return &CODE,
        ".gitignore" | ".gitattributes" | ".gitmodules" | ".editorconfig" | ".env"
        | "cargo.lock" | "flake.lock" | "package-lock.json" => return &CONFIG,
        "license" | "licence" | "readme" | "changelog" | "authors" => return &DOCUMENT,
        _ => {}
    }
    let extension = file
        .path
        .extension()
        .unwrap_or_default()
        .to_string_lossy()
        .to_ascii_lowercase();
    match extension.as_str() {
        "rs" | "go" | "py" | "pyw" | "js" | "jsx" | "ts" | "tsx" | "c" | "h" | "cpp" | "hpp"
        | "cc" | "cs" | "java" | "kt" | "swift" | "rb" | "php" | "lua" | "nix" | "html" | "htm"
        | "css" | "scss" | "sass" | "vue" | "svelte" | "zig" | "ex" | "exs" | "erl" | "hs"
        | "r" | "dart" | "sql" | "wasm" => &CODE,
        "png" | "jpg" | "jpeg" | "gif" | "webp" | "bmp" | "tiff" | "tif" | "ico" | "svg"
        | "svgz" | "avif" | "heic" | "raw" | "psd" => &IMAGE,
        "mp3" | "flac" | "wav" | "ogg" | "opus" | "aac" | "m4a" | "aiff" | "mid" | "midi" => &AUDIO,
        "mp4" | "mkv" | "webm" | "mov" | "avi" | "m4v" | "mpeg" | "mpg" => &VIDEO,
        "zip" | "tar" | "gz" | "bz2" | "xz" | "zst" | "7z" | "rar" | "tgz" | "deb" | "rpm"
        | "iso" => &ARCHIVE,
        "txt" | "md" | "markdown" | "rst" | "pdf" | "doc" | "docx" | "odt" | "rtf" | "epub"
        | "csv" | "tsv" | "xls" | "xlsx" | "ods" | "ppt" | "pptx" | "tex" | "log" => &DOCUMENT,
        "json" | "jsonc" | "toml" | "yaml" | "yml" | "xml" | "ini" | "conf" | "cfg" | "env"
        | "lock" | "properties" => &CONFIG,
        "db" | "sqlite" | "sqlite3" | "mdb" => &DATABASE,
        "sh" | "bash" | "zsh" | "fish" | "ps1" | "bat" | "cmd" => &TERMINAL,
        _ => &FILE,
    }
}
