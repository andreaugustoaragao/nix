use rune::{
    Color, Cx, El, GrowthSpec, ScrollSpec, SurfaceFit, TextStyle, col, el, row, text, text_input,
};

use crate::{
    file::{self, File, Preview},
    icon,
    operations::{Choice, Status},
    state::State,
};

const ROW: f32 = 27.0;
const MONO: TextStyle = TextStyle::new(13.0, 400.0).mono().lh(20.0);

#[derive(Clone, Copy)]
struct Palette {
    dark: bool,
    background: Color,
    panel: Color,
    text: Color,
    muted: Color,
    line: Color,
    accent: Color,
    folder: Color,
    selected: Color,
}

fn palette(dark: bool) -> Palette {
    let colors = if dark {
        [
            "#151b24", "#1b2330", "#dce4ef", "#91a0b5", "#303d50", "#91baf8", "#e8c180", "#24476c",
        ]
    } else {
        [
            "#f9fbfe", "#edf2f8", "#25354b", "#536781", "#ccd6e4", "#245da5", "#896015", "#dbeaff",
        ]
    };
    let [
        background,
        panel,
        text,
        muted,
        line,
        accent,
        folder,
        selected,
    ] = colors.map(|c| rune::color::hex(c).expect("palette color"));
    Palette {
        dark,
        background,
        panel,
        text,
        muted,
        line,
        accent,
        folder,
        selected,
    }
}

fn rule(p: Palette) -> El {
    el().w(1.0).h_full().fill(p.line)
}

fn label(value: impl Into<String>, p: Palette) -> El {
    text(value).font(MONO).color(p.muted).truncate().shrink()
}

pub fn view(s: &State, cx: &mut Cx<State>) -> El {
    let p = palette(s.dark.unwrap_or(cx.system_dark()));
    cx.reduced_motion(true);
    let tab = s.tab();
    let mut tabs = row()
        .h(37.0)
        .w_full()
        .center_y()
        .gap(1.0)
        .fill(p.panel)
        .px(8.0);
    for (index, tab) in s.tabs.iter().enumerate() {
        let title = tab.name.clone().unwrap_or_else(|| s.folder_name(&tab.cwd));
        tabs = tabs.child(
            row()
                .key(format!("tab-{index}"))
                .role("tab")
                .label(format!("Tab {}: {title}", index + 1))
                .h(29.0)
                .px(10.0)
                .gap(8.0)
                .center_y()
                .radius(3.0)
                .fill(if index == s.active {
                    p.selected
                } else {
                    Color::TRANSPARENT
                })
                .hover(p.selected.alpha(0.6))
                .on_press_tx(move |s: &mut State, tx| {
                    s.command(&format!("tab_switch {index}"), tx);
                    tx.blur();
                })
                .child(text(format!("{}", index + 1)).font(MONO).color(p.muted))
                .child(text(title).font(MONO).color(if index == s.active {
                    p.accent
                } else {
                    p.text
                })),
        );
    }
    tabs = tabs.child(el().grow(1.0)).child(
        text("Yazi Rune")
            .font(TextStyle::new(12.0, 500.0))
            .color(p.muted)
            .mr(8.0),
    );
    let path = row()
        .h(39.0)
        .w_full()
        .px(14.0)
        .center_y()
        .gap(10.0)
        .child(action_button("Places", p, |s, tx| s.command("places", tx)))
        .child(action_button("Location", p, |s, tx| {
            s.command("cd --interactive", tx)
        }))
        .child(action_button("Go to file", p, |s, tx| s.show_picker(tx)))
        .child(action_button("Search", p, |s, tx| s.command("search", tx)))
        .child(
            text(s.display_location(&tab.cwd))
                .key("cwd")
                .font(MONO)
                .color(p.accent)
                .truncate()
                .shrink()
                .grow(1.0),
        )
        .child(label(
            if tab.loading {
                "Loading…".into()
            } else {
                format!("{} entries", tab.visible.len())
            },
            p,
        ));
    let total: f32 = s.preference.ratio.iter().sum();
    let ratio = if total > 0.0 && s.preference.ratio.iter().all(|n| n.is_finite() && *n > 0.0) {
        s.preference.ratio
    } else {
        [1.0, 4.0, 3.0]
    };
    let parent = col()
        .key("parent-panel")
        .grow(ratio[0])
        .min_w(0.0)
        .min_h(0.0)
        .child(panel_header("Parent", p))
        .child(
            col()
                .key("parent")
                .grow(1.0)
                .min_h(0.0)
                .w_full()
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .child(
                    col()
                        .key("rows")
                        .w_full()
                        .growth(GrowthSpec::default())
                        .virtual_rows(
                            s.parent.len(),
                            ROW,
                            |s: &State, i| s.parent[i].key.as_str().into(),
                            move |s: &State, i| {
                                let file = &s.parent[i];
                                let path = file.path.clone();
                                let directory = file.directory;
                                draggable_file(
                                    file_row(file, file.path == s.tab().cwd, false, false, p),
                                    file,
                                )
                                .on_press_tx(
                                    move |s: &mut State, tx| {
                                        if directory {
                                            s.cd(path.clone(), tx, true);
                                        }
                                        tx.blur();
                                    },
                                )
                            },
                        )
                        .virtual_rows_version(s.revision),
                ),
        );
    let current =
        col()
            .key("current-panel")
            .grow(ratio[1])
            .min_w(0.0)
            .min_h(0.0)
            .child(panel_header("Files", p))
            .child(
                col()
                    .key("current")
                    .grow(1.0)
                    .min_h(0.0)
                    .w_full()
                    .scroll(ScrollSpec {
                        stick_bottom: false,
                    })
                    .scroll_margin(ROW * 3.0)
                    .child(
                        col()
                            .key("rows")
                            .w_full()
                            .growth(GrowthSpec::default())
                            .virtual_rows(
                                tab.visible.len(),
                                ROW,
                                |s: &State, i| s.tab().entry(i).key.as_str().into(),
                                move |s: &State, i| {
                                    let file = s.tab().entry(i);
                                    let path = file.path.clone();
                                    let open_path = path.clone();
                                    let context_path = path.clone();
                                    let row = file_row(
                                        file,
                                        i == s.tab().cursor
                                            || s.drop_hover.as_deref() == Some(&file.path),
                                        s.tab().selected(i),
                                        true,
                                        p,
                                    )
                                    .on_press_tx(move |s: &mut State, tx| {
                                        s.hover(&path, tx);
                                        tx.blur();
                                    })
                                    .on_secondary_press(move |s: &mut State, _, tx| {
                                        s.hover(&context_path, tx);
                                        s.context_open = true;
                                        tx.blur();
                                    })
                                    .on_double_press_tx(move |s: &mut State, tx| {
                                        s.hover(&open_path, tx);
                                        s.enter(tx, true);
                                        tx.blur();
                                    });
                                    draggable_file(row, file)
                                },
                            )
                            .virtual_rows_version(s.revision)
                            .on_visible_rows(|s: &mut State, range| {
                                s.page_size = range.len().max(1);
                                false
                            }),
                    ),
            );
    let preview_header = if let Some(file) = tab.file() {
        draggable_file(
            panel_header(&format!("Preview · {}", file.name), p).truncate(),
            file,
        )
    } else {
        panel_header("Preview", p)
    };
    let preview = col()
        .key("preview-panel")
        .grow(ratio[2])
        .min_w(0.0)
        .min_h(0.0)
        .child(preview_header)
        .child(if s.picker.is_none() {
            preview(s, p)
        } else {
            el()
        });
    let panes = row()
        .key("panes")
        .grow(1.0)
        .min_h(0.0)
        .w_full()
        .child(parent)
        .child(rule(p))
        .child(current)
        .child(rule(p))
        .child(preview);
    let mode = if let Some(v) = tab.visual {
        if v.unset { "UNSET" } else { "SELECT" }
    } else {
        "NORMAL"
    };
    let info = tab
        .file()
        .map(|f| {
            format!(
                "{}{}",
                file::human_size(f.size),
                if f.symlink { "  symlink" } else { "" }
            )
        })
        .unwrap_or_default();
    let count = format!(
        "{}/{}",
        if tab.visible.is_empty() {
            0
        } else {
            tab.cursor + 1
        },
        tab.visible.len()
    );
    let status = row()
        .key("status")
        .h(29.0)
        .w_full()
        .px(12.0)
        .gap(13.0)
        .center_y()
        .fill(p.panel)
        .child(text(mode).font(TextStyle::new(11.0, 650.0)).color(p.accent))
        .child(label(info, p))
        .child(label(
            if tab.selected.is_empty() {
                String::new()
            } else {
                format!("{} selected", tab.selected.len())
            },
            p,
        ))
        .child(el().grow(1.0))
        .child(label(
            if s.preference.show_hidden {
                "Hidden shown"
            } else {
                "Hidden off"
            },
            p,
        ))
        .child(label(count, p))
        .child(action_button(
            s.queue
                .active()
                .map(|t| format!("{} · {}", t.title, file::human_size(t.bytes)))
                .unwrap_or_else(|| "Tasks".into()),
            p,
            |s, _| s.tasks_open = !s.tasks_open,
        ));
    let mut root = col()
        .key("app")
        .role("application")
        .label("Yazi Rune file manager")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .w_full()
        .h_full()
        .fill(p.background)
        .child(tabs)
        .child(path)
        .child(el().h(1.0).w_full().fill(p.line))
        .child(panes)
        .child(status);
    if let Some(prompt) = s.prompt {
        root = root.child(
            row()
                .key("prompt-bar")
                .h(43.0)
                .w_full()
                .px(14.0)
                .gap(12.0)
                .center_y()
                .fill(p.panel)
                .child(text(prompt.title()).font(MONO).color(p.accent))
                .child(
                    text_input(&s.input, MONO)
                        .key("prompt")
                        .label(prompt.title())
                        .single_line()
                        .grow(1.0)
                        .min_w(0.0)
                        .color(p.text)
                        .on_edit(|s: &mut State| &mut s.input)
                        .on_submit(|s: &mut State, tx| s.submit_prompt(tx)),
                )
                .child(label("Enter to accept · Esc to close", p)),
        );
    } else if !s.pending.is_empty() {
        let items: Vec<_> = s
            .bindings
            .iter()
            .filter(|b| b.on.list().starts_with(&s.pending))
            .collect();
        let mut which = col()
            .key("which")
            .w_full()
            .px(14.0)
            .py(9.0)
            .gap(5.0)
            .fill(p.panel);
        for b in items.iter().take(9) {
            which = which.child(
                row()
                    .gap(12.0)
                    .child(
                        text(b.on.list().join(" "))
                            .font(MONO)
                            .color(p.accent)
                            .w(90.0),
                    )
                    .child(label(b.desc.clone(), p)),
            );
        }
        root = root.child(which);
    } else if let Some(message) = &s.message {
        root = root.child(
            text(message)
                .key("message")
                .font(MONO)
                .color(p.folder)
                .w_full()
                .px(14.0)
                .py(8.0)
                .fill(p.panel),
        );
    } else {
        root = root.child(
            row()
                .h(28.0)
                .w_full()
                .px(14.0)
                .gap(17.0)
                .center_y()
                .child(label("h j k l  Navigate", p))
                .child(label("Space  Select", p))
                .child(label("/  Find", p))
                .child(label("Ctrl+P  Go to file", p))
                .child(label("tt  New tab", p))
                .child(label("~  Help", p)),
        );
    }
    if s.picker.is_some() {
        root = root.child(finder_overlay(s, p));
    }
    if s.drop_decision.is_some() {
        root = root.child(drop_overlay(s, p));
    }
    if s.panel.is_some() {
        root = root.child(desktop_overlay(
            s,
            p,
            cx.layout_size("app").map_or(360.0, |size| size[1]),
        ));
    }
    if s.authentication.is_some() || s.question.is_some() {
        root = root.child(authentication_overlay(
            s,
            p,
            cx.layout_size("app").map_or(360.0, |size| size[1]),
        ));
    }
    if s.help || s.spot {
        root = root.child(overlay(s, p));
    }
    if s.queue.conflict.is_some() || s.confirmation.is_some() || s.tasks_open || s.context_open {
        root = root.child(operation_overlay(
            s,
            p,
            cx.layout_size("app").map_or(360.0, |size| size[1]),
        ));
    }
    root.instant_changes()
}

fn panel_header(title: &str, p: Palette) -> El {
    text(title)
        .font(TextStyle::new(11.0, 500.0))
        .color(p.muted)
        .w_full()
        .h(25.0)
        .px(12.0)
        .py(5.0)
}

fn draggable_file(element: El, file: &File) -> El {
    let path = file.path.clone();
    let directory = file.directory;
    element.on_drag(move |s: &mut State, drag, _| s.drag_file(&path, directory, drag))
}

fn file_row(file: &File, hovered: bool, selected: bool, metadata: bool, p: Palette) -> El {
    let glyph = icon::for_file(file);
    let mut row = row()
        .key(file.key.clone())
        .role("listitem")
        .label(file.name.clone())
        .w_full()
        .h(ROW)
        .px(10.0)
        .gap(7.0)
        .center_y()
        .fill(if hovered {
            p.selected
        } else if selected {
            p.selected.alpha(0.35)
        } else {
            Color::TRANSPARENT
        })
        .hover(p.selected.alpha(0.35))
        .child(
            rune::icon(glyph, 16.0)
                .label(glyph.name)
                .color(if file.directory { p.folder } else { p.muted }),
        )
        .child(
            text(&file.name)
                .font(MONO)
                .color(if file.directory { p.folder } else { p.text })
                .truncate()
                .shrink()
                .min_w(0.0)
                .grow(1.0),
        );
    if file.symlink {
        row = row.child(
            rune::icon(&icon::LINK, 12.0)
                .label("Symbolic link")
                .color(p.muted),
        );
    }
    if selected {
        row = row.child(
            rune::icon(&icon::CHECK, 14.0)
                .label("Selected")
                .color(p.accent),
        );
    }
    if metadata && !file.directory {
        row = row.child(
            text(file::human_size(file.size))
                .font(TextStyle::new(11.0, 400.0).mono())
                .color(p.muted),
        );
    }
    row
}

fn preview(s: &State, p: Palette) -> El {
    let scroll = s.preview_scroll.clone();
    let body = match &s.preview {
        Preview::Empty => col().padding(18.0).child(label("No file selected", p)),
        Preview::Loading => col().padding(18.0).child(label("Loading preview…", p)),
        Preview::Message(message) => col()
            .padding(18.0)
            .child(text(message).font(MONO).color(p.muted).w_full()),
        Preview::Image(image) => el()
            .key("image")
            .w_full()
            .h_full()
            .padding(14.0)
            .pixels_fit(image.pixels(), SurfaceFit::Fit),
        Preview::Pdf(pdf) => {
            let image = match &pdf.content {
                crate::pdf::Page::Ready(image) => el()
                    .key("pdf-page")
                    .w_full()
                    .grow(1.0)
                    .min_h(0.0)
                    .padding(14.0)
                    .pixels_fit(image.pixels(), SurfaceFit::Fit),
                crate::pdf::Page::Loading => col()
                    .grow(1.0)
                    .padding(18.0)
                    .child(label("Rendering page…", p)),
                crate::pdf::Page::Error(error) => col()
                    .grow(1.0)
                    .padding(18.0)
                    .child(text(error).font(MONO).color(p.muted).w_full()),
            };
            col()
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .child(
                    row()
                        .w_full()
                        .h(40.0)
                        .px(12.0)
                        .gap(8.0)
                        .center_y()
                        .child(
                            action_button("Previous", p, |s, _| s.seek_pdf(-1))
                                .key("pdf-previous")
                                .disabled(pdf.page == 1)
                                .opacity(if pdf.page == 1 { 0.4 } else { 1.0 }),
                        )
                        .child(label(format!("{} / {}", pdf.page, pdf.pages()), p).grow(1.0))
                        .child(
                            action_button("Next", p, |s, _| s.seek_pdf(1))
                                .key("pdf-next")
                                .disabled(pdf.page == pdf.pages())
                                .opacity(if pdf.page == pdf.pages() { 0.4 } else { 1.0 }),
                        ),
                )
                .child(image)
                .child(label("J / K · next / previous page", p).px(12.0).py(6.0))
        }
        Preview::Directory(files) => col()
            .key("preview")
            .w_full()
            .grow(1.0)
            .min_h(0.0)
            .scroll(ScrollSpec {
                stick_bottom: false,
            })
            .on_scroll_offset(move |pos| {
                scroll.set([pos.offset[1], pos.max[1]]);
            })
            .child(
                col()
                    .key("preview-rows")
                    .w_full()
                    .growth(GrowthSpec::default())
                    .virtual_rows(
                        files.len(),
                        ROW,
                        |s: &State, i| {
                            let Preview::Directory(files) = &s.preview else {
                                unreachable!()
                            };
                            files[i].key.as_str().into()
                        },
                        move |s: &State, i| {
                            let Preview::Directory(files) = &s.preview else {
                                unreachable!()
                            };
                            draggable_file(file_row(&files[i], false, false, false, p), &files[i])
                        },
                    ),
            ),
        Preview::Markdown {
            source,
            path,
            truncated,
        } => {
            let path = path.clone();
            let style = document_style(p);
            let markdown = rune_kit::Markdown::new(source)
                .tasks_read_only()
                .selectable(true)
                .scroll_wide(true)
                .on_link_tx(move |s: &mut State, link, tx| s.open_preview_link(&path, link, tx))
                .link_help(|link| Some(link.to_owned()))
                .render(&style)
                .key("markdown")
                .w_full()
                .min_w(0.0);
            let mut body = col().w_full().grow(1.0).min_h(0.0).child(
                col()
                    .key("preview")
                    .w_full()
                    .grow(1.0)
                    .min_h(0.0)
                    .scroll(ScrollSpec {
                        stick_bottom: false,
                    })
                    .on_scroll_offset(move |pos| {
                        scroll.set([pos.offset[1], pos.max[1]]);
                    })
                    .child(col().w_full().min_w(0.0).padding(16.0).child(markdown)),
            );
            if *truncated {
                body = body.child(
                    label("Preview limited to 256 KiB / 4,000 lines", p)
                        .px(12.0)
                        .py(6.0),
                );
            }
            body
        }
        Preview::Zip(zip) => zip_preview(s, zip, p),
        Preview::Core(core) => core_preview(s, core, p),
        Preview::Code(code) => code_preview(s, code, p),
        Preview::Html(html) => html_preview(s, html, p),
        Preview::Text { lines, truncated } => {
            let scroll = s.preview_scroll.clone();
            let text = col()
                .key("preview")
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .scroll_xy()
                .on_scroll_offset(move |pos| {
                    scroll.set([pos.offset[1], pos.max[1]]);
                })
                .child(
                    col()
                        .key("text-lines")
                        .min_w(0.0)
                        .growth(GrowthSpec::default())
                        .virtual_rows(
                            lines.len(),
                            20.0,
                            |_: &State, i| format!("line-{i}").into(),
                            move |s: &State, i| {
                                let Preview::Text { lines, .. } = &s.preview else {
                                    unreachable!()
                                };
                                row()
                                    .h(20.0)
                                    .gap(12.0)
                                    .px(12.0)
                                    .child(
                                        text(format!("{:>4}", i + 1))
                                            .font(MONO)
                                            .color(p.muted)
                                            .w(36.0),
                                    )
                                    .child(text(&lines[i]).font(MONO).color(p.text))
                            },
                        ),
                );
            let mut body = col().w_full().grow(1.0).min_h(0.0).child(text);
            if *truncated {
                body = body.child(
                    label("Preview limited to 256 KiB / 4,000 lines", p)
                        .px(12.0)
                        .py(6.0),
                );
            }
            body
        }
    };
    let body = body.grow(1.0).min_h(0.0).min_w(0.0);
    if let Some(file) = s.preview_file() {
        draggable_file(body, file)
    } else {
        body
    }
}

fn zip_preview(s: &State, zip: &crate::archive::ZipPreview, p: Palette) -> El {
    let mut header = col()
        .w_full()
        .min_w(0.0)
        .padding(14.0)
        .gap(8.0)
        .child(
            text("ZIP archive")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        )
        .child(
            text(format!(
                "{} on disk · {} files · {}{} folders",
                file::human_size(zip.archive_size),
                zip.files,
                if zip.folders_limited { "≥" } else { "" },
                zip.folders
            ))
            .font(MONO)
            .color(p.text)
            .wrap()
            .w_full(),
        )
        .child(
            text("Directory metadata · contents and CRCs not verified")
                .font(TextStyle::new(11.0, 400.0))
                .color(p.muted)
                .wrap()
                .w_full(),
        );
    if zip.encrypted > 0 {
        header = header.child(
            text(format!(
                "{} encrypted entries · no password needed to inspect metadata",
                zip.encrypted
            ))
            .font(MONO)
            .color(p.folder)
            .wrap()
            .w_full(),
        );
    }
    if !zip.issues.is_empty() {
        header = header.child(
            text(format!(
                "{} metadata notices · see Overview",
                zip.issues.len()
            ))
            .font(MONO)
            .color(p.folder)
            .wrap()
            .w_full(),
        );
    }
    let mut tabs = row().role("tablist").w_full().gap(8.0);
    for (contents, title) in [(false, "Overview"), (true, "Entries")] {
        let change = move |s: &mut State, tx: &mut rune::Tx| {
            if let Preview::Zip(zip) = &mut s.preview {
                zip.contents = contents;
                s.preview_scroll.set([0.0; 2]);
                tx.scroll_to_y("preview", 0.0);
            }
        };
        tabs = tabs.child(
            action_button(title, p, change)
                .key(if contents {
                    "zip-entries-tab"
                } else {
                    "zip-overview-tab"
                })
                .role("tab")
                .focus_selected(contents == zip.contents)
                .fill(if contents == zip.contents {
                    p.selected
                } else {
                    p.panel
                })
                .on_key(move |s, key, tx| {
                    let activate = crate::keymap::key_name(key)
                        .is_some_and(|key| matches!(key.as_str(), "<Enter>" | " "));
                    if activate {
                        change(s, tx);
                    }
                    activate
                }),
        );
    }
    header = header.child(tabs);
    let scroll = s.preview_scroll.clone();
    let content = if zip.contents {
        col()
            .key("zip-entries")
            .w_full()
            .growth(GrowthSpec::default())
            .virtual_rows(
                zip.entries.len(),
                66.0,
                |_: &State, i| format!("zip-entry-{i}").into(),
                move |s: &State, i| {
                    let Preview::Zip(zip) = &s.preview else {
                        unreachable!()
                    };
                    let entry = &zip.entries[i];
                    col()
                        .h(66.0)
                        .w_full()
                        .min_w(0.0)
                        .px(12.0)
                        .py(3.0)
                        .child(
                            text(format!(
                                "{}{}",
                                entry.path,
                                if entry.directory && !entry.path.ends_with('/') {
                                    "/"
                                } else {
                                    ""
                                }
                            ))
                            .font(MONO)
                            .color(if entry.directory { p.folder } else { p.text })
                            .truncate()
                            .w_full()
                            .help(&entry.path),
                        )
                        .child(
                            text(format!(
                                "{} → {} · {}",
                                file::human_size(entry.packed),
                                file::human_size(entry.unpacked),
                                entry.method
                            ))
                            .font(TextStyle::new(11.0, 400.0).mono())
                            .color(p.muted)
                            .truncate()
                            .w_full(),
                        )
                        .child(
                            text(format!(
                                "{}{}{}",
                                entry.date,
                                if entry.flags.is_empty() { "" } else { " · " },
                                entry.flags
                            ))
                            .font(TextStyle::new(11.0, 400.0).mono())
                            .color(if entry.flags.is_empty() {
                                p.muted
                            } else {
                                p.folder
                            })
                            .truncate()
                            .w_full()
                            .help(format!("ZIP timestamp has no timezone. {}", entry.flags)),
                        )
                },
            )
    } else {
        let denominator = zip.unpacked.max(zip.packed).max(1) as f64;
        let bar = |title: &str, bytes: u64, color: Color| {
            let fraction = (bytes as f64 / denominator) as f32;
            col()
                .w_full()
                .gap(4.0)
                .child(
                    row()
                        .w_full()
                        .child(label(title, p).grow(1.0))
                        .child(label(file::human_size(bytes), p)),
                )
                .child(
                    row()
                        .w_full()
                        .h(7.0)
                        .child(el().h(7.0).grow(fraction).fill(color))
                        .child(el().h(7.0).grow(1.0 - fraction).fill(p.line)),
                )
        };
        let mut body = col()
            .w_full()
            .min_w(0.0)
            .padding(14.0)
            .gap(10.0)
            .child(bar("Packed entry data", zip.packed, p.accent))
            .child(bar("Unpacked (declared)", zip.unpacked, p.folder));
        if zip.unpacked > 0 {
            let saved = 100.0 * (1.0 - zip.packed as f64 / zip.unpacked as f64);
            let expansion = if zip.packed > 0 {
                format!(
                    " · {:.1}× declared expansion",
                    zip.unpacked as f64 / zip.packed as f64
                )
            } else {
                String::new()
            };
            body = body.child(
                text(format!(
                    "Entry data {:.1}% {}{expansion}",
                    saved.abs(),
                    if saved >= 0.0 { "smaller" } else { "larger" }
                ))
                .font(MONO)
                .color(p.muted)
                .wrap()
                .w_full(),
            );
        }
        for issue in &zip.issues {
            body = body.child(text(issue).font(MONO).color(p.folder).wrap().w_full());
        }
        body = body.child(
            text("File types")
                .font(TextStyle::new(14.0, 600.0))
                .color(p.text),
        );
        if zip.types.is_empty() {
            body = body.child(label("No file entries", p));
        }
        for kind in zip.types.iter().take(8) {
            body = body.child(
                row()
                    .w_full()
                    .gap(8.0)
                    .child(
                        text(&kind.name)
                            .font(MONO)
                            .color(p.accent)
                            .truncate()
                            .grow(1.0),
                    )
                    .child(label(
                        format!("{} · {}", kind.files, file::human_size(kind.bytes)),
                        p,
                    )),
            );
        }
        if zip.types.len() > 8 {
            body = body.child(label(
                format!("Showing 8 of {} file types", zip.types.len()),
                p,
            ));
        }
        body = body.child(
            text("Largest files")
                .font(TextStyle::new(14.0, 600.0))
                .color(p.text),
        );
        if zip.largest.is_empty() {
            body = body.child(label("No file entries", p));
        }
        for &index in &zip.largest {
            let entry = &zip.entries[index];
            body = body.child(
                row()
                    .w_full()
                    .gap(8.0)
                    .child(
                        text(&entry.path)
                            .font(MONO)
                            .color(p.text)
                            .truncate()
                            .grow(1.0)
                            .help(&entry.path),
                    )
                    .child(label(file::human_size(entry.unpacked), p)),
            );
        }
        body = body.child(
            text("Folder structure")
                .font(TextStyle::new(14.0, 600.0))
                .color(p.text),
        );
        if zip.tree.is_empty() {
            body = body.child(label("Empty archive", p));
        }
        for node in &zip.tree {
            let depth = node.path.matches('/').count();
            let name = node.path.rsplit('/').next().unwrap_or(&node.path);
            body = body.child(
                text(format!(
                    "{}{}{}",
                    "  ".repeat(depth.min(12)),
                    name,
                    if node.directory { "/" } else { "" }
                ))
                .font(MONO)
                .color(if node.directory { p.folder } else { p.text })
                .truncate()
                .w_full()
                .help(&node.path),
            );
        }
        if zip.tree_limited {
            body = body.child(label("Structure limited to the first 200 paths; use Entries for the full inspected list", p).wrap().w_full());
        }
        body
    };
    col().w_full().grow(1.0).min_h(0.0).child(header).child(
        col()
            .key("preview")
            .w_full()
            .grow(1.0)
            .min_h(0.0)
            .scroll(ScrollSpec {
                stick_bottom: false,
            })
            .on_scroll_offset(move |pos| {
                scroll.set([pos.offset[1], pos.max[1]]);
            })
            .child(content),
    )
}

fn core_preview(s: &State, core: &crate::core_dump::CoreDump, p: Palette) -> El {
    let mut content = col()
        .w_full()
        .min_w(0.0)
        .padding(14.0)
        .gap(10.0)
        .child(
            text("Core dump")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        )
        .child(
            text(&core.architecture)
                .font(MONO)
                .color(p.muted)
                .wrap()
                .w_full(),
        );
    if !core.signal.is_empty() {
        let fault = if core.fault.is_empty() {
            String::new()
        } else {
            format!(" · fault address {}", core.fault)
        };
        content = content.child(
            text(format!("{}{fault} · {} threads", core.signal, core.threads))
                .font(MONO)
                .color(p.folder)
                .wrap()
                .w_full(),
        );
    }
    if !core.symbols.is_empty() {
        content = content.child(
            text(&core.symbols)
                .font(MONO)
                .color(p.muted)
                .wrap()
                .w_full(),
        );
    }
    if !core.process.is_empty() {
        content = content.child(
            text(format!("{} · PID {}", core.process, core.pid))
                .font(MONO)
                .color(p.text)
                .wrap_anywhere()
                .w_full(),
        );
    }
    if !core.notice.is_empty() {
        content = content.child(
            text(&core.notice)
                .font(MONO)
                .color(p.folder)
                .wrap()
                .w_full(),
        );
    }
    for (index, section) in core.sections.iter().enumerate() {
        let expanded = section.expanded;
        let toggle = move |s: &mut State, _: &mut rune::Tx| {
            if let Preview::Core(core) = &mut s.preview
                && let Some(section) = core.sections.get_mut(index)
            {
                section.expanded = !section.expanded;
            }
        };
        content = content.child(
            row()
                .key(format!("core-section-{index}"))
                .w_full()
                .px(8.0)
                .py(7.0)
                .fill(p.panel)
                .hover(p.selected)
                .role("button")
                .label(&section.title)
                .expanded(expanded)
                .focusable(true)
                .on_press_tx(toggle)
                .on_key(move |s, key, tx| {
                    let activate = crate::keymap::key_name(key)
                        .is_some_and(|key| matches!(key.as_str(), "<Enter>" | " "));
                    if activate {
                        toggle(s, tx);
                    }
                    activate
                })
                .child(
                    text(format!(
                        "{} {}",
                        if expanded { "▾" } else { "▸" },
                        section.title
                    ))
                    .font(MONO)
                    .color(p.accent)
                    .wrap()
                    .w_full(),
                ),
        );
        if expanded {
            content = content.child(
                text(&section.body)
                    .font(MONO)
                    .color(p.text)
                    .selectable(true)
                    .wrap_anywhere()
                    .w_full(),
            );
        }
    }
    let scroll = s.preview_scroll.clone();
    col()
        .key("preview")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .on_scroll_offset(move |pos| {
            scroll.set([pos.offset[1], pos.max[1]]);
        })
        .child(content)
}

fn document_style(p: Palette) -> rune_kit::MarkdownStyle {
    rune_kit::MarkdownStyle::neutral(p.dark)
        .text(p.text)
        .muted(p.muted)
        .link(p.accent)
        .body_font(TextStyle::new(14.0, 400.0).lh(22.0))
        .heading_font(1, TextStyle::new(24.0, 650.0).lh(30.0))
        .heading_font(2, TextStyle::new(20.0, 600.0).lh(26.0))
        .heading_font(3, TextStyle::new(16.0, 600.0).lh(23.0))
        .code_block_font(MONO)
        .code_block(p.panel, p.line)
        .inline_code_bg(p.panel)
        .quote_rule(p.line)
        .rule(p.line)
        .selection(p.selected)
        .list(22.0, 4.0)
}

fn code_preview(s: &State, code: &crate::code::Code, p: Palette) -> El {
    let scroll = s.preview_scroll.clone();
    let mut body = col()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .child(
            row()
                .w_full()
                .px(12.0)
                .py(7.0)
                .gap(12.0)
                .fill(p.panel)
                .child(text(&code.language).font(MONO).color(p.accent))
                .child(label(format!("{} lines", code.lines.len()), p)),
        )
        .child(
            col()
                .key("preview")
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .scroll_xy()
                .on_scroll_offset(move |pos| {
                    scroll.set([pos.offset[1], pos.max[1]]);
                })
                .child(
                    col()
                        .key("code-lines")
                        .min_w(0.0)
                        .growth(GrowthSpec::default())
                        .virtual_rows(
                            code.lines.len(),
                            20.0,
                            |_: &State, i| format!("code-line-{i}").into(),
                            move |s: &State, i| {
                                let code = match &s.preview {
                                    Preview::Code(code) => code,
                                    Preview::Html(html) => &html.source.code,
                                    _ => unreachable!(),
                                };
                                let line = &code.lines[i];
                                row()
                                    .h(20.0)
                                    .gap(12.0)
                                    .px(12.0)
                                    .child(
                                        text(format!("{:>4}", i + 1))
                                            .font(MONO)
                                            .color(p.muted)
                                            .w(36.0),
                                    )
                                    .child(text(&line.text).font(MONO).color(p.text).spans(
                                        if p.dark {
                                            line.dark.clone()
                                        } else {
                                            line.light.clone()
                                        },
                                    ))
                            },
                        ),
                ),
        );
    if let Some(note) = &code.note {
        body = body.child(label(note, p).px(12.0).py(6.0));
    }
    if code.truncated {
        body = body.child(
            label("Preview limited to 256 KiB / 4,000 lines", p)
                .px(12.0)
                .py(6.0),
        );
    }
    body
}

fn html_preview(s: &State, html: &crate::html::Html, p: Palette) -> El {
    use crate::html::{Part, View};
    let source = matches!(html.view, View::Source);
    let rendering = matches!(html.view, View::Loading | View::Rendered(_));
    let toolbar = row()
        .w_full()
        .h(40.0)
        .px(12.0)
        .gap(8.0)
        .center_y()
        .child(
            action_button("Source", p, |s, tx| s.render_html(false, tx))
                .key("html-source")
                .fill(if source { p.selected } else { p.panel })
                .disabled(source),
        )
        .child(
            action_button("Render", p, |s, tx| s.render_html(true, tx))
                .key("html-render")
                .fill(if rendering { p.selected } else { p.panel })
                .disabled(rendering),
        );
    let content = match &html.view {
        View::Source => code_preview(s, &html.source.code, p),
        View::Loading => col()
            .w_full()
            .grow(1.0)
            .padding(18.0)
            .child(label("Rendering HTML…", p)),
        View::Error(error) => col()
            .w_full()
            .grow(1.0)
            .padding(18.0)
            .child(label(error, p)),
        View::Rendered(document) => {
            let style = document_style(p);
            let mut content = col()
                .key("html-content")
                .w_full()
                .min_w(0.0)
                .padding(16.0)
                .gap(12.0);
            for (i, part) in document.parts.iter().enumerate() {
                let part = match part {
                    Part::Text { source, .. } => {
                        let path = html.source.path.clone();
                        rune_kit::Markdown::new(source)
                            .autolink(false)
                            .tasks_read_only()
                            .selectable(true)
                            .scroll_wide(true)
                            .on_link_tx(move |s: &mut State, link, tx| {
                                s.open_html_link(&path, link, tx)
                            })
                            .link_help(|link| Some(link.to_owned()))
                            .render(&style)
                            .w_full()
                            .min_w(0.0)
                    }
                    Part::Image { image, alt } => {
                        let pixels = image.pixels();
                        let (width, height) = pixels.size();
                        let height =
                            (height as f32 / width.max(1) as f32 * 520.0).clamp(60.0, 420.0);
                        col()
                            .w_full()
                            .min_w(0.0)
                            .child(el().w_full().h(height).pixels_fit(pixels, SurfaceFit::Fit))
                            .child(label(alt, p).py(4.0))
                    }
                };
                content = content.child(part.key(format!("html-part-{i}")));
            }
            if document.parts.is_empty() {
                content = content.child(label("No static content to render", p));
            }
            let scroll = s.preview_scroll.clone();
            let mut body = col().w_full().grow(1.0).min_h(0.0).child(
                col()
                    .key("preview")
                    .w_full()
                    .grow(1.0)
                    .min_h(0.0)
                    .scroll(ScrollSpec {
                        stick_bottom: false,
                    })
                    .on_scroll_offset(move |pos| {
                        scroll.set([pos.offset[1], pos.max[1]]);
                    })
                    .child(content),
            );
            if html.source.truncated || document.limited {
                body = body.child(label("HTML preview limited", p).px(12.0).py(6.0));
            }
            body
        }
    };
    col()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .child(toolbar)
        .child(content)
        .child(
            label("Static HTML · document styling · no JavaScript", p)
                .px(12.0)
                .py(6.0),
        )
}

fn overlay(s: &State, p: Palette) -> El {
    let mut content = col()
        .key("overlay")
        .w_full()
        .padding(20.0)
        .gap(12.0)
        .fill(p.background);
    if s.spot {
        content = content.child(
            text("File information")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        );
        if let Some(properties) = &s.properties {
            for (name, value) in &properties.rows {
                content = content.child(
                    row()
                        .gap(20.0)
                        .w_full()
                        .child(text(name).font(MONO).color(p.muted).w(130.0))
                        .child(
                            text(if name == "Location" {
                                s.display_location(&properties.path)
                            } else {
                                value.clone()
                            })
                            .font(MONO)
                            .color(p.text)
                            .grow(1.0)
                            .min_w(0.0),
                        ),
                );
            }
            content = content.child(
                row()
                    .gap(8.0)
                    .child(action_button("Change permissions", p, |s, tx| {
                        s.spot = false;
                        s.command("permissions", tx);
                    }))
                    .child(action_button("Open with", p, |s, tx| {
                        s.spot = false;
                        s.command("open_with", tx);
                    })),
            );
        } else {
            content = content.child(label("Reading file properties…", p));
        }
    } else {
        content = content.child(text("Keyboard navigation").font(TextStyle::new(20.0, 600.0)).color(p.text))
            .child(label("Navigate with Yazi bindings. Use the toolbar and context menu for desktop actions.", p));
        let mut bindings = col().w_full().gap(6.0);
        for binding in &s.bindings {
            bindings = bindings.child(
                row()
                    .gap(15.0)
                    .child(
                        text(binding.on.list().join(" "))
                            .font(MONO)
                            .color(p.accent)
                            .w(170.0),
                    )
                    .child(
                        text(&binding.desc)
                            .font(MONO)
                            .color(p.text)
                            .grow(1.0)
                            .min_w(0.0),
                    ),
            );
        }
        content = content.child(bindings);
    }

    el().key("overlay-layer")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background)
        .modal(false, |s: &mut State| {
            s.help = false;
            s.spot = false;
        })
        .child(
            col()
                .w_full()
                .h_full()
                .child(
                    col()
                        .w_full()
                        .grow(1.0)
                        .min_h(0.0)
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(
                    row()
                        .w_full()
                        .padding(12.0)
                        .gap(12.0)
                        .child(action_button("Close", p, |s, _| {
                            s.help = false;
                            s.spot = false;
                        }))
                        .child(label("Esc or q to close", p)),
                ),
        )
}

fn action_button(
    title: impl Into<String>,
    p: Palette,
    action: impl Fn(&mut State, &mut rune::Tx) + 'static,
) -> El {
    let title = title.into();
    row()
        .role("button")
        .focusable(true)
        .label(&title)
        .px(10.0)
        .h(26.0)
        .center_y()
        .radius(4.0)
        .fill(p.selected.alpha(0.6))
        .hover(p.selected)
        .on_press_tx(action)
        .child(text(title).font(TextStyle::new(12.0, 500.0)).color(p.text))
}

fn finder_overlay(s: &State, p: Palette) -> El {
    let picker = s.picker.as_ref().unwrap();
    let mut controls = row()
        .w_full()
        .center_y()
        .gap(8.0)
        .child(
            text("Go to file")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        )
        .child(el().grow(1.0))
        .child(action_button("Folder", p, |s, _| s.picker_scope(false)).key("finder-folder"));
    if picker.project().is_some() {
        controls = controls
            .child(action_button("Project", p, |s, _| s.picker_scope(true)).key("finder-project"));
    }
    controls = controls
        .child(action_button(
            if picker.all_files {
                "Hidden & ignored: shown"
            } else {
                "Hidden & ignored: off"
            },
            p,
            |s, _| s.picker_all(),
        ))
        .child(action_button("Close", p, |s, tx| s.close_picker(tx)));
    let results = col()
        .key("finder-results")
        .role("list")
        .label("Matching files")
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .scroll(ScrollSpec {
            stick_bottom: false,
        })
        .scroll_margin(ROW * 2.0)
        .child(
            col()
                .key("rows")
                .w_full()
                .growth(GrowthSpec::default())
                .virtual_rows(
                    picker.files.len(),
                    ROW,
                    |s: &State, i| s.picker.as_ref().unwrap().files[i].key.as_str().into(),
                    move |s: &State, i| {
                        let picker = s.picker.as_ref().unwrap();
                        file_row(&picker.files[i], i == picker.cursor, false, true, p)
                            .on_press_tx(move |s: &mut State, tx| s.picker_hover(i, tx))
                            .on_double_press_tx(move |s: &mut State, tx| {
                                s.picker_hover(i, tx);
                                s.picker_accept(true, tx);
                            })
                    },
                )
                .virtual_rows_version(s.revision),
        );
    let mut list = col()
        .grow(1.0)
        .min_w(0.0)
        .min_h(0.0)
        .child(panel_header("Files · relevance order", p))
        .child(results);
    if picker.files.is_empty() {
        list = list.child(
            text(if picker.loading || picker.scanning {
                "Indexing files…"
            } else {
                "No matching files"
            })
            .font(MONO)
            .color(p.muted)
            .padding(16.0),
        );
    }
    let selected = picker
        .file()
        .map(|file| file.name.as_str())
        .unwrap_or("Preview");
    let body = row()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .child(list)
        .child(el().w(1.0).h_full().fill(p.line))
        .child(
            col()
                .grow(1.0)
                .min_w(0.0)
                .min_h(0.0)
                .child(panel_header(selected, p).truncate())
                .child(preview(s, p)),
        );
    let mut content = col().w_full().h_full().padding(16.0).gap(10.0)
        .child(controls)
        .child(text(picker.root.to_string_lossy()).font(MONO).color(p.muted).truncate())
        .child(text_input(&s.input, MONO)
            .key("finder-input")
            .on_input_key(|s: &mut State, key, tx| s.key(key, tx))
            .label("File name or path")
            .single_line().w_full().h(36.0).color(p.text)
            .on_edit(|s: &mut State| &mut s.input)
            .on_submit(|s: &mut State, tx| s.picker_accept(true, tx)))
        .child(body)
        .child(text(format!("{} {} · {} indexed{}{}", picker.files.len(), if picker.files.len() == 1 { "result" } else { "results" }, picker.indexed,
            if picker.scanning { " · indexing…" } else { "" },
            if picker.watching { " · live" } else { "" }))
            .font(MONO).color(p.muted))
        .child(row().w_full().gap(8.0).center_y()
            .child(action_button("Open", p, |s, tx| s.picker_accept(true, tx)))
            .child(action_button("Reveal", p, |s, tx| s.picker_accept(false, tx)))
            .child(action_button("Refresh", p, |s, tx| s.command("finder_refresh", tx)))
            .child(el().grow(1.0)))
        .child(text("↑ ↓ Select · Enter Open · Shift+Enter Reveal · Ctrl+I Hidden & ignored · Esc Close")
            .font(TextStyle::new(11.0, 400.0)).color(p.muted).w_full());
    if let Some(error) = &picker.error {
        content = content.child(text(error).font(MONO).color(p.folder).w_full());
    }
    el().key("finder-layer")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .role("dialog")
        .label("Go to file")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background)
        .modal(false, |s: &mut State| s.dismiss_picker())
        .child(content)
}

fn operation_overlay(s: &State, p: Palette, height: f32) -> El {
    let mut content = col()
        .w_full()
        .gap(12.0)
        .role("dialog")
        .label("File operations");
    if let Some(conflict) = &s.queue.conflict {
        if conflict.can_merge {
            content = content.child(
                row()
                    .gap(8.0)
                    .child(action_button("Merge folders (m)", p, |s, _| {
                        s.queue.answer(Choice::Merge, false)
                    }))
                    .child(action_button("Merge all folders (M)", p, |s, _| {
                        s.queue.answer(Choice::Merge, true)
                    })),
            );
        }
        content = content.child(text("Destination already exists").font(TextStyle::new(20.0, 600.0)).color(p.text))
            .child(text(format!("Source: {}", conflict.source.display())).font(MONO).color(p.text).w_full())
            .child(text(format!("Destination: {}", conflict.destination.display())).font(MONO).color(p.text).w_full())
            .child(text("Replacing a folder replaces its contents. Choose Keep both to preserve both items.").font(MONO).color(p.muted).w_full())
            .child(row().gap(8.0)
                .child(action_button("Replace (r)", p, |s, _| s.queue.answer(Choice::Replace, false)))
                .child(action_button("Keep both (k)", p, |s, _| s.queue.answer(Choice::KeepBoth, false)))
                .child(action_button("Skip (s)", p, |s, _| s.queue.answer(Choice::Skip, false))))
            .child(row().gap(8.0)
                .child(action_button("Replace all (R)", p, |s, _| s.queue.answer(Choice::Replace, true)))
                .child(action_button("Keep all (K)", p, |s, _| s.queue.answer(Choice::KeepBoth, true)))
                .child(action_button("Skip all (S)", p, |s, _| s.queue.answer(Choice::Skip, true))))
            .child(action_button("Cancel (Esc)", p, |s, _| s.queue.answer(Choice::Cancel, false)));
    } else if let Some(operation) = &s.confirmation {
        content = content
            .child(
                text(format!("{} selected items?", operation.title()))
                    .font(TextStyle::new(20.0, 600.0))
                    .color(p.text),
            )
            .child(
                text(
                    if matches!(
                        operation,
                        crate::operations::Operation::Delete(_)
                            | crate::operations::Operation::DeleteTrash(_)
                    ) {
                        "Permanent deletion cannot be undone."
                    } else {
                        "You can restore these items from the trash."
                    },
                )
                .font(MONO)
                .color(p.muted)
                .w_full(),
            )
            .child(
                row()
                    .gap(8.0)
                    .child(action_button("Confirm (y)", p, |s, _| {
                        if let Some(operation) = s.confirmation.take() {
                            s.enqueue(operation, false);
                        }
                    }))
                    .child(action_button("Cancel (n)", p, |s, _| s.confirmation = None)),
            );
    } else if s.context_open {
        content = content.child(
            text("File actions")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        );
        let mut actions = col().w_full().gap(6.0);
        for (label, command) in [
            ("Open", "open"),
            ("New window", "new_window"),
            ("Open with", "open_with"),
            ("Places and devices", "places"),
            ("Bookmark folder", "bookmark"),
            ("Copy", "yank"),
            ("Cut", "yank --cut"),
            ("Paste", "paste"),
            ("Undo last operation", "undo"),
            ("Rename", "rename"),
            ("New file or folder", "create"),
            ("Move to trash", "remove"),
            ("Delete permanently", "remove --permanently"),
            ("Create symbolic links", "link"),
            ("Create hard links", "hardlink"),
            ("Change permissions", "permissions"),
            ("Create archive", "archive"),
            ("Extract archive", "extract"),
            ("Open trash", "trash"),
            ("Restore from trash", "restore"),
            ("File properties", "spot"),
        ] {
            actions = actions.child(action_button(label, p, move |s, tx| {
                s.context_open = false;
                s.command(command, tx);
            }));
        }
        content = content.child(
            col()
                .w_full()
                .max_h(230.0)
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .child(actions),
        );
    } else {
        content = content.child(
            text("File tasks")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        );
        if s.queue.undo_available() {
            content = content.child(action_button("Undo last operation (Ctrl+Z)", p, |s, tx| {
                s.command("undo", tx)
            }));
        }
        let mut tasks = col().w_full().gap(10.0);
        for task in s.queue.tasks.iter().rev() {
            let id = task.id;
            let mut card = col()
                .w_full()
                .gap(4.0)
                .child(
                    text(format!(
                        "{} · {:?} · {} entries · {}",
                        task.title,
                        task.status,
                        task.entries,
                        file::human_size(task.bytes)
                    ))
                    .font(MONO)
                    .color(p.text)
                    .w_full(),
                )
                .child(
                    text(task.current.to_string_lossy())
                        .font(MONO)
                        .color(p.muted)
                        .w_full(),
                );
            for error in task.errors.iter().chain(&task.warnings) {
                card = card.child(text(error).font(MONO).color(p.folder).w_full());
            }
            if matches!(
                task.status,
                Status::Queued | Status::Running | Status::Waiting
            ) {
                card = card.child(action_button("Cancel task", p, move |s, _| {
                    s.queue.cancel(id)
                }));
            }
            tasks = tasks.child(card);
        }
        if s.queue.tasks.is_empty() {
            tasks = tasks.child(label("No file tasks yet", p));
        }
        content = content.child(
            col()
                .w_full()
                .max_h(230.0)
                .scroll(ScrollSpec {
                    stick_bottom: false,
                })
                .child(tasks),
        );
    }
    el().key("operation-layer")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.85))
        .modal(false, |s: &mut State| {
            if s.queue.conflict.is_some() {
                s.queue.answer(Choice::Cancel, false);
            }
            s.confirmation = None;
            s.context_open = false;
            s.tasks_open = false;
        })
        .center()
        .child(
            col()
                .w(530.0)
                .padding(20.0)
                .gap(12.0)
                .fill(p.panel)
                .radius(8.0)
                .child(
                    col()
                        .w_full()
                        .max_h((height - 110.0).max(120.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(action_button(
                    if s.queue.conflict.is_some() || s.confirmation.is_some() {
                        "Cancel"
                    } else {
                        "Close"
                    },
                    p,
                    |s, _| {
                        s.queue.answer(Choice::Cancel, false);
                        s.confirmation = None;
                        s.context_open = false;
                        s.tasks_open = false;
                    },
                )),
        )
}

fn desktop_overlay(s: &State, p: Palette, height: f32) -> El {
    use crate::state::Panel;
    let mut content = col().w_full().gap(12.0);
    let mut items = col().w_full().gap(8.0);
    if s.panel == Some(Panel::Places) {
        content = content.child(
            text("Places and devices")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        );
        for place in &s.places {
            let place = place.clone();
            let name = format!(
                "{}{}",
                place.name,
                if place.mounted { "" } else { " (not mounted)" }
            );
            let unmount = place.clone();
            let eject = place.clone();
            let mut item = row().gap(8.0).child(action_button(name, p, move |s, tx| {
                s.open_place(&place, tx)
            }));
            if unmount.unmount {
                item = item.child(action_button("Unmount", p, move |s, _| {
                    s.mount_action(crate::mounts::Action::Unmount(unmount.clone()))
                }));
            }
            if eject.eject {
                item = item.child(action_button("Eject", p, move |s, _| {
                    s.mount_action(crate::mounts::Action::Eject(eject.clone()))
                }));
            }
            items = items.child(item);
        }
        content = content.child(action_button("Connect to server", p, |s, tx| {
            s.panel = None;
            s.command("connect", tx);
        }));
        if s.mounts.busy() {
            content = content.child(action_button("Cancel device operation", p, |s, _| {
                s.cancel_mount()
            }));
        }
        content = content.child(
            row()
                .gap(8.0)
                .child(action_button("Bookmark current folder", p, |s, tx| {
                    s.command("bookmark", tx)
                }))
                .child(action_button("Refresh devices", p, |s, tx| {
                    s.command("refresh_places", tx)
                }))
                .child(action_button("Trash", p, |s, tx| {
                    s.panel = None;
                    s.command("trash", tx);
                })),
        );
    } else if s.panel == Some(Panel::Trash) {
        content = content
            .child(
                text("Trash")
                    .font(TextStyle::new(20.0, 600.0))
                    .color(p.text),
            )
            .child(
                text("All mounted volumes · ↑/↓ navigate · Space select · r restore · d delete")
                    .font(MONO)
                    .color(p.muted)
                    .wrap()
                    .w_full(),
            )
            .child(
                row()
                    .gap(8.0)
                    .child(action_button("Restore selected", p, |s, tx| {
                        s.command("restore", tx)
                    }))
                    .child(action_button("Delete selected", p, |s, tx| {
                        s.command("trash_delete", tx)
                    })),
            )
            .child(
                row()
                    .gap(8.0)
                    .child(action_button("Empty trash…", p, |s, tx| {
                        s.command("trash_empty", tx)
                    }))
                    .child(action_button("Refresh", p, |s, tx| {
                        s.command("refresh_trash", tx)
                    })),
            );
        if let Some(entries) = &s.trash {
            if entries.is_empty() {
                items = items.child(label("Trash is empty", p));
            }
            for (index, entry) in entries.iter().enumerate() {
                let uri = entry.uri.clone();
                let selected = s.trash_selected.contains(&entry.uri);
                items = items.child(
                    col()
                        .key(format!("trash-entry-{index}"))
                        .w_full()
                        .gap(3.0)
                        .child(action_button(
                            format!(
                                "{} {} {}",
                                if index == s.trash_cursor { "›" } else { " " },
                                if selected { "✓" } else { "○" },
                                entry.name
                            ),
                            p,
                            move |s, _| {
                                s.trash_cursor = index;
                                if !s.trash_selected.remove(&uri) {
                                    s.trash_selected.insert(uri.clone());
                                }
                            },
                        ))
                        .child(
                            text(format!("From {}", entry.original.display()))
                                .wrap_anywhere()
                                .font(MONO)
                                .color(p.muted)
                                .w_full(),
                        )
                        .child(label(
                            format!("{} · {}", entry.deleted, file::human_size(entry.size)),
                            p,
                        )),
                );
            }
        } else {
            items = items.child(label("Reading trash…", p));
        }
    } else {
        content = content.child(
            text("Open with")
                .font(TextStyle::new(20.0, 600.0))
                .color(p.text),
        );
        if let Some(apps) = &s.applications {
            content = content.child(label(
                format!("{} · {} item(s)", apps.mime, apps.paths.len()),
                p,
            ));
            for app in &apps.apps {
                let id = app.id.clone();
                let default_id = id.clone();
                items = items.child(
                    row()
                        .gap(8.0)
                        .child(action_button(&app.name, p, move |s, _| {
                            s.launch_app(id.clone(), false)
                        }))
                        .child(action_button("Always use", p, move |s, _| {
                            s.launch_app(default_id.clone(), true)
                        })),
                );
            }
            if apps.apps.is_empty() {
                items = items.child(label("No installed applications found", p));
            }
            content = content.child(action_button("Other program…", p, |s, tx| {
                s.command("open_command", tx)
            }));
        } else {
            items = items.child(label("Finding applications…", p));
        }
    }
    if let Some(message) = &s.message {
        content = content.child(text(message).font(MONO).color(p.folder).w_full());
    }
    content = content.child(items);
    el().key("desktop-layer")
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.85))
        .modal(false, |s: &mut State| s.panel = None)
        .center()
        .child(
            col()
                .w(560.0)
                .padding(20.0)
                .gap(12.0)
                .fill(p.panel)
                .radius(8.0)
                .child(
                    col()
                        .key("desktop-content")
                        .w_full()
                        .max_h((height - 110.0).max(120.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(action_button("Close", p, |s, _| s.panel = None)),
        )
}

fn authentication_overlay(s: &State, p: Palette, height: f32) -> El {
    let mut content = col().w_full().gap(12.0);
    if let Some(auth) = &s.authentication {
        content = content.child(text(&auth.message).font(MONO).color(p.text).w_full());
        if auth.flags.contains(gio::AskPasswordFlags::NEED_USERNAME) {
            content = content.child(
                text_input(&auth.user, MONO)
                    .key("auth-user")
                    .label("Username")
                    .single_line()
                    .w_full()
                    .color(p.text)
                    .on_edit(|s: &mut State| &mut s.authentication.as_mut().unwrap().user),
            );
        }
        if auth.flags.contains(gio::AskPasswordFlags::NEED_DOMAIN) {
            content = content.child(
                text_input(&auth.domain, MONO)
                    .key("auth-domain")
                    .label("Domain")
                    .single_line()
                    .w_full()
                    .color(p.text)
                    .on_edit(|s: &mut State| &mut s.authentication.as_mut().unwrap().domain),
            );
        }
        if auth.flags.contains(gio::AskPasswordFlags::NEED_PASSWORD) {
            content = content.child(
                text_input(&auth.password, MONO)
                    .key("auth-password")
                    .label("Password")
                    .single_line()
                    .w_full()
                    .color(p.text)
                    .on_edit(|s: &mut State| &mut s.authentication.as_mut().unwrap().password)
                    .on_submit(|s: &mut State, _| s.authenticate(false)),
            );
        }
        content = content.child(action_button("Connect", p, |s, _| s.authenticate(false)));
        if auth
            .flags
            .contains(gio::AskPasswordFlags::ANONYMOUS_SUPPORTED)
        {
            content = content.child(action_button("Connect anonymously", p, |s, _| {
                s.authenticate(true)
            }));
        }
    }
    if let Some(question) = &s.question {
        content = content.child(text(&question.message).font(MONO).color(p.text).w_full());
        for (index, choice) in question.choices.iter().enumerate() {
            content = content.child(action_button(choice, p, move |s, _| {
                if let Some(question) = s.question.take() {
                    let _ = question.reply.send(Some(index));
                }
            }));
        }
    }
    el().key("authentication-layer")
        .absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.85))
        .modal(false, |s: &mut State| s.cancel_mount())
        .center()
        .child(
            col()
                .w(540.0)
                .padding(20.0)
                .gap(12.0)
                .fill(p.panel)
                .radius(8.0)
                .child(
                    col()
                        .w_full()
                        .max_h((height - 110.0).max(120.0))
                        .scroll(ScrollSpec {
                            stick_bottom: false,
                        })
                        .child(content),
                )
                .child(action_button("Cancel", p, |s, _| s.cancel_mount())),
        )
}

fn drop_overlay(s: &State, p: Palette) -> El {
    let drop = s.drop_decision.as_ref().expect("drop decision");
    el().absolute(0.0, 0.0)
        .w_full()
        .h_full()
        .fill(p.background.alpha(0.85))
        .on_key(|s: &mut State, key, tx| s.key(key, tx))
        .modal(false, |s: &mut State| {
            if let Some(drop) = s.drop_decision.take() {
                s.cancel_drop(drop.token);
            }
        })
        .center()
        .child(
            col()
                .w(520.0)
                .padding(20.0)
                .gap(12.0)
                .fill(p.panel)
                .radius(8.0)
                .child(
                    text(format!("Drop {} item(s)", drop.paths.len()))
                        .font(TextStyle::new(20.0, 600.0))
                        .color(p.text),
                )
                .child(
                    text(drop.destination.display().to_string())
                        .font(MONO)
                        .color(p.muted)
                        .wrap_anywhere()
                        .w_full(),
                )
                .child(
                    row()
                        .gap(8.0)
                        .child(action_button("Copy (c)", p, |s, _| {
                            if let Some(drop) = s.drop_decision.take() {
                                s.accept_drop(drop, 1);
                            }
                        }))
                        .child(action_button("Move (m)", p, |s, _| {
                            if let Some(drop) = s.drop_decision.take() {
                                s.accept_drop(drop, 2);
                            }
                        }))
                        .child(action_button("Link (l)", p, |s, _| {
                            if let Some(drop) = s.drop_decision.take() {
                                s.accept_drop(drop, 8);
                            }
                        })),
                )
                .child(action_button("Cancel", p, |s, _| {
                    if let Some(drop) = s.drop_decision.take() {
                        s.cancel_drop(drop.token);
                    }
                })),
        )
}
