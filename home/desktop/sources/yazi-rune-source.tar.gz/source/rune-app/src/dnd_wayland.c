#define _GNU_SOURCE
#include <wayland-client.h>
#include <xkbcommon/xkbcommon.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <sys/mman.h>

#define COPY WL_DATA_DEVICE_MANAGER_DND_ACTION_COPY
#define MOVE WL_DATA_DEVICE_MANAGER_DND_ACTION_MOVE
#define ASK WL_DATA_DEVICE_MANAGER_DND_ACTION_ASK
#define LIMIT (1024 * 1024)

typedef void (*yr_callback)(void *, uint32_t, uint32_t, double, double, uint32_t, const char *, size_t);
struct yr_dnd;
struct yr_offer {
    struct yr_offer *next;
    struct yr_dnd *owner;
    struct wl_data_offer *proxy;
    uint32_t token, serial, actions, action;
    int uri, link, local, fd, eof, dropped, delivered, previewed;
    double x, y;
    char *data;
    size_t length;
};
struct yr_send { struct yr_send *next; int fd; size_t offset; };
struct yr_dnd {
    struct wl_display *display;
    struct wl_event_queue *queue;
    struct wl_registry *registry;
    struct wl_seat *seat;
    struct wl_pointer *pointer;
    struct wl_keyboard *keyboard;
    struct wl_data_device_manager *manager;
    struct wl_data_device *device;
    struct wl_data_source *source;
    struct wl_compositor *compositor;
    struct wl_shm *shm;
    struct wl_surface *icon;
    struct wl_buffer *icon_buffer;
    uint32_t *icon_pixels;
    struct yr_offer *offers, *current;
    struct yr_send *sends;
    struct xkb_context *xkb;
    struct xkb_keymap *keymap;
    struct xkb_state *keys;
    uint32_t surface, focus, serial, manager_version, preferred, modifiers;
    char *payload;
    size_t payload_length;
    yr_callback callback;
    void *context;
};
static void emit(struct yr_dnd *d, uint32_t event, uint32_t token, double x, double y, uint32_t action, const char *text, size_t length) {
    d->callback(d->context, event, token, x, y, action, text, length);
}
static void fail(struct yr_dnd *d, const char *text) { emit(d, 4, 0, 0, 0, 0, text, strlen(text)); }
static void destroy_offer(struct yr_dnd *d, struct yr_offer *o) {
    struct yr_offer **slot = &d->offers;
    while (*slot && *slot != o) slot = &(*slot)->next;
    if (*slot) *slot = o->next;
    if (d->current == o) d->current = NULL;
    if (o->fd >= 0) close(o->fd);
    wl_data_offer_destroy(o->proxy);
    free(o->data); free(o);
}
static void offer_mime(void *data, struct wl_data_offer *proxy, const char *mime) {
    (void)proxy;
    struct yr_offer *o = data;
    if (!strcmp(mime, "text/uri-list")) o->uri = 1;
    if (!strcmp(mime, "application/x-yazi-rune-action-link")) o->link=1;
    if (!strcmp(mime, "application/x-yazi-rune-files")) o->local=1;
}
static void offer_actions(void *data, struct wl_data_offer *proxy, uint32_t actions) {
    (void)proxy; ((struct yr_offer *)data)->actions = actions;
}
static void offer_action(void *data, struct wl_data_offer *proxy, uint32_t action) {
    (void)proxy; ((struct yr_offer *)data)->action = action;
}
static const struct wl_data_offer_listener offer_listener = { .offer=offer_mime, .source_actions=offer_actions, .action=offer_action };
static void device_offer(void *data, struct wl_data_device *device, struct wl_data_offer *proxy) {
    (void)device;
    struct yr_dnd *d = data;
    struct yr_offer *o = calloc(1, sizeof(*o));
    if (!o) { wl_data_offer_destroy(proxy); return; }
    o->owner=d; o->proxy=proxy; o->token=wl_proxy_get_id((struct wl_proxy *)proxy); o->fd=-1;
    o->actions=COPY; o->next=d->offers; d->offers=o;
    wl_proxy_set_queue((struct wl_proxy *)proxy, d->queue);
    wl_data_offer_add_listener(proxy, &offer_listener, o);
}
static struct yr_offer *find_offer(struct yr_dnd *d, struct wl_data_offer *proxy) {
    for (struct yr_offer *o=d->offers; o; o=o->next) if (o->proxy == proxy) return o;
    return NULL;
}
static void device_enter(void *data, struct wl_data_device *device, uint32_t serial, struct wl_surface *surface, wl_fixed_t x, wl_fixed_t y, struct wl_data_offer *proxy) {
    (void)device;
    struct yr_dnd *d=data; struct yr_offer *o=find_offer(d, proxy);
    if (!o || wl_proxy_get_id((struct wl_proxy *)surface) != d->surface || !o->uri) {
        if (o) wl_data_offer_accept(proxy, serial, NULL);
        return;
    }
    d->preferred=o->local?COPY:ASK; d->current=o; o->serial=serial; o->x=wl_fixed_to_double(x); o->y=wl_fixed_to_double(y);
    wl_data_offer_accept(proxy, serial, "text/uri-list");
    if (wl_proxy_get_version((struct wl_proxy *)proxy)>=3) wl_data_offer_set_actions(proxy, COPY|MOVE|ASK, d->preferred);
    else o->action=COPY;
    int fds[2];
    if (pipe2(fds, O_CLOEXEC|O_NONBLOCK)<0) { fail(d,"Could not receive drag data"); return; }
    o->fd=fds[0];
    wl_data_offer_receive(proxy, "text/uri-list", fds[1]); close(fds[1]);
    emit(d,1,o->token,o->x,o->y,o->action,NULL,0);
}
static void device_leave(void *data, struct wl_data_device *device) {
    (void)device; struct yr_dnd *d=data;
    if (d->current && !d->current->dropped) destroy_offer(d,d->current);
    emit(d,1,0,0,0,0,NULL,0);
}
static void device_motion(void *data, struct wl_data_device *device, uint32_t time, wl_fixed_t x, wl_fixed_t y) {
    (void)device; (void)time; struct yr_dnd *d=data;
    if (d->current) {
        d->current->x=wl_fixed_to_double(x); d->current->y=wl_fixed_to_double(y);
        emit(d,1,d->current->token,d->current->x,d->current->y,d->current->action,NULL,0);
    }
}
static void device_drop(void *data, struct wl_data_device *device) {
    (void)device; struct yr_dnd *d=data;
    if (d->current) { d->current->dropped=1; d->current=NULL; }
}
static void device_selection(void *data, struct wl_data_device *device, struct wl_data_offer *proxy) {
    (void)device; struct yr_dnd *d=data; struct yr_offer *o=find_offer(d,proxy);
    if (o && !o->dropped && o != d->current) destroy_offer(d,o);
}
static const struct wl_data_device_listener device_listener = {
    .data_offer=device_offer, .enter=device_enter, .leave=device_leave, .motion=device_motion, .drop=device_drop, .selection=device_selection,
};
static void pointer_enter(void *data, struct wl_pointer *p, uint32_t serial, struct wl_surface *surface, wl_fixed_t x, wl_fixed_t y) {
    (void)p; (void)serial; (void)x; (void)y;
    ((struct yr_dnd *)data)->focus=wl_proxy_get_id((struct wl_proxy *)surface);
}
static void pointer_leave(void *data, struct wl_pointer *p, uint32_t serial, struct wl_surface *surface) {
    (void)p; (void)serial; (void)surface; ((struct yr_dnd *)data)->focus=0;
}
static void pointer_button(void *data, struct wl_pointer *p, uint32_t serial, uint32_t time, uint32_t button, uint32_t state) {
    (void)p; (void)time; struct yr_dnd *d=data;
    if (state==WL_POINTER_BUTTON_STATE_PRESSED && button==0x110 && d->focus==d->surface) d->serial=serial;
    if (state==WL_POINTER_BUTTON_STATE_RELEASED && !d->source) d->serial=0;
}
static void pointer_motion(void *d, struct wl_pointer *p, uint32_t t, wl_fixed_t x, wl_fixed_t y) { (void)d; (void)p; (void)t; (void)x; (void)y; }
static void pointer_axis(void *d, struct wl_pointer *p, uint32_t t, uint32_t axis, wl_fixed_t value) { (void)d; (void)p; (void)t; (void)axis; (void)value; }
static void pointer_frame(void *d, struct wl_pointer *p) { (void)d; (void)p; }
static void pointer_axis_source(void *d, struct wl_pointer *p, uint32_t source) { (void)d; (void)p; (void)source; }
static void pointer_axis_stop(void *d, struct wl_pointer *p, uint32_t time, uint32_t axis) { (void)d; (void)p; (void)time; (void)axis; }
static void pointer_discrete(void *d, struct wl_pointer *p, uint32_t axis, int32_t value) { (void)d; (void)p; (void)axis; (void)value; }
static const struct wl_pointer_listener pointer_listener = {
    .enter=pointer_enter,.leave=pointer_leave,.motion=pointer_motion,.button=pointer_button,.axis=pointer_axis,
    .frame=pointer_frame,.axis_source=pointer_axis_source,.axis_stop=pointer_axis_stop,.axis_discrete=pointer_discrete,
};
static void keyboard_map(void *data, struct wl_keyboard *keyboard, uint32_t format, int32_t fd, uint32_t size) {
    (void)keyboard; struct yr_dnd *d=data;
    if (format!=WL_KEYBOARD_KEYMAP_FORMAT_XKB_V1 || !size || size>LIMIT) { close(fd); return; }
    char *map=mmap(NULL,size,PROT_READ,MAP_PRIVATE,fd,0);close(fd);
    if (map==MAP_FAILED) return;
    struct xkb_keymap *keymap=xkb_keymap_new_from_buffer(d->xkb,map,size-1,XKB_KEYMAP_FORMAT_TEXT_V1,XKB_KEYMAP_COMPILE_NO_FLAGS);
    munmap(map,size);
    if (!keymap) return;
    if (d->keys) xkb_state_unref(d->keys);
    if (d->keymap) xkb_keymap_unref(d->keymap);
    d->keymap=keymap;d->keys=xkb_state_new(keymap);
}
static void keyboard_enter(void *d, struct wl_keyboard *k, uint32_t serial, struct wl_surface *s, struct wl_array *keys) { (void)d;(void)k;(void)serial;(void)s;(void)keys; }
static void keyboard_leave(void *d, struct wl_keyboard *k, uint32_t serial, struct wl_surface *s) { (void)k;(void)serial;(void)s;((struct yr_dnd *)d)->modifiers=0; }
static void keyboard_key(void *d, struct wl_keyboard *k, uint32_t serial, uint32_t time, uint32_t key, uint32_t state) { (void)d;(void)k;(void)serial;(void)time;(void)key;(void)state; }
static void keyboard_modifiers(void *data, struct wl_keyboard *k, uint32_t serial, uint32_t depressed, uint32_t latched, uint32_t locked, uint32_t group) {
    (void)k;(void)serial;struct yr_dnd *d=data;if (!d->keys) return;
    xkb_state_update_mask(d->keys,depressed,latched,locked,0,0,group);
    d->modifiers=(xkb_state_mod_name_is_active(d->keys,"Control",XKB_STATE_MODS_EFFECTIVE)>0?1:0)
        |(xkb_state_mod_name_is_active(d->keys,"Shift",XKB_STATE_MODS_EFFECTIVE)>0?2:0);
}
static void keyboard_repeat(void *d, struct wl_keyboard *k, int32_t rate, int32_t delay) { (void)d;(void)k;(void)rate;(void)delay; }
static const struct wl_keyboard_listener keyboard_listener={.keymap=keyboard_map,.enter=keyboard_enter,.leave=keyboard_leave,.key=keyboard_key,.modifiers=keyboard_modifiers,.repeat_info=keyboard_repeat};
static void seat_capabilities(void *data, struct wl_seat *seat, uint32_t caps) {
    struct yr_dnd *d=data;
    if (!(caps&WL_SEAT_CAPABILITY_POINTER) && d->pointer) {
        wl_pointer_release(d->pointer); d->pointer=NULL; d->focus=0; d->serial=0;
    }
    if (!(caps&WL_SEAT_CAPABILITY_KEYBOARD) && d->keyboard) {
        wl_keyboard_release(d->keyboard); d->keyboard=NULL; d->modifiers=0;
    }
    if ((caps&WL_SEAT_CAPABILITY_KEYBOARD) && !d->keyboard) {
        d->keyboard=wl_seat_get_keyboard(seat);wl_keyboard_add_listener(d->keyboard,&keyboard_listener,d);
    }
    if ((caps&WL_SEAT_CAPABILITY_POINTER) && !d->pointer) {
        d->pointer=wl_seat_get_pointer(seat); wl_pointer_add_listener(d->pointer,&pointer_listener,d);
    }
}
static void seat_name(void *data, struct wl_seat *seat, const char *name) { (void)data; (void)seat; (void)name; }
static const struct wl_seat_listener seat_listener={.capabilities=seat_capabilities,.name=seat_name};
static void registry_global(void *data, struct wl_registry *registry, uint32_t name, const char *interface, uint32_t version) {
    struct yr_dnd *d=data;
    if (!strcmp(interface,"wl_seat") && !d->seat && version>=5) {
        d->seat=wl_registry_bind(registry,name,&wl_seat_interface,version<7?version:7);
        wl_seat_add_listener(d->seat,&seat_listener,d);
    } else if (!strcmp(interface,"wl_compositor") && !d->compositor) {
        d->compositor=wl_registry_bind(registry,name,&wl_compositor_interface,version<4?version:4);
    } else if (!strcmp(interface,"wl_shm") && !d->shm) {
        d->shm=wl_registry_bind(registry,name,&wl_shm_interface,1);
    } else if (!strcmp(interface,"wl_data_device_manager") && !d->manager && version>=3) {
        d->manager_version=version<3?version:3;
        d->manager=wl_registry_bind(registry,name,&wl_data_device_manager_interface,d->manager_version);
    }
}
static void registry_remove(void *data, struct wl_registry *registry, uint32_t name) { (void)data; (void)registry; (void)name; }
static const struct wl_registry_listener registry_listener={.global=registry_global,.global_remove=registry_remove};
static void icon_rect(uint32_t *pixels, int x, int y, int w, int h, uint32_t color) {
    for (int row=y;row<y+h;row++) for (int col=x;col<x+w;col++) pixels[row*80+col]=color;
}
static int create_icon(struct yr_dnd *d, uint32_t count, int directory) {
    const int size=80*64*4;
    int fd=memfd_create("yazi-rune-drag",MFD_CLOEXEC);
    if (fd<0) return 0;
    if (ftruncate(fd,size)<0) {close(fd);return 0;}
    void *pixels=mmap(NULL,size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    if (pixels==MAP_FAILED) {close(fd);return 0;}
    d->icon_pixels=pixels;
    struct wl_shm_pool *pool=wl_shm_create_pool(d->shm,fd,size);close(fd);
    if (!pool) return 0;
    d->icon_buffer=wl_shm_pool_create_buffer(pool,0,80,64,80*4,WL_SHM_FORMAT_ARGB8888);wl_shm_pool_destroy(pool);
    d->icon=wl_compositor_create_surface(d->compositor);
    if (!d->icon || !d->icon_buffer) return 0;
    if (count>1) icon_rect(pixels,20,12,38,44,0xff303d50);
    if (directory) {
        icon_rect(pixels,12,13,20,13,0xffe8c180);
        icon_rect(pixels,10,21,48,32,0xffe8c180);
        icon_rect(pixels,14,26,40,23,0xff896015);
        icon_rect(pixels,14,26,40,3,0xffffe3b0);
    } else {
        icon_rect(pixels,14,8,38,46,0xff91baf8);
        icon_rect(pixels,18,12,30,38,0xff1b2330);
        for (int row=0;row<9;row++) for (int col=row;col<9;col++) ((uint32_t *)pixels)[(8+row)*80+43+col]=0xffdce4ef;
        icon_rect(pixels,22,22,22,3,0xffdce4ef);
        icon_rect(pixels,22,30,22,3,0xffdce4ef);
        icon_rect(pixels,22,38,16,3,0xffdce4ef);
    }
    if (count>1) {
        static const uint8_t digits[10][5]={{7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},{7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7}};
        char label[8];if (count>999) strcpy(label,"999+");else snprintf(label,sizeof(label),"%u",count);
        int length=(int)strlen(label),x=80-(length*8+8);
        icon_rect(pixels,x,44,length*8+8,16,0xff24476c);
        for (int n=0;n<length;n++) for (int row=0;row<5;row++) {
            uint8_t bits=label[n]=='+'?(row==2?7:(row==1||row==3?2:0)):digits[label[n]-'0'][row];
            for (int col=0;col<3;col++) if (bits&(1u<<(2-col))) icon_rect(pixels,x+4+n*8+col*2,47+row*2,2,2,0xffffffff);
        }
    }
    wl_surface_attach(d->icon,d->icon_buffer,12,12);wl_surface_damage(d->icon,0,0,80,64);
    return 1;
}
static void clear_source(struct yr_dnd *d) {
    while (d->sends) { struct yr_send *s=d->sends; d->sends=s->next; close(s->fd); free(s); }
    if (d->source) wl_data_source_destroy(d->source);
    if (d->icon) wl_surface_destroy(d->icon);
    if (d->icon_buffer) wl_buffer_destroy(d->icon_buffer);
    if (d->icon_pixels) munmap(d->icon_pixels,80*64*4);
    d->icon=NULL;d->icon_buffer=NULL;d->icon_pixels=NULL;
    d->source=NULL; d->serial=0; free(d->payload); d->payload=NULL; d->payload_length=0;
}
static void source_target(void *d, struct wl_data_source *source, const char *mime) { (void)d; (void)source; (void)mime; }
static void source_send(void *data, struct wl_data_source *source, const char *mime, int32_t fd) {
    (void)source; struct yr_dnd *d=data;
    if (strcmp(mime,"text/uri-list")) { close(fd); return; }
    struct yr_send *s=calloc(1,sizeof(*s));
    if (!s) { close(fd); return; }
    fcntl(fd,F_SETFL,fcntl(fd,F_GETFL)|O_NONBLOCK); s->fd=fd; s->next=d->sends; d->sends=s;
}
static void source_cancelled(void *data, struct wl_data_source *source) { (void)source; struct yr_dnd *d=data; clear_source(d); emit(d,3,0,0,0,0,NULL,0); }
static void source_performed(void *data, struct wl_data_source *source) { (void)data; (void)source; }
static void source_finished(void *data, struct wl_data_source *source) { (void)source; struct yr_dnd *d=data; clear_source(d); emit(d,3,0,0,0,1,NULL,0); }
static void source_action(void *data, struct wl_data_source *source, uint32_t action) { (void)data; (void)source; (void)action; }
static const struct wl_data_source_listener source_listener={.target=source_target,.send=source_send,.cancelled=source_cancelled,.dnd_drop_performed=source_performed,.dnd_finished=source_finished,.action=source_action};
void yr_dnd_destroy(struct yr_dnd *d) {
    if (!d) return;
    clear_source(d);
    while (d->offers) destroy_offer(d,d->offers);
    if (d->device) wl_data_device_release(d->device);
    if (d->pointer) wl_pointer_release(d->pointer);
    if (d->keyboard) wl_keyboard_release(d->keyboard);
    if (d->manager) wl_data_device_manager_destroy(d->manager);
    if (d->seat) wl_seat_release(d->seat);
    if (d->compositor) wl_compositor_destroy(d->compositor);
    if (d->shm) wl_shm_destroy(d->shm);
    if (d->registry) wl_registry_destroy(d->registry);
    if (d->keys) xkb_state_unref(d->keys);
    if (d->keymap) xkb_keymap_unref(d->keymap);
    if (d->xkb) xkb_context_unref(d->xkb);
    wl_display_flush(d->display);
    wl_event_queue_destroy(d->queue); free(d);
}
struct yr_dnd *yr_dnd_create(struct wl_surface *surface, yr_callback callback, void *context) {
    struct yr_dnd *d=calloc(1,sizeof(*d)); if (!d) return NULL;
    d->display=wl_proxy_get_display((struct wl_proxy *)surface); d->surface=wl_proxy_get_id((struct wl_proxy *)surface);
    d->callback=callback;d->context=context;d->preferred=COPY;d->xkb=xkb_context_new(XKB_CONTEXT_NO_FLAGS);
    if (!d->xkb) {free(d);return NULL;}
    d->queue=wl_display_create_queue(d->display);
    if (!d->queue) { if (d->xkb) xkb_context_unref(d->xkb);free(d); return NULL; }
    struct wl_proxy *wrapper=wl_proxy_create_wrapper(d->display);
    wl_proxy_set_queue(wrapper,d->queue);d->registry=wl_display_get_registry((struct wl_display *)wrapper);wl_proxy_wrapper_destroy(wrapper);
    wl_registry_add_listener(d->registry,&registry_listener,d);
    if (wl_display_roundtrip_queue(d->display,d->queue)<0 || !d->seat || !d->manager || !d->compositor || !d->shm) { yr_dnd_destroy(d); return NULL; }
    d->device=wl_data_device_manager_get_data_device(d->manager,d->seat);wl_data_device_add_listener(d->device,&device_listener,d);
    if (wl_display_roundtrip_queue(d->display,d->queue)<0) { yr_dnd_destroy(d); return NULL; }
    return d;
}
int yr_dnd_start(struct yr_dnd *d, struct wl_surface *origin, const char *data, size_t length, uint32_t count, int directory) {
    if (!d || d->source || !d->serial || d->focus!=d->surface || !length || length>LIMIT) return 0;
    if (wl_proxy_get_display((struct wl_proxy *)origin)!=d->display || wl_proxy_get_id((struct wl_proxy *)origin)!=d->surface) return 0;
    d->payload=malloc(length); if (!d->payload) return 0;memcpy(d->payload,data,length);d->payload_length=length;
    d->source=wl_data_device_manager_create_data_source(d->manager);wl_data_source_add_listener(d->source,&source_listener,d);
    if (!create_icon(d,count,directory)) {clear_source(d);fail(d,"Could not create drag icon");return 0;}
    wl_data_source_offer(d->source,"text/uri-list");
    wl_data_source_offer(d->source,"application/x-yazi-rune-files");
    if (d->modifiers==3) wl_data_source_offer(d->source,"application/x-yazi-rune-action-link");
    uint32_t actions=d->modifiers==1?COPY:d->modifiers==2?MOVE:d->modifiers==3?COPY:COPY|MOVE|ASK;
    if (d->manager_version>=3) wl_data_source_set_actions(d->source,actions);
    wl_data_device_start_drag(d->device,d->source,origin,d->icon,d->serial);wl_surface_commit(d->icon);wl_display_flush(d->display);return 1;
}
void yr_dnd_prefer(struct yr_dnd *d, uint32_t token, uint32_t action) {
    if (!d || !d->current || d->current->token!=token || (action!=COPY && action!=MOVE && action!=ASK)) return;
    d->preferred=action;
    if (d->current && wl_proxy_get_version((struct wl_proxy *)d->current->proxy)>=3) {
        wl_data_offer_set_actions(d->current->proxy,COPY|MOVE|ASK,action);wl_display_flush(d->display);
    }
}
void yr_dnd_finish(struct yr_dnd *d, uint32_t token, int success, uint32_t action) {
    for (struct yr_offer *o=d->offers; o; o=o->next) if (o->token==token) {
        if (success && o->dropped && (o->action==COPY || o->action==MOVE || (o->action==ASK && (action==COPY || action==MOVE) && (o->actions & action))) && wl_proxy_get_version((struct wl_proxy *)o->proxy)>=3) {
            if (o->action==ASK) wl_data_offer_set_actions(o->proxy,action,action);
            wl_data_offer_finish(o->proxy);
        }
        destroy_offer(d,o);wl_display_flush(d->display);return;
    }
}
void yr_dnd_poll(struct yr_dnd *d) {
    if (!d) return;
    if (wl_display_dispatch_queue_pending(d->display,d->queue)<0) { fail(d,"Wayland drag connection failed"); return; }
    struct yr_send **slot=&d->sends;
    while (*slot) {
        struct yr_send *s=*slot;ssize_t n=write(s->fd,d->payload+s->offset,d->payload_length-s->offset);
        if (n>0) s->offset+=(size_t)n;
        if (s->offset==d->payload_length || (n<0 && errno!=EAGAIN && errno!=EINTR)) {
            *slot=s->next;close(s->fd);free(s);
        } else slot=&s->next;
    }
    struct yr_offer *o=d->offers;
    while (o) {
        struct yr_offer *next=o->next;
        if (o->fd>=0 && !o->eof) {
            char buffer[4096];ssize_t n;
            while ((n=read(o->fd,buffer,sizeof(buffer)))>0) {
                if (o->length+(size_t)n>LIMIT) { fail(d,"Dragged file list is too large"); destroy_offer(d,o);o=NULL;break; }
                char *data=realloc(o->data,o->length+(size_t)n);
                if (!data) { fail(d,"Could not receive dragged files");destroy_offer(d,o);o=NULL;break; }
                o->data=data;memcpy(data+o->length,buffer,(size_t)n);o->length+=(size_t)n;
            }
            if (o && n==0) { o->eof=1;close(o->fd);o->fd=-1; }
            else if (o && n<0 && errno!=EAGAIN && errno!=EINTR) { destroy_offer(d,o);o=NULL; }
        }
        if (o && o->eof && !o->previewed) {
            o->previewed=1;emit(d,5,o->token,o->x,o->y,o->local,o->data,o->length);
        }
        if (o && o->eof && o->dropped && !o->delivered) {
            o->delivered=1;emit(d,2,o->token,o->x,o->y,(o->link?8:o->action) | (!o->local && (o->actions & COPY) && (o->actions & MOVE)?16:0),o->data,o->length);
        }
        o=next;
    }
    wl_display_flush(d->display);
}
