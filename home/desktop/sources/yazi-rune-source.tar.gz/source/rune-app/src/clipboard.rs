use std::{
    io::Read,
    path::PathBuf,
    sync::mpsc::{self, Receiver, Sender},
    thread,
};

use rune::Waker;
use wl_clipboard_rs::{copy, paste};

#[derive(Clone, PartialEq, Eq)]
pub struct Yank {
    pub paths: Vec<PathBuf>,
    pub cut: bool,
}

enum Request {
    Write(Yank),
    Consume(Yank, Yank),
    Read { destination: PathBuf, force: bool },
}

pub enum Event {
    Written(Result<(), String>),
    Paste {
        files: Result<Option<Yank>, String>,
        destination: PathBuf,
        force: bool,
    },
}

#[derive(Default)]
pub struct Clipboard {
    input: Option<Sender<Request>>,
    output: Option<Receiver<Event>>,
}

impl Clipboard {
    pub fn start(&mut self, waker: Waker) {
        let (input, requests) = mpsc::channel();
        let (output, events) = mpsc::channel();
        self.input = Some(input);
        self.output = Some(events);
        thread::spawn(move || {
            for request in requests {
                let event = match request {
                    Request::Write(files) => Event::Written(write(files)),
                    Request::Consume(files, remaining) => Event::Written(consume(files, remaining)),
                    Request::Read { destination, force } => Event::Paste {
                        files: read(),
                        destination,
                        force,
                    },
                };
                if output.send(event).is_err() {
                    return;
                }
                (waker)();
            }
        });
    }

    pub fn write(&self, files: &Yank) {
        if let Some(input) = &self.input {
            let _ = input.send(Request::Write(files.clone()));
        }
    }

    pub fn consume(&self, files: &Yank, remaining: &Yank) {
        if let Some(input) = &self.input {
            let _ = input.send(Request::Consume(files.clone(), remaining.clone()));
        }
    }

    pub fn paste(&self, destination: PathBuf, force: bool) {
        if let Some(input) = &self.input {
            let _ = input.send(Request::Read { destination, force });
        }
    }

    pub fn take(&self) -> Vec<Event> {
        self.output
            .as_ref()
            .map(|r| r.try_iter().collect())
            .unwrap_or_default()
    }
}

fn write(files: Yank) -> Result<(), String> {
    let uris = files
        .paths
        .iter()
        .map(|path| {
            url::Url::from_file_path(path)
                .map(|uri| uri.to_string())
                .map_err(|_| "Clipboard files must be absolute paths".to_owned())
        })
        .collect::<Result<Vec<_>, _>>()?
        .join("\r\n");
    let gnome = format!("{}\n{}", if files.cut { "cut" } else { "copy" }, uris);
    let sources = [
        ("text/uri-list", uris),
        ("x-special/gnome-copied-files", gnome),
        (
            "application/x-kde-cutselection",
            if files.cut { "1" } else { "0" }.into(),
        ),
    ];
    copy::Options::new()
        .copy_multi(
            sources
                .into_iter()
                .map(|(mime, data)| copy::MimeSource {
                    source: copy::Source::Bytes(data.into_bytes().into_boxed_slice()),
                    mime_type: copy::MimeType::Specific(mime.into()),
                })
                .collect(),
        )
        .map_err(|error| error.to_string())
}

fn read_mime(mime: &str) -> Result<String, String> {
    let (pipe, _) = paste::get_contents(
        paste::ClipboardType::Regular,
        paste::Seat::Unspecified,
        paste::MimeType::Specific(mime),
    )
    .map_err(|error| error.to_string())?;
    let mut data = String::new();
    pipe.take(1024 * 1024 + 1)
        .read_to_string(&mut data)
        .map_err(|error| error.to_string())?;
    if data.len() > 1024 * 1024 {
        return Err("File clipboard exceeds 1 MiB".into());
    }
    Ok(data)
}

fn read() -> Result<Option<Yank>, String> {
    let types = paste::get_mime_types(paste::ClipboardType::Regular, paste::Seat::Unspecified)
        .map_err(|error| error.to_string())?;
    let (uris, cut) = if types.contains("x-special/gnome-copied-files") {
        let data = read_mime("x-special/gnome-copied-files")?;
        let (action, uris) = data.split_once('\n').ok_or("Invalid file clipboard")?;
        if !matches!(action.trim(), "copy" | "cut") {
            return Err("Invalid clipboard action".into());
        }
        (uris.to_owned(), action.trim() == "cut")
    } else if types.contains("text/uri-list") {
        let cut = types.contains("application/x-kde-cutselection")
            && read_mime("application/x-kde-cutselection")?.trim() == "1";
        (read_mime("text/uri-list")?, cut)
    } else {
        return Ok(None);
    };
    let paths = uris
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(|line| {
            url::Url::parse(line)
                .map_err(|error| error.to_string())?
                .to_file_path()
                .map_err(|_| format!("Clipboard location is not a local file: {line}"))
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Some(Yank { paths, cut }))
}

fn consume(files: Yank, remaining: Yank) -> Result<(), String> {
    if let Ok(Some(current)) = read()
        && current.cut
        && current.paths == files.paths
    {
        let paths = remaining.paths;
        if paths.is_empty() {
            copy::clear(copy::ClipboardType::Regular, copy::Seat::All).map_err(|e| e.to_string())
        } else {
            write(Yank { paths, cut: true })
        }
    } else {
        Ok(())
    }
}
