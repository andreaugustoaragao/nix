use std::{
    fs,
    io::{Cursor, Read},
    path::{Path, PathBuf},
    sync::Arc,
};

use gio::prelude::CancellableExt;
use html5ever::{parse_document, tendril::TendrilSink};
use markup5ever_rcdom::{Handle, NodeData, RcDom};

use crate::code::Code;

pub struct Html {
    pub source: Arc<Source>,
    pub view: View,
}

pub struct Source {
    pub path: PathBuf,
    pub text: String,
    pub code: Code,
    pub truncated: bool,
}

pub enum View {
    Source,
    Loading,
    Rendered(Document),
    Error(String),
}

pub struct Document {
    pub parts: Vec<Part>,
    pub limited: bool,
}

pub enum Part {
    Text {
        source: String,
        anchors: Vec<String>,
    },
    Image {
        image: rune::Image,
        alt: String,
    },
}

impl Html {
    pub fn new(
        path: PathBuf,
        text: &str,
        truncated: bool,
        cancel: &gio::Cancellable,
    ) -> Option<Self> {
        let mut lines = text.split_inclusive('\n');
        let text: String = lines.by_ref().take(4000).collect();
        let truncated = truncated || lines.next().is_some();
        let code = Code::new(Path::new("preview.html"), &text, truncated, cancel)?;
        Some(Self {
            source: Arc::new(Source {
                path,
                text,
                code,
                truncated,
            }),
            view: View::Source,
        })
    }

    pub fn render(
        source: Arc<Source>,
        cache: &rune::ImageCache,
        cancel: &gio::Cancellable,
    ) -> Self {
        let view = document(&source, cache, cancel)
            .map(View::Rendered)
            .unwrap_or_else(View::Error);
        Self { source, view }
    }

    pub fn status(&self) -> &'static str {
        match self.view {
            View::Source => "source",
            View::Loading => "loading",
            View::Rendered(_) => "rendered",
            View::Error(_) => "error",
        }
    }
}

fn attribute(node: &Handle, key: &str) -> Option<String> {
    let NodeData::Element { attrs, .. } = &node.data else {
        return None;
    };
    attrs
        .borrow()
        .iter()
        .find(|a| a.name.local.as_ref() == key)
        .map(|a| a.value.to_string())
}

fn name(node: &Handle) -> &str {
    match &node.data {
        NodeData::Element { name, .. } => name.local.as_ref(),
        _ => "",
    }
}

fn hidden(node: &Handle) -> bool {
    matches!(
        name(node),
        "head"
            | "script"
            | "style"
            | "template"
            | "iframe"
            | "object"
            | "embed"
            | "form"
            | "input"
            | "button"
            | "select"
            | "textarea"
    ) || attribute(node, "hidden").is_some()
        || attribute(node, "style").is_some_and(|s| {
            s.split(';').any(|rule| {
                rule.split_once(':').is_some_and(|(key, value)| {
                    let value = value.split('!').next().unwrap_or_default().trim();
                    (key.trim().eq_ignore_ascii_case("display")
                        && value.eq_ignore_ascii_case("none"))
                        || (key.trim().eq_ignore_ascii_case("visibility")
                            && value.eq_ignore_ascii_case("hidden"))
                })
            })
        })
}

fn escaped(text: &str) -> String {
    let mut result = String::new();
    for c in text.chars() {
        if matches!(
            c,
            '\\' | '`'
                | '*'
                | '_'
                | '['
                | ']'
                | '<'
                | '>'
                | '#'
                | '!'
                | '|'
                | '~'
                | '.'
                | '-'
                | '+'
                | ')'
        ) {
            result.push('\\');
        }
        result.push(if c.is_control() && !c.is_whitespace() {
            '�'
        } else {
            c
        });
    }
    result
}

fn plain(node: &Handle) -> String {
    let mut result = String::new();
    let mut stack = vec![(node.clone(), 0)];
    let mut visited = 0;
    while let Some((node, depth)) = stack.pop() {
        visited += 1;
        if depth > 64 || visited > 20000 || result.len() >= 256 * 1024 {
            break;
        }
        if hidden(&node) {
            continue;
        }
        if matches!(name(&node), "p" | "div" | "li") {
            result.push('\n');
        }
        if let NodeData::Text { contents } = &node.data {
            result.push_str(&contents.borrow());
        } else if name(&node) == "br" {
            result.push('\n');
        } else if name(&node) == "img" {
            result.push_str(&attribute(&node, "alt").unwrap_or_default());
        }
        stack.extend(
            node.children
                .borrow()
                .iter()
                .rev()
                .map(|node| (node.clone(), depth + 1)),
        );
    }
    result
}

fn document(
    source: &Source,
    cache: &rune::ImageCache,
    cancel: &gio::Cancellable,
) -> Result<Document, String> {
    if cancel.is_cancelled() {
        return Err("Rendering cancelled".into());
    }
    let options = html5ever::ParseOpts {
        tree_builder: html5ever::tree_builder::TreeBuilderOpts {
            scripting_enabled: false,
            ..Default::default()
        },
        ..Default::default()
    };
    let dom = parse_document(RcDom::default(), options).one(source.text.as_str());
    let location = source
        .path
        .canonicalize()
        .unwrap_or_else(|_| source.path.clone());
    let root = location.parent().and_then(|path| {
        fs::File::open(path)
            .ok()
            .map(|dir| (path.to_path_buf(), dir))
    });
    let mut builder = Builder {
        source,
        cache,
        cancel,
        root,
        location,
        pending: String::new(),
        anchors: Vec::new(),
        parts: Vec::new(),
        lists: Vec::new(),
        nodes: 0,
        blocks: 0,
        text_bytes: 0,
        image_bytes: 0,
        pixels: 0,
        images: 0,
        limited: false,
    };
    builder.walk(&dom.document, 0);
    if cancel.is_cancelled() {
        return Err("Rendering cancelled".into());
    }
    builder.flush();
    Ok(Document {
        parts: builder.parts,
        limited: builder.limited,
    })
}

struct Builder<'a> {
    source: &'a Source,
    cache: &'a rune::ImageCache,
    cancel: &'a gio::Cancellable,
    root: Option<(PathBuf, fs::File)>,
    location: PathBuf,
    pending: String,
    anchors: Vec<String>,
    parts: Vec<Part>,
    lists: Vec<usize>,
    nodes: usize,
    blocks: usize,
    text_bytes: usize,
    image_bytes: usize,
    pixels: u64,
    images: usize,
    limited: bool,
}

impl Builder<'_> {
    fn push(&mut self, text: &str) {
        let mut count = text
            .len()
            .min((256 * 1024usize).saturating_sub(self.text_bytes));
        while !text.is_char_boundary(count) {
            count -= 1;
        }
        self.pending.push_str(&text[..count]);
        self.text_bytes += count;
        if count < text.len() {
            self.limited = true;
        }
    }

    fn flush(&mut self) {
        if !self.pending.trim().is_empty() {
            self.parts.push(Part::Text {
                source: std::mem::take(&mut self.pending),
                anchors: std::mem::take(&mut self.anchors),
            });
        } else {
            self.pending.clear();
            self.anchors.clear();
        }
    }

    fn children(&mut self, node: &Handle, depth: usize) {
        for child in node.children.borrow().iter() {
            self.walk(child, depth + 1);
        }
    }

    fn walk(&mut self, node: &Handle, depth: usize) {
        if self.cancel.is_cancelled() {
            return;
        }
        if self.text_bytes >= 256 * 1024 || self.nodes >= 20000 || self.blocks >= 1000 {
            self.limited = true;
            return;
        }
        self.nodes += 1;
        if depth > 64 || self.nodes > 20000 {
            self.limited = true;
            return;
        }
        if hidden(node) {
            return;
        }
        if let NodeData::Text { contents } = &node.data {
            let text = contents.borrow();
            let mut collapsed = String::new();
            let mut space = self.pending.chars().last().is_none_or(char::is_whitespace);
            for c in text.chars() {
                if c.is_whitespace() {
                    if !space {
                        collapsed.push(' ');
                    }
                    space = true;
                } else {
                    collapsed.push(c);
                    space = false;
                }
            }
            self.push(&escaped(&collapsed));
            return;
        }
        let tag = name(node);
        let block = matches!(
            tag,
            "p" | "div"
                | "section"
                | "article"
                | "main"
                | "header"
                | "footer"
                | "nav"
                | "aside"
                | "h1"
                | "h2"
                | "h3"
                | "h4"
                | "h5"
                | "h6"
                | "pre"
                | "table"
                | "blockquote"
                | "li"
                | "hr"
        );
        if block {
            self.blocks += 1;
            if self.blocks > 1000 {
                self.limited = true;
                return;
            }
            if self.lists.is_empty() {
                self.push("\n\n");
            }
        }
        if let Some(id) = attribute(node, "id").filter(|id| !id.is_empty()) {
            if block && self.lists.is_empty() {
                self.flush();
            }
            self.anchors.push(id);
        }
        match tag {
            "h1" | "h2" | "h3" | "h4" | "h5" | "h6" => {
                self.push(&"#".repeat(tag.as_bytes()[1] as usize - b'0' as usize));
                self.push(" ");
                self.children(node, depth);
            }
            "b" | "strong" => {
                self.push("**");
                self.children(node, depth);
                self.push("**");
            }
            "i" | "em" => {
                self.push("*");
                self.children(node, depth);
                self.push("*");
            }
            "s" | "del" | "strike" => {
                self.push("~~");
                self.children(node, depth);
                self.push("~~");
            }
            "br" => self.push("  \n"),
            "hr" => self.push("---"),
            "code" | "kbd" | "samp" => {
                let text = plain(node).replace('\n', " ");
                let fence =
                    "`".repeat(text.split(|c| c != '`').map(str::len).max().unwrap_or(0) + 1);
                self.push(&fence);
                self.push(" ");
                self.push(&text);
                self.push(" ");
                self.push(&fence);
            }
            "pre" => {
                let text = plain(node);
                let fence = "`"
                    .repeat(3.max(text.split(|c| c != '`').map(str::len).max().unwrap_or(0) + 1));
                self.push(&fence);
                self.push("\n");
                self.push(&text);
                self.push("\n");
                self.push(&fence);
            }
            "ul" | "ol" => {
                self.push("\n");
                self.lists.push(if tag == "ol" { 1 } else { 0 });
                self.children(node, depth);
                self.lists.pop();
                self.push("\n");
            }
            "li" => {
                self.push("\n");
                self.push(&"    ".repeat(self.lists.len().saturating_sub(1)));
                let marker = if let Some(number) = self.lists.last_mut() {
                    if *number == 0 {
                        "- ".into()
                    } else {
                        let marker = format!("{number}. ");
                        *number += 1;
                        marker
                    }
                } else {
                    "- ".into()
                };
                self.push(&marker);
                self.children(node, depth);
            }
            "a" => {
                let href = attribute(node, "href").and_then(|href| {
                    url::Url::from_file_path(&self.source.path)
                        .ok()?
                        .join(&href)
                        .ok()
                });
                if let Some(href) = href
                    .filter(|href| matches!(href.scheme(), "file" | "http" | "https" | "mailto"))
                {
                    self.push("[");
                    self.children(node, depth);
                    self.push("](<");
                    self.push(href.as_str());
                    self.push(">)");
                } else {
                    self.children(node, depth);
                }
            }
            "blockquote" => {
                let text = plain(node);
                for line in text.trim().lines() {
                    self.push("> ");
                    self.push(&escaped(line));
                    self.push("\n");
                }
            }
            "img" => self.image(node),
            "table" => self.table(node),
            _ => self.children(node, depth),
        }
        if block && self.lists.is_empty() {
            self.push("\n\n");
        }
    }

    fn table(&mut self, table: &Handle) {
        let mut rows = Vec::new();
        let mut stack = vec![(table.clone(), 0)];
        while let Some((node, depth)) = stack.pop() {
            self.nodes += 1;
            if depth > 64 || self.nodes > 20000 || rows.len() >= 256 || self.cancel.is_cancelled() {
                self.limited = true;
                break;
            }
            if hidden(&node) {
                continue;
            }
            if name(&node) == "tr" {
                let row: Vec<_> = node
                    .children
                    .borrow()
                    .iter()
                    .filter(|cell| matches!(name(cell), "th" | "td"))
                    .take(32)
                    .map(|cell| {
                        escaped(&plain(cell).split_whitespace().collect::<Vec<_>>().join(" "))
                    })
                    .collect();
                if !row.is_empty() {
                    rows.push(row);
                }
            } else {
                stack.extend(
                    node.children
                        .borrow()
                        .iter()
                        .rev()
                        .map(|node| (node.clone(), depth + 1)),
                );
            }
        }
        let width = rows.iter().map(Vec::len).max().unwrap_or(0);
        for (index, row) in rows.iter().enumerate() {
            self.push("|");
            for column in 0..width {
                self.push(row.get(column).map_or("", String::as_str));
                self.push("|");
            }
            self.push("\n");
            if index == 0 {
                self.push("|");
                for _ in 0..width {
                    self.push("---|");
                }
                self.push("\n");
            }
        }
    }

    fn image(&mut self, node: &Handle) {
        let alt = attribute(node, "alt")
            .filter(|alt| !alt.is_empty())
            .unwrap_or_else(|| "Image".into());
        match attribute(node, "src")
            .ok_or_else(|| "missing source".to_owned())
            .and_then(|src| self.load_image(&src))
        {
            Ok(image) => {
                self.flush();
                self.parts.push(Part::Image { image, alt });
            }
            Err(reason) => {
                self.push("\n\n");
                self.push(&escaped(&format!("{alt} · {reason}")));
                self.push("\n\n");
            }
        }
    }

    fn load_image(&mut self, src: &str) -> Result<rune::Image, String> {
        let target = url::Url::from_file_path(&self.location)
            .map_err(|_| "invalid location")?
            .join(src)
            .map_err(|_| "invalid image location")?;
        if target.scheme() != "file" {
            return Err("remote image not loaded".into());
        }
        let path = target
            .to_file_path()
            .map_err(|_| "invalid image location")?;
        let (root, directory) = self.root.as_ref().ok_or("image folder unavailable")?;
        let relative = path
            .strip_prefix(root)
            .map_err(|_| "image outside document folder")?;
        if self.images >= 8 {
            self.limited = true;
            return Err("image preview limit".into());
        }
        let limit =
            (4 * 1024 * 1024usize).min((16 * 1024 * 1024usize).saturating_sub(self.image_bytes));
        use rustix::fs::{Mode, OFlags, ResolveFlags, openat2};
        let file = fs::File::from(
            openat2(
                directory,
                relative,
                OFlags::RDONLY | OFlags::NONBLOCK | OFlags::CLOEXEC,
                Mode::empty(),
                ResolveFlags::BENEATH | ResolveFlags::NO_MAGICLINKS,
            )
            .map_err(|_| "image unavailable")?,
        );
        if !file.metadata().map_err(|_| "image unavailable")?.is_file() {
            return Err("unsupported image type".into());
        }
        let mut bytes = Vec::new();
        file.take(limit as u64 + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| "could not read image")?;
        self.image_bytes += bytes.len();
        if bytes.len() > limit {
            self.limited = true;
            return Err("image preview limit".into());
        }
        let reader = image::ImageReader::new(Cursor::new(&bytes))
            .with_guessed_format()
            .map_err(|_| "unsupported image type")?;
        if !matches!(
            reader.format(),
            Some(image::ImageFormat::Png | image::ImageFormat::Jpeg)
        ) {
            return Err("PNG/JPEG images supported".into());
        }
        let (width, height) = reader.into_dimensions().map_err(|_| "invalid image")?;
        let pixels = u64::from(width) * u64::from(height);
        if self.pixels + pixels > 8_000_000 {
            self.limited = true;
            return Err("image resolution limit".into());
        }
        if self.cancel.is_cancelled() {
            return Err("rendering cancelled".into());
        }
        let image = self.cache.load(bytes);
        image.wait().map_err(|_| "could not decode image")?;
        self.images += 1;
        self.pixels += pixels;
        Ok(image)
    }
}
