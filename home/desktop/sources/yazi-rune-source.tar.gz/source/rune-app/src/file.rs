use std::{
    fs,
    io::{self, Read},
    path::{Path, PathBuf},
    time::SystemTime,
};

use gio::prelude::*;
use serde::Serialize;

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct File {
    pub path: PathBuf,
    pub name: String,
    pub directory: bool,
    pub symlink: bool,
    pub size: u64,
    pub mode: u32,
    pub modified: Option<SystemTime>,
    pub key: String,
}

pub struct Folder {
    pub path: PathBuf,
    pub files: Result<Vec<File>, String>,
    pub parent: Vec<File>,
    pub note: Option<String>,
    pub fallback: Option<PathBuf>,
}

pub fn read_folder(path: PathBuf) -> Folder {
    let files = read_dir(&path);
    let fallback = if files.is_err() && !path.is_dir() {
        path.ancestors()
            .skip(1)
            .find(|p| p.is_dir())
            .map(Path::to_path_buf)
    } else {
        None
    };
    let parent = path
        .parent()
        .and_then(|p| read_dir(p).ok())
        .unwrap_or_default();
    Folder {
        path,
        files,
        parent,
        note: None,
        fallback,
    }
}

pub fn read_dir(path: &Path) -> Result<Vec<File>, String> {
    let entries = fs::read_dir(path).map_err(|e| format!("{}: {e}", path.display()))?;
    let mut files = Vec::new();
    for entry in entries {
        let entry = entry.map_err(|e| e.to_string())?;
        if let Some(file) = read_file(entry.path()) {
            files.push(file);
        }
    }
    Ok(files)
}

pub fn read_file(path: PathBuf) -> Option<File> {
    use std::os::unix::fs::PermissionsExt;
    let metadata = fs::symlink_metadata(&path).ok()?;
    let symlink = metadata.is_symlink();
    let directory = metadata.is_dir() || (symlink && path.is_dir());
    let name = path.file_name()?.to_string_lossy().into_owned();
    let key = format!(
        "file:{}",
        path.as_os_str()
            .as_encoded_bytes()
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect::<String>()
    );
    Some(File {
        path,
        name,
        directory,
        symlink,
        size: metadata.len(),
        mode: metadata.permissions().mode(),
        modified: metadata.modified().ok(),
        key,
    })
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize)]
pub enum SortBy {
    Alphabetical,
    Natural,
    Extension,
    Size,
    #[default]
    Modified,
}

pub fn sort(
    files: &mut [File],
    by: SortBy,
    reverse: bool,
    sensitive: bool,
    directories_first: bool,
) {
    files.sort_by(|a, b| {
        if directories_first && a.directory != b.directory {
            return b.directory.cmp(&a.directory);
        }
        let name = || {
            if sensitive {
                a.name.cmp(&b.name)
            } else {
                a.name.to_lowercase().cmp(&b.name.to_lowercase())
            }
        };
        let order = match by {
            SortBy::Alphabetical => name(),
            SortBy::Natural if sensitive => natord::compare(&a.name, &b.name),
            SortBy::Natural => natord::compare_ignore_case(&a.name, &b.name),
            SortBy::Extension => a.path.extension().cmp(&b.path.extension()).then_with(name),
            SortBy::Size => a.size.cmp(&b.size).then_with(name),
            SortBy::Modified => a.modified.cmp(&b.modified).then_with(name),
        };
        let order = order.then_with(|| a.path.cmp(&b.path));
        if reverse { order.reverse() } else { order }
    });
}

pub enum Preview {
    Empty,
    Loading,
    Directory(Vec<File>),
    Text {
        lines: Vec<String>,
        truncated: bool,
    },
    Markdown {
        source: String,
        path: PathBuf,
        truncated: bool,
    },
    Image(rune::Image),
    Message(String),
}

impl Preview {
    pub fn kind(&self) -> &'static str {
        match self {
            Self::Empty => "empty",
            Self::Loading => "loading",
            Self::Directory(_) => "directory",
            Self::Text { .. } => "text",
            Self::Markdown { .. } => "markdown",
            Self::Image(_) => "image",
            Self::Message(_) => "message",
        }
    }
}

pub fn preview(path: PathBuf, directory: bool, cache: std::sync::Arc<rune::ImageCache>) -> Preview {
    if directory {
        return match read_dir(&path) {
            Ok(files) => Preview::Directory(files),
            Err(error) => Preview::Message(error),
        };
    }
    let extension = path
        .extension()
        .unwrap_or_default()
        .to_string_lossy()
        .to_ascii_lowercase();
    if [
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "tiff", "tif", "ico", "svg", "svgz",
    ]
    .contains(&extension.as_str())
    {
        let image = cache.file(&path, 900.0, 1.0);
        return match image.wait() {
            Ok(_) => Preview::Image(image),
            Err(error) => Preview::Message(format!("Could not preview image: {error}")),
        };
    }
    let result = (|| -> io::Result<_> {
        if !fs::metadata(&path)?.is_file() {
            return Ok(Preview::Message("No preview for this file type".into()));
        }
        let file = fs::File::open(&path)?;
        let mut bytes = Vec::new();
        file.take(256 * 1024 + 1).read_to_end(&mut bytes)?;
        Ok(text_preview(path.clone(), bytes))
    })();
    result
        .unwrap_or_else(|e| Preview::Message(format!("Could not preview {}: {e}", path.display())))
}

fn text_preview(path: PathBuf, mut bytes: Vec<u8>) -> Preview {
    let extension = path
        .extension()
        .unwrap_or_default()
        .to_string_lossy()
        .to_ascii_lowercase();
    let truncated = bytes.len() > 256 * 1024;
    bytes.truncate(256 * 1024);
    if bytes.contains(&0) {
        return Preview::Message("Binary file · open with o".into());
    }
    let source = String::from_utf8_lossy(&bytes);
    if ["md", "markdown", "mdown", "mkd", "mkdn", "mdwn"].contains(&extension.as_str()) {
        let mut lines = source.split_inclusive('\n');
        let source: String = lines.by_ref().take(4000).collect();
        let truncated = truncated || lines.next().is_some();
        let source = source
            .chars()
            .map(|c| {
                if c.is_control() && !matches!(c, '\n' | '\r' | '\t') {
                    '�'
                } else {
                    c
                }
            })
            .collect();
        return Preview::Markdown {
            source,
            path: path.clone(),
            truncated,
        };
    }
    let lines: Vec<_> = source
        .lines()
        .take(4000)
        .map(|l| {
            l.chars()
                .map(|c| {
                    if c.is_control() && c != '\t' {
                        '�'
                    } else {
                        c
                    }
                })
                .collect::<String>()
                .replace('\t', "  ")
        })
        .collect();
    let truncated = truncated || source.lines().count() > 4000;
    Preview::Text { lines, truncated }
}

pub fn human_size(size: u64) -> String {
    let units = ["B", "KiB", "MiB", "GiB", "TiB"];
    let mut value = size as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < units.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{size} B")
    } else {
        format!("{value:.1} {}", units[unit])
    }
}

pub fn remote_uri(root: &crate::operations::RemoteRoot, path: &Path) -> gio::File {
    let file = gio::File::for_uri(&root.uri);
    let relative = path
        .strip_prefix(&root.path)
        .expect("path within remote mount");
    if relative.as_os_str().is_empty() {
        file
    } else {
        file.resolve_relative_path(relative)
    }
}

pub fn read_dir_remote(
    path: &Path,
    root: &crate::operations::RemoteRoot,
    cancel: &gio::Cancellable,
) -> Result<Vec<File>, String> {
    let directory = remote_uri(root, path);
    let entries = directory.enumerate_children("standard::name,standard::type,standard::size,standard::is-symlink,unix::mode,time::modified,time::modified-usec,time::modified-nsec", gio::FileQueryInfoFlags::NOFOLLOW_SYMLINKS, Some(cancel)).map_err(|error| error.to_string())?;
    let mut files = Vec::new();
    while let Some(info) = entries
        .next_file(Some(cancel))
        .map_err(|error| error.to_string())?
    {
        let name = info.name();
        if name.components().count() != 1
            || !matches!(
                name.components().next(),
                Some(std::path::Component::Normal(_))
            )
        {
            return Err("Invalid remote filename".into());
        }
        let path = path.join(&name);
        let symlink = info.is_symlink() || info.file_type() == gio::FileType::SymbolicLink;
        let directory = info.file_type() == gio::FileType::Directory
            || (symlink
                && directory
                    .child(&name)
                    .query_info(
                        "standard::type",
                        gio::FileQueryInfoFlags::NONE,
                        Some(cancel),
                    )
                    .is_ok_and(|target| target.file_type() == gio::FileType::Directory));
        let metadata = crate::metadata::Metadata::remote(&info);
        let modified = metadata.modified();
        files.push(File {
            key: format!(
                "file:{}",
                path.as_os_str()
                    .as_encoded_bytes()
                    .iter()
                    .map(|b| format!("{b:02x}"))
                    .collect::<String>()
            ),
            path,
            name: name.to_string_lossy().into_owned(),
            directory,
            symlink,
            size: metadata.len(),
            mode: {
                use std::os::unix::fs::PermissionsExt;
                metadata.permissions().mode()
            },
            modified: if modified.unix_seconds() >= 0 {
                SystemTime::UNIX_EPOCH.checked_add(std::time::Duration::new(
                    modified.unix_seconds() as u64,
                    modified.nanoseconds(),
                ))
            } else {
                None
            },
        });
    }
    Ok(files)
}

pub fn read_folder_remote(
    path: PathBuf,
    root: crate::operations::RemoteRoot,
    cancel: gio::Cancellable,
) -> Folder {
    let files = read_dir_remote(&path, &root, &cancel);
    let parent = path
        .parent()
        .filter(|path| path.starts_with(&root.path))
        .and_then(|path| read_dir_remote(path, &root, &cancel).ok())
        .unwrap_or_default();
    Folder {
        path,
        files,
        parent,
        note: None,
        fallback: None,
    }
}

pub fn preview_remote(
    path: PathBuf,
    directory: bool,
    root: crate::operations::RemoteRoot,
    cancel: gio::Cancellable,
    cache: std::sync::Arc<rune::ImageCache>,
) -> Preview {
    if directory {
        return match read_dir_remote(&path, &root, &cancel) {
            Ok(files) => Preview::Directory(files),
            Err(error) => Preview::Message(error),
        };
    }
    let extension = path
        .extension()
        .unwrap_or_default()
        .to_string_lossy()
        .to_ascii_lowercase();
    let image = [
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "tiff", "tif", "ico", "svg", "svgz",
    ]
    .contains(&extension.as_str());
    let limit = if image { 32 * 1024 * 1024 } else { 256 * 1024 };
    let result = (|| -> Result<Preview, String> {
        let file = remote_uri(&root, &path);
        if file
            .query_info(
                "standard::type",
                gio::FileQueryInfoFlags::NONE,
                Some(&cancel),
            )
            .map_err(|error| error.to_string())?
            .file_type()
            != gio::FileType::Regular
        {
            return Ok(Preview::Message("No preview for this file type".into()));
        }
        let stream =
            gio::prelude::FileExt::read(&file, Some(&cancel)).map_err(|error| error.to_string())?;
        let mut bytes = Vec::new();
        loop {
            let mut buffer = vec![0; (limit + 1 - bytes.len()).min(128 * 1024)];
            let count =
                gio::prelude::InputStreamExtManual::read(&stream, &mut buffer, Some(&cancel))
                    .map_err(|error| error.to_string())?;
            bytes.extend_from_slice(&buffer[..count]);
            if count == 0 || bytes.len() > limit {
                break;
            }
        }
        let _ = stream.close(Some(&cancel));
        if image {
            if bytes.len() > limit {
                return Ok(Preview::Message(
                    "Image exceeds the 32 MiB remote preview limit".into(),
                ));
            }
            let image = if matches!(extension.as_str(), "svg" | "svgz") {
                cache.load_mime(bytes, "image/svg+xml", 900.0, 1.0)
            } else {
                cache.load(bytes)
            };
            image.wait().map_err(|error| error.to_string())?;
            Ok(Preview::Image(image))
        } else {
            Ok(text_preview(path.clone(), bytes))
        }
    })();
    result.unwrap_or_else(Preview::Message)
}
