#[path = "../src/code.rs"]
mod code;

use rune::{
    App, AppSpec, Color, Cx, El, Family, Image, ImageCache, Key, SurfaceFit, TextStyle, col, el,
    row, text,
};
use std::{collections::BTreeSet, path::Path};

#[derive(Clone, Copy, PartialEq)]
enum Concept {
    Workbench,
    Gallery,
    Desk,
}
#[derive(Clone, Copy)]
enum Kind {
    Folder,
    Rust,
    Json,
    Markdown,
    Image,
    Pdf,
    Archive,
}
struct Entry {
    name: &'static str,
    kind: Kind,
    size: &'static str,
    modified: &'static str,
}
struct Study {
    concept: Concept,
    cursor: usize,
    selected: BTreeSet<usize>,
    artwork: Image,
    report: Image,
    rust: code::Code,
    json: code::Code,
}
#[derive(Clone, Copy)]
struct Paint {
    bg: Color,
    panel: Color,
    ink: Color,
    muted: Color,
    accent: Color,
    selected: Color,
    line: Color,
}

const ENTRIES: &[Entry] = &[
    Entry {
        name: "src",
        kind: Kind::Folder,
        size: "19 items",
        modified: "Today 14:32",
    },
    Entry {
        name: "screenshots",
        kind: Kind::Folder,
        size: "8 items",
        modified: "Today 13:40",
    },
    Entry {
        name: "main.rs",
        kind: Kind::Rust,
        size: "7.2 KiB",
        modified: "Today 14:31",
    },
    Entry {
        name: "preview.json",
        kind: Kind::Json,
        size: "342 B",
        modified: "Today 14:20",
    },
    Entry {
        name: "RUNE.md",
        kind: Kind::Markdown,
        size: "6.5 KiB",
        modified: "Today 14:08",
    },
    Entry {
        name: "navigation.svg",
        kind: Kind::Image,
        size: "24 KiB",
        modified: "Today 13:40",
    },
    Entry {
        name: "verification.pdf",
        kind: Kind::Pdf,
        size: "84 KiB",
        modified: "Yesterday",
    },
    Entry {
        name: "source.tar.gz",
        kind: Kind::Archive,
        size: "102 KiB",
        modified: "Yesterday",
    },
];
const SOURCE: &str = "// A native Rune window\nuse rune::{App, AppSpec, Cx, El};\n\nfn view(s: &State, cx: &mut Cx<State>) -> El {\n    let p = palette(cx.system_dark());\n\n    row()\n        .key(\"workspace\")\n        .w_full()\n        .h_full()\n        .child(file_list(s, p))\n        .child(preview(s, p))\n}\n\nfn main() {\n    let spec = AppSpec::new(\n        \"Yazi Rune\",\n        (1160.0, 740.0),\n        State::new,\n        view,\n    );\n    App::new(spec).run();\n}\n";
const JSON: &str = r#"{"preview":{"language":"Rust","theme":"system","line_numbers":true},"navigation":{"folders_first":true,"sort":"modified","descending":true},"features":["Markdown","PDF","Wayland drag and drop"]}"#;
const MARKDOWN: &str = "# A workspace you can read\n\nYazi Rune brings keyboard file navigation into a native graphical window. Keep the current folder in view while inspecting the file you need.\n\n## Browse, inspect, act\n\nMove with **j** and **k**. Press **Enter** to open the selected file. The preview follows selection and keeps documents readable.\n\n- Source files have syntax colors and line numbers.\n- JSON is formatted without changing the original file.\n- Markdown renders headings, links, tables and code.\n- PDFs have page controls and keyboard navigation.\n\n> File previews should help you decide what to open, copy or move.\n\n## Supported previews\n\n| File | Preview |\n| --- | --- |\n| `.rs`, `.py`, `.nix` | Syntax-colored source |\n| `.json` | Formatted data |\n| `.md` | Rendered document |\n| `.pdf` | Fitted page |\n\nRead the [project guide](https://github.com/anomalyco/rune) for more about Rune.\n";
const FOLDER: rune::Icon = rune::Icon {
    name: "Folder",
    view: 24.0,
    body: r#"<path d="M2 5h7l3 3h10v12H2Z" stroke="currentColor" stroke-linejoin="round"/>"#,
};
const FILE: rune::Icon = rune::Icon {
    name: "File",
    view: 24.0,
    body: r#"<path d="M5 2h9l5 5v15H5ZM14 2v5h5M8 12h8M8 16h6" stroke="currentColor" stroke-linejoin="round"/>"#,
};
const CODE: rune::Icon = rune::Icon {
    name: "Source",
    view: 24.0,
    body: r#"<path d="m8 6-6 6 6 6m8-12 6 6-6 6m-3-15-2 18" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>"#,
};

fn hex(s: &str) -> Color {
    rune::color::hex(s).unwrap()
}
fn paint(c: Concept) -> Paint {
    let values = match c {
        Concept::Workbench => [
            "#162235", "#20314A", "#DBE5F2", "#A4B4C9", "#91BDFF", "#304D73", "#34485F",
        ],
        Concept::Gallery => [
            "#F1F3F8", "#FFFFFF", "#222B42", "#5A6680", "#56449B", "#DCD4F1", "#CED3E0",
        ],
        Concept::Desk => [
            "#E3EAF0", "#FAFCFD", "#233F51", "#577080", "#1F6889", "#C9DEE8", "#C1CFD8",
        ],
    };
    let [bg, panel, ink, muted, accent, selected, line] = values.map(hex);
    Paint {
        bg,
        panel,
        ink,
        muted,
        accent,
        selected,
        line,
    }
}
fn font(size: f32, weight: f32, c: Concept) -> TextStyle {
    TextStyle::new(size, weight).family(if c == Concept::Gallery {
        Family::Sans
    } else {
        Family::Named("Cantarell")
    })
}
fn label(s: impl Into<String>, size: f32, p: Paint, c: Concept) -> El {
    text(s).font(font(size, 400.0, c)).color(p.ink)
}
fn small(s: impl Into<String>, p: Paint, c: Concept) -> El {
    label(s, 12.0, p, c).color(p.muted)
}
fn line(p: Paint) -> El {
    el().h(1.0).w_full().fill(p.line)
}
fn glyph(kind: Kind, size: f32, p: Paint) -> El {
    rune::icon(
        match kind {
            Kind::Folder => &FOLDER,
            Kind::Rust | Kind::Json => &CODE,
            _ => &FILE,
        },
        size,
    )
    .color(p.accent)
}
fn init() -> Study {
    let cache = ImageCache::new(std::sync::Arc::new(|| {}));
    let artwork = cache.svg(
        include_bytes!("assets/navigation.svg").as_slice(),
        1200.0,
        1.0,
    );
    let report = cache.load(include_bytes!("assets/report.png").as_slice());
    artwork.wait().unwrap();
    report.wait().unwrap();
    let cancel = gio::Cancellable::new();
    Study {
        concept: Concept::Workbench,
        cursor: 2,
        selected: BTreeSet::new(),
        artwork,
        report,
        rust: code::Code::new(Path::new("main.rs"), SOURCE, false, &cancel).unwrap(),
        json: code::Code::new(Path::new("preview.json"), JSON, false, &cancel).unwrap(),
    }
}
fn select(s: &mut Study, i: usize) {
    s.cursor = i;
}
fn switch(s: &mut Study, c: Concept) {
    s.concept = c;
    s.cursor = match c {
        Concept::Workbench => 2,
        Concept::Gallery => 5,
        Concept::Desk => 4,
    };
}
fn switcher(s: &Study, p: Paint) -> El {
    let c = s.concept;
    let mut bar = row()
        .w_full()
        .h(44.0)
        .px(18.0)
        .gap(8.0)
        .center_y()
        .fill(p.panel)
        .child(text("Yazi Rune").font(font(15.0, 650.0, c)).color(p.ink));
    for (i, (concept, title)) in [
        (Concept::Workbench, "Workbench"),
        (Concept::Gallery, "Gallery"),
        (Concept::Desk, "Reading desk"),
    ]
    .into_iter()
    .enumerate()
    {
        bar = bar.child(
            label(format!("{}  {title}", i + 1), 12.0, p, c)
                .key(format!("concept-{i}"))
                .role("button")
                .label(title)
                .px(12.0)
                .py(6.0)
                .radius(6.0)
                .fill(if concept == c {
                    p.selected
                } else {
                    Color::TRANSPARENT
                })
                .hover(p.selected.alpha(0.5))
                .on_press(move |s: &mut Study| switch(s, concept)),
        );
    }
    bar.child(el().grow(1.0))
        .child(small("Design study · sample workspace", p, c))
}
fn path(p: Paint, c: Concept) -> El {
    row()
        .h(48.0)
        .w_full()
        .px(20.0)
        .gap(12.0)
        .center_y()
        .child(small("Home", p, c))
        .child(small("/", p, c))
        .child(small("Projects", p, c))
        .child(small("/", p, c))
        .child(label("yazi-rune", 15.0, p, c))
        .child(el().grow(1.0))
        .child(small("Folders first · Modified ↓", p, c))
}
fn footer(s: &Study, p: Paint) -> El {
    row()
        .h(34.0)
        .w_full()
        .px(20.0)
        .gap(22.0)
        .center_y()
        .fill(p.panel)
        .child(small(
            format!(
                "{} / {}  {}",
                s.cursor + 1,
                ENTRIES.len(),
                ENTRIES[s.cursor].name
            ),
            p,
            s.concept,
        ))
        .child(small(
            format!("{} selected", s.selected.len()),
            p,
            s.concept,
        ))
        .child(el().grow(1.0))
        .child(small(
            "j/k navigate   Space select   1/2/3 concept",
            p,
            s.concept,
        ))
}
fn places(p: Paint, c: Concept, width: f32) -> El {
    let mut side = col()
        .w(width)
        .h_full()
        .padding(16.0)
        .gap(9.0)
        .fill(p.panel)
        .child(text("Places").font(font(14.0, 600.0, c)).color(p.ink))
        .child(el().h(8.0));
    for name in ["Home", "Downloads", "Documents", "Projects"] {
        side = side.child(
            row()
                .h(32.0)
                .gap(10.0)
                .center_y()
                .child(glyph(Kind::Folder, 16.0, p))
                .child(label(name, 13.0, p, c)),
        );
    }
    side.child(el().h(28.0))
        .child(small("Devices", p, c))
        .child(label("System drive", 13.0, p, c))
        .child(small("162 GiB available", p, c))
        .child(el().h(28.0))
        .child(small("Bookmarks", p, c))
        .child(
            label("yazi-rune", 13.0, p, c)
                .px(8.0)
                .py(8.0)
                .radius(5.0)
                .fill(p.selected),
        )
        .child(label("nix", 13.0, p, c))
        .child(label("Rune source", 13.0, p, c))
        .child(el().grow(1.0))
        .child(line(p))
        .child(label("Trash", 13.0, p, c))
        .child(small("3 items", p, c))
}
fn files(s: &Study, p: Paint, detailed: bool) -> El {
    let c = s.concept;
    let mut list = col().w_full().gap(2.0);
    for (i, entry) in ENTRIES.iter().enumerate() {
        let mut r = row()
            .key(format!("file-{i}"))
            .role("listitem")
            .label(entry.name)
            .w_full()
            .h(if detailed { 44.0 } else { 38.0 })
            .px(12.0)
            .gap(10.0)
            .center_y()
            .radius(5.0)
            .fill(if i == s.cursor {
                p.selected
            } else {
                Color::TRANSPARENT
            })
            .hover(p.selected.alpha(0.4))
            .on_press(move |s: &mut Study| select(s, i))
            .child(glyph(entry.kind, 18.0, p))
            .child(
                label(entry.name, 13.0, p, c)
                    .grow(1.0)
                    .min_w(0.0)
                    .truncate(),
            );
        if detailed {
            r = r
                .child(small(entry.size, p, c).w(68.0))
                .child(small(entry.modified, p, c).w(88.0));
        }
        if s.selected.contains(&i) {
            r = r.child(label("✓", 13.0, p, c).color(p.accent));
        }
        list = list.child(r);
    }
    list
}
fn code_view(code: &code::Code, p: Paint, dark: bool, mini: bool) -> El {
    let mut body = col().gap(0.0).min_w(0.0);
    if !mini {
        body = body.child(
            text(&code.language)
                .font(TextStyle::new(12.0, 500.0))
                .color(p.accent)
                .py(8.0),
        );
    }
    for (i, l) in code
        .lines
        .iter()
        .enumerate()
        .take(if mini { 6 } else { 100 })
    {
        let size = if mini { 10.0 } else { 13.0 };
        body = body.child(
            row()
                .h(if mini { 15.0 } else { 23.0 })
                .gap(14.0)
                .child(
                    text(format!("{:>2}", i + 1))
                        .font(TextStyle::new(size, 400.0).mono())
                        .color(p.muted)
                        .w(24.0),
                )
                .child(
                    text(&l.text)
                        .font(TextStyle::new(size, 400.0).mono())
                        .color(p.ink)
                        .spans(if dark {
                            l.dark.clone()
                        } else {
                            l.light.clone()
                        }),
                ),
        );
    }
    if !mini {
        if let Some(note) = &code.note {
            body = body.child(
                text(note)
                    .font(TextStyle::new(11.0, 400.0))
                    .color(p.muted)
                    .py(8.0),
            );
        }
        if code.truncated {
            body = body.child(
                text("Preview limited")
                    .font(TextStyle::new(11.0, 400.0))
                    .color(p.muted),
            );
        }
    }
    body
}
fn content(s: &Study, p: Paint, mini: bool) -> El {
    let entry = &ENTRIES[s.cursor];
    match entry.kind {
        Kind::Rust => code_view(&s.rust, p, s.concept == Concept::Workbench, mini),
        Kind::Json => code_view(&s.json, p, s.concept == Concept::Workbench, mini),
        Kind::Markdown => {
            let serif = s.concept == Concept::Desk;
            let body = TextStyle::new(
                if mini {
                    11.0
                } else if serif {
                    16.0
                } else {
                    14.0
                },
                400.0,
            )
            .family(if serif {
                Family::Named("Noto Serif")
            } else {
                Family::Sans
            })
            .lh(if serif { 27.0 } else { 22.0 });
            let heading = TextStyle::new(
                if mini {
                    17.0
                } else if serif {
                    32.0
                } else {
                    25.0
                },
                600.0,
            )
            .family(if serif {
                Family::Named("Noto Serif")
            } else {
                Family::Sans
            })
            .lh(if serif { 42.0 } else { 32.0 });
            rune_kit::Markdown::new(if mini {
                "# A workspace you can read\n\nBrowse files. Read documents. Keep your context."
            } else {
                MARKDOWN
            })
            .tasks_read_only()
            .render(
                &rune_kit::MarkdownStyle::neutral(false)
                    .text(p.ink)
                    .muted(p.muted)
                    .link(p.accent)
                    .body_font(body)
                    .heading_font(1, heading)
                    .heading_font(2, TextStyle::new(20.0, 600.0).lh(30.0))
                    .rule(p.line)
                    .code_block(p.bg, p.line),
            )
            .w_full()
            .min_w(0.0)
        }
        Kind::Image => el()
            .w_full()
            .h_full()
            .min_h(100.0)
            .pixels_fit(s.artwork.pixels(), SurfaceFit::Fit),
        Kind::Pdf => el()
            .w_full()
            .h_full()
            .min_h(100.0)
            .pixels_fit(s.report.pixels(), SurfaceFit::Fit),
        Kind::Folder => col()
            .gap(10.0)
            .child(glyph(Kind::Folder, 40.0, p))
            .child(label("Folder contents", 18.0, p, s.concept))
            .child(label("file.rs", 14.0, p, s.concept))
            .child(label("ui.rs", 14.0, p, s.concept))
            .child(label("state.rs", 14.0, p, s.concept))
            .child(label("code.rs", 14.0, p, s.concept)),
        Kind::Archive => col()
            .gap(12.0)
            .child(label("Source archive", 24.0, p, s.concept))
            .child(small("source/rune-app/src", p, s.concept))
            .child(small("source/rune-app/share", p, s.concept))
            .child(small("source/rune-app/Cargo.toml", p, s.concept)),
    }
}
fn inspector(s: &Study, p: Paint) -> El {
    let entry = &ENTRIES[s.cursor];
    col()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .fill(p.bg)
        .child(
            row()
                .h(48.0)
                .w_full()
                .px(20.0)
                .gap(12.0)
                .center_y()
                .child(glyph(entry.kind, 18.0, p))
                .child(label(entry.name, 15.0, p, s.concept))
                .child(el().grow(1.0))
                .child(small("Preview", p, s.concept)),
        )
        .child(line(p))
        .child(
            col()
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .scroll_xy()
                .padding(20.0)
                .child(content(s, p, false)),
        )
        .child(
            row()
                .h(34.0)
                .px(20.0)
                .w_full()
                .center_y()
                .child(small("Read only", p, s.concept))
                .child(el().grow(1.0))
                .child(small(entry.size, p, s.concept)),
        )
}
fn workbench(s: &Study, p: Paint) -> El {
    row()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .gap(1.0)
        .fill(p.line)
        .child(places(p, s.concept, 154.0))
        .child(
            col()
                .w(126.0)
                .h_full()
                .padding(12.0)
                .gap(8.0)
                .fill(p.bg)
                .child(small("Projects", p, s.concept))
                .child(el().h(12.0))
                .child(label("nix", 13.0, p, s.concept).py(7.0))
                .child(
                    label("yazi-rune", 13.0, p, s.concept)
                        .px(5.0)
                        .py(7.0)
                        .radius(4.0)
                        .fill(p.selected),
                )
                .child(label("rune", 13.0, p, s.concept).py(7.0)),
        )
        .child(
            col()
                .grow(1.1)
                .min_w(285.0)
                .h_full()
                .fill(p.bg)
                .child(
                    row()
                        .h(48.0)
                        .px(16.0)
                        .w_full()
                        .center_y()
                        .child(label("Files", 14.0, p, s.concept))
                        .child(el().grow(1.0))
                        .child(small("8 items", p, s.concept)),
                )
                .child(line(p))
                .child(
                    col()
                        .grow(1.0)
                        .min_h(0.0)
                        .w_full()
                        .padding(8.0)
                        .scroll_xy()
                        .child(files(s, p, true)),
                )
                .child(line(p))
                .child(
                    row()
                        .h(42.0)
                        .px(16.0)
                        .center_y()
                        .gap(16.0)
                        .child(small("Copy", p, s.concept))
                        .child(small("Move", p, s.concept))
                        .child(small("Trash", p, s.concept))
                        .child(small("Rename", p, s.concept)),
                ),
        )
        .child(col().grow(1.4).min_w(300.0).h_full().child(inspector(s, p)))
}
fn thumbnail(s: &Study, i: usize, p: Paint) -> El {
    let mut alt = Study {
        concept: s.concept,
        cursor: i,
        selected: s.selected.clone(),
        artwork: s.artwork.clone(),
        report: s.report.clone(),
        rust: code::Code {
            language: String::new(),
            lines: Vec::new(),
            note: None,
            truncated: false,
        },
        json: code::Code {
            language: String::new(),
            lines: Vec::new(),
            note: None,
            truncated: false,
        },
    };
    match ENTRIES[i].kind {
        Kind::Rust => code_view(&s.rust, p, false, true),
        Kind::Json => code_view(&s.json, p, false, true),
        _ => {
            alt.cursor = i;
            content(&alt, p, true)
        }
    }
}
fn gallery(s: &Study, p: Paint) -> El {
    let c = s.concept;
    let mut folders = row().h(48.0).w_full().gap(12.0);
    for (i, entry) in ENTRIES.iter().enumerate().take(2) {
        folders = folders.child(
            row()
                .key(format!("folder-{i}"))
                .role("button")
                .label(entry.name)
                .grow(1.0)
                .h(44.0)
                .px(16.0)
                .gap(12.0)
                .center_y()
                .radius(8.0)
                .fill(p.panel)
                .border(1.0, if s.cursor == i { p.accent } else { p.line })
                .on_press(move |s: &mut Study| select(s, i))
                .child(glyph(Kind::Folder, 22.0, p))
                .child(label(entry.name, 14.0, p, c))
                .child(el().grow(1.0))
                .child(small(entry.size, p, c)),
        );
    }
    let mut grid = col().w_full().gap(14.0);
    for group in [2..5, 5..8] {
        let mut r = row().w_full().h(178.0).gap(14.0);
        for i in group {
            let e = &ENTRIES[i];
            r = r.child(
                col()
                    .key(format!("tile-{i}"))
                    .role("button")
                    .label(e.name)
                    .grow(1.0)
                    .min_w(0.0)
                    .h(178.0)
                    .radius(9.0)
                    .fill(p.panel)
                    .border(
                        if s.cursor == i { 2.0 } else { 1.0 },
                        if s.cursor == i { p.accent } else { p.line },
                    )
                    .shadow(3.0, 10.0, p.ink.alpha(0.07))
                    .hover(p.selected.alpha(0.35))
                    .on_press(move |s: &mut Study| select(s, i))
                    .child(
                        col()
                            .h(123.0)
                            .w_full()
                            .min_w(0.0)
                            .padding(12.0)
                            .clip_soft(0.0)
                            .child(thumbnail(s, i, p)),
                    )
                    .child(line(p))
                    .child(
                        row()
                            .w_full()
                            .px(12.0)
                            .py(8.0)
                            .gap(10.0)
                            .center_y()
                            .child(glyph(e.kind, 17.0, p))
                            .child(
                                col()
                                    .grow(1.0)
                                    .min_w(0.0)
                                    .child(label(e.name, 13.0, p, c).truncate())
                                    .child(small(e.size, p, c)),
                            ),
                    ),
            );
        }
        grid = grid.child(r);
    }
    row()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .gap(1.0)
        .fill(p.line)
        .child(places(p, c, 164.0))
        .child(
            col()
                .grow(1.0)
                .min_w(0.0)
                .min_h(0.0)
                .h_full()
                .fill(p.bg)
                .child(
                    col()
                        .w_full()
                        .grow(1.0)
                        .min_h(0.0)
                        .scroll_xy()
                        .padding(22.0)
                        .gap(15.0)
                        .child(folders)
                        .child(grid),
                )
                .child(
                    row()
                        .w_full()
                        .h(264.0)
                        .gap(24.0)
                        .padding(22.0)
                        .fill(p.panel)
                        .child(
                            col()
                                .grow(1.6)
                                .min_w(0.0)
                                .h_full()
                                .clip_soft(0.0)
                                .child(content(s, p, false)),
                        )
                        .child(
                            col()
                                .grow(1.0)
                                .min_w(200.0)
                                .gap(10.0)
                                .child(
                                    text(ENTRIES[s.cursor].name)
                                        .font(font(22.0, 600.0, c))
                                        .color(p.ink),
                                )
                                .child(small("Selected file", p, c))
                                .child(line(p))
                                .child(small(format!("Size    {}", ENTRIES[s.cursor].size), p, c))
                                .child(small(
                                    format!("Modified    {}", ENTRIES[s.cursor].modified),
                                    p,
                                    c,
                                ))
                                .child(el().grow(1.0))
                                .child(small("Copy   Move   Rename   Trash", p, c)),
                        ),
                ),
        )
}
fn desk(s: &Study, p: Paint) -> El {
    let c = s.concept;
    let mut siblings = row()
        .h(94.0)
        .w_full()
        .gap(12.0)
        .px(18.0)
        .py(12.0)
        .fill(p.panel);
    for i in [2, 3, 4, 5, 6] {
        siblings = siblings.child(
            row()
                .key(format!("sibling-{i}"))
                .role("button")
                .label(ENTRIES[i].name)
                .grow(1.0)
                .min_w(0.0)
                .h(68.0)
                .gap(10.0)
                .px(12.0)
                .center_y()
                .radius(6.0)
                .fill(if s.cursor == i { p.selected } else { p.bg })
                .border(1.0, p.line)
                .on_press(move |s: &mut Study| select(s, i))
                .child(glyph(ENTRIES[i].kind, 22.0, p))
                .child(
                    col()
                        .min_w(0.0)
                        .grow(1.0)
                        .child(label(ENTRIES[i].name, 12.0, p, c).truncate())
                        .child(small(ENTRIES[i].size, p, c)),
                ),
        );
    }
    col()
        .w_full()
        .grow(1.0)
        .min_h(0.0)
        .child(
            row()
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .child(
                    col()
                        .w(210.0)
                        .h_full()
                        .padding(16.0)
                        .gap(12.0)
                        .child(label("Workspace", 16.0, p, c))
                        .child(small("yazi-rune", p, c))
                        .child(line(p))
                        .child(files(s, p, false))
                        .child(el().grow(1.0))
                        .child(small("Home / Projects", p, c)),
                )
                .child(
                    col()
                        .grow(1.0)
                        .min_w(0.0)
                        .h_full()
                        .padding(20.0)
                        .items_center()
                        .child(
                            col()
                                .key("document-page")
                                .w_full()
                                .max_w(820.0)
                                .grow(1.0)
                                .min_h(0.0)
                                .fill(p.panel)
                                .radius(3.0)
                                .shadow(5.0, 20.0, p.ink.alpha(0.12))
                                .child(
                                    row()
                                        .h(42.0)
                                        .px(28.0)
                                        .w_full()
                                        .center_y()
                                        .child(small(ENTRIES[s.cursor].name, p, c))
                                        .child(el().grow(1.0))
                                        .child(small("Preview", p, c)),
                                )
                                .child(line(p))
                                .child(
                                    col()
                                        .key("document-scroll")
                                        .w_full()
                                        .grow(1.0)
                                        .min_h(0.0)
                                        .scroll(rune::ScrollSpec {
                                            stick_bottom: false,
                                        })
                                        .padding(32.0)
                                        .child(content(s, p, false)),
                                ),
                        ),
                )
                .child(
                    col()
                        .w(172.0)
                        .h_full()
                        .padding(18.0)
                        .gap(12.0)
                        .child(label("File details", 15.0, p, c))
                        .child(line(p))
                        .child(small("Size", p, c))
                        .child(label(ENTRIES[s.cursor].size, 14.0, p, c))
                        .child(small("Modified", p, c))
                        .child(label(ENTRIES[s.cursor].modified, 13.0, p, c))
                        .child(small("Location", p, c))
                        .child(label("~/Projects/\nyazi-rune", 13.0, p, c))
                        .child(el().h(22.0))
                        .child(small("Navigation", p, c))
                        .child(label("j / k  Sibling file", 12.0, p, c))
                        .child(label("J / K  Preview", 12.0, p, c))
                        .child(el().grow(1.0))
                        .child(line(p))
                        .child(label("Copy\nMove\nRename\nTrash", 13.0, p, c)),
                ),
        )
        .child(siblings)
}
fn view(s: &Study, cx: &mut Cx<Study>) -> El {
    cx.reduced_motion(cx.system_reduced_motion());
    let p = paint(s.concept);
    col()
        .key("study")
        .w_full()
        .h_full()
        .fill(p.bg)
        .child(switcher(s, p))
        .child(line(p))
        .child(path(p, s.concept))
        .child(match s.concept {
            Concept::Workbench => workbench(s, p),
            Concept::Gallery => gallery(s, p),
            Concept::Desk => desk(s, p),
        })
        .child(footer(s, p))
}
fn main() {
    let spec = AppSpec {
        min_size: Some((940.0, 680.0)),
        families: ("Inter", "Cascadia Code"),
        fonts: &[
            include_bytes!("assets/Inter-Regular.ttf"),
            include_bytes!("assets/Inter-SemiBold.ttf"),
            include_bytes!("assets/Cantarell.otf"),
            include_bytes!("assets/NotoSerif.ttf"),
            include_bytes!("assets/CascadiaCode.otf"),
        ],
        scenes: &[
            ("workbench", |s| switch(s, Concept::Workbench)),
            ("gallery", |s| switch(s, Concept::Gallery)),
            ("desk", |s| switch(s, Concept::Desk)),
        ],
        on_key: Some(|s: &mut Study, k, tx| {
            match &k.key {
                Key::Text(k) if k == "1" => switch(s, Concept::Workbench),
                Key::Text(k) if k == "2" => switch(s, Concept::Gallery),
                Key::Text(k) if k == "3" => switch(s, Concept::Desk),
                Key::Text(k) if k == "j" => s.cursor = (s.cursor + 1).min(ENTRIES.len() - 1),
                Key::Text(k) if k == "k" => s.cursor = s.cursor.saturating_sub(1),
                Key::Down => s.cursor = (s.cursor + 1).min(ENTRIES.len() - 1),
                Key::Up => s.cursor = s.cursor.saturating_sub(1),
                Key::Text(k) if k == " " => {
                    if !s.selected.insert(s.cursor) {
                        s.selected.remove(&s.cursor);
                    }
                }
                Key::Enter => {}
                Key::Text(k) if k == "J" => tx.scroll_page("document-scroll", 1),
                Key::Text(k) if k == "K" => tx.scroll_page("document-scroll", -1),
                Key::Text(k) if k == "q" => tx.quit(),
                _ => return false,
            }
            true
        }),
        ..AppSpec::new("Yazi Rune design concepts", (1440.0, 960.0), init, view)
    };
    App::new(spec).run();
}
