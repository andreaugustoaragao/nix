fn main() {
    let wayland = pkg_config::Config::new()
        .cargo_metadata(false)
        .atleast_version("1.23")
        .probe("wayland-client")
        .expect("Wayland client development libraries");
    let xkb = pkg_config::Config::new()
        .cargo_metadata(false)
        .probe("xkbcommon")
        .expect("xkbcommon development libraries");
    cc::Build::new()
        .opt_level(1)
        .file("src/dnd_wayland.c")
        .includes(&wayland.include_paths)
        .includes(&xkb.include_paths)
        .flag_if_supported("-std=c11")
        .compile("yazi_rune_dnd");
    for path in wayland.link_paths.iter().chain(&xkb.link_paths) {
        println!("cargo:rustc-link-search=native={}", path.display());
    }
    for library in wayland.libs.iter().chain(&xkb.libs) {
        println!("cargo:rustc-link-lib={library}");
    }
    println!("cargo:rerun-if-changed=src/dnd_wayland.c");

    let cairo = pkg_config::Config::new()
        .cargo_metadata(false)
        .probe("cairo")
        .expect("cairo development libraries");
    let pangocairo = pkg_config::Config::new()
        .cargo_metadata(false)
        .probe("pangocairo")
        .expect("pangocairo development libraries");
    let pixbuf = pkg_config::Config::new()
        .cargo_metadata(false)
        .probe("gdk-pixbuf-2.0")
        .expect("gdk-pixbuf development libraries");
    cc::Build::new()
        .opt_level(1)
        .file("src/printing_native.c")
        .includes(&cairo.include_paths)
        .includes(&pangocairo.include_paths)
        .includes(&pixbuf.include_paths)
        .flag_if_supported("-std=c11")
        .compile("yazi_rune_print");
    for path in cairo
        .link_paths
        .iter()
        .chain(&pangocairo.link_paths)
        .chain(&pixbuf.link_paths)
    {
        println!("cargo:rustc-link-search=native={}", path.display());
    }
    for library in cairo
        .libs
        .iter()
        .chain(&pangocairo.libs)
        .chain(&pixbuf.libs)
    {
        println!("cargo:rustc-link-lib={library}");
    }
    println!("cargo:rerun-if-changed=src/printing_native.c");
}
